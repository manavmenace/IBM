package prudential.api;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.TimeZone;
import java.util.logging.Logger;

import org.json.JSONException;
import org.json.JSONObject;


public class GenericClass {
	private static final Logger LOGGER = Logger.getLogger(GenericClass.class.getName());
	DatabaseUtil util=new DatabaseUtil();
		
	public boolean chkIfAccountExists(String AccountNo,Connection connection) throws SQLException{
		if(connection ==null || connection.isClosed() )
		{
			LOGGER.info("Inside chkIfAccountExists connection open : "+connection);
			connection = util.getConnection();
		}
	//	Connection connection = DatabaseUtil.getConnection();
		boolean accountExists = false;
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery("SELECT count(*) FROM Rtl_Account_Master where accountNo ="+ AccountNo);			
			while (rs.next()) {
				accountExists = (rs.getInt(1) == 0) ? false : true;
			}
		try{
			if(statement !=null)
			{   	statement.close(); }
			if(rs != null)
			{		rs.close(); 	}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		//	connection = null;
		//	connection.close();		
		return accountExists;
	}
	
	public String chkIfPayeeExists(String AccountNo, String custId,Connection connection) throws SQLException{
		//Connection connection = DatabaseUtil.getConnection();
		
		if(connection ==null || connection.isClosed() )
		{
			LOGGER.info("Inside chkIfAccountExists connection open : "+connection);
			connection = util.getConnection();
		}
		String payeename = "";
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery("SELECT PAYEENAME FROM Rtl_Payee_Details where payeeaccountno ='"+ AccountNo
					+"' ");		//and c_custId = '"+custId+"'	
			while (rs.next()) {
				payeename = rs.getString("payeename");
			}
			try{
				if(statement !=null)
				{   	statement.close(); }
				if(rs != null)
				{		rs.close(); 	}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}	
		//	connection = null;
			// connection.close();			
		return payeename;
	}
	
	public String getCustId(String AccountNo,Connection connection) throws SQLException{
	//	Connection connection = DatabaseUtil.getConnection();
		
		if(connection ==null || connection.isClosed() )
		{
			LOGGER.info("Inside chkIfAccountExists connection open : "+connection);
			connection = util.getConnection();
		}
		
		String custId = "";		
			Statement statement = connection.createStatement();			
			ResultSet rs = statement.executeQuery("select custId from Rtl_Account_Master where accountNo ='"+ AccountNo+"'");
			while (rs.next()) {
				custId = rs.getString(1);
			}
			try{
				if(statement !=null)
				{   	statement.close(); }
				if(rs != null)
				{		rs.close(); 	}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			//	connection = null;
			//connection.close();			
		return custId;
	}
	
	public double getBalance(String AccountNo,Connection connection) throws SQLException{
	//	Connection connection = DatabaseUtil.getConnection();
		
		if(connection ==null || connection.isClosed() )
		{
			LOGGER.info("Inside chkIfAccountExists connection open : "+connection);
			connection = util.getConnection();
		}
		double balance = 0.0D;	
			Statement statement = connection.createStatement();			
			ResultSet rs = statement.executeQuery("select balance from Rtl_Account_Master where accountNo ='"+ AccountNo+"'");
			while (rs.next()) {
				balance = rs.getDouble(1);
			}
			try{
				if(statement !=null)
				{   	statement.close(); }
				if(rs != null)
				{		rs.close(); 	}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			//	connection = null;
				//connection.close();			
		return balance;
	}
	
	public String addTransactionDtl(String custId, double amount, String status, String transactionDate,
			String fromAccount, String toAccount, String c_accountNo, String credit_debit_flag,Double srcBalance,String type_of_transaction,Connection connection) throws SQLException{
		boolean returnValue=false;
//		Connection connection = DatabaseUtil.getConnection();
	
		if(connection ==null || connection.isClosed() )
		{
			LOGGER.info("Inside chkIfAccountExists connection open : "+connection);
			connection = util.getConnection();
		}
		LOGGER.info("in addTransactionDtl -- srcBalance : "+srcBalance);
		String query="Select max(tranid) from Rtl_Transaction_Details";
		Double cloasingbal;
		if(credit_debit_flag.contains("D"))
				{
			cloasingbal=srcBalance - amount;
				}
		else {
			Double closingdestbal = getBalance(toAccount,connection);
			cloasingbal=closingdestbal + amount;
		}
		Statement st = connection.createStatement();
		ResultSet rs = st.executeQuery(query);
		int maxTranId = 0;
		while(rs.next()){
			maxTranId = rs.getInt(1);
		}
		maxTranId++;
		
			PreparedStatement ps = connection.prepareStatement("insert into Rtl_Transaction_Details("
					+ "custId,amount,status,transactionDate,fromAccount,toAccount,c_accountNo,credit_debit_flag,tranid,Closing_balance,REMARK)"
					+ " values(?,?,?,?,?,?,?,?,?,?,?)");
			ps.setString(1, custId);			
			ps.setDouble(2, amount);
			ps.setString(3, status);
			ps.setString(4, transactionDate);
			ps.setString(5, fromAccount);
			ps.setString(6, toAccount);
			ps.setString(7, c_accountNo);
			ps.setString(8, credit_debit_flag);
			ps.setInt(9, maxTranId);
			ps.setString(10, cloasingbal+"");
			ps.setString(11, type_of_transaction);
			
			returnValue=ps.execute();
			connection.commit();
			
			try{
				if(ps !=null)
				{   	ps.close(); }
				if(st != null)
				{st.close();}
				if(rs != null)
				{		rs.close(); 	}
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			//connection.close();
//			connection = null;
		return maxTranId+"";
	}
	
	public int updateBalance(String accountNo, double amount,Connection connection) throws SQLException{
	//	Connection connection = DatabaseUtil.getConnection();
		if(connection ==null || connection.isClosed() )
		{
			LOGGER.info("Inside chkIfAccountExists connection open : "+connection);
			connection = util.getConnection();
		}
		
		int returnValue=0;		
			PreparedStatement ps = connection.prepareStatement("update Rtl_Account_Master set balance = ? where "
					+ " accountNo = ?");
					
			ps.setDouble(1, amount);
			ps.setString(2, accountNo);			
			
			returnValue=ps.executeUpdate();
			connection.commit();
			try{
				if(ps !=null)
				{   	ps.close(); }
				}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			//connection.close();
//			connection = null;
		return returnValue;	
	}
	
	public String getSQLDate(Date date){
		
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	//	SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		sdf.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
		String SQLFormattedDate = sdf.format(date);
		
		return SQLFormattedDate;
	}
	
	public String getJsonErr(int errCd, String errMsg, String errDesc) throws JSONException{
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("code", errCd);
		jsonObject.put("message", errMsg);
		jsonObject.put("description", errDesc);
		return jsonObject.toString();
	}
}
