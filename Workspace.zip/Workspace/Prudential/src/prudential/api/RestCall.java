package prudential.api;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import java.util.logging.Logger;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;




@Path("/icici")
public class RestCall
	{
		private static final Logger LOGGER = Logger.getLogger(RestCall.class.getName());
		DatabaseUtil util = new DatabaseUtil();
		JSONObject returnMessage;
		JSONObject successObj;


		public RestCall() throws JSONException
			{
				successObj = new JSONObject();
				successObj.put("code", 200);
			}


		@GET
		@Path("/quickquotes")
		@Produces
		public String getMFDetails(@QueryParam("client_id")
		String client_id, @QueryParam("token")
		String token, @QueryParam("name")
		String name, @QueryParam("dob")
		String dob, @QueryParam("gender")
		String gender, @QueryParam("marital_status")
		String marital_status,  @QueryParam("mode_of_payment")
		String mode_of_payment, @QueryParam("tobacco")
		String tobacco,@QueryParam("term")
		String term) throws JSONException
			{
				// quickquotes?name=Rahuk&dob=2016-02-01&gender=male&marital_status=single&term=y&mode_of_payment=linked&tobacco=Smaoker
				CommonMethod commonmethod = new CommonMethod();
				JSONObject errjobj = new JSONObject();
				JSONArray jarray = new JSONArray();
				Connection connection = null;
				//int count = 0;
				boolean flag = false;
				LOGGER.info("Inside getQuickQuote ");
				LOGGER.info("client_id : " + client_id);
				LOGGER.info("token : " + token);
				try
					{
						if (connection == null || connection.isClosed())
							{
								LOGGER.info("Inside connection open : " + connection);
								connection = util.getConnection();
							}
						flag = validateClient(client_id, token, "P_quickquotes", connection);
						if (flag)
							{	
							if (name.length()>1 && name.length()<15)
								{
								boolean result1 = validateBdate(dob);
								if(result1)
									{
									if (gender.equalsIgnoreCase("Male") || gender.equalsIgnoreCase("female"))
										{
										if (marital_status.equalsIgnoreCase("MARRIED") || marital_status.equalsIgnoreCase("Unmarried"))
											{
											if (mode_of_payment.equalsIgnoreCase("online")||mode_of_payment.equalsIgnoreCase("offline"))
												{
												if (tobacco.equalsIgnoreCase("yes") || tobacco.equalsIgnoreCase("no"))
													{
														// y m q hy
									
														jarray.put(successObj);
														if (term.trim().equalsIgnoreCase("y"))
															{
																errjobj.put("annual_premium", 12000);
															}
													else if (term.trim().equalsIgnoreCase("h"))
															{
																errjobj.put("annual_premium", 6000);
															}
													else if (term.trim().equalsIgnoreCase("q"))
															{
																errjobj.put("annual_premium", 4000);
															}
													else if (term.trim().equalsIgnoreCase("m"))
															{
															errjobj.put("annual_premium", 1000);
															}
													else
															{
															errjobj = commonmethod.getJsonStatus(400, "Invalid Parameter", "Invalid Term value");
															}
														jarray.put(errjobj);
														}else
														{
															errjobj = commonmethod.getJsonStatus(400, "invalid parameter tobacco", "Should be Yes or No");
															jarray.put(errjobj);
														}
													}
													else 
														{	errjobj = commonmethod.getJsonStatus(400, "invalid parameter Mode of Payment", "Should be Online OR Offline");
															jarray.put(errjobj);
														}
													}
												else {
														errjobj = commonmethod.getJsonStatus(400, "invalid parameter marital state", "Should be Married OR Unmarried");
														jarray.put(errjobj);
													}
												}
											else {	
													errjobj = commonmethod.getJsonStatus(400, "invalid parameter gender", "Should be Male or female ");
													jarray.put(errjobj);
												}
											}
										else
											{
												errjobj = commonmethod.getJsonStatus(400, "Bad request. Invalid Request parameter", "Date of Birth should be in dd-MM-YYYY format and should be less than current date");
												jarray.put(errjobj);
											}
										}
									else {
										errjobj = commonmethod.getJsonStatus(400, "invalid parameter name", "Should be not be null and Should not be more than 35 Char");
										jarray.put(errjobj);
								     }
									}
								else
									{
								// authoriztion failed
								LOGGER.info("Inside getQuickQuotes --> ");
								errjobj = commonmethod.getJsonStatus(401, "User Not Authorized", "Access Denied");
								jarray.put(errjobj);
									}
								}
				catch (Exception e)
					{
						e.printStackTrace();
						errjobj = commonmethod.getJsonStatus(402, "Error in processing", "Error while processing request. Please check request parameters in API Manual");
						jarray.put(errjobj);
					}
				finally
					{
						try
							{
								if (connection != null)
									{
										connection.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				return jarray.toString();
			}


		// purchasepolicy?name=Rahuk&dob=2016-02-01&gender=male&marital_status=single&term=y&nationality=Indian&mobileno=8097704006&nominee_name=Amar
		@GET
		@Path("/purchasepolicy")
		@Produces
		public String getPurchasePolicy(@QueryParam("client_id")
		String client_id, @QueryParam("token")
		String token, @QueryParam("cust_id")
		String cust_id, @QueryParam("name")
		String name, @QueryParam("dob")
		String dob, @QueryParam("age")
		String age, @QueryParam("gender")
		String gender, @QueryParam("marital_status")
		String marital_status, @QueryParam("nationality")
		String nationality, @QueryParam("mobileno")
		String mobileno, @QueryParam("address")
		String address, @QueryParam("segment")
		String segment, @QueryParam("nominee_name")
		String nominee_name, @QueryParam("tobacco")
		String tobacco) throws JSONException
			{
				// age ,gender,mari_status,putress,tobbaco
				LOGGER.info("####---------- Puechase Policy ---------####");
				CommonMethod commonmethod = new CommonMethod();
				JSONObject errjobj = new JSONObject();
				String result = "";
				Connection connection = null;
				JSONArray jarray = new JSONArray();
				int count = 0;
				boolean flag = false;
				boolean accflag = false;
				LOGGER.info("Inside purchasepolicy ");
				try
					{
						if (connection == null || connection.isClosed())
							{
								LOGGER.info("Inside connection open : " + connection);
								connection = util.getConnection();
							}
						flag = validateClient(client_id, token, "P_purchasepolicy", connection);
						if (flag)
							{
								if (validateCustid(cust_id))
									{
										accflag = authenticateCustidOnly("A", cust_id, client_id, connection);
										if (accflag)
											{
							if (name.length()>1 && name.length()<35)
								{
									boolean result1 = validateBdate(dob);
							
								if (result1)
									{
										if (age.length() >= 1 && age.length() <= 3)
											{
												if (gender.equalsIgnoreCase("Male") || gender.equalsIgnoreCase("female"))
													{
														if (marital_status.equalsIgnoreCase("MARRIED") || marital_status.equalsIgnoreCase("Unmarried"))
															{
															if(nationality.length()>1 && nationality.length()<15)
																{
																if (mobileno.length()==10)
																	{
																	if (address.length() > 1 && address.length() < 100)
																		{
																		if (segment.equalsIgnoreCase("NRI") || segment.equalsIgnoreCase("Corporate") || segment.equalsIgnoreCase("Urban") || segment.equalsIgnoreCase("Regular"))
																			{
																			if (nominee_name.length()>1 && nominee_name.length()<35)
																				{
																				if (tobacco.equalsIgnoreCase("yes") || tobacco.equalsIgnoreCase("no"))
																					{
																						result = purchasepolicy(cust_id, name, dob, age, gender, marital_status, address, nationality, segment, mobileno, tobacco, nominee_name, connection);
																						jarray.put(successObj);
																						errjobj.put("annual_premium", 12000);
																						jarray.put(result);
																					}
																				else
																					{
																						errjobj = commonmethod.getJsonStatus(400, "invalid parameter tobacco", "Should be Yes or No");
																						jarray.put(errjobj);
																					}
																					}
																			else 
																					{
																						errjobj = commonmethod.getJsonStatus(400, "invalid parameter nominee_name", "Should be not be null and Should not be more than 35 Char");
																						jarray.put(errjobj);
																					
																					}
																			}
																		else
																			{
																				errjobj = commonmethod.getJsonStatus(400, "invalid parameter segment", "Should be NRI or Corporate or Urban or Regular");
																				jarray.put(errjobj);
																			}
																		}
																else
																	{
																		errjobj = commonmethod.getJsonStatus(400, "invalid parameter address", "Should not be null and Should not be more than 100 Char");
																		jarray.put(errjobj);
																	}
															}
															else
															{
																errjobj = commonmethod.getJsonStatus(400,"invalid parameter mobile no", "Should be 10 digit");
															}
															}
														else
														{
															errjobj = commonmethod.getJsonStatus(400, "invalid parameter nationality", "Should be not be null and Should not be more than 15 Char");
															jarray.put(errjobj);
															
														}
														}
													else
														{
															errjobj = commonmethod.getJsonStatus(400, "invalid parameter marital state", "Should be Married OR Unmarried");
															jarray.put(errjobj);
														
														}
													}
												else
													{
														errjobj = commonmethod.getJsonStatus(400, "invalid parameter gender", "Should be Male or female ");
														jarray.put(errjobj);
													}
											}
										else
											{
												errjobj = commonmethod.getJsonStatus(400, "invalid parameter age ", "can not be null and valide upto 3 digit ");
												jarray.put(errjobj);
											}
									}
								else
									{
										errjobj = commonmethod.getJsonStatus(400, "Bad request. Invalid Request parameter", "Date of Birth should be in dd-MM-YYYY format and should be less than current date");
										jarray.put(errjobj);
									}
								}else
									{
										errjobj = commonmethod.getJsonStatus(400, "invalid parameter name", "Should be not be null and Should not be more than 35 Char");
										jarray.put(errjobj);
										
									}
											}
										else
											{
												errjobj = commonmethod.getJsonStatus(401, "User Not Authorized", "This Customer ID does not belongs to participant");
												jarray.put(errjobj);
												//LOGGER.info(returnMessage.toString() + " -- " + accountno);
											}
									}
								else
									{
										errjobj = commonmethod.getJsonStatus(400, "Bad request. Request parameter are not provided.", "Customer ID should be 8 Digits & can contain only Numbers");
										jarray.put(errjobj);
									}
										
							}
						else
							{
								// authoriztion failed
								LOGGER.info("Inside purchasepolicy --> ");
								errjobj = commonmethod.getJsonStatus(401, "User Not Authorized", "Access Denied");
								jarray.put(errjobj);
							}
					}
				catch (Exception e)
					{
						e.printStackTrace();
						errjobj = commonmethod.getJsonStatus(402, "Error in processing", "Error while processing request. Please check request parameters in API Manual");
						jarray.put(errjobj);
					}
				finally
					{
						try
							{
								if (connection != null)
									{
										connection.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				LOGGER.info("####---------- Puechase Policy End---------####");
				return jarray.toString();
			}


		public boolean validateBdate(String dob)
			{
				CommonMethod commonmethod = new CommonMethod();
				JSONObject errjobj = new JSONObject();
				JSONArray jarray = new JSONArray();
				/*
				 * Date date = null;
				 * 
				 * try { SimpleDateFormat sdf = new
				 * SimpleDateFormat("dd-MM-yyyy"); date = sdf.parse(dob);
				 * 
				 * if (!dob.equals(sdf.format(date))) {
				 * 
				 * errjobj =commonmethod.getJsonStatus(400,
				 * "Request parameter are not valid.", "Expiry Date  is invalid"
				 * ); jarray.put(errjobj); return false; } } catch
				 * (ParseException ex) { errjobj
				 * =commonmethod.getJsonStatus(400,
				 * "Request parameter are not valid.",
				 * "Date format is not Valid "); jarray.put(errjobj);
				 * ex.printStackTrace(); return false;
				 * 
				 * } return true;dd-mm-yyyy
				 */
				if (dob != null && !dob.isEmpty() && dob.length() == 10 && dob.charAt(2) == '-' && dob.charAt(5) == '-')
					{
						String sDat = dob.split("-")[0];
						String sMnth = dob.split("-")[1];
						String sYr = dob.split("-")[2];
						if (sMnth.matches("[0-9]+") && sYr.matches("[0-9]+"))
							{	int date =Integer.parseInt(sDat);
								int mnth = Integer.parseInt(sMnth);
								int  yr = Integer.parseInt(sYr);
								Calendar c = Calendar.getInstance();
								int currMnth = c.get(Calendar.MONTH) + 1;
								int currYr = c.get(Calendar.YEAR);
								int currDate = c.get(Calendar.DATE);
								if ((yr == currYr && mnth <=currMnth && mnth < 13 && date < 32) || (yr < currYr && mnth >= 1 && mnth < 13 && date < 32))
									{
										return true;
									}
								else
									{
										LOGGER.info("Invalid birth Date!" + mnth + " " + yr);
										/*errjobj = commonmethod.getJsonStatus(400, "Bad request. Invalid Request parameter", " Date of Birth should be in dd-MM-YYYY format and should be less than current date");
										jarray.put(errjobj);*/
										return false;
									}
							}
						else
							{
								LOGGER.info("Invalid birth Date!");
								/*errjobj = commonmethod.getJsonStatus(400, "Bad request. Invalid Request parameter", "Date of Birth should be in dd-MM-YYYY format and should be less than current date");
								jarray.put(errjobj);*/
								return false;
							}
					}
				else
					{
						LOGGER.info("Invalid birth Date!!");
						/*errjobj = commonmethod.getJsonStatus(400, "Bad request. Invalid Request parameter", "Date of Birth should be in dd-MM-YYYY format and should be less than current date");
						jarray.put(errjobj);*/
						return false;
					}
			}


		@GET
		@Path("/viewpolicydetails")
		@Produces
		public String viewCurrencyPairs(@QueryParam("client_id")
		String client_id, @QueryParam("token")
		String token, @QueryParam("custid")
		String custid) throws JSONException
			{
				String returnValue = "";
				JSONObject jobj = new JSONObject();
				Connection connection = null;
				CommonMethod dao = new CommonMethod();
				boolean accflag = false;
				// SecuritirsDAO dao = new SecuritirsDAO();
				try
					{
						LOGGER.info(" -------- View Policy Details --------");
						LOGGER.info("Client ID :" + client_id);
						LOGGER.info("Token :" + token);
						LOGGER.info("cust_id :" + custid);
						if (client_id.equals("") || token.equals("") || custid.equals("") || custid == null)
							{
								returnValue = dao.getJsonStatus1(400, "Bad request.", "Please enter all required values.");
							}
						else
							{
								if (connection == null || connection.isClosed())
									{
										LOGGER.info("Inside connection open : " + connection);
										connection = util.getConnection();
									}
								boolean isClientValidated = validateClient(client_id, token, "P_viewpolicydetails", connection);
								if (isClientValidated)
									{
										if (validateCustid(custid))
											{
												accflag = authenticateCustidOnly("A", custid, client_id, connection);
												if (accflag)
													{
										JSONArray jsonArray = getPolicyDetails(custid, connection);
										if (jsonArray.toString().length() > 50)
											{
												returnValue = jsonArray.toString();
											}
										else
											{
												returnValue = dao.getJsonStatus1(402, "No records available.", "No data Found");
											}
													}
												else
													{
														returnValue = dao.getJsonStatus1(401, "User Not Authorized", "This Customer ID does not belongs to participant");
														
														//LOGGER.info(returnMessage.toString() + " -- " + accountno);
													}
											}
										else
											{
												returnValue = dao.getJsonStatus1(400, "Bad request. Request parameter are not provided.", "Customer ID should be 8 Digits & can contain only Numbers");
												
											}
									}
								else
									{
										LOGGER.info("User Not Authorized");
										returnValue = dao.getJsonStatus1(401, "User Not Authorized", "Access Denied");
									}
							}
					}
				catch (SQLException e)
					{
						LOGGER.info(e.getMessage());
						returnValue = dao.getJsonStatus1(501, "Database connectivity issue or Timeouts.", "Database Error. Please try after some time.");
					}
				catch (Exception e)
					{
						LOGGER.info(e.getMessage());
						returnValue = dao.getJsonStatus1(402, "Error in processing.", "Error while processing request. Please check request parameters in API Manual");
					}
				finally
					{
						try
							{
								if (connection != null)
									{
										connection.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				return returnValue;
			}


		// Veiw customer details
		//Veiw customer details 
		
		@GET
		@Path("/viewcustomerdetails")
		@Produces
		public String viewCustomerDetails(@QueryParam("client_id") String client_id,
				@QueryParam("token") String token,
				@QueryParam("custid") String custid,
				@QueryParam("policyno") String policyno) throws JSONException {
			String returnValue = "";
			JSONObject jobj = new JSONObject();
			Connection connection = null;
			CommonMethod dao = new CommonMethod();
			boolean accflag = false;
			
			// SecuritirsDAO dao = new SecuritirsDAO();

			try {
				System.out.println(" -------- View Policy Details --------");
				System.out.println("Client ID :"+client_id);
				System.out.println("Token :"+token);
				System.out.println("cust_id :"+custid);
				if (client_id.equals("") || token.equals("") || custid.equals("") || custid==null) {
					returnValue = dao.getJsonStatus1(400, "Bad request.",
							"Please enter all required values.");
				} else {
					if(connection ==null || connection.isClosed() )
					{
						System.out.println("Inside connection open : "+connection);
						connection = util.getConnection();
					}
					boolean isClientValidated = validateClient(client_id, token,"P_viewcustomerdetails",connection);
					
					if (isClientValidated) {
						
						if (validateCustid(custid))
							{
								accflag = authenticateCustidOnly("A", custid, client_id, connection);
								if (accflag)
									{
						
							if (policyno.length()==6)
						{
				

						JSONArray jsonArray = getCustomerDetails(custid,policyno,connection);
						System.out.println("jsonArray.toString().length()....." + jsonArray.toString().length());
						if (jsonArray.toString().length() > 50) {
							System.out.println("Inside if::length is more than 50");
							returnValue = jsonArray.toString();
						} else {
							System.out.println("Inside else::length is less than 50");
							returnValue = dao
									.getJsonStatus1(402, "No records available.",
											"No data Found");
						}
						}
						else
						{
							returnValue = dao.getJsonStatus1(400,"invalide parameter policy number", "Invalide Policy Number");
							//jarray.put(errjobj);
						}
									}
								else
									{
										returnValue = dao.getJsonStatus1(401, "User Not Authorized", "This Customer ID does not belongs to participant");
										
										//LOGGER.info(returnMessage.toString() + " -- " + accountno);
									}
							}
						else
							{
								returnValue = dao.getJsonStatus1(400, "Bad request. Request parameter are not provided.", "Customer ID should be 8 Digits & can contain only Numbers");
								
							}
					}
						
					 else {
						LOGGER.info("User Not Authorized");
						returnValue = dao.getJsonStatus1(401,
								"User Not Authorized", "Access Denied");
					}
				
				}
			} catch (SQLException e) {
				LOGGER.info(e.getMessage());
				returnValue = dao.getJsonStatus1(501,
						"Database connectivity issue or Timeouts.",
						"Database Error. Please try after some time.");
			} catch (Exception e) {
				LOGGER.info(e.getMessage());
				returnValue = dao.getJsonStatus1(402, "Error in processing.",
						"Error while processing request. Please check request parameters in API Manual");
			}
			finally
			{
				try {
					if(connection != null)
					{connection.close();}
				}
				catch(Exception e)
				{e.printStackTrace();}
			}

			return returnValue;
		}

		public JSONArray getCustomerDetails(String custid, String policyno,Connection connection) throws SQLException, JSONException {
			JSONArray jsonArray = new JSONArray();
			JSONObject gobj = new JSONObject();
			JSONObject jsonObject = new JSONObject();
			Statement statement = null;
			ResultSet resultSet = null;
			//connection =null;
			gobj.put("code", 200);
			System.out.println("in getcutomerdetails");
//			Connection connection = DatabaseUtil.getConnection();
			if(connection ==null || connection.isClosed() )
			{
				System.out.println("Inside connection open : "+connection);
				connection = util.getConnection();
			}

			statement = connection.createStatement();// CUST_ID: 11111111
			String queryString = "select GENDER,AGE,MARITAL_STATUS,address,Segment,risk_profile,premium_paid from Prudential_Purchase_policy where cust_id ='"+custid+"' and POLICY_NO='"+policyno+"'";
			System.out.println("query"+ queryString);
			resultSet = statement.executeQuery(queryString);
			System.out.println("after execution");
			
			jsonArray.put(gobj);
			System.out.println("inside gobj");
			if (resultSet.next()) {
				
				//System.out.println("resultSet.getString(custid) : "+ resultSet.getString("cust_id"));
				//System.out.println("resultSet.getString(policy_no) : "+ resultSet.getString("policy_no"));
				System.out.println(".....Inside while.....");
				//JSONObject jsonObject = new JSONObject();
			
				jsonObject.put("Gender", resultSet.getString("GENDER"));
				jsonObject.put("Age", resultSet.getString("AGE"));
				jsonObject.put("MARITAL STATUS", resultSet.getString("MARITAL_STATUS"));
				jsonObject.put("address",resultSet.getString("address"));
				jsonObject.put("Segment", resultSet.getString("Segment"));
				jsonObject.put("Risk Profile", resultSet.getString("risk_profile"));
				jsonObject.put("Premium Paid", resultSet.getString("premium_paid"));

				jsonArray.put(jsonObject);
			}
			
			//System.out.println("jsonArray:::" + jsonArray.toString());
			
			try{
			if(statement != null)
			{statement.close();}
			if(resultSet != null)
			{resultSet.close();}
			}
			catch(Exception e){
				e.printStackTrace();
			}
			
			return jsonArray;
		}


		public JSONArray getPolicyDetails(String custid, Connection connection) throws SQLException, JSONException
			{
				JSONArray jsonArray = new JSONArray();
				JSONObject gobj = new JSONObject();
				Statement statement = null;
				ResultSet resultSet = null;
				gobj.put("code", 200);
				LOGGER.info("in getpolicydetails");
				// Connection connection = DatabaseUtil.getConnection();
				if (connection == null || connection.isClosed())
					{
						LOGGER.info("Inside connection open : " + connection);
						connection = util.getConnection();
					}
				statement = connection.createStatement();// CUST_ID: 11111111
				String queryString = "select cust_id,policy_no,AmtDue,PaidtoDate,PolicyName,PremiumAmt,InstallmentsDue,ULIP_POLICY,POLICYSTATUS," + "Sum_Assured,NAV_DATE,FUND_CODE,FUND_NAME,FUND_UNITS,FUND_VALUE,mode_of_payment,FUND_NAV from Prudential_Purchase_policy where cust_id = '" + custid + "'";
				resultSet = statement.executeQuery(queryString);
				// String curr_pair = "", rate_for_buy = "", rate_for_sell = "",
				// deal_type = "";
				jsonArray.put(gobj);
				while (resultSet.next())
					{
						/*
						 * curr_pair = resultSet.getString("curr_pair");
						 * rate_for_buy = resultSet.getString("rate_for_buy");
						 * rate_for_sell = resultSet.getString("rate_for_sell");
						 * deal_type = resultSet.getString("deal_type");
						 */
						LOGGER.info("resultSet.getString(custid) : " + resultSet.getString("cust_id"));
						LOGGER.info("resultSet.getString(policy_no) : " + resultSet.getString("policy_no"));
						JSONObject jsonObject = new JSONObject();
						jsonObject.put("cust_id", resultSet.getString("cust_id"));
						jsonObject.put("policy_no", resultSet.getString("policy_no"));
						jsonObject.put("amtdue", resultSet.getString("AmtDue"));
						jsonObject.put("PremiumAmt", resultSet.getString("premiumamt"));
						jsonObject.put("installmentsdue", resultSet.getString("InstallmentsDue"));
						jsonObject.put("ulip_policy", resultSet.getString("ULIP_POLICY"));
						jsonObject.put("policy_status", resultSet.getString("POLICYSTATUS"));
						jsonObject.put("sum_assured", resultSet.getString("Sum_Assured") );
						jsonObject.put("nav_date", resultSet.getString("NAV_DATE"));
						LOGGER.info("Near If");
						if (resultSet.getString("FUND_CODE") != null)
							{
								jsonObject.put("fund_code", resultSet.getString("FUND_CODE"));
							}
						else
							{
								jsonObject.put("fund_code", "");
							}
						if (resultSet.getString("FUND_NAME") != null)
							{
								jsonObject.put("fund_name", resultSet.getString("FUND_NAME"));
							}
						else
							{
								jsonObject.put("fund_name", "");
							}
						jsonObject.put("fund_unit", resultSet.getString("FUND_UNITS") );
						jsonObject.put("fund_value", resultSet.getString("FUND_VALUE") );
						jsonObject.put("mode_of_payment", resultSet.getString("mode_of_payment"));
						if (resultSet.getString("FUND_NAV") != null)
							{
								jsonObject.put("fund_nav", resultSet.getString("FUND_NAV"));
							}
						else
							{
								jsonObject.put("fund_nav", "");
							}
						// jsonObject.put("goal_id",
						// resultSet.getString("goal_id"));
						jsonArray.put(jsonObject);
					}
				try
					{
						if (statement != null)
							{
								statement.close();
							}
						if (resultSet != null)
							{
								resultSet.close();
							}
					}
				catch (Exception e)
					{
						e.printStackTrace();
					}
				return jsonArray;
			}


		public String purchasepolicy(String cust_id, String name, String dob, String age, String gender, String marital_status, String address, String nationality, String segment, String mobileno, String tobacco, String nominee_name, Connection connection)
			{
				Statement statement = null;
				ResultSet rs = null;
				Date date = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				sdf.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
				String sysdate = sdf.format(date);
				// String trandtl=getTransactionDtl();
				try
					{
						if (connection == null || connection.isClosed())
							{
								LOGGER.info("Inside connection open : " + connection);
								connection = util.getConnection();
							}
						String accountno = getAccountNo(cust_id, connection);
						if (accountno.equals(""))
							{
								CommonMethod commonmethod = new CommonMethod();
								JSONObject errjobj = new JSONObject();
								errjobj = commonmethod.getJsonStatus(401, "Customer ID doesnot Exists", "Invalid Data");
								return errjobj.toString();
							}
						else
							{
								String query = "Select max(policy_no) from Prudential_Purchase_policy";
								if (connection == null || connection.isClosed())
									{
										LOGGER.info("Inside connection open : " + connection);
										connection = util.getConnection();
									}
								// Connection connection =
								// DatabaseUtil.getConnection();
								statement = connection.createStatement();
								rs = statement.executeQuery(query);
								int policyno = 0;
								while (rs.next())
									{
										policyno = rs.getInt(1);
									}
								policyno++;
								LOGGER.info("Max policy no : " + policyno);
								JSONObject gobj = new JSONObject();
								JSONArray jarray = new JSONArray();
								gobj.put("code", 200);
								jarray.put(gobj);
								Boolean insertflag = statement
										.execute("insert into Prudential_Purchase_policy (POLICY_NO,CUST_ID,NAME,GENDER,DOB,AGE,MARITAL_STATUS,address,NATIONALITY,Segment,risk_profile,MOBILE_NO,N_NAME,AMTDUE,PAIDTODATE,POLICYNAME,PREMIUMAMT,INSTALLMENTSDUE,ULIP_POLICY,POLICYSTATUS,SUM_ASSURED,NAV_DATE,FUND_CODE,FUND_NAME,FUND_UNITS,FUND_VALUE,MODE_OF_PAYMENT,FUND_NAV,premium_paid) values" + "('"
												+ policyno + "','" + cust_id + "','" + name + "','" + gender + "','" + dob + "','" + age + "','" + marital_status + "','" + address + "','" + nationality + "','" + segment + "', '" + tobacco + "','" + mobileno + "','" + nominee_name
												+ "','50000','2017-02-01','ICICI_Policy','1000','10000','Link','IF','100000','2016-01-01','IC20523','ICICIPruMF',1000,1000,'Linked_Account','46.23','1')");
								/*
								 * "insert into Prudential_Purchase_policy (cust_id,name,gender,dob,marital_status,nationality,mobile_no,n_name,AmtDue,PaidtoDate,PolicyName,PremiumAmt,InstallmentsDue,ULIP_POLICY,POLICYSTATUS,Sum_Assured,NAV_DATE,FUND_CODE,FUND_NAME,FUND_UNITS,FUND_VALUE,mode_of_payment,FUND_NAV,goal_id) values "
								 * + "('" + cust_id + "','"+ name + "','" +
								 * gender+ "','" + dob+ "','"+ marital_status+
								 * "','" + nationality+ "','"+ mobileno + "','"
								 * + nominee_name +
								 * "','50000','2016-02-01','ICICI_Policy','1000','10000','Link','IF','100000','2016-01-01','','',1000,1000,'Linked_Account','','goalid')"
								 * );
								 */
								JSONObject jsonObject = new JSONObject();
								jsonObject.put("message", "SUCCESS");
								jsonObject.put("date_of_transaction", sysdate);
								jsonObject.put("policy_no", policyno);
								String tranStatus = fundTransfer(accountno, connection);
								LOGGER.info("Prudential tranStatus" + tranStatus);
								if (tranStatus.contains("Insufficient"))
									{
										LOGGER.info("Prudential insuffienct if");
										connection.rollback();
										return tranStatus;
									}
								else
									if (tranStatus.contains("SUCCESS"))
										{
											LOGGER.info("Prudential success if");
											connection.commit();
											return jsonObject.toString();
										}
									else
										{
											LOGGER.info("Prudential error if");
											connection.rollback();
											return tranStatus;
										}
							}
					}
				catch (Exception e)
					{
						e.printStackTrace();
					}
				finally
					{
						try
							{
								if (statement != null)
									{
										statement.close();
									}
								if (rs != null)
									{
										rs.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				return null;
			}


		public String fundTransfer(String accountno, Connection connection) throws JSONException
			{
				LOGGER.info("---------- Fund Transfer -----------" + accountno);
				String email = "test@abc.com";
				String token = "f5316a5e35a4";
				String srcAccount = accountno;
				String destAccount = "5555666677770002";
				String amt = "5000";
				String payeeDesc = "icici";
				String payeeId = "1";
				String type_of_transaction = "purchase product";
				GenericClass genericClass = new GenericClass();
				String returnMessage = "";
				JSONArray jarr = new JSONArray();
				ArrayList<String> type_tran = new ArrayList<String>();
				// jarr.put(gobj);
				LOGGER.info("Validation Details " + email + " userid is " + token);
				type_tran.add("pmr");
				type_tran.add("dth");
				type_tran.add("school fee payment");
				type_tran.add("Movie Ticket");
				type_tran.add("electricity");
				type_tran.add("restaurant ticket");
				type_tran.add("Fuel");
				type_tran.add("groceries");
				type_tran.add("home loan emi");
				type_tran.add("insurance payment");
				type_tran.add("car insurance");
				type_tran.add("mf payments");
				type_tran.add("purchase product");
				Boolean flag = true;
				if (flag)
					{
						try
							{
								if (connection == null || connection.isClosed())
									{
										LOGGER.info("Inside connection open : " + connection);
										connection = util.getConnection();
									}
								if (srcAccount.equals("") || destAccount.equals("") || amt.equals("") || payeeDesc.equals("") || payeeId.equals("") || type_of_transaction.equals(""))
									{
										returnMessage = genericClass.getJsonErr(400, "Bad request.", "Please enter all required values.");
									}
								else
									if (Double.parseDouble(amt) <= 0)
										{
											returnMessage = genericClass.getJsonErr(400, "Bad request.", "Invalid Amount.");
										}
									else
										if (!type_tran.contains(type_of_transaction.toLowerCase()))
											{
												returnMessage = genericClass.getJsonErr(400, "Bad request.", "Type of Transaction should be from list");
											}
										else
											{
												// Validate if source account
												// exists
												boolean srcAccountExists = genericClass.chkIfAccountExists(srcAccount, connection);
												if (srcAccountExists)
													{
														// Validate if Payee is
														// listed in Payee list
														// based on
														// Customer ID.
														String srcCustId = genericClass.getCustId(srcAccount, connection);
														String payeenamedb = genericClass.chkIfPayeeExists(destAccount, srcCustId, connection);
														if (!payeenamedb.equalsIgnoreCase(""))
															{
																// Check if
																// enough
																// balance is
																// available in
																// source
																// account to
																// transfer.
																double srcBalance = genericClass.getBalance(srcAccount, connection);
																boolean balanceAvailable = (srcBalance < Double.parseDouble(amt)) ? false : true;
																if (balanceAvailable)
																	{
																		// Fetch
																		// details
																		// to
																		// enter
																		// in
																		// Transaction
																		// &
																		// Account
																		// details
																		// table.
																		String destCustId = genericClass.getCustId(destAccount, connection);
																		Date todaysDate = new Date();
																		String todaysDate_SQLFormatted = genericClass.getSQLDate(todaysDate);
																		LOGGER.info("---------- todaysDate_SQLFormatted -------" + todaysDate_SQLFormatted);
																		// Make
																		// Transaction
																		// entries
																		// Source
																		// transaction
																		// entry
																		String tranid = genericClass.addTransactionDtl(srcCustId, Double.parseDouble(amt), "0", todaysDate_SQLFormatted, srcAccount, destAccount, srcAccount, "Dr.", srcBalance, type_of_transaction, connection);
																		String destAccTran_ReturnVal = genericClass.addTransactionDtl(destCustId, Double.parseDouble(amt), "0", todaysDate_SQLFormatted, srcAccount, destAccount, destAccount, "Cr.", srcBalance, type_of_transaction, connection);
																		// Make
																		// Account
																		// Balance
																		// Updates
																		double newSrcBalance = srcBalance - Double.parseDouble(amt);
																		int srcBalanceUpdateResult = genericClass.updateBalance(srcAccount, newSrcBalance, connection);
																		double destBalance = genericClass.getBalance(destAccount, connection);
																		double newDestBalance = destBalance + Double.parseDouble(amt);
																		int destBalanceUpdateResult = genericClass.updateBalance(destAccount, newDestBalance, connection);
																		LOGGER.info("tranid: " + tranid + " destAccTran_ReturnVal: " + destAccTran_ReturnVal + " srcBalanceUpdateResult: " + srcBalanceUpdateResult + " destBalanceUpdateResult: " + destBalanceUpdateResult);
																		JSONObject js = new JSONObject();
																		js.put("transaction_amount", amt + ".00");
																		js.put("status", "SUCCESS");
																		js.put("destination_accountno", destAccount);
																		js.put("payee_name", payeenamedb);
																		js.put("payee_id", "1");
																		js.put("transaction_date", todaysDate_SQLFormatted);
																		js.put("referance_no", tranid);
																		jarr.put(js);
																		returnMessage = jarr.toString();
																	}
																else
																	{
																		returnMessage = genericClass.getJsonErr(402, "Error in processing.", "Insufficient Balance");
																	}
															}
														else
															{
																returnMessage = genericClass.getJsonErr(402, "Error in processing.", "Destination Account doesn't exist.");
															}
													}
												else
													{
														returnMessage = genericClass.getJsonErr(402, "Error in processing.", "Source account doesn't exist.");
													}
											}
							}
						catch (SQLException e)
							{
								returnMessage = genericClass.getJsonErr(402, "Error in processing.", "Fund Transfer failed.");
								e.printStackTrace();
								LOGGER.info(e.getMessage());
							}
						catch (Exception e)
							{
								returnMessage = genericClass.getJsonErr(402, "Error in processing.", "Error while processing request. Please check request parameters in API Manual");
								e.printStackTrace();
								LOGGER.info(e.getMessage());
							}
					}
				else
					{
						LOGGER.info("Token Verification Failed.");
						returnMessage = genericClass.getJsonErr(401, "User Not Authorized", "Access Denied");
					}
				LOGGER.info("returnMessage: " + returnMessage);
				return returnMessage;
			}


		public String getAccountNo(String cust_id, Connection connection) throws SQLException
			{
				LOGGER.info("-------------Get Account No--------------Cust id : " + cust_id);
				// Connection connection = DatabaseUtil.getConnection();
				if (connection == null || connection.isClosed())
					{
						LOGGER.info("Inside connection open : " + connection);
						connection = util.getConnection();
					}
				String accountNo = "";
				Statement statement = connection.createStatement();
				ResultSet rs = statement.executeQuery("select accountNo from Rtl_Account_Master where custId ='" + cust_id + "'");
				while (rs.next())
					{
						accountNo = rs.getString("accountNo");
					}
				connection = null;
				LOGGER.info("---Cust id : " + cust_id + " Account no" + accountNo);
				try
					{
						if (statement != null)
							{
								statement.close();
							}
						if (rs != null)
							{
								rs.close();
							}
					}
				catch (Exception e)
					{
						e.printStackTrace();
					}
				return accountNo;
			}


		
		public Boolean authenticateCustidOnly(String flag, String custid, String client_id, Connection connection)
			{
				LOGGER.info("------------ authenticateCustidOnly --------------Account No : " + custid);
				LOGGER.info("/*/*" + "Select CUSTID from PARTICIPANT_MASTER  where LOWER(CLIENT_ID)=" + client_id.toLowerCase() + "");
				String query = "Select CUSTID from PARTICIPANT_MASTER  where LOWER(CLIENT_ID)='" + client_id.toLowerCase() + "'";
				DatabaseUtil util = new DatabaseUtil();
				String cust_ids = null;
				Statement statement = null;
				Statement stmt1 = null;
				ResultSet rs1 = null;
				ResultSet rs = null;
				try
					{
						if (connection == null || connection.isClosed())
							{
								LOGGER.info("Inside authenticateCustidOnly connection open : " + connection);
								connection = util.getConnection();
							}
						statement = connection.createStatement();
						rs = statement.executeQuery(query);
						while (rs.next())
							{
								cust_ids = rs.getString("CUSTID");
							}
						LOGGER.info("cust_ids : " + cust_ids);
						if (cust_ids.contains(custid))
							{
								LOGGER.info("Cust ID Successfully validated..");
								return true;
							}
						else
							{
								LOGGER.info("Cust ID not validated..");
								return false;
							}
					}
				catch (SQLException e)
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
						return false;
					}
				finally
					{
						try
							{
								if (rs != null)
									{
										rs.close();
									}
								if (statement != null)
									{
										statement.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
			}
		
		
		
		public Boolean validateCustid(String custid)
			{
				String regex = "[0-9]+";
				if (custid.length() == 8)
					{
						if (custid.matches(regex))
							{
								return true;
							}
						else
							{
								return false;
							}
					}
				else
					{
						return false;
					}
			}

		
		
		
		public boolean validateClient(String client_id, String token, String api_name, Connection connection)
			{
				// Connection connection = null;
				CommonMethod commonmethod = new CommonMethod();
				JSONObject errjobj = new JSONObject();
				JSONArray jarray = new JSONArray();
				ResultSet rs = null;
				Statement statement = null;
				PreparedStatement pstatement = null;
				int count = 0;
				// String client_id = "";
				String result = "";
				String query = "";
				boolean flag = false;
				String current_time = null;
				LOGGER.info("Inside validateClient(..) method client_id is " + client_id + " token is " + token);
				try
					{
						// if(connection == null || connection.isClosed()){
						// connection = DatabaseUtil.getConnection();
						if (connection == null || connection.isClosed())
							{
								LOGGER.info("Inside connection open : " + connection);
								connection = util.getConnection();
							}
						Date currdate = new Date();
						SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
						current_time = formatter.format(currdate);
						// }
						if (!client_id.equals(""))
							{
								if (!token.equals(""))
									{
										// query = "select client_id,token from
										// participant_token_details where
										// client_id='"+client_id+"' and
										// token='"+token+"' and (SELECT
										// MINUTE(expiry_time) -
										// MINUTE('"+current_time+"') FROM
										// SYSIBM.SYSDUMMY1) > 0";
										/*
										 * "select client_id,token from participant_token_details where LOWER(client_id)='"
										 * +client_id.toLowerCase()+
										 * "' and token='"+token+
										 * "' and (SELECT timestampdiff (4, char(timestamp(p.expiry_time)-timestamp('"
										 * +current_time+
										 * "'))) FROM participant_token_details p, SYSIBM.SYSDUMMY1 where p.client_id='"
										 * +client_id+"' and p.token='"+token+
										 * "') >0";
										 */
										query = "select client_id,token from participant_token_details " + "where client_id='" + client_id + "' and token = '" + token + "' and  EXPIRY_TIME>CURRENT_TIMESTAMP";
										LOGGER.info("VALIDATE_____________" + query);
										statement = connection.createStatement();
										rs = statement.executeQuery(query);
										while (rs.next())
											{
												LOGGER.info("****************************************************");
												JSONObject jobj = new JSONObject();
												jobj.put("client_id", rs.getString(1));
												jobj.put("token", rs.getString(2));
												jarray.put(jobj);
											}
										if (jarray.length() != 0)
											{
												flag = true;
												//
												// updateTokenValidity(client_id,
												// token);
												setApiUsageStatus(client_id, api_name, connection);
											}
										LOGGER.info("validate-" + flag);
										return flag;
									}
								else
									{
										LOGGER.info("Inside validateClient(..) method ---> token input is found blank");
										/*
										 * errjobj =
										 * commonmethod.getJsonStatus(400,
										 * "Bad request",
										 * "Token should not be blank");
										 * jarray.put(errjobj);
										 * errjobj.put("ERROR",
										 * "User Id cannot be blank");
										 * jarray.put(errjobj);
										 */
										return flag;
									}
							}
						else
							{
								LOGGER.info("Inside validateClient(..) method ---> client_id id input is not set");
								/*
								 * errjobj = commonmethod.getJsonStatus(400,
								 * "Bad request",
								 * "client_id Id should not be blank");
								 * jarray.put(errjobj); errjobj.put("ERROR",
								 * "client_id Id cannot be blank");
								 * jarray.put(errjobj);
								 */
								return flag;
							}
					}
				catch (SQLException e)
					{
						e.printStackTrace();
						return flag;
						/*
						 * errjobj = commonmethod.getJsonStatus(501,
						 * "Database connectivity issues or timeouts",
						 * "Please try after some time"); jarray.put(errjobj);
						 * errjobj.put("ERROR",
						 * "Database Error,Please try after some time");
						 * jarray.put(errjobj);
						 */
					}
				catch (Exception e)
					{
						e.printStackTrace();
						return flag;
						/*
						 * errjobj = commonmethod.getJsonStatus(402,
						 * "Error in processing",
						 * "Error while processing request");
						 * jarray.put(errjobj);
						 */
					}
				finally
					{
						try
							{
								if (statement != null)
									{
										statement.close();
									}
								if (rs != null)
									{
										rs.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
						// return flag;
					}
			}


		public void setApiUsageStatus(String client_id, String api_name, Connection connection)
			{
				String query = "";
				PreparedStatement pstatement = null;
				int count = 0;
				// String client_id = "";
				String result = "";
				boolean returnValue = false;
				String current_time = null;
				LOGGER.info("Inside setApiUsageStatus(..) method client_id is " + client_id + " api_name is " + api_name);
				try
					{
						// connection = DatabaseUtil.getConnection();
						if (connection == null || connection.isClosed())
							{
								LOGGER.info("Inside connection open : " + connection);
								connection = util.getConnection();
							}
						Date currdate = new Date();
						SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
						current_time = formatter.format(currdate);
						query = "insert into participant_apiusage_rev(client_id,api_name,time) values(?,?,?)";
						pstatement = connection.prepareStatement(query);
						pstatement.setString(1, client_id);
						// pstatement.setString(2, userid);
						pstatement.setString(2, api_name);
						pstatement.setString(3, current_time);
						returnValue = pstatement.execute();
						connection.commit();
						LOGGER.info("Inside setApiUsageStatus(..) method insert result" + returnValue);
						try
							{
								if (pstatement != null)
									{
										pstatement.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				catch (Exception e)
					{
						e.printStackTrace();
						LOGGER.warning("Exception in setApiUsageStatus() method" + e.getMessage());
					}
			}
	}
