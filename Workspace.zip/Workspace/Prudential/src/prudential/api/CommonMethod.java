package prudential.api;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.TimeZone;
import java.util.UUID;
import java.util.logging.Logger;

import org.json.JSONException;
import org.json.JSONObject;



public class CommonMethod {
	private static final Logger LOGGER = Logger.getLogger(CommonMethod.class.getName());
	public JSONObject getJsonStatus(int errCd, String errMsg, String errDesc) throws JSONException{
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("code", errCd);
		jsonObject.put("message", errMsg);
		jsonObject.put("description", errDesc);
		return jsonObject;
	}
	
	public String getJsonStatus1(int errCd, String errMsg, String errDesc) throws JSONException{
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("code", errCd);
		jsonObject.put("message", errMsg);
		jsonObject.put("description", errDesc);
		return jsonObject+"";
	}
	
	public String generateToken(){
		String str = (UUID.randomUUID().toString()).replace("-", "");
		LOGGER.info("uuid = " + str);
		if(str.contains("%")){
			str = str.replace("%", "");
		}
		String token = str.substring(1, 13);
		LOGGER.info("token = " + token);
		/*int randomToken=0;	
		ByteArrayOutputStream baos = null;
		DataOutputStream dos = null;
		byte[] data = null;
		String token = "";
		try{
		     //generate a 6 digit integer 
		     randomToken = (int)(Math.random()*99999)+100000;
//		     String token = String.valueOf(randomToken);
		     baos = new ByteArrayOutputStream ();
		     dos = new DataOutputStream (baos);
		     dos.writeInt (randomToken);
		     data = baos.toByteArray();
		     token = data.toString();
		     LOGGER.info("TOKEN:::"+token);
			}
			catch(Exception e){
				e.printStackTrace();
			}*/
		     return token;
	}
	
	public boolean validateDate(String dateInString){
		boolean flag = false;
		boolean compare_currdateFlag = false;
		Date currdate = new Date();
		try{
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
		//		String dateInString = "2015-03-07";

		LOGGER.info("CURR "+formatter.format(currdate));
		Date enterddate = formatter.parse(dateInString);
		LOGGER.info("FORM "+formatter.format(enterddate));
		
		compare_currdateFlag = compareDatesByDateMethods(formatter, enterddate, currdate);
		if(compare_currdateFlag){
		
		Calendar cal = Calendar.getInstance();
		cal.setTime(enterddate);  //use java.util.Date object as arguement
		// get the value of all the calendar date fields.
		int enter_year = cal.get(Calendar.YEAR);
		LOGGER.info("Enter Year: " +enter_year);
		int enter_month = cal.get(Calendar.MONTH);
		LOGGER.info("ENter Month: " +enter_month );
		int enter_day = cal.get(Calendar.DATE);
		LOGGER.info("Enter Day: " +enter_day );

		cal.setTime(currdate);  //use java.util.Date object as arguement
		// get the value of all the calendar date fields.
		int curr_year = cal.get(Calendar.YEAR);
		LOGGER.info("current Year: " +curr_year);
		int curr_year_month = cal.get(Calendar.MONTH);
		LOGGER.info("current Month: " + curr_year_month);
		int curr_year_day = cal.get(Calendar.DATE);
		LOGGER.info("current Day: " +curr_year_day );

		String start_date ="";
		String end_date = "";
		if(enter_year == curr_year){
			if((enter_month+1) <= 3){
				flag = true;
				LOGGER.info("Enterd date is valid");
				return flag;
			}
			{
				LOGGER.info("Invalid Date");
				return flag;
			}
		}
		if(enter_year == curr_year-1){
			if((enter_month+1) >= 4){
			flag = true;	
			return flag;
			}
			else{
				LOGGER.info("Invalid Date");
				return flag;
			}
		}
		}
		else{
			return false;
		}
		}
		catch(Exception e){
			e.printStackTrace();
			return flag;
		}
		return flag;
	}
	
	public HashMap getDates(String dateInString) {
		// TODO Auto-generated method stub
		HashMap hm = new HashMap<String, String>();
		try{
			Date currdate = new Date();

			DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
			//		String dateInString = "2015-03-07";

			LOGGER.info("CURR "+formatter.format(currdate));
			Date enterddate = formatter.parse(dateInString);
			LOGGER.info("FORM "+formatter.format(enterddate));

			Calendar cal = Calendar.getInstance();
			cal.setTime(enterddate);  //use java.util.Date object as arguement
			// get the value of all the calendar date fields.
			int enter_year = cal.get(Calendar.YEAR);
			LOGGER.info("Enter Year: " +enter_year);
			int enter_month = cal.get(Calendar.MONTH);
			LOGGER.info("ENter Month: " +enter_month );
			int enter_day = cal.get(Calendar.DATE);
			LOGGER.info("Enter Day: " +enter_day );

			cal.setTime(currdate);  //use java.util.Date object as arguement
			// get the value of all the calendar date fields.
			int curr_year = cal.get(Calendar.YEAR);
			LOGGER.info("current Year: " +curr_year);
			int curr_year_month = cal.get(Calendar.MONTH);
			LOGGER.info("current Month: " + curr_year_month);
			int curr_year_day = cal.get(Calendar.DATE);
			LOGGER.info("current Day: " +curr_year_day );

			String start_date ="";
			String end_date = "";
			if(enter_year == curr_year){
				if((enter_month+1) <= 3){
					LOGGER.info("Enterd date is valid");
					start_date 	= (curr_year-1)+"-04-01";
					end_date 	= dateInString;
				}
				{
					LOGGER.info("Invalid Date");
				}
			}
			if(enter_year == curr_year-1){
				if((enter_month+1) >= 4){
					start_date = curr_year-1+"-04-01";
					end_date = dateInString;
				}
				else{
					LOGGER.info("Invalid Date");
				}
			}


			hm.put("currYear_strat_date", start_date);
			hm.put("currYear_end_date", end_date);
			hm.put("prevYear_start_date",curr_year-2+"-04-01" );
			hm.put("prevYear_end_date",String.valueOf(curr_year-1) +"-"+String.valueOf(enter_month+1)+"-"+String.valueOf(enter_day+1));
			return hm;
		}
		catch(Exception e){
			e.printStackTrace();
			return hm;
		}
	}

	public  boolean compareDatesByDateMethods(DateFormat df, Date enterd_date, Date current_date) {
        //how to check if two dates are equals in java
                if (enterd_date.after(current_date)) {
            LOGGER.info(df.format(enterd_date) + " comes after " + df.format(current_date));
            return false;
                }
                else{
                	return true;
                }
                
        
    }
	public JSONObject getFinancialYear(String start_date) throws JSONException{
		String[] dateArray = start_date.split("-");
		int year = Integer.parseInt(dateArray[0]);
	    int month = Integer.parseInt(dateArray[1]);
	    int day = Integer.parseInt(dateArray[2]);
	    int startFinancialYr, endFinancialYr, prevStartFinYr, prevEndFinYr;
	    
		//Getting Financial year of the date entered.
	    if (month < 4) {
	        LOGGER.info("Financial Year : " + (year - 1) + "-" + year);
	        startFinancialYr = year - 1;
	        endFinancialYr = year; 
	    } else {
	        LOGGER.info("Financial Year : " + year + "-" + (year + 1));
	        startFinancialYr = year;
	        endFinancialYr = year + 1;
	    }
	    
	    prevStartFinYr = startFinancialYr - 1;
	    prevEndFinYr = endFinancialYr - 1;
		
	    String startFinancialYrDate = String.valueOf(startFinancialYr)+"-04-01";
	    String endFinancialYrDate = String.valueOf(endFinancialYr)+"-03-31";
	    
	    String startPrevFinancialYrDate = String.valueOf(prevStartFinYr)+"-04-01";
	    String endPrevFinancialYrDate = String.valueOf(prevStartFinYr)+"-03-31";
	    
	    JSONObject jsonObject = new JSONObject();
	    jsonObject.put("startFinancialYrDate", startFinancialYrDate);
	    jsonObject.put("endFinancialYrDate", endFinancialYrDate);
	    jsonObject.put("startPrevFinancialYrDate", startPrevFinancialYrDate);
	    jsonObject.put("endPrevFinancialYrDate", endPrevFinancialYrDate);
	    return jsonObject;
	}

	public JSONObject getJsonErr(int errCd, String errMsg, String errDesc) throws JSONException {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("code", errCd);

        if (errCd == 400) {
            jsonObject.put("message", "Bad request. Invalid Request parameter");
        } else if (errCd == 501) {
            jsonObject
                    .put("message",
                            "Processing error � One or more of internal systems gave an error while processing the request");
        } else if (errCd == 503) {
            jsonObject.put("message", "No Data Found");
        } else {
            jsonObject.put("message", errMsg);

        }
        jsonObject.put("description", errDesc);
        return jsonObject;
    }


}
