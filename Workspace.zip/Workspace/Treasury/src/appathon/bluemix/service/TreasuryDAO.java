package appathon.bluemix.service;




import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.TimeZone;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;




public class TreasuryDAO
	{
		private static final Logger log = Logger.getLogger(TreasuryDAO.class.getName());
		DatabaseUtil util = new DatabaseUtil();


		public String getJsonStatus(int errCd, String errMsg, String errDesc) throws JSONException
			{
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("code", errCd);
				jsonObject.put("message", errMsg);
				jsonObject.put("description", errDesc);
				return jsonObject.toString();
			}


		public String getSQLDate(Date date)
			{
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				sdf.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
				String SQLFormattedDate = sdf.format(date);
				return SQLFormattedDate;
			}


		public Boolean authenticateCustidOnly(String flag, String custid, String client_id, Connection connection) throws SQLException
			{
				log.info("------------ authenticateCustidOnly --------------Accoun No : " + custid);
				String query = "Select CUSTID from PARTICIPANT_MASTER  where LOWER(CLIENT_ID)='" + client_id.toLowerCase() + "'";
				if (connection == null || connection.isClosed())
					{
						connection = util.getConnection();
						log.info("Inside fundTransfer connection open -->: " + connection);
					}
				String cust_ids = null;
				Statement statement = null;
				ResultSet rs = null;
				try
					{
						statement = connection.createStatement();
						rs = statement.executeQuery(query);
						while (rs.next())
							{
								cust_ids = rs.getString("CUSTID");
							}
						log.info("cust_ids : " + cust_ids);
					}
				catch (SQLException e)
					{
						e.printStackTrace();
						return false;
					}
				try
					{
						if (statement != null)
							{
								statement.close();
							}
						if (rs != null)
							{
								rs.close();
							}
					}
				catch (Exception e)
					{
						e.printStackTrace();
					}
				if (cust_ids.contains(custid))
					{
						log.info("Cust ID Successfully validated..");
						return true;
					}
				else
					{
						log.info("Cust ID not validated..");
						return false;
					}
			}


		public boolean validateClient(String client_id, String token, String api_name, Connection connection) throws SQLException
			{
				if (connection == null || connection.isClosed())
					{
						connection = util.getConnection();
						log.info("Inside connection open -->: " + connection);
					}
				CommonMethod commonmethod = new CommonMethod();
				JSONObject errjobj = new JSONObject();
				JSONArray jarray = new JSONArray();
				ResultSet rs = null;
				Statement statement = null;
				PreparedStatement pstatement = null;
				// String client_id = "";
				String query = "";
				boolean flag = false;
				String current_time = null;
				log.info("Inside validateClient(..) method client_id is " + client_id + " token is " + token);
				try
					{
						// if(connection == null || connection.isClosed()){
						if (connection == null || connection.isClosed())
							{
								connection = util.getConnection();
								log.info("Inside connection open -->: " + connection);
							}
						Date currdate = new Date();
						SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
						current_time = formatter.format(currdate);
						// }
						if (!client_id.equals(""))
							{
								if (!token.equals(""))
									{
										query = "select client_id,token from participant_token_details " + "where client_id='" + client_id + "' and token = '" + token + "'";
										log.info("VALIDATE Querry" + query);
										statement = connection.createStatement();
										rs = statement.executeQuery(query);
										while (rs.next())
											{
												log.info("---- In Result Set -----");
												JSONObject jobj = new JSONObject();
												jobj.put("client_id", rs.getString(1));
												jobj.put("token", rs.getString(2));
												jarray.put(jobj);
											}
										if (jarray.length()
												 != 0)
											{
												flag = true;
												//
												// updateTokenValidity(client_id,
												// token);
												setApiUsageStatus(client_id, api_name, connection);
											}
										log.info("validate-" + flag);
										return flag;
									}
								else
									{
										log.info("Inside validateClient(..) method ---> token input is found blank");
										return flag;
									}
							}
						else
							{
								log.info("Inside validateClient(..) method ---> client_id id input is not set");
								return flag;
							}
					}
				catch (SQLException e)
					{
						e.printStackTrace();
						return flag;
					}
				catch (Exception e)
					{
						e.printStackTrace();
						return flag;
					}
				finally
					{
						try
							{
								if (statement != null)
									{
										statement.close();
									}
								if (rs != null)
									{
										rs.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							} // return flag;
					}
			}


		public void setApiUsageStatus(String client_id, String api_name, Connection connection)
			{
				String query = "";
				ResultSet rs = null;
				PreparedStatement pstatement = null;
				int count = 0;
				// String client_id = "";
				String result = "";
				boolean returnValue = false;
				String current_time = null;
				log.info("Inside setApiUsageStatus(..) method client_id is " + client_id + " api_name is " + api_name);
				try
					{
						// if(connection == null || connection.isClosed()){
						// connection = DatabaseUtil.getConnection();
						// }
						if (connection == null || connection.isClosed())
							{
								connection = util.getConnection();
								log.info("Inside connection open -->: " + connection);
							}
						Date currdate = new Date();
						SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
						current_time = formatter.format(currdate);
						query = "insert into participant_apiusage_rev(client_id,api_name,time) values(?,?,?)";
						pstatement = connection.prepareStatement(query);
						pstatement.setString(1, client_id);
						// pstatement.setString(2, userid);
						pstatement.setString(2, api_name);
						pstatement.setString(3, current_time);
						returnValue = pstatement.execute();
						connection.commit();
						log.info("Inside setApiUsageStatus(..) method insert result" + returnValue);
					}
				catch (SQLException sq)
					{
						sq.printStackTrace();
						log.warning("SQLException in setApiUsageStatus() method" + sq.getMessage());
					}
				catch (Exception e)
					{
						e.printStackTrace();
						log.warning("Exception in setApiUsageStatus() method" + e.getMessage());
					}
				finally
					{
						try
							{
								if (pstatement != null)
									{
										pstatement.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
			}


		public JSONArray getCurrencyPairs(String custid, String user_id, Connection connection) throws SQLException, JSONException
			{
				JSONArray jsonArray = new JSONArray();
				JSONObject gobj = new JSONObject();
				gobj.put("code", 200);
				Statement statement = null;
				ResultSet resultSet = null;
				if (connection == null || connection.isClosed())
					{
						connection = util.getConnection();
						log.info("Inside connection open -->: " + connection);
					}
				statement = connection.createStatement();// CUST_ID: 11111111
				String queryString = "Select * from Tre_Currency_Master where LOWER(user_id) = '" + user_id.toLowerCase() + "' and CUST_ID='" + custid + "'";
				resultSet = statement.executeQuery(queryString);
				String curr_pair = "", rate_for_buy = "", rate_for_sell = "", deal_type = "";
				jsonArray.put(gobj);
				while (resultSet.next())
					{
						curr_pair = resultSet.getString("curr_pair");
						rate_for_buy = resultSet.getString("rate_for_buy");
						rate_for_sell = resultSet.getString("rate_for_sell");
						deal_type = resultSet.getString("deal_type");
						JSONObject jsonObject = new JSONObject();
						jsonObject.put("curr_pair", curr_pair);
						jsonObject.put("rate_for_buy", rate_for_buy);
						jsonObject.put("rate_for_sell", rate_for_sell);
						jsonObject.put("deal_type", deal_type);
						jsonArray.put(jsonObject);
					}
				try
					{
						if (statement != null)
							{
								statement.close();
							}
						if (resultSet != null)
							{
								resultSet.close();
							}
					}
				catch (Exception e)
					{
						e.printStackTrace();
					}
				return jsonArray;
			}


		public String getAccountNo_fund(String cust_id, Connection connection) throws SQLException
			{
				log.info("-------------Get Account No--------------Cust id : " + cust_id);
				// Connection connection = DatabaseUtil.getConnection();
				Statement statement = null;
				ResultSet rs = null;
				if (connection == null || connection.isClosed())
					{
						connection = util.getConnection();
						log.info("Inside connection open -->: " + connection);
					}
				String accountNo = "";
				statement = connection.createStatement();
				rs = statement.executeQuery("select accountNo from Rtl_Account_Master where custId ='" + cust_id + "'");
				while (rs.next())
					{
						accountNo = rs.getString("accountNo");
					}
				log.info("---Cust id : " + cust_id + " Account no" + accountNo);
				try
					{
						if (statement != null)
							{
								statement.close();
							}
						if (rs != null)
							{
								rs.close();
							}
					}
				catch (Exception e)
					{
						e.printStackTrace();
					}
				return accountNo;
			}


		public String addDealBookingDtl(String foreign_currency_pair, double amt_foreign_currency1, String deal_side, String deal_type, String comments, String deal_date, String cust_id, Connection connection) throws SQLException, JSONException
			{
				boolean returnValue = false;
				if (connection == null || connection.isClosed())
					{
						connection = util.getConnection();
						connection.setAutoCommit(false);
						log.info("Inside connection open -->: " + connection);
					}
				String accountno = getAccountNo_fund(cust_id, connection);
				if (accountno.equals(""))
					{
						CommonMethod commonmethod = new CommonMethod();
						JSONObject errjobj = new JSONObject();
						errjobj = commonmethod.getJsonStatus(401, "Customer ID does not Exists", "Invalid Data");
						return errjobj.toString();
					}
				else
					{
						log.info("-----------get Rate");
						String q1 = "";
						if (deal_side.equalsIgnoreCase("SELL"))
							{
								
								q1 = "select RATE_FOR_SELL from tre_currency_master where CUST_ID = '"+cust_id.trim()+"' and upper(CURR_PAIR) ='"+foreign_currency_pair.trim()+"' and upper(DEAL_TYPE)='"+ deal_type.trim()+"'";
								
							}
						else
							if (deal_side.equalsIgnoreCase("BUY"))
								{
									q1 = "select RATE_FOR_BUY from tre_currency_master where CUST_ID = '"+cust_id.trim()+"' and upper(CURR_PAIR) ='"+foreign_currency_pair.trim()+"' and upper(DEAL_TYPE)='"+deal_type.trim()+"'";
								}
							else
								{
									CommonMethod commonmethod = new CommonMethod();
									JSONObject errjobj = new JSONObject();
									errjobj = commonmethod.getJsonStatus(401, "Customer Data does not Exists", "Invalid Data");
									return errjobj.toString();
								}
						String fixed_rate = "";
						log.info(q1);
						Statement my = connection.createStatement();
						ResultSet rs2 = my.executeQuery(q1);
						while (rs2.next())
							{
								fixed_rate = rs2.getString(1);
							}
						Double new_rate=Double.parseDouble(fixed_rate);
						log.info("******** fixed_rate"+ fixed_rate);
						String amt_foreign_currency2 = (amt_foreign_currency1 / new_rate) + "";
						log.info("insert into TRE_TRANS_DETAILS (" + "FOREIGN_CURRENCY_PAIR, AMT_FOREIGN_CURRENCY1, DEAL_SIDE, DEAL_TYPE, COMMENTS, DEAL_DATE, RATE, AMT_FOREIGN_CURRENCY2,CUSTID)" + " values("+foreign_currency_pair+","+amt_foreign_currency1+","+deal_side+","+deal_type+","+comments+","+deal_date+","+fixed_rate+","+amt_foreign_currency2+","+cust_id+")");
						PreparedStatement ps = connection.prepareStatement("insert into TRE_TRANS_DETAILS (" + "FOREIGN_CURRENCY_PAIR, AMT_FOREIGN_CURRENCY1, DEAL_SIDE, DEAL_TYPE, COMMENTS, DEAL_DATE, RATE, AMT_FOREIGN_CURRENCY2,CUSTID)" + " values(?,?,?,?,?,?,?,?,?)");
						ps.setString(1, foreign_currency_pair);
						ps.setString(2, amt_foreign_currency1 + "");
						ps.setString(3, deal_side);
						ps.setString(4, deal_type);
						ps.setString(5, comments);
						ps.setString(6, deal_date);
						ps.setString(7, fixed_rate + "");
						// ps.setInt(8, maxDealNo);
						ps.setString(8, amt_foreign_currency2);
						ps.setString(9, cust_id);
						returnValue = ps.execute();
						// connection.commit();
						String tranStatus = fundTransfer(accountno, connection, amt_foreign_currency2);
						log.info("Prudential tranStatus" + tranStatus);
						if (tranStatus.contains("Insufficient"))
							{
								log.info("Prudential insuffienct if");
								connection.rollback();
								return tranStatus;
							}
						else
							if (tranStatus.contains("SUCCESS"))
								{
									log.info("Prudential success if");
									connection.commit();
									// return amt_foreign_currency2 + "0";
									int maxDealNo = 0;
									String query1 = "Select max(deal_no) from TRE_TRANS_DETAILS";
									Statement st1 = connection.createStatement();
									ResultSet rs1 = st1.executeQuery(query1);
									while (rs1.next())
										{
											maxDealNo = rs1.getInt(1);
										}	
									return maxDealNo + "#" + amt_foreign_currency2 + "0";
								}
							else
								{
									log.info("Prudential error if");
									connection.rollback();
									return tranStatus;
								}
					}
			}


		public String fundTransfer(String accountno, Connection connection, String amt) throws JSONException
			{
				log.info("---------- Fund Transfer -----------" + accountno);
				//String email = "test@abc.com";
				//String token = "f5316a5e35a4";
				String srcAccount = accountno;
				//String destAccount = "4444777755558888";
				String destAccount = "5555666677779999";
				// String amt = "5000";
				String payeeDesc = "icici";
				String payeeId = "13001";
				String type_of_transaction = "purchase product";
				GenericClass genericClass = new GenericClass();
				String returnMessage = "";
				JSONArray jarr = new JSONArray();
				ArrayList<String> type_tran = new ArrayList<String>();
				// jarr.add(gobj);
			//	log.info("Validation Details " + email + " userid is " + token);
				type_tran.add("pmr");
				type_tran.add("dth");
				type_tran.add("school fee payment");
				type_tran.add("Movie Ticket");
				type_tran.add("electricity");
				type_tran.add("restaurant ticket");
				type_tran.add("Fuel");
				type_tran.add("groceries");
				type_tran.add("home loan emi");
				type_tran.add("insurance payment");
				type_tran.add("car insurance");
				type_tran.add("mf payments");
				type_tran.add("purchase product");
				Boolean flag = true;
				if (flag)
					{
						try
							{
								if (srcAccount.equals("") || destAccount.equals("") || amt.equals("") || payeeDesc.equals("") || payeeId.equals("") || type_of_transaction.equals(""))
									{
										returnMessage = genericClass.getJsonErr(400, "Bad request.", "Please enter all required values.");
									}
								else
									if (Double.parseDouble(amt) <= 0)
										{
											returnMessage = genericClass.getJsonErr(400, "Bad request.", "Invalid Amount.");
										}
									else
										if (!type_tran.contains(type_of_transaction.toLowerCase()))
											{
												returnMessage = genericClass.getJsonErr(400, "Bad request.", "Type of Transaction should be from list");
											}
										else
											{
												// Validate if source account
												// exists
												boolean srcAccountExists = genericClass.chkIfAccountExists(srcAccount, connection);
												if (srcAccountExists)
													{
														// Validate if Payee is
														// listed in Payee list
														// based on
														// Customer ID.
														String srcCustId = genericClass.getCustId(srcAccount, connection);
														String payeenamedb = genericClass.chkIfPayeeExists(destAccount, srcCustId, connection);
														if (!payeenamedb.equalsIgnoreCase(""))
															{
																log.info("payee got");
																// Check if
																// enough
																// balance is
																// available in
																// source
																// account to
																// transfer.
																double srcBalance = genericClass.getBalance(srcAccount, connection);
																boolean balanceAvailable = (srcBalance < Double.parseDouble(amt)) ? false : true;
																if (balanceAvailable)
																	{
																		// Fetch
																		// details
																		// to
																		// enter
																		// in
																		// Transaction
																		// &
																		// Account
																		// details
																		// table.
																		String destCustId = genericClass.getCustId(destAccount, connection);
																		Date todaysDate = new Date();
																		String todaysDate_SQLFormatted = genericClass.getSQLDate(todaysDate);
																		log.info("---------- todaysDate_SQLFormatted -------" + todaysDate_SQLFormatted);
																		// Make
																		// Transaction
																		// entries
																		// Source
																		// transaction
																		// entry
																		String tranid = genericClass.addTransactionDtl(srcCustId, Double.parseDouble(amt), "0", todaysDate_SQLFormatted, srcAccount, destAccount, srcAccount, "Dr.", srcBalance, type_of_transaction, connection);
																		String destAccTran_ReturnVal = genericClass.addTransactionDtl(destCustId, Double.parseDouble(amt), "0", todaysDate_SQLFormatted, srcAccount, destAccount, destAccount, "Cr.", srcBalance, type_of_transaction, connection);
																		// Make
																		// Account
																		// Balance
																		// Updates
																		double newSrcBalance = srcBalance - Double.parseDouble(amt);
																		int srcBalanceUpdateResult = genericClass.updateBalance(srcAccount, newSrcBalance, connection);
																		double destBalance = genericClass.getBalance(destAccount, connection);
																		double newDestBalance = destBalance + Double.parseDouble(amt);
																		int destBalanceUpdateResult = genericClass.updateBalance(destAccount, newDestBalance, connection);
																		log.info("tranid: " + tranid + " destAccTran_ReturnVal: " + destAccTran_ReturnVal + " srcBalanceUpdateResult: " + srcBalanceUpdateResult + " destBalanceUpdateResult: " + destBalanceUpdateResult);
																		JSONObject js = new JSONObject();
																		js.put("transaction_amount", amt + ".00");
																		js.put("status", "SUCCESS");
																		js.put("destination_accountno", destAccount);
																		js.put("payee_name", payeenamedb);
																		js.put("payee_id", "1");
																		js.put("transaction_date", todaysDate_SQLFormatted);
																		js.put("referance_no", tranid);
																		jarr.put(js);
																		returnMessage = jarr.toString();
																	}
																else
																	{
																		returnMessage = genericClass.getJsonErr(402, "Error in processing.", "Insufficient Balance");
																	}
															}
														else
															{
																returnMessage = genericClass.getJsonErr(402, "Error in processing.", "Destination Account doesn't exist.");
															}
													}
												else
													{
														returnMessage = genericClass.getJsonErr(402, "Error in processing.", "Source account doesn't exist.");
													}
											}
							}
						catch (SQLException e)
							{
								returnMessage = genericClass.getJsonErr(402, "Error in processing.", "Fund Transfer failed.");
								e.printStackTrace();
								log.info(e.getMessage());
							}
						catch (Exception e)
							{
								returnMessage = genericClass.getJsonErr(402, "Error in processing.", "Fund Transfer failed.");
								e.printStackTrace();
								log.info(e.getMessage());
							}
					}
				else
					{
						log.info("Token Verification Failed.");
						returnMessage = genericClass.getJsonErr(401, "User Not Authorized", "Access Denied");
					}
				log.info("returnMessage: " + returnMessage);
				return returnMessage;
			}


		public String getAccountNo(String cust_id, Connection connection) throws SQLException
			{
				if (connection == null || connection.isClosed())
					{
						connection = util.getConnection();
						log.info("Inside connection open -->: " + connection);
					}
				String accountNo = "";
				Statement statement = connection.createStatement();
				ResultSet rs = statement.executeQuery("select accountNo from Rtl_Account_Master where custId ='" + cust_id + "'");
				while (rs.next())
					{
						accountNo = rs.getString(1);
					}
				try
					{
						if (statement != null)
							{
								statement.close();
							}
						if (rs != null)
							{
								rs.close();
							}
					}
				catch (Exception e)
					{
						e.printStackTrace();
					}
				return accountNo;
			}


		public String getTransactionDtl(String querry, Connection connection) throws SQLException, JSONException
			{
				String transactionDtl = "";
				JSONObject gobj = new JSONObject();
				JSONArray jarray = new JSONArray();
				
				
				if (connection == null || connection.isClosed())
					{
						connection = util.getConnection();
						log.info("Inside connection open -->: " + connection);
					}
				Statement statement = connection.createStatement();
				ResultSet rs = statement.executeQuery(querry);
				while (rs.next())
					{
						JSONObject jobj = new JSONObject();
						jobj.put("deal_no", rs.getString("DEAL_NO"));
						jobj.put("foreign_currency_pair", rs.getString("FOREIGN_CURRENCY_PAIR"));
						jobj.put("amt_foreign_currency1", rs.getString("AMT_FOREIGN_CURRENCY1") + "0");
						jobj.put("amt_foreign_currency2", rs.getString("AMT_FOREIGN_CURRENCY2") + "0");
						jobj.put("deal_side", rs.getString("DEAL_SIDE"));
						jobj.put("deal_type", rs.getString("DEAL_TYPE"));
						jobj.put("comments", rs.getString("COMMENTS"));
						jobj.put("deal_date", rs.getString("DEAL_DATE"));
						gobj.put("code", 200);
						jarray.put(gobj);
						jarray.put(jobj);
					}
				try
					{
						if (statement != null)
							{
								statement.close();
							}
						if (rs != null)
							{
								rs.close();
							}
					}
				catch (Exception e)
					{
						e.printStackTrace();
					}
				if (jarray.length() > 0) transactionDtl = jarray.toString();
				else
					transactionDtl = "";
				return transactionDtl;
			}


		public boolean chkIfCurrCdExists(String curr_pair, Connection connection) throws SQLException
			{
				boolean currCdExists = false;
				if (connection == null || connection.isClosed())
					{
						connection = util.getConnection();
						log.info("Inside connection open -->: " + connection);
					}
				Statement statement = connection.createStatement();
				ResultSet rs = statement.executeQuery("select count(*) from Tre_Currency_Master where UPPER(curr_pair) = '" + curr_pair + "'");
				while (rs.next())
					{
						currCdExists = rs.getInt(1) > 0 ? true : false;
					}
				try
					{
						if (statement != null)
							{
								statement.close();
							}
						if (rs != null)
							{
								rs.close();
							}
					}
				catch (Exception e)
					{
						e.printStackTrace();
					}
				return currCdExists;
			}
	}
