package appathon.bluemix.service;




import java.sql.Connection;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.TimeZone;
import java.util.logging.Logger;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;




@Path("/icici")
public class TreasuryRestCall
	{
		private static final Logger log = Logger.getLogger(TreasuryRestCall.class.getName());
		DatabaseUtil util = new DatabaseUtil();


		public TreasuryRestCall() throws JSONException
			{
				log.info("------------- TreasuryRestCall Constructor ------------");
				gobj.put("code", 200);
				count = 0;
			}

		CommonMethod comn=new CommonMethod();
		JSONObject gobj = new JSONObject();
		public int count = 0;
		
		
		
		
		@GET
		@Path("/temp")
		@Produces
		public String test(){ return "ok";}

		// http://retail_banking.mybluemix.net/banking/icicibank_treasury/viewCurrencyPairs?email=test@abc.com&token=f5316a5e35a4&custid=11111111&user_id=AAAAAAAA&pwd=pwd
		@GET
		@Path("/viewCurrencyPairs")
		@Produces
		public String viewCurrencyPairs(@Context UriInfo uriInfo,@QueryParam("client_id")
		String client_id, @QueryParam("token")
		String token, @QueryParam("cust_id")
		String custid, @QueryParam("user_id")
		String user_id
		// @QueryParam("pwd") String pwd)
		) throws JSONException
			{
				String returnValue = "";
				Boolean accflag = false;
				TreasuryDAO treasuryDao = new TreasuryDAO();
				JSONArray jsonArray = new JSONArray();
				Connection connection = null;
				log.info("###----------- View Currency Pair ------------###");
				log.info("Client ID : " + client_id);
				log.info("Token : " + token);
				log.info("Cust ID : " + custid);
				log.info("User ID : " + user_id);
				// log.info("password ID : " + pwd);
				try
					{
						HashSet<String> set = new HashSet<String>();
						set.add("client_id");
						set.add("token");
						set.add("cust_id");
						set.add("user_id");
						String data=comn.keyvalidation(uriInfo,set);
						if(data.equalsIgnoreCase("ok"))
						{
						if (client_id.equals("") || token.equals("") || custid.equals("") || user_id.equals(""))
							{
								returnValue = treasuryDao.getJsonStatus(400, "Bad request.", "Please enter all required values.");
							}
						else
							{
								if (connection == null || connection.isClosed())
									{
										connection = util.getConnection();
										log.info("Inside connection open -->: " + connection);
									}
								boolean isClientValidated = treasuryDao.validateClient(client_id, token, "T_viewCurrencyPairs", connection);
								if (isClientValidated)
									{
										accflag = treasuryDao.authenticateCustidOnly("C", custid, client_id, connection);
										log.info("Cust ID Validation Flag : " + accflag);
										if (accflag)
											{
												jsonArray = treasuryDao.getCurrencyPairs(custid, user_id, connection);
											}
										else
											{
												returnValue = treasuryDao.getJsonStatus(401, "User Not Authorized", "This Customer ID does not belongs to participant");
												log.info(returnValue.toString() + " -- " + custid);
												jsonArray.put(returnValue);
											}
										if (jsonArray.toString().length() > 50)
											{
												returnValue = jsonArray.toString();
											}
										else
											{
												returnValue = treasuryDao.getJsonStatus(402, "No records available.", "No Records available");
											}
									}
								else
									{
										log.info("User Not Authorized");
										returnValue = treasuryDao.getJsonStatus(401, "User Not Authorized", "Access Denied");
									}
							}
						}
						else
						{
							gobj.put("code",454);
							gobj.put("description","Invalid Parameter");
							gobj.put("message",data);
							jsonArray.put(gobj);
							System.out.println(jsonArray.toString());
							return jsonArray.toString();
						}
					}
				catch (SQLException e)
					{
						log.info(e.getMessage());
						returnValue = treasuryDao.getJsonStatus(501, "Database connectivity issue or Timeouts.", "Database Error. Please try after some time.");
					}
				catch (Exception e)
					{
						log.info(e.getMessage());
						returnValue = treasuryDao.getJsonStatus(402, "Error in processing.", "Currency Pairs value couldn't be fetched.");
					}
				finally
					{
						try
							{
								if (connection != null)
									{
										connection.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				return returnValue;
			}


		// http://retail_banking.mybluemix.net/banking/icicibank_treasury/bookDeal?email=test@abc.com&token=6b81867b5114&srcCurrency=INR&destCurrency=USD&dealSide=SELL&dealType=dummyDealType&amt=1200&comments=Booking_Deal&custId=cust01
		// http://retail_banking.mybluemix.net/banking/icicibank_treasury/bookDeal?email=test@abc.com&token=f5316a5e35a4&foreign_currency_pair=INR/USD&amt_foreign_currency1=50&deal_side=SELL&deal_type=value_spot&comments=my_comments&rate=21
		@GET
		@Path("/bookDeal")
		@Produces
		public String bookDeal(@Context UriInfo uriInfo,@QueryParam("client_id")
		String client_id, @QueryParam("token")
		String token, @QueryParam("cust_id")
		String cust_id, @QueryParam("foreign_currency_pair")
		String foreign_currency_pair, @QueryParam("amt_foreign_currency1")
		String amt_foreign_currency1, @QueryParam("deal_side")
		String deal_side, @QueryParam("deal_type")
		String deal_type, @QueryParam("comments")
		String comments) throws JSONException
			{
				String returnValue = "";
				log.info("----------- Book Deal ------------");
				log.info("Client ID : " + client_id);
				log.info("Token : " + token);
				log.info("Cust ID : " + cust_id);
				log.info("amt_foreign_currency1 : " + amt_foreign_currency1);
				log.info("foreign_currency_pair : " + foreign_currency_pair);
				TreasuryDAO treasuryDao = new TreasuryDAO();
				JSONArray jarr = new JSONArray();
				Connection connection = null;
				try
					{	
						HashSet<String> set = new HashSet<String>();
						set.add("client_id");
						set.add("token");
						set.add("cust_id");
						set.add("foreign_currency_pair");
						set.add("amt_foreign_currency1");
						set.add("deal_side");
						set.add("deal_type");
						set.add("comments");
						String data=comn.keyvalidation(uriInfo,set);
						if(data.equalsIgnoreCase("ok"))
						{
						if (client_id.equals("") || token.equals("") || foreign_currency_pair.equals("") || amt_foreign_currency1.equals("") || deal_side.equals("") || deal_type.equals("") || cust_id.equals(""))
							{
								returnValue = treasuryDao.getJsonStatus(400, "Bad request.", "Please enter all required values.");
							}
						else
							{
								if (connection == null || connection.isClosed())
									{
										connection = util.getConnection();
										log.info("Inside connection open -->: " + connection);
									}
								boolean isClientValidated = treasuryDao.validateClient(client_id, token, "T_bookDeal", connection);
								if (isClientValidated)
									{
										if (!treasuryDao.chkIfCurrCdExists(foreign_currency_pair.toUpperCase(), connection))
											{
												returnValue = treasuryDao.getJsonStatus(400, "Bad request.", "Invalid Currency Pair.");
											}
										else
											if (!((deal_side.equalsIgnoreCase("SELL") || (deal_side.equalsIgnoreCase("BUY")))))
												{
													returnValue = treasuryDao.getJsonStatus(400, "Bad request.", "Deal Side should be either 'SELL' or 'BUY'.");
												}
											else
												if (Double.parseDouble(amt_foreign_currency1) < 0)
													{
														returnValue = treasuryDao.getJsonStatus(400, "Bad request.", "Invalid Amount.");
													}
												else
													if (!treasuryDao.authenticateCustidOnly("C", cust_id, client_id, connection))
														{
															returnValue = treasuryDao.getJsonStatus(401, "User Not Authorized", "This Customer ID does not belongs to participant");
															log.info(returnValue.toString() + " -- " + cust_id);
														}
													else
														{
															Date todaysDate = new Date();
															String todaysDate_SQLFormatted = treasuryDao.getSQLDate(todaysDate);
															String dealBook_returnVal = treasuryDao.addDealBookingDtl(foreign_currency_pair.toUpperCase(), Double.parseDouble(amt_foreign_currency1), deal_side, deal_type.toUpperCase(), comments, todaysDate_SQLFormatted, cust_id, connection);
															String dealarr[] = dealBook_returnVal.split("#");
															log.info("----dealarr---- " + dealarr.toString());
															JSONObject js = new JSONObject();
															js.put("dealno", dealarr[0]);
															js.put("amount_foreign_currency_2", dealarr[1]);
															log.info("dealBook_returnVal: " + dealBook_returnVal);
															jarr.put(gobj);
															jarr.put(js);
															returnValue = jarr.toString();
														}
									}
								else
									{
										log.info("User Not Authorized");
										returnValue = treasuryDao.getJsonStatus(401, "User Not Authorized", "Access Denied");
									}
							}
					}else
						{
							gobj.put("code",454);
							gobj.put("description","Invalid Parameter");
							gobj.put("message",data);
							jarr.put(gobj);
							System.out.println(jarr.toString());
							return jarr.toString();
						}
					}
				catch (SQLException e)
					{
						returnValue = treasuryDao.getJsonStatus(501, "Database connectivity issue or Timeouts.", "Database Error. Please try after some time.");
						e.printStackTrace();
						log.info(e.getMessage());
					}
				catch (Exception e)
					{
						returnValue = treasuryDao.getJsonStatus(402, "Error in processing.", "Deal cannot be booked.");
						e.printStackTrace();
						log.info(e.getMessage());
					}
				finally
					{
						try
							{
								if (connection != null)
									{
										connection.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				return returnValue;
			}


		// http://retail_banking.mybluemix.net/banking/icicibank_treasury/dealMis?email=test@abc.com&token=f5316a5e35a4&dealno=1021698567&fromDate=2016-01-13&toDate=2016-02-02
		@GET
		@Path("/dealMis")
		@Produces
		public String dealMis(@Context UriInfo uriInfo,@QueryParam("client_id")
		String client_id, @QueryParam("token")
		String token, @QueryParam("dealno")
		String dealno, @QueryParam("from_date")
		String fromDate, @QueryParam("to_date")
		String toDate, @QueryParam("cust_id")
		String custid) throws JSONException
			{
				String returnValue = "";
				String query = "";
				String tranDtl = "";
				TreasuryDAO treasuryDao = new TreasuryDAO();
				JSONArray jarr=new JSONArray();
				Connection connection = null;
				log.info("###------------ Deal MIS ------------###");
				log.info("Client  ID : " + client_id);
				log.info("Token : " + token);
				log.info("Deal No : " + dealno);
				try
					{
						HashSet<String> set = new HashSet<String>();
						set.add("client_id");
						set.add("token");
						set.add("dealno");
						set.add("from_date");
						set.add("to_date");
						set.add("cust_id");
						String data=comn.keyvalidation(uriInfo,set);
						if(data.equalsIgnoreCase("ok"))
						{
						if (connection == null || connection.isClosed())
							{
								connection = util.getConnection();
								log.info("Inside connection open -->: " + connection);
							}
						boolean isClientValidated = treasuryDao.validateClient(client_id, token, "T_DealMis", connection);
						if (isClientValidated)
							{
								if (!fromDate.equals("") && !toDate.equals(""))
									{
										String isdatecorrect = datevalidator(fromDate, toDate);
										if (isdatecorrect.equalsIgnoreCase("success"))
											{
												query = "select * from TRE_TRANS_DETAILS where deal_date between '" + fromDate + "' and '" + toDate + "' and custid='" + custid + "' and deal_no='" + dealno + "'";
												tranDtl = treasuryDao.getTransactionDtl(query, connection);
											}
										else
											{
												returnValue = getJsonErr(400, "", isdatecorrect).toString();
												log.info(returnValue);
											}
										if (!tranDtl.equals("")) returnValue = tranDtl;
										else
											{
												returnValue = treasuryDao.getJsonStatus(503, "No Data Found.", "MIS of Deal not available for the given date range.");
											}
									}
								else
									if (!dealno.equals(""))
										{
											query = "select * from TRE_TRANS_DETAILS where DEAL_NO='" + dealno + "'";
											tranDtl = treasuryDao.getTransactionDtl(query, connection);
											if (!tranDtl.equals("")) returnValue = tranDtl;
											else
												{
													returnValue = treasuryDao.getJsonStatus(503, "No Data Found.", "MIS of Deal not available for the given date range.");
												}
										}
									else
										{
											returnValue = treasuryDao.getJsonStatus(400, "Bad request.", "Please enter all required parameters.");
										}
							}
						else
							{
								log.info("User Not Authorized");
								returnValue = treasuryDao.getJsonStatus(401, "User Not Authorized", "Access Denied");
							}
					}
						else
						{
							gobj.put("code",454);
							gobj.put("description","Invalid Parameter");
							gobj.put("message",data);
							jarr.put(gobj);
							System.out.println(jarr.toString());
							return jarr.toString();
						}
					}
				catch (SQLException e)
					{
						returnValue = treasuryDao.getJsonStatus(501, "Database connectivity issue or Timeouts.", "Database Error. Please try after some time.");
						e.printStackTrace();
						log.info(e.getMessage());
					}
				catch (Exception e)
					{
						returnValue = treasuryDao.getJsonStatus(402, "Error in processing.", "MIS of Deal could not be fetched successfully.");
						e.printStackTrace();
						log.info(e.getMessage());
					}
				finally
					{
						try
							{
								if (connection != null)
									{
										connection.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				return returnValue;
			}


		public String datevalidator(String fromdate, String todate)
			{
				String Error = "success";
				try
					{
						Date date = new Date();
						// displaying this date on IST timezone
						DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
						df.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
						String sysdate = df.format(date);
						log.info("Date in Indian Timezone (IST) : " + sysdate);
						SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
						Date fdate = sdf.parse(fromdate);
						Date tdate = sdf.parse(todate);
						log.info(sdf.format(fdate));
						log.info(sdf.format(tdate));
						if (fdate.after(tdate))
							{
								Error = "From date cannot be greated then todate";
								log.info("From date cannot be greated then todate");
							}
						if (fdate.before(tdate))
							{
								log.info("To date cannot be greater then todays date");
							}
						if (fdate.equals(tdate))
							{
								log.info("Date1 is equal Date2");
							}
					}
				catch (ParseException ex)
					{
						Error = "Date format Exception";
						ex.printStackTrace();
					}
				catch (Exception e)
					{
						e.printStackTrace();
					}
				return Error;
			}


		public JSONObject getJsonErr(int errCd, String errMsg, String errDesc) throws JSONException
			{
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("code", errCd);
				if (errCd == 400)
					{
						jsonObject.put("message", "Bad request. Invalid Request parameter");
					}
				else
					if (errCd == 501)
						{
							jsonObject.put("message", "Processing error � One or more of internal systems gave an error while processing the request");
						}
					else
						if (errCd == 503)
							{
								jsonObject.put("message", "No Data Found");
							}
						else
							{
								jsonObject.put("message", errMsg);
							}
				jsonObject.put("description", errDesc);
				log.info("getJsonErr() -->" + jsonObject.toString());
				return jsonObject;
			}
	}
