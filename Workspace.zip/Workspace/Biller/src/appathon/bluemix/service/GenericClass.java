package appathon.bluemix.service;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.json.JSONException;
import org.json.JSONObject;


public class GenericClass {

/*	DatabaseUtil util=null;
	public GenericClass() {

		util=new DatabaseUtil();
	}
*/	public boolean chkIfAccountExists(String AccountNo,Connection connection) throws SQLException{
		DatabaseUtil util = new DatabaseUtil();
		Statement statement = null;
		ResultSet rs = null;
		boolean accountExists = false;
		try{
			if(connection ==null || connection.isClosed() )
			{
				System.out.println("Inside chkIfAccountExists connection open : "+connection);
				connection = util.getConnection();
			}
			statement = connection.createStatement();
			rs = statement.executeQuery("SELECT count(*) FROM fnpbbmor.Rtl_Account_Master where accountNo ="+ AccountNo);			
			while (rs.next()) {
				accountExists = (rs.getInt(1) == 0) ? false : true;
			}
	
			if(rs != null){
				rs.close();
			}
			if(statement != null){
				statement.close();
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		//	connection.close();		
		return accountExists;
	}

	public String chkIfPayeeExists(String AccountNo, String custId,Connection connection) throws SQLException{
		DatabaseUtil util = new DatabaseUtil();
		Statement statement = null;
		ResultSet rs = null;
		String payeename = "";
		try{
		if(connection ==null || connection.isClosed() )
		{
			System.out.println("Inside chkIfPayeeExists connection open : "+connection);
			connection = util.getConnection();
		}
	
			statement = connection.createStatement();
			rs = statement.executeQuery("SELECT PAYEENAME FROM fnpbbmor.Rtl_Payee_Details where payeeaccountno ='"+ AccountNo
					+"' and c_custId = '"+custId+"'");			
			while (rs.next()) {
				payeename = rs.getString("payeename");
			}
			// connection.close();	
			if(rs != null){
				rs.close();
			}
			if(statement != null){
				statement.close();
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return payeename;
	}

	public String getCustId(String AccountNo,Connection connection) throws SQLException{
		DatabaseUtil util = new DatabaseUtil();
		Statement statement=null;
		ResultSet rs =null;
		String custId = "";
		try{
		if(connection ==null || connection.isClosed() )
		{
			System.out.println("Inside getCustId connection open : "+connection);
			connection = util.getConnection();
		}
		statement = connection.createStatement();			
		rs = statement.executeQuery("select custId from fnpbbmor.Rtl_Account_Master where accountNo ='"+ AccountNo+"'");
		while (rs.next()) {
			custId = rs.getString(1);
		}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally
		{
			try{if(rs != null){
				rs.close();
			}
			if(statement != null){
				statement.close();
			}
			}catch(Exception e)
			{e.printStackTrace();}
			
		}
		//connection.close();			
		return custId;
	}

	public double getBalance(String AccountNo,Connection connection) throws SQLException{
		DatabaseUtil util =new DatabaseUtil();
		double balance = 0.0D;	
		Statement statement=null;
		ResultSet rs =null;
		try {
			if(connection ==null || connection.isClosed() )
			{
				System.out.println("Inside getBalance connection open : "+connection);
				connection = util.getConnection();
			}	
		
		statement = connection.createStatement();			
		rs = statement.executeQuery("select balance from fnpbbmor.Rtl_Account_Master where accountNo ='"+ AccountNo+"'");
		while (rs.next()) {
			balance = rs.getDouble(1);
		}
		connection = null;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally
		{
			try{if(rs != null){
				rs.close();
			}
			if(statement != null){
				statement.close();
			}
			}catch(Exception e)
			{e.printStackTrace();}
			
		}
		//connection.close();			
		return balance;
	}

	public synchronized String addTransactionDtl(String custId, double amount, String status, String transactionDate,
			String fromAccount, String toAccount, String c_accountNo, String credit_debit_flag,Double srcBalance,String type_of_transaction,Connection connection) throws SQLException{
		Statement st=null;
		ResultSet rs=null;
		PreparedStatement ps=null;
		DatabaseUtil util=new DatabaseUtil();
		boolean returnValue=false;
		if(connection ==null || connection.isClosed() )
		{
			System.out.println("Inside addTransactionDtl connection open : "+connection);
			connection = util.getConnection();
		}
		System.out.println("in addTransactionDtl -- srcBalance : "+srcBalance);
		String query="Select max(tranid) from fnpbbmor.Rtl_Transaction_Details";
		Double cloasingbal;
		if(credit_debit_flag.contains("D"))
		{
			cloasingbal=srcBalance - amount;
		}
		else {
			Double closingdestbal = getBalance(toAccount,connection);
			cloasingbal=closingdestbal + amount;
		}
		st = connection.createStatement();
		rs = st.executeQuery(query);
		int maxTranId = 0;
		while(rs.next()){
			maxTranId = rs.getInt(1);
		}
		maxTranId++;

		ps = connection.prepareStatement("insert into fnpbbmor.Rtl_Transaction_Details("
				+ "custId,amount,status,transactionDate,fromAccount,toAccount,c_accountNo,credit_debit_flag,tranid,Closing_balance,REMARK)"
				+ " values(?,?,?,?,?,?,?,?,?,?,?)");
		ps.setString(1, custId);			
		ps.setDouble(2, amount);
		ps.setString(3, status);
		ps.setString(4, transactionDate);
		ps.setString(5, fromAccount);
		ps.setString(6, toAccount);
		ps.setString(7, c_accountNo);
		ps.setString(8, credit_debit_flag);
		ps.setInt(9, maxTranId);
		ps.setString(10, cloasingbal+"");
		ps.setString(11, type_of_transaction);

		returnValue=ps.execute();
		connection.commit();
		//connection.close();
		
			if(rs != null){
				rs.close();
			}
			if(st != null){
				st.close();
			}
			if(ps != null)
			{ps.close();}
			
		return maxTranId+"";
	}

	public int updateBalance(String accountNo, double amount,Connection connection) throws SQLException{

		DatabaseUtil util=new DatabaseUtil();
		PreparedStatement ps=null;
		if(connection ==null || connection.isClosed() )
		{
			System.out.println("Inside updateBalance connection open : "+connection);
			connection = util.getConnection();
		}
		int returnValue=0;		
		ps = connection.prepareStatement("update fnpbbmor.Rtl_Account_Master set balance = ? where "
				+ " accountNo = ?");

		ps.setDouble(1, amount);
		ps.setString(2, accountNo);			

		returnValue=ps.executeUpdate();
		connection.commit();
		//connection.close();
	if(ps != null)
	{
		ps.close();
	}
		return returnValue;	
	}

	public String getSQLDate(Date date){

		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		//	SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		sdf.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
		String SQLFormattedDate = sdf.format(date);

		return SQLFormattedDate;
	}

	public String getJsonErr(int errCd, String errMsg, String errDesc) throws JSONException{
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("code", errCd);
		jsonObject.put("message", errMsg);
		jsonObject.put("description", errDesc);
		return jsonObject.toString();
	}
}
