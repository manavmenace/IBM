package appathon.bluemix.service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.UriInfo;

import org.json.JSONException;
import org.json.JSONObject;

public class CommonMethod
  {
	
	public JSONObject getJsonErr(int errCd, String errMsg, String errDesc) throws JSONException
	  {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("code", errCd);
		jsonObject.put("message", errMsg);
		jsonObject.put("description", errDesc);
		return jsonObject;
	  }
	
	protected String keyvalidation(UriInfo uriInfo, HashSet<String> set)
	  {
		StringBuilder sb = new StringBuilder();
		try
		  {
			System.out.println(uriInfo.getQueryParameters());
			
			MultivaluedMap<String, String> params = uriInfo.getQueryParameters();
			System.out.println("fixd keys : " + set);
			
			System.out.println(params.keySet().containsAll(set));
			
			for (String d : set)
			  {
				if (params.keySet().containsAll(set))
				  {
					return "ok";
				  }
				System.out.println();
				if (!params.containsKey(d))
				  {
					sb.append(d + "----");
				  }
			  }
			return "key issue for " + sb.toString();
			
		  } catch (Exception e)
		  {
			
			System.err.println(e.getMessage());
		  }
		return "please Check all key it should be " + set + " only";
	  }
	
	
	
	public Boolean authenticateCustidOnly(String flag, String custid, String client_id, Connection connection)
	  {
		System.out.println("------------ authenticateCustidOnly --------------Account No : " + custid);
		String query = "Select CUSTID from PARTICIPANT_MASTER  where LOWER(CLIENT_ID)='" + client_id.toLowerCase() + "'";
		DatabaseUtil util = new DatabaseUtil();
		String cust_ids = null;
		Statement statement = null;
		ResultSet rs = null;
		try
		  {
			if (connection == null || connection.isClosed())
			  {
				System.out.println("Inside authenticateCustidOnly connection open : " + connection);
				connection = util.getConnection();
			  }
			statement = connection.createStatement();
			
			rs = statement.executeQuery(query);
			while (rs.next())
			  {
				cust_ids = rs.getString("CUSTID");
			  }
			System.out.println("cust_ids : " + cust_ids);
			
			if (cust_ids.contains(custid))
			  {
				System.out.println("Cust ID Successfully validated..");
				return true;
			  } else
			  {
				System.out.println("Cust ID not validated..");
				return false;
			  }
		  } catch (SQLException e)
		  {
			e.printStackTrace();
			return false;
		  } finally
		  {
			try
			  {
				if (rs != null)
				  {
					rs.close();
				  }
				if (statement != null)
				  {
					statement.close();
				  }
			  } catch (Exception e)
			  {
				e.printStackTrace();
			  }
		  }
	  }
	
	
	
	

  }
