package appathon.bluemix.service;

/**
 *
 * @author 
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.logging.Logger;
import com.microsoft.sqlserver.jdbc.SQLServerDriver;

public class DatabaseUtil
{
  private static final Logger log = Logger.getLogger(DatabaseUtil.class.getName());
  
  public Connection getConnection()
  {
    Connection conn = null;
    
    String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    try
    {
      Class.forName(driver);
      conn = DriverManager.getConnection("jdbc:sqlserver:**);
      if (conn.equals(null)) {
        System.out.println("error");
      }
      System.out.println("connection Success");
      System.out.println("connection Success");
    }
    catch (Exception e)
    {
      System.out.println("Error");
      e.printStackTrace();
    }
    return conn;
  }
		public static void main(String[] args)
			{
				DatabaseUtil o = new DatabaseUtil();
				System.out.println(o.getConnection());
			}
	}
