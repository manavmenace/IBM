package appathon.bluemix.service;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.TimeZone;
import java.util.logging.Logger;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@Path("/icici")
public class RestCall extends CommonMethod implements SqlQueries
  {
	public RestCall() throws JSONException
	  {
		log.info("-------------Constructor------------");
		gobj.put("code", 200);
		count = 0;
	  }
	
	private static final Logger log        = Logger.getLogger(RestCall.class.getName());
	Connection  connection = null;
	
	@Override
	public Connection getconnection()
	  {
		try
		  {
			if (connection == null || connection.isClosed())
			  {
				System.out.println("Inside getMessage connection open : " + connection);
				DatabaseUtil dbUtil = new DatabaseUtil();
				connection = dbUtil.getConnection();
			  }
			
		  } catch (Exception e)
		  {
			log.info(e.getMessage());
		  }
		return connection;
	  }
	
	JSONObject returnMessage = new JSONObject();
	JSONObject gobj          = new JSONObject();
	JSONObject jobj          = new JSONObject();
	JSONArray  jarray        = new JSONArray();
	boolean    flag;
	public int count=0;
	
	// http://localhost:8080/Biller/Biller/icici/billerdetail?client_id=test@abc.com&token=f5316a5e35a4&billername=gas
	// [{"code":200},{"State":"MADHYA PRADESH","BillerDetail":"IOCL"},{"State":"MADHYA PRADESH","BillerDetail":"IOCL"},{"State":"MADHYA PRADESH","BillerDetail":"IOCL"},{"State":"MADHYA PRADESH","BillerDetail":"IOCL"},{"State":"MADHYA PRADESH","BillerDetail":"IOCL"},{"State":"MADHYA PRADESH","BillerDetail":"IOCL"},{"State":"MADHYA PRADESH","BillerDetail":"IOCL"},{"State":"MADHYA PRADESH","BillerDetail":"IOCL"}]
	
	@GET
	@Path("/billerdetail")
	@Produces
	public String getMessage(@Context UriInfo uriInfo, @QueryParam("client_id") String client_id, @QueryParam("token") String token, @QueryParam("billername") String billername) throws JSONException
	  {
		log.info("###---- Biller Detail ----###");
		
		Statement statement = null;
		ResultSet rs = null;
		String result = "";
		String biller = "";
		String childid = "";
		String state = "";
		log.info("Initiate Biller Detail for parentid :" + billername);
		boolean flag = false;
		log.info("Validation Details " + client_id + " userid is " + token);
		try
		  {
			HashSet<String> set = new HashSet<String>();
			set.add("client_id");
			set.add("token");
			set.add("billername");
			String data = keyvalidation(uriInfo, set);
			if (data.equalsIgnoreCase("ok"))
			  {
				
				
				flag = validateClient(client_id, token, "billerdetail");
				if (flag)
				  {
					log.info("validation of Biller Details Successfull");
					// log.info("select biller_detail, child_id, state from biller_details where lower(biller_name) = lower('"
					// + billername + "')");
					System.out.println("select biller_detail, child_id, state from BILLERS_DETAILS where lower(biller_name) =" + billername.toLowerCase());
					PreparedStatement preparedStatement = getconnection().prepareStatement(getBillerDetails);
					preparedStatement.setString(1, billername.toLowerCase());
					rs = preparedStatement.executeQuery();
					
					if (!rs.equals(null))
					  {
						int jh=0;
						while (rs.next())
						  {
							biller = rs.getString(1);
							childid = rs.getString(2);
							state = rs.getString(3);
							System.out.println("------"+jh +"BillerDetail"+biller+"   State"+state);
							jh++;
							if (count == 0)
							  {
								jarray.put(gobj);
							  }
							JSONObject jobj =new JSONObject();
							count++;
							jobj.put("BillerDetail", biller);
							jobj.put("State", state);
							jarray.put(jobj);
							System.out.println(jarray.toString());
							log.info("Biller Detail for :" + billername + " is " + biller + ", Child id is " + childid + "and state is " + state);
						  }
					  } else
					  {
						returnMessage = getJsonErr(401, "Bad request. Request parameter are not provided.", "Biller Name not properly given");
					  }
				  } else
				  {
					log.info("Token Verification Failed.");
					returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
					jarray.put(returnMessage);
				  }
				if (jarray.length() == 0)
				  {
					jarray.put(returnMessage);
					result = jarray.toString();
				  } else
				  {
					result = jarray.toString();
				  }
			  } else
			  {
				jobj.put("code", 454);
				jobj.put("description", "Invalid Parameter");
				jobj.put("message", data);
				jarray.put(jobj);
				System.out.println(jarray.toString());
				return result;
			  }
		  } catch (SQLException e)
		  {
			
			e.printStackTrace();
			returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
			log.info(jobj.toString() + " -- " + billername);
		  } catch (Exception ex)
		  {
			ex.printStackTrace();
			returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
			log.info(jobj.toString() + " -- " + billername);
		  } finally
		  {
			try
			  {
				if (rs != null)
				  {
					rs.close();
				  }
				if (statement != null)
				  {
					statement.close();
				  }
				if (connection != null)
				  {
					connection.close();
				  }
			  } catch (Exception e)
			  {
				e.printStackTrace();
			  }
		  }
		return result;
	  }
	
	// http://localhost:8080/Biller/Biller/icici/addbiller?client_id=test@abc.com&token=f5316a5e35a4&billerdetail=Tata Power&state=MADHYA PRADESH&custid=33337689&nickname=sac&consumerno=78547854
	// [{"code":200},{"Success":"Biller Successfully added for child Id : 1006"}]
	// {"message":"Bad request. Invalid Request parameter","description":"Nickname for Account number already added.","code":400}
	
	@GET
	@Path("/addbiller")
	@Produces
	public String addBiller(@Context UriInfo uriInfo, @QueryParam("client_id") String client_id, @QueryParam("token") String token, @QueryParam("billerdetail") String billerdetail, @QueryParam("state") String state, @QueryParam("custid") String custid, @QueryParam("nickname") String nickname, @QueryParam("consumerno") String consumerno) throws JSONException
	  {
		log.info("###---- Biller Detail ----###");
		ResultSet rs = null;
		ResultSet rs1 = null;
		ResultSet rs2 = null;
		ResultSet rs3 = null;
		String result = "";
		String billerName = "";
		String parentid = "";
		String childid = "";
		PreparedStatement preparedStatement = null;
		
		log.info("Adding biller detail for :" + billerdetail + " and state is : " + state);
		boolean flag = false;
		log.info("Validation Details " + client_id + " userid is " + token);
		try
		  {
			HashSet<String> set = new HashSet<String>();
			set.add("client_id");
			set.add("token");
			set.add("billerdetail");
			set.add("state");
			set.add("custid");
			set.add("nickname");
			set.add("consumerno");
			String data = keyvalidation(uriInfo, set);
			if (data.equalsIgnoreCase("ok"))
			  {
				flag = validateClient(client_id, token, "addbiller");
				if (flag)
				  {
					String regex = "[0-9]+";
					if (!custid.equals(""))
					  {
						if (custid.length() == 8)
						  {
							if (custid.matches(regex))
							  {
								if (!nickname.trim().equalsIgnoreCase(""))
								  {
									preparedStatement = getconnection().prepareStatement(getAccountNumber);
									preparedStatement.setString(1, custid);
									rs = preparedStatement.executeQuery();
									if (rs.next())
									  {
										String accountno = rs.getString("accountno");
										preparedStatement = getconnection().prepareStatement(checkNickName);
										preparedStatement.setString(1, accountno);
										preparedStatement.setString(2, nickname);
										log.info("select * from add_biller where Account_number = " + accountno + " and nickname = '" + nickname + "'");
										rs1 = preparedStatement.executeQuery();
										if (rs1.next())
										  {
											returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided correctly.", "Nickname for Account number already added.");
											return returnMessage.toString();
										  }
										preparedStatement = getconnection().prepareStatement(getAddBillerDetails);
										preparedStatement.setString(1, billerdetail.toLowerCase());
										preparedStatement.setString(2, state.toLowerCase());
										log.info("select * from add_biller where Account_number = " + accountno + " and nickname = '" + nickname + "'");
										rs2 = preparedStatement.executeQuery();
										if (rs2.next())
										  {
											billerName = rs2.getString("biller_name");
											parentid = rs2.getString("parent_id");
											billerdetail = rs2.getString("biller_detail");
											state = rs2.getString("state");
											childid = rs2.getString("child_id");
											System.out.println(billerName);
											System.out.println(parentid);
											System.out.println(billerdetail);
											System.out.println(state);
											if (billerName.equalsIgnoreCase("mobile"))
											  {
												int len = consumerno.length();
												if (len == 10)
												  {
													if (consumerno.matches(regex))
													  {
														preparedStatement = getconnection().prepareStatement(addBiller);
														preparedStatement.setString(1, billerdetail.toLowerCase());
														preparedStatement.setString(2, state.toLowerCase());
														log.info("insert into add_biller (Account_number,biller_name,parent_id,biller_detail,child_id,state,nickname,consumer_no) values (" + accountno + ",'" + billerName + "','" + parentid + "','" + billerdetail + "'," + childid + ",'" + state + "','" + nickname + "'," + consumerno + ")");
														
														preparedStatement.executeUpdate();
														if (count == 0)
														  {
															jarray.put(gobj);
														  }
														count++;
														jobj.put("Success", "Biller Successfully added for : " + billerdetail + " " + state);
														jarray.put(jobj);
														log.info("Biller detail for :" + billerName + " is " + billerdetail + ", and state is " + state);
														return jarray.toString();
													  } else
													  {
														returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Mobile number should be digit only");
													  }
												  } else
												  {
													returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Mobile number should be 10 digit");
												  }
											  }
											
											if (!billerName.equalsIgnoreCase("mobile"))
											  {
												int len = consumerno.length();
												if (len == 8)
												  {
													if (consumerno.matches(regex))
													  {
														preparedStatement = getconnection().prepareStatement(addBiller);
														preparedStatement.setString(1, accountno);
														preparedStatement.setString(2, billerName);
														preparedStatement.setString(3, parentid);
														preparedStatement.setString(4, billerdetail);
														preparedStatement.setString(5, childid);
														preparedStatement.setString(6, state);
														preparedStatement.setString(7, nickname);
														preparedStatement.setString(8, consumerno);
														log.info("insert into add_biller (Account_number,biller_name,parent_id,biller_detail,child_id,state,nickname,consumer_no) values (" + accountno + ",'" + billerName + "','" + parentid + "','" + billerdetail + "'," + childid + ",'" + state + "','" + nickname + "'," + consumerno + ")");
														
														preparedStatement.executeUpdate();
														if (count == 0)
														  {
															jarray.put(gobj);
														  }
														count++;
														jobj.put("Success", "Biller Successfully added for child Id : " + childid);
														jarray.put(jobj);
														log.info("Biller Detail for :" + parentid + " is " + billerdetail + ", Child id is " + childid + "and state is " + state);
														return jarray.toString();
														
													  } else
													  {
														returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Consumer number should be digit only");
													  }
												  } else
												  {
													returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Consumer number should be equal to 8");
												  }
											  }
										  } else
										  {
											// returnMessage =
											// getJsonErr(400,"",
											// "Account Number should contain only Numbers");
											returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Biller Detail or State not provided properly.");
											log.info(returnMessage.toString() + " -- " + parentid);
										  }
									  } else
									  {
										returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Cust Id not mapped with any account number");
									  }
									
								  } else
								  {
									returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Nickname can't be blank or null");
								  }
							  } else
							  {
								// returnMessage = getJsonErr(400,"",
								// "Account Number should contain only Numbers");
								returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Child Id not provided properly.");
								log.info(returnMessage.toString() + " -- " + parentid);
							  }
							
						  } else
						  {
							// returnMessage =
							// getJsonErr(400,"","Account Number should be 4
							// digits");
							returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Cust Id should be 8 digits");
							log.info(returnMessage.toString() + " -- " + parentid);
						  }
					  } else
					  {
						// returnMessage =
						// getJsonErr(400,"","Account Number cannot be Empty");
						returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "parent id cannot be Empty");
						
						log.info(returnMessage.toString() + " -- " + parentid);
					  }
				  } else
				  {
					log.info("Token Verification Failed.");
					returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
					jarray.put(returnMessage);
				  }
				// String out = "" + accountno + " : " + result;
				if (jarray.length() == 0)
				  {
					jarray.put(returnMessage);
					result = jarray.toString();
				  } else
				  {
					// jarray.put(jobj);
					result = jarray.toString();
				  }
			  } else
			  {
				jobj.put("code", 454);
				jobj.put("description", "Invalid Parameter");
				jobj.put("message", data);
				jarray.put(jobj);
				System.out.println(jarray.toString());
				return jarray.toString();
			  }
		  } catch (SQLException e)
		  {
			e.printStackTrace();
			returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
			// returnMessage = getJsonErr(400,"",
			// "Database Error. Please try after some time");
			log.info(jobj.toString() + " -- " + parentid);
		  } catch (Exception ex)
		  {
			ex.printStackTrace();
			returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
			// returnMessage = getJsonErr(400,"",
			// "Database Error. Please try after some time");
			log.info(jobj.toString() + " -- " + parentid);
		  } finally
		  {
			try
			  {
				if (rs != null)
				  {
					rs.close();
				  }
				if (rs1 != null)
				  {
					rs1.close();
				  }
				if (rs2 != null)
				  {
					rs2.close();
				  }
				if (rs3 != null)
				  {
					rs3.close();
				  }
				if (preparedStatement != null)
				  {
					preparedStatement.close();
				  }
				if (getconnection() != null)
				  {
					getconnection().close();
				  }
			  } catch (Exception e)
			  {
				e.printStackTrace();
			  }
		  }
		return result;
	  }
	
	@GET
	@Path("/schedulePay")
	@Produces
	public String schedulePay(
		@Context UriInfo uriInfo, 
		@QueryParam("client_id") String client_id, 
		@QueryParam("token") String token, 
		@QueryParam("custid") String custid, 
		@QueryParam("nickname") String nickname, 
		@QueryParam("autodate") String autodate, 
		@QueryParam("limitedpay") String limitedpay, 
		@QueryParam("limitedamt") String limitedamt) throws JSONException
	  {
		log.info("###---- Biller Detail ----###");
		System.out.println("m in");
		Statement statement = null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		String result = "";
		String parentid = "";
		JSONObject jobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		
		log.info("Initiate Auto pay for custId:" + custid + " and NickName " + nickname);
		boolean flag = false;
		log.info("Validation Details " + client_id + " userid is " + token);
		try
		  {
			HashSet<String> set = new HashSet<String>();
			set.add("client_id");
			set.add("token");
			set.add("custid");
			set.add("nickname");
			set.add("autodate");
			set.add("limitedpay");
			set.add("limitedamt");
			statement=getconnection().createStatement();
			String data = keyvalidation(uriInfo, set);
			if (data.equalsIgnoreCase("ok"))
			  {
				
				flag = validateClient(client_id, token, "schedulePay");
				if (flag)
				  {
					String regex = "[0-9]+";
					if (!custid.equals(""))
					  {
						if (custid.length() == 8)
						  {
							if (custid.matches(regex))
							  {
								if (!nickname.trim().equals(""))
								  {
									if (limitedamt.length() < 5||!limitedamt.equalsIgnoreCase(""))
									  {
										if (limitedpay.equalsIgnoreCase("Y") || limitedpay.equalsIgnoreCase("N"))
										  {
											
											int amt = Integer.parseInt(limitedamt);
											if (amt > 1)
											  {
												int auto = Integer.parseInt(autodate);
												
												if (auto > 0 && auto < 16)
												  {
													PreparedStatement preparedStatement = getconnection().prepareStatement(getAccountNo);
													preparedStatement.setString(1, custid);
													rs = preparedStatement.executeQuery();
													if (rs.next())
													  {
														String accountno = rs.getString("accountno");
														System.out.println("Account No :"+accountno);
														System.out.println("nickname  :"+nickname);
														PreparedStatement preparedStatement1 = getconnection().prepareStatement(autoPayCheck);
														preparedStatement1.setString(1, accountno);
														preparedStatement1.setString(2, nickname);
														rs1 = preparedStatement1.executeQuery();
														//System.out.println("rs1 value" +rs1.next());
														System.out.println("select * from add_biller where Account_number = "+accountno+" and nickname = "+nickname+"");
														if (rs1.next())
														  {
															System.out.println("inside add biller while");
															if (limitedpay.equals("N"))
															  {
																
																boolean s=statement.execute("update add_biller set auto_pay = 'Y',date='" + autodate + "',limited_pay = upper('" + limitedpay + "'),limited_amt=NULL where Account_number = '" + accountno + "' and nickname = '" + nickname + "'");
																System.out.println(s);
																if (count == 0)
																  {
																	jarray.put(gobj);
																  }
																count++;
																jobj.put("Success", "Schedule Pay Success For account number : " + accountno + " and NickName : " + nickname);
																jarray.put(jobj);
															  } else
															  {
																  System.out.println("update add_biller set auto_pay = 'Y',date='" + autodate + "',limited_pay = upper('" + limitedpay + "'),limited_amt='" + limitedamt + "' where Account_number = '" + accountno + "' and nickname = '" + nickname + "'");
																statement.execute("update add_biller set auto_pay = 'Y',date='" + autodate + "',limited_pay = upper('" + limitedpay + "'),limited_amt='" + limitedamt + "' where Account_number = '" + accountno + "' and nickname = '" + nickname + "'");
																if (count == 0)
																  {
																	jarray.put(gobj);
																  }
																count++;
																jobj.put("Success", "Schedule Pay Success For account number : " + accountno + " and NickName : " + nickname);
																jarray.put(jobj);
															  }
														  } else
														  {
															returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Nickname not added to the given Cust Id");
														  }
													  } else
													  {
														returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Cust Id not mapped with any account number");
													  }
												  } else
												  {
													returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Schedualed date can be in between 1-15");
												  }
											  } else
											  {
												returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Limited Amount cantnot be less the 1");
											  }
										  } else
										  {
											returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Auto deduction must be Y or N");
										  }
									  } else
									  {
										returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Amount cant be greater then 99999");
									  }
								  } else
								  {
									returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "NickName can't be blank");
								  }
							  } else
							  {
								returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Account number must contains numbers only");
							  }
							
						  } else
						  {
							returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Cust Id must contains 8 digits");
							log.info(returnMessage.toString() + " -- " + parentid);
						  }
						
					  } else
					  {
						returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Account number is mandatory");
						log.info(returnMessage.toString() + " -- " + parentid);
					  }
				  } else
				  {
					returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Access Denied");
					
					log.info(returnMessage.toString() + " -- " + parentid);
				  }
				if (jarray.length() == 0)
				  {
					jarray.put(returnMessage);
					result = jarray.toString();
				  } else
				  {
					result = jarray.toString();
				  }
			  } else
			  {
				jobj.put("code", 454);
				jobj.put("description", "Invalid Parameter");
				jobj.put("message", data);
				jarray.put(jobj);
				System.out.println(jarray.toString());
				return jarray.toString();
			  }
		  }
		
		catch (SQLException e)
		  {
			e.printStackTrace();
			returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
			log.info(jobj.toString() + " -- " + parentid);
		  } catch (Exception ex)
		  {
			ex.printStackTrace();
			returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
			log.info(jobj.toString() + " -- " + parentid);
		  } finally
		  {
			try
			  {
				if (rs != null)
				  {
					rs.close();
				  }
				if (rs1 != null)
				  {
					rs1.close();
				  }
				if (statement != null)
				  {
					statement.close();
				  }
				if (getconnection() != null)
				  {
					getconnection().close();
				  }
			  } catch (Exception e)
			  {
				e.printStackTrace();
			  }
		  }
		return result;
	  }
	
	@GET
	@Path("/billpay")
	@Produces
	public String billpay(@Context UriInfo uriInfo, @QueryParam("client_id") String client_id, @QueryParam("token") String token, @QueryParam("custid") String custid, @QueryParam("nickname") String nickname, @QueryParam("amount") String amount) throws JSONException
	  {
		log.info("###---- Biller Detail ----###");
		System.out.println("m in");
		Statement statement = null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		ResultSet rs2 = null;
		ResultSet rs3 = null;
		String result = "";
		String parentid = "";
		
		log.info("Initiate Auto pay for custid:" + custid + " and NickName " + nickname);
		boolean flag = false;
		log.info("Validation Details " + client_id + " userid is " + token);
		try
		  {
			HashSet<String> set = new HashSet<String>();
			set.add("client_id");
			set.add("token");
			set.add("custid");
			set.add("nickname");
			set.add("amount");
			String data = keyvalidation(uriInfo, set);
			if (data.equalsIgnoreCase("ok"))
			  {
				
				flag = validateClient(client_id, token, "billpay");
				if (flag)
				  {
					String regex = "[0-9]+";
					if (!custid.equals(""))
					  {
						if (custid.length() == 8)
						  {
							if (custid.matches(regex))
							  {
								if (!amount.equals(""))
								  {
									if (amount.matches(regex))
									  {
										if (amount.trim().length() < 6)
										  {
											if (!nickname.equals(""))
											  {
												
												statement = getconnection().createStatement();
												
												rs = statement.executeQuery("select accountno from rtl_account_master where custid=" + custid);
												if (rs.next())
												  {
													String accountno = rs.getString("accountno");
													rs1 = statement.executeQuery("select * from rtl_account_master where Accountno = " + accountno);
													if (rs1.next())
													  {
														rs2 = statement.executeQuery("select * from add_biller where Account_number = " + accountno + " and nickname = '" + nickname + "'");
														if (rs2.next())
														  {
															rs3 = statement.executeQuery("select * from rtl_account_master where Accountno = " + accountno + " and balance >='"+ amount+"'");
															if (rs3.next())
															  {
																System.out.println("M in for sch");
																
																PreparedStatement preparedStatement1 = getconnection().prepareStatement("update rtl_account_master set balance = (balance-?) where accountno = ?");
																preparedStatement1.setInt(1, (int)Double.parseDouble(amount));
																//preparedStatement1.setString(1, amount);
																preparedStatement1.setString(2, accountno);
																int i  = preparedStatement1.executeUpdate();
																
															
																
																System.out.println("updated rows "+i);
																if(i>0){
																//boolean i = statement.execute("update rtl_account_master set balance = (balance-" +amount+ ") where accountno = " + accountno);
																int k = statement.executeUpdate("insert into biller_transaction_master select " + accountno + "," + custid + "," + amount + ",biller_name,biller_detail,consumer_no from add_biller where account_number=" + accountno + " and nickname='" + nickname + "'");
																
																if (k >0)
																  {
																	if (count == 0)
																	  {
																		jarray.put(gobj);
																	  }
																	count++;
																	jobj.put("Success", "Bill paid successfully from account number : " + accountno + " to " + nickname + " biller");
																	jarray.put(jobj);
																  }
																
															  } else
															  {
																returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
															  }
															  } else
															  {
																returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Insufficient fund in account : " + accountno);
															  }
															
														  } else
														  {
															returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Nickname " + nickname + " not added for account number : " + accountno);
														  }
														
													  } else
													  {
														returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "account number : " + accountno + " not available");
													  }
												  } else
												  {
													returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Cust Id not mapped with any account number");
												  }
											  } else
											  {
												returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Nickname cannot be null");
											  }
										  } else
										  {
											returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Amount cant be greater then 99999");
										  }
									  } else
									  {
										returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Amount can be digits only.");
									  }
								  } else
								  {
									returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Amount cannot be blank.");
								  }
							  } else
							  {
								returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Cust Id must contains numbers only");
							  }
							
						  } else
						  {
							returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Cust Id must contains 8 digit");
							log.info(returnMessage.toString() + " -- " + parentid);
						  }
						
					  } else
					  {
						returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Cust Id cannot be blank");
						log.info(returnMessage.toString() + " -- " + parentid);
					  }
				  } else
				  {
					returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Access Denied");
					
					log.info(returnMessage.toString() + " -- " + parentid);
				  }
				if (jarray.length() == 0)
				  {
					jarray.put(returnMessage);
					result = jarray.toString();
				  } else
				  {
					result = jarray.toString();
				  }
			  } else
			  {
				jobj.put("code", 454);
				jobj.put("description", "Invalid Parameter");
				jobj.put("message", data);
				jarray.put(jobj);
				System.out.println(jarray.toString());
				return jarray.toString();
			  }
		  } catch (SQLException e)
		  {
			e.printStackTrace();
			returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
			log.info(jobj.toString() + " -- " + parentid);
		  } catch (Exception ex)
		  {
			ex.printStackTrace();
			returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
			log.info(jobj.toString() + " -- " + parentid);
		  } finally
		  {
			try
			  {
				if (rs != null)
				  {
					rs.close();
				  }
				if (statement != null)
				  {
					statement.close();
				  }
				if (getconnection() != null)
				  {
					getconnection().close();
				  }
			  } catch (Exception e)
			  {
				e.printStackTrace();
			  }
		  }
		return result;
	  }
	
	// Authorize Using debit card details
	@GET
	@Path("/authDebitDetails")
	@Produces
	public String authMyDebitCardDetails(@Context UriInfo uriInfo, @QueryParam("client_id") String client_id, @QueryParam("token") String token, @QueryParam("custid") String custid, @QueryParam("debit_card_no") String debit_card_no, @QueryParam("cvv") String cvv, @QueryParam("expiry_date") String expiry_date, @QueryParam("nickname") String nickname, @QueryParam("amount") String amount)
	    throws JSONException
	  {
		log.info("###---- Authenticate Debit Details ----###");
		Connection connection = null;
		Statement statement = null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		ResultSet rs2 = null;
		ResultSet rs3 = null;
		ResultSet rs4 = null;
		ResultSet rs5 = null;
		JSONObject jobjj = new JSONObject();
		JSONArray jarray = new JSONArray();
		CommonMethod comn = new CommonMethod();
		Boolean accflag = false;
		DatabaseUtil dbUtil = new DatabaseUtil();
		log.info("User debit_card_no :" + debit_card_no);
		String out = "";
		String regex = "[0-9]+";
		log.info("Validation Details userid is " + client_id + " token is " + token);
		CommonMethod comm = new CommonMethod();
		try
		  {
			HashSet<String> set = new HashSet<String>();
			set.add("client_id");
			set.add("token");
			set.add("custid");
			set.add("debit_card_no");
			set.add("cvv");
			set.add("expiry_date");
			set.add("nickname");
			set.add("amount");
			String data = comn.keyvalidation(uriInfo, set);
			if (data.equalsIgnoreCase("ok"))
			  {
				flag = validateClient(client_id, token, "AuthDebitCard");
				if (flag)
				  {
					if (!custid.equals(""))
					  {
						if (custid.length() == 8)
						  {
							if (custid.matches(regex))
							  {
								if (!amount.equals(""))
								  {
									if (amount.matches(regex))
									  {
										if (amount.trim().length() < 6)
										  {
											if (!nickname.equals(""))
											  {
												
												log.info("cust id validated");
												accflag = comn.authenticateCustidOnly("C", custid, client_id, getconnection());
												if (accflag)
												  {
													log.info("AuthDebitCard try");
													statement = getconnection().createStatement();
													rs = statement.executeQuery("SELECT custid,Debit_card_no,cvv ,exp_date,Type_of_card FROM rtl_account_master  where custid ='" + custid + "'");
													if (rs.next())
													  {
														log.info("inside AuthmyDebitCardDetails while");
														JSONObject jobj = new JSONObject();
														if (debit_card_no.equalsIgnoreCase(rs.getString("Debit_card_no")) || rs.getString("Debit_card_no") == null || rs.getString("Debit_card_no") == "")
														  {
															log.info("debit success");
															if (cvv.length() == 3)
															  {
																log.info("cvv success cvv lenght is" + cvv.length());
																if (cvv.equalsIgnoreCase(rs.getString("cvv")))
																  {
																	if (expiry_date.length() == 5)
																	  {
																		if (expiry_date.equalsIgnoreCase(rs.getString("exp_date")))
																		  {
																			if (amount.matches(regex))
																			  {
																				if (custid.matches(regex) && custid.length() == 8)
																				  {
																					rs2 = statement.executeQuery("select accountno from rtl_account_master where custid=" + custid);
																					if (rs2.next())
																					  {
																						String accountno = rs2.getString("accountno");
																						rs3 = statement.executeQuery("select * from rtl_account_master where Accountno = " + accountno);
																						if (rs3.next())
																						  {
																							rs4 = statement.executeQuery("select * from add_biller where Account_number = " + accountno + " and nickname = '" + nickname + "'");
																							if (rs4.next())
																							  {
																								rs5 = statement.executeQuery("select * from rtl_account_master where Accountno = " + accountno + " and balance >=" + amount);
																								if (rs5.next())
																								  {
																									
																									
																									boolean i = statement.execute("update rtl_account_master set balance = (convert(float,balance)-" + amount + ") where accountno = " + accountno);
																									boolean k = statement.execute("insert into biller_transaction_master select " + accountno + "," + custid + "," + amount + ",biller_name,biller_detail,consumer_no from add_biller where account_number=" + accountno + " and nickname='" + nickname + "'");
																									if (!k)
																									  {
																										if (count == 0)
																										  {
																											jarray.put(gobj);
																										  }
																										count++;
																										jobj.put("Success", "Bill paid successfully from account number : " + accountno + " to " + nickname + " biller");
																										jarray.put(jobj);
																									  }
																									
																								  } else
																								  {
																									returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Insufficient fund in account : " + accountno);
																								  }
																								
																							  } else
																							  {
																								returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Biller " + nickname + " not added for account number : " + accountno);
																							  }
																							
																						  } else
																						  {
																							returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "account number : " + accountno + " not available");
																						  }
																					  } else
																					  {
																						returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Cust Id not mapped with any account number");
																					  }
																					
																					log.info("count is :" + count);
																					if (count == 0)
																					  {
																						jarray.put(gobj);
																					  }
																					count++;
																					log.info("new count is :" + count);
																					log.info("jarray object size before" + jarray.length());
																					log.info("adding jarray object" + jarray.length());
																				  } else
																				  {
																					returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "account number must be numeric and 16 digit");
																				  }
																				
																			  } else
																			  {
																				returnMessage = comm.getJsonErr(400, "Bad Request Parameter", "Amount must be numeric");
																			  }
																		  } else
																		  {
																			returnMessage = comm.getJsonErr(102, "Wrong Expiry date Entered", "Wrong  Expiry date Entered by Participant");
																		  }
																	  } else
																	  {
																		returnMessage = comm.getJsonErr(102, "Wrong Expiry date Entered", "Wrong  Expiry date Entered by Participant");
																	  }
																  } else
																  {
																	returnMessage = comm.getJsonErr(101, "Wrong CVV Number Entered", "This cvv number does not belongs to participant");
																  }
															  } else
															  {
																returnMessage = comm.getJsonErr(101, "Wrong CVV Number Entered", "Wrong cvv number Entered by Participant");
															  }
														  } else
														  {
															returnMessage = comm.getJsonErr(101, "Wrong Debit card Number Entered", "This Customer Debit card does not belongs to participant");
														  }
													  }
												  } else
												  {
													returnMessage = comm.getJsonErr(401, "User Not Authorized", "This Customer ID does not belongs to participant");
													log.info(returnMessage.toString() + " -- " + custid);
												  }
											  } else
											  {
												returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Nickname cannot be null");
											  }
										  } else
										  {
											returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Amount cant be greater then 99999");
										  }
									  } else
									  {
										returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Amount can be digits only.");
									  }
								  } else
								  {
									returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Amount cannot be blank.");
								  }
							  } else
							  {
								returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Cust Id must contains numbers only");
							  }
							
						  } else
						  {
							// returnMessage = getJsonErr(400,"",
							// "Account Number should contain only Numbers");
							returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Cust Id must contains 8 digit");
							// log.info(returnMessage.toString() + " -- " +
							// parentid);
						  }
						
					  } else
					  {
						// returnMessage =
						// getJsonErr(400,"","Account Number should be 4
						// digits");
						returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Cust Id cannot be blank");
						// log.info(returnMessage.toString() + " -- " +
						// parentid);
					  }
					
				  } else
				  {
					log.info("Token Verification Failed.");
					returnMessage = comm.getJsonErr(401, "User Not Authorized", "Access Denied");
					jarray.put(returnMessage);
				  }
				log.info("checking jarray size" + jarray.length());
				if (jarray.length() == 0)
				  {
					returnMessage = comm.getJsonErr(503, "", "card does not exist");
					jarray.put(returnMessage);
					out = jarray.toString();
				  } else
				  {
					out = jarray.toString();
				  }
			  } else
			  {
				jobjj.put("code", 454);
				jobjj.put("description", "Invalid Parameter");
				jobjj.put("message", data);
				jarray.put(jobjj);
				System.out.println(jarray.toString());
				return jarray.toString();
			  }
		  } catch (SQLException e)
		  {
			
			returnMessage = comm.getJsonErr(501, "", "Database Error. Please try after some time");
			log.info(returnMessage + " -- " + custid);
			e.printStackTrace();
		  } catch (Exception ex)
		  {
			returnMessage = comm.getJsonErr(501, "", "Database Error. Please try after some time");
			log.info(returnMessage + " -- " + custid);
			ex.printStackTrace();
		  } finally
		  {
			try
			  {
				if (rs != null)
				  {
					rs.close();
				  }
				if (rs1 != null)
				  {
					rs1.close();
				  }
				if (rs2 != null)
				  {
					rs2.close();
				  }
				if (rs3 != null)
				  {
					rs3.close();
				  }
				if (rs4 != null)
				  {
					rs4.close();
				  }
				if (statement != null)
				  {
					statement.close();
				  }
				if (getconnection() != null)
				  {
					getconnection().close();
				  }
			  } catch (Exception e)
			  {
				e.printStackTrace();
			  }
		  }
		return out;
	  }
	
	public JSONObject getJsonErr(int errCd, String errMsg, String errDesc) throws JSONException
	  {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("code", errCd);
		
		if (errCd == 400)
		  {
			jsonObject.put("message", "Bad request. Invalid Request parameter");
		  } else if (errCd == 501)
		  {
			jsonObject.put("message", "Processing error � One or more of internal systems gave an error while processing the request");
		  } else if (errCd == 503)
		  {
			jsonObject.put("message", "No Data Found");
		  } else
		  {
			jsonObject.put("message", errMsg);
			
		  }
		jsonObject.put("description", errDesc);
		log.info("getJsonErr() -->" + jsonObject.toString());
		return jsonObject;
	  }
	
	public boolean validateClient(String client_id, String token, String api_name) throws JSONException
	  {
		// Connection connection = null;
		JSONArray jarray = new JSONArray();
		ResultSet rs = null;
		Statement statement = null;
		// String client_id = "";
		StringWriter errors = new StringWriter();
		String query = "";
		boolean flag = false;
		String current_time = null;
		log.info("Inside validateClient method LOWER(client_id) is " + client_id.toLowerCase() + " token is " + token);
		try
		  {
			System.out.println("Validate Connection Accept : " + getconnection());
			
			Date currdate = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
			current_time = formatter.format(currdate);
			// }
			if (!client_id.equals(""))
			  {
				System.out.println("client");
				if (!token.equals(""))
				  {
					query = "select client_id,token from participant_token_details " + "where client_id='" + client_id + "' and token = '" + token + "'";
					System.out.println(query);
					System.out.println("token");
					log.info("VALIDATE_____________" + query);
					statement = getconnection().createStatement();
					rs = statement.executeQuery(query);
					
					while (rs.next())
					  {
						System.out.println("****************************************************");
						JSONObject jobj = new JSONObject();
						jobj.put("client_id", rs.getString(1));
						jobj.put("token", rs.getString(2));
						jarray.put(jobj);
					  }
					if (jarray.length() != 0)
					  {
						flag = true;
						setApiUsageStatus(client_id, api_name);
					  } else
					  {
						returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
						jarray.put(returnMessage);
					  }
					System.out.println("validate-" + flag);
					return flag;
				  } else
				  {
					log.info("Inside validateClient(..) method ---> token input is found blank");
					
					return flag;
				  }
			  } else
			  {
				log.info("Inside validateClient(..) method ---> client_id id input is not set");
				
				return flag;
			  }
		  } catch (SQLException e)
		  {
			e.printStackTrace();
			returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
			jarray.put(returnMessage);
			e.printStackTrace(new PrintWriter(errors));
			return flag;
			
		  } catch (Exception e)
		  {
			e.printStackTrace();
			return flag;
			
		  } finally
		  {
			try
			  {
				if (rs != null)
				  {
					rs.close();
				  }
				
				if (statement != null)
				  {
					statement.close();
				  }
			  } catch (Exception e)
			  {
				e.printStackTrace();
			  }
			// return flag;
		  }
	  }
	
	public Boolean validateCustid(String custid)
	  {
		String regex = "[0-9]+";
		if (custid.length() == 8)
		  {
			if (custid.matches(regex))
			  {
				return true;
			  } else
			  {
				return false;
			  }
		  } else
		  {
			return false;
		  }
	  }
	
	public void setApiUsageStatus(String client_id, String api_name)
	  {
		String query = "";
		// Connection connection = null;
		PreparedStatement pstatement = null;
		// String client_id = "";
		boolean returnValue = false;
		String current_time = null;
		log.info("Inside setApiUsageStatus client_id is " + client_id + " api_name is " + api_name);
		try
		  {
			
			Date currdate = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
			current_time = formatter.format(currdate);
			query = "insert into participant_apiusage_rev(client_id,api_name,time) values(?,?,?)";
			pstatement = getconnection().prepareStatement(query);
			pstatement.setString(1, client_id);
			pstatement.setString(2, api_name);
			pstatement.setString(3, current_time);
			returnValue = pstatement.execute();
			connection.commit();
			log.info("Inside setApiUsageStatus Insert Status : " + returnValue);
		  } catch (Exception e)
		  {
			e.printStackTrace();
			log.warning("Exception in setApiUsageStatus : " + e.getMessage());
		  } finally
		  {
			try
			  {
				if (pstatement != null)
				  {
					pstatement.close();
				  }
			  } catch (Exception e)
			  {
				e.printStackTrace();
			  }
		  }
		
	  }
	
  }