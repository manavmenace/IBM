package appathon.bluemix.service;

import java.sql.Connection;

public interface SqlQueries
  {
	public Connection getconnection();
	String getBillerDetails    = "select BILLER_DETAIL, child_id, state from BILLERS_DETAILS where lower(BILLER_NAME) = ?";
	String getAccountNumber    = "select accountno from rtl_account_master where custid=?";
	String checkNickName       = "select * from add_biller where account_number = ? and nickname = ?";
	String getAddBillerDetails = "select * from BILLERS_DETAILS where lower(biller_detail) = ? and lower(state)=?";
	String addBiller           = "insert into add_biller (Account_number,biller_name,parent_id,biller_detail,child_id,state,nickname,consumer_no) values (?,?,?,?,?,?,?,?)";
	String getAccountNo        = "select accountno from rtl_account_master where custid= ?";
	String autoPayCheck        = "select * from add_biller where Account_number = ? and nickname = ? ";
  }
