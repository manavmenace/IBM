package appathon.bluemix.service;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.logging.Logger;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.UriInfo;


public class CreditCardDAO {
	private static final Logger log = Logger.getLogger(CreditCardDAO.class.getName());

	protected String keyvalidation(UriInfo uriInfo, HashSet<String> set) {
		StringBuilder sb=new StringBuilder();
		try {
			System.out.println(uriInfo.getQueryParameters());
			
			MultivaluedMap<String, String> params = uriInfo.getQueryParameters();
			
			
			System.out.println("**********" + set);

			System.out.println(params.keySet().containsAll(set));
			
			for(String d :set){
			if (params.keySet().containsAll(set)) {
				return "ok";
			} 
			System.out.println();
			if (!params.containsKey(d)){
				sb.append(d+"----");
			}
			}
			return "key issue for "+sb.toString();
			
		} catch (Exception e) {
			
			System.err.println(e.getMessage());
		}
		return "please Check all key it should be " + set + " only";
	}
	public String addCreditCard(Integer cust_Id, String cardType, Integer userCardNo, String expDate, String cvvNo) {
		
		Connection connection = null;
		Statement statement = null;
		DatabaseUtil util = new DatabaseUtil();
		String result = "";
		String preDefinedCardNo = "437551021234";
		
		//For DB2
		String query = "INSERT INTO RTL_CARD_DETAILS (CARD_NUMBER, CARD_TYPE, CARD_STATUS, CUSTID, CARD_EXPIRY_DATE, AVAIL_LMT, OVERSEAS_FLG, CVV_NO) values "
						+ "('" + preDefinedCardNo + userCardNo + "', '" + cardType + "', 'ACTIVE', '" + cust_Id + "', '" + expDate + "', '40000', 'N', '" + cvvNo + "')";
		
		//For SQL
		/*String query = "INSERT INTO RTL_CARD_DETAILS (CARD_NUMBER, CARD_TYPE, CARD_STATUS, CUSTID, CARD_EXPIRY_DATE, AVAIL_LMT, OVERSEAS_FLG, CVV_NO) values "
				+ "('" + preDefinedCardNo + userCardNo + "', '" + cardType + "', 'ACTIVE', '" + cust_Id + "', '" + expDate + "', '40000', 'N', '" + cvvNo + "')";*/
		try {
			
			if (connection == null || connection.isClosed()) {
				log.info("Inside addCreditCard connection open : " + connection);
				connection = util.getConnection();
			}
			connection = util.getConnection();
	
			statement = connection.createStatement();
			log.info("insert query is::" + query);
			int records = statement.executeUpdate(query);
			
			if (records >= 1) {
				result = "Credit Card Details Added Successfully for custId : " + cust_Id;
				
			} else {
				result = "Some error occured while adding Credit Card details!";
			}
		
		}  catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result;
		
	}


	public String changeCreditLimit(Integer cust_Id, String creditLimit) {
		
		Connection connection = null;
		Statement statement = null;
		DatabaseUtil util = new DatabaseUtil();
		String result = "";
		
		String query = "UPDATE RTL_CARD_DETAILS SET AVAIL_LMT = " + creditLimit + " where CUSTID = " + cust_Id;	//For DB2
		/*String query = "UPDATE RTL_CARD_DETAILS SET AVAIL_LMT = " + creditLimit + " where CUSTID = " + cust_Id;*/	//For SQL
		
		try {
			
			if (connection == null || connection.isClosed()) {
				log.info("Inside transactioninterval connection open : " + connection);
				connection = util.getConnection();
			}
			connection = util.getConnection();
	
			statement = connection.createStatement();
			log.info("update query is::" + query);
			int records = statement.executeUpdate(query);
			
			log.info("records updated:::" + records);
			
			if (records >= 1) {
				result = "Credit Limit changed Successfully to " + creditLimit + " for custId : " + cust_Id;
				
			} else {
				result = "Some error occured while adding Credit Card details!";
			}
			
		
		}  catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		return result;
		
	}



	public String changeOverseasFlag(Integer cust_Id, String overseaasFlag) {
		
		Connection connection = null;
		Statement statement = null;
		DatabaseUtil util = new DatabaseUtil();
		String result = "";
		
		String query = "UPDATE RTL_CARD_DETAILS SET OVERSEAS_FLG = '" + overseaasFlag + "' where CUSTID = " + cust_Id;		//For DB2
		/*String query = "UPDATE RTL_CARD_DETAILS SET OVERSEAS_FLG = '" + overseaasFlag + "' where CUSTID = " + cust_Id;*/		//For SQL
		
		try {
			
			if (connection == null || connection.isClosed()) {
				log.info("Inside changeOverseasFlag connection open : " + connection);
				connection = util.getConnection();
			}
			connection = util.getConnection();
	
			statement = connection.createStatement();
			log.info("update query is::" + query);
			int records = statement.executeUpdate(query);
			
			log.info("records updated:::" + records);
			
			if (records >= 1) {
				
				if (overseaasFlag.equals("Y")) {
					result = "Card activated successfully for overseas use for custId : " + cust_Id;
				} else {
					result = "Card deactivated successfully for overseas use for custId : " + cust_Id;
				}
			} else {
				result = "Some error occured while changing overseas flag!";
			}
			
		
		}  catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		
		return result;
	}



	public String changeCardStatus(Integer cust_Id, String cardStatus) {
		
		Connection connection = null;
		Statement statement = null;
		DatabaseUtil util = new DatabaseUtil();
		String result = "";
		
		String query = "UPDATE RTL_CARD_DETAILS SET CARD_STATUS = '" + cardStatus + "' where CUSTID = " + cust_Id;		//For DB2
		/*String query = "UPDATE RTL_CARD_DETAILS SET CARD_STATUS = '" + cardStatus + "' where CUSTID = " + cust_Id;*/		//For SQL
		
		try {
			
			if (connection == null || connection.isClosed()) {
				log.info("Inside blockCard connection open : " + connection);
				connection = util.getConnection();
			}
			connection = util.getConnection();
	
			statement = connection.createStatement();
			log.info("update query is::" + query);
			int records = statement.executeUpdate(query);
			
			log.info("records updated:::" + records);
			
			if (records >= 1) {
				result = "Card status changed successfully to " + cardStatus + " for custId : " + cust_Id;
			} else {
				result = "Some error occured while blocking card";
			}
			
		
		}  catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		
		return result;
	}
	
	public Boolean isCardExistForCustId(Integer cust_Id) {
		
		Connection connection = null;
		Statement statement = null;
		ResultSet rs = null;
		DatabaseUtil util = new DatabaseUtil();
		
		Boolean isExist = false;
		Integer cnt = 0;
		
		String query = "select count(*) from rtl_card_details where CUSTID = " + cust_Id;		//For DB2
		/*String query = "select count(*) from rtl_card_details where CUSTID = " + cust_Id;*/		//For SQL
		
		try {
			
			if (connection == null || connection.isClosed()) {
				log.info("Inside isCardExistForCustId connection open : " + connection);
				connection = util.getConnection();
			}
			connection = util.getConnection();
	
			statement = connection.createStatement();
			log.info("select query is::" + query);
			rs = statement.executeQuery(query);
			
			while (rs.next()) {
				cnt = rs.getInt(1);
				log.info("Count::" + cnt);
			}
			
			if (cnt > 0) {
				isExist = true;
			}
			
		
		}  catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		return isExist;
	}
	
}