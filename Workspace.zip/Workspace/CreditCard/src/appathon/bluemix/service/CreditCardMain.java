package appathon.bluemix.service;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.TimeZone;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;




@Path("/icici")
public class CreditCardMain
	{
		/*
		 * private static final Logger logger =
		 * Logger.getLogger(CreditCardMain.class.getName());
		 */
		public CreditCardMain() throws JSONException
			{
				System.out.println("-------------Constructor------------");
				gobj.put("code", 200);
				count = 0;
			}

		
		JSONObject returnMessage = new JSONObject();
		CreditCardDAO dao = new CreditCardDAO();
		JSONObject gobj = new JSONObject();
		boolean flag;
		public int count;

		//http://localhost:8080/CreditCard/CreditCard/icici/addCreditCard?client_id=palak@gmail.com&token=7474&custId=33335474&cardType=MASTERCARD&cardNo=7744&expDate=05-16&cvvNo=789
		@GET
		@Path("/addCreditCard")
		@Produces
		public String addCreditCard(@Context UriInfo uriInfo,@QueryParam("client_id")
		String clientId, @QueryParam("token")
		String token, @QueryParam("cust_id")
		String custId, @QueryParam("card_type")
		String cardType, @QueryParam("card_no")
		String cardNo, @QueryParam("exp_date")
		String expDate, @QueryParam("cvv_no")
		String cvvNo) throws JSONException
			{
				System.out.println("user.home dir::: " + System.getProperty("user.home"));
				// logger.info("Inside addCreditCard method()......");
				System.out.println("###---- Add Credit Card ----###");
				Connection connection = null;
				Statement statement = null;
				ResultSet rs = null;
				String result = "";
				DatabaseUtil dbUtil = new DatabaseUtil();
				JSONObject jobj = new JSONObject();
				JSONArray jarray = new JSONArray();
				System.out.println("Adding Card details started for customerId :" + custId);
				Boolean isValidCustId = false;
				String response = "";
				String apiName = "addCreditCard";
				try
					{
						HashSet<String> set = new HashSet<String>();
						set.add("client_id");
						set.add("token");
						set.add("cust_id");
						set.add("card_type");
						set.add("card_no");
						set.add("exp_date");
						set.add("cvv_no");
						String data=dao.keyvalidation(uriInfo,set);
						if(data.equalsIgnoreCase("ok"))
						{
						if (connection == null || connection.isClosed())
							{
								System.out.println("Inside getMessage connection open : " + connection);
								connection = dbUtil.getConnection();
							}
						if (validateClient(clientId, token, apiName, connection))
							{
								if (custId != null && !custId.isEmpty())
									{
										isValidCustId = authenticateCustId(custId, clientId, connection);
										if (isValidCustId)
											{
												cardType = cardType.toUpperCase();
												if (validateCardDetails(cardType, cardNo, expDate, cvvNo))
													{
														System.out.println("Card Validation Success");
														Integer cust_Id = Integer.parseInt(custId);
														Integer card_No = Integer.parseInt(cardNo);
														if (!dao.isCardExistForCustId(cust_Id))
															{
																response = dao.addCreditCard(cust_Id, cardType, card_No, expDate, cvvNo);
																jarray.put(gobj);
																jobj.put("response", response);
																jarray.put(jobj);
															}
														else
															{
																returnMessage = getJsonErr(400, "Invalid Request.", "Credit Card already exists for the cust id " + custId);
																jarray.put(returnMessage);
															}
													}
											}
										else
											{
												returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Customer ID invalid. It should be 8 Digits & can contain only Numbers");
											}
									}
								else
									{
										returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Customer ID cannot be null");
									}
							}
						else
							{
								System.out.println("Token Verification Failed.");
								returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
							}
					}
					else
						{
							returnMessage.put("code",454);
							returnMessage.put("description","Invalid Parameter");
							returnMessage.put("message",data);
							jarray.put(returnMessage);
							System.out.println(jarray.toString());
							return jarray.toString();
						}
				}
				catch (SQLException e)
					{
						e.printStackTrace();
						returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
					}
				catch (Exception ex)
					{
						ex.printStackTrace();
						returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
					}
				finally
					{
						try
							{
								if (rs != null)
									{
										rs.close();
									}
								if (statement != null)
									{
										statement.close();
									}
								if (connection != null)
									{
										connection.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				if (jarray.length() == 0)
					{
						jarray.put(returnMessage);
						result = jarray.toString();
					}
				else
					{
						result = jarray.toString();
					}
				return result;
			}


		@GET
		@Path("/changeCreditLimit")
		@Produces
		public String changeCreditLimit(@Context UriInfo uriInfo,@QueryParam("client_id")
		String clientId, @QueryParam("token")
		String token, @QueryParam("cust_id")
		String custId, @QueryParam("credit_limit")
		String creditLimit) throws JSONException
			{
				Connection connection = null;
				Statement statement = null;
				ResultSet rs = null;
				DatabaseUtil dbUtil = new DatabaseUtil();
				JSONObject jobj = new JSONObject();
				JSONArray jarray = new JSONArray();
				System.out.println("Change Credit Limit for customerId :" + custId);
				Boolean isValidCustId = false;
				String result = "";
				String response = "";
				String apiName = "changeCreditLimit";
				try
					{
						HashSet<String> set = new HashSet<String>();
						set.add("client_id");
						set.add("token");
						set.add("cust_id");
						set.add("credit_limit");
						String data=dao.keyvalidation(uriInfo,set);
						if(data.equalsIgnoreCase("ok"))
						{
						if (connection == null || connection.isClosed())
							{
								System.out.println("Inside changeCreditLimit connection open : " + connection);
								connection = dbUtil.getConnection();
							}
						if (validateClient(clientId, token, apiName, connection))
							{
								if (!custId.isEmpty())
									{
										isValidCustId = authenticateCustId(custId, clientId, connection);
										if (isValidCustId)
											{
												if (validateCreditLimit(creditLimit))
													{
														Integer cust_Id = Integer.parseInt(custId);
														if (dao.isCardExistForCustId(cust_Id))
															{
																response = dao.changeCreditLimit(cust_Id, creditLimit);
																jarray.put(gobj);
																jobj.put("response", response);
																jarray.put(jobj);
															}
														else
															{
																returnMessage = getJsonErr(503, "No Data Found.", "Credit card does not exist. Please add Credit Card first to proceed");
															}
													}
											}
										else
											{
												returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Customer ID should be 8 Digits & can contain only Numbers");
											}
									}
								else
									{
										returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Customer ID cannot be null");
									}
							}
						else
							{
								System.out.println("Token Verification Failed.");
								returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
							}
						}
						else
						{
							returnMessage.put("code",454);
							returnMessage.put("description","Invalid Parameter");
							returnMessage.put("message",data);
							jarray.put(returnMessage);
							System.out.println(jarray.toString());
							return jarray.toString();
						}
					}
				catch (SQLException e)
					{
						e.printStackTrace();
						returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
					}
				catch (Exception ex)
					{
						ex.printStackTrace();
						returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
					}
				finally
					{
						try
							{
								if (rs != null)
									{
										rs.close();
									}
								if (statement != null)
									{
										statement.close();
									}
								if (connection != null)
									{
										connection.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				if (jarray.length() == 0)
					{
						jarray.put(returnMessage);
						result = jarray.toString();
					}
				else
					{
						result = jarray.toString();
					}
				return result;
			}


		@GET
		@Path("/activateCardOverseas")
		@Produces
		public String activateCardOverseas(@Context UriInfo uriInfo,@QueryParam("client_id")
		String clientId, @QueryParam("token")
		String token, @QueryParam("cust_id")
		String custId, @QueryParam("overseas_flag")
		String overseasFlag) throws JSONException
			{
				Connection connection = null;
				Statement statement = null;
				ResultSet rs = null;
				DatabaseUtil dbUtil = new DatabaseUtil();
				JSONObject jobj = new JSONObject();
				JSONArray jarray = new JSONArray();
				System.out.println("Change overseas activation for customerId :" + custId);
				Boolean isValidCustId = false;
				String response = "";
				String result = "";
				String apiName = "activateCardOverseas";
				try
					{
						HashSet<String> set = new HashSet<String>();
						set.add("client_id");
						set.add("token");
						set.add("cust_id");
						set.add("overseas_flag");
						String data=dao.keyvalidation(uriInfo,set);
						if(data.equalsIgnoreCase("ok"))
						{
						if (connection == null || connection.isClosed())
							{
								System.out.println("Inside activateCardOverseas connection open : " + connection);
								connection = dbUtil.getConnection();
							}
						if (validateClient(clientId, token, apiName, connection))
							{
								if (!custId.isEmpty())
									{
										isValidCustId = authenticateCustId(custId, clientId, connection);
										if (isValidCustId)
											{
												if (validateFlag(overseasFlag))
													{
														Integer cust_Id = Integer.parseInt(custId);
														if (dao.isCardExistForCustId(cust_Id))
															{
																response = dao.changeOverseasFlag(cust_Id, overseasFlag);
																jarray.put(gobj);
																jobj.put("response", response);
																jarray.put(jobj);
															}
														else
															{
																returnMessage = getJsonErr(503, "No Data Found.", "Credit card does not exist. Please add Credit Card first to proceed");
															}
													}
												else
													{
														returnMessage = getJsonErr(400, "Bad request. Invalid Request Parameter.", "Overseas Flag can only be either Y or N");
													}
											}
										else
											{
												returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Customer ID should be 8 Digits & can contain only Numbers");
											}
									}
								else
									{
										returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Customer ID cannot be null");
									}
							}
						else
							{
								System.out.println("Token Verification Failed.");
								returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
							}
						}
						else
						{
							returnMessage.put("code",454);
							returnMessage.put("description","Invalid Parameter");
							returnMessage.put("message",data);
							jarray.put(returnMessage);
							System.out.println(jarray.toString());
							return jarray.toString();
						}
					}
				catch (SQLException e)
					{
						e.printStackTrace();
						returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
					}
				catch (Exception ex)
					{
						ex.printStackTrace();
						returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
					}
				finally
					{
						try
							{
								if (rs != null)
									{
										rs.close();
									}
								if (statement != null)
									{
										statement.close();
									}
								if (connection != null)
									{
										connection.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				if (jarray.length() == 0)
					{
						jarray.put(returnMessage);
						result = jarray.toString();
					}
				else
					{
						result = jarray.toString();
					}
				return result;
			}


		@GET
		@Path("/changeCardStatus")
		@Produces
		public String changeCardStatus(@Context UriInfo uriInfo,@QueryParam("client_id")
		String clientId, @QueryParam("token")
		String token, @QueryParam("cust_id")
		String custId, @QueryParam("card_status")
		String cardStatus) throws JSONException
			{
				Connection connection = null;
				Statement statement = null;
				ResultSet rs = null;
				String result = "";
				DatabaseUtil dbUtil = new DatabaseUtil();
				JSONObject jobj = new JSONObject();
				JSONArray jarray = new JSONArray();
				System.out.println("Block Card for customerId :" + custId);
				Boolean isValidCustId = false;
				String response = "";
				String apiName = "changeCardStatus";
				try
					{
						HashSet<String> set = new HashSet<String>();
						set.add("client_id");
						set.add("token");
						set.add("cust_id");
						set.add("card_status");
						String data=dao.keyvalidation(uriInfo,set);
						if(data.equalsIgnoreCase("ok"))
						{
						if (connection == null || connection.isClosed())
							{
								System.out.println("Inside blockCard connection open : " + connection);
								connection = dbUtil.getConnection();
							}
						if (validateClient(clientId, token, apiName, connection))
							{
								if (!custId.isEmpty())
									{
										isValidCustId = authenticateCustId(custId, clientId, connection);
										if (isValidCustId)
											{
												Integer cust_Id = Integer.parseInt(custId);
												cardStatus = cardStatus.toUpperCase();
												if (cardStatus.equals("ACTIVE") || cardStatus.equals("INACTIVE"))
													{
														if (dao.isCardExistForCustId(cust_Id))
															{
																response = dao.changeCardStatus(cust_Id, cardStatus);
																jarray.put(gobj);
																jobj.put("response", response);
																jarray.put(jobj);
															}
														else
															{
																returnMessage = getJsonErr(503, "No Data Found.", "Credit card does not exist. Please add Credit Card first to proceed");
															}
													}
												else
													{
														returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Invalid Card Status");
													}
											}
										else
											{
												returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Customer ID should be 8 Digits & can contain only Numbers");
											}
									}
								else
									{
										returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Customer ID cannot be null");
									}
							}
						else
							{
								System.out.println("Token Verification Failed.");
								returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
							}
					}
						else
						{
							returnMessage.put("code",454);
							returnMessage.put("description","Invalid Parameter");
							returnMessage.put("message",data);
							jarray.put(returnMessage);
							System.out.println(jarray.toString());
							return jarray.toString();
						}
					}
				catch (SQLException e)
					{
						e.printStackTrace();
						returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
					}
				catch (Exception ex)
					{
						ex.printStackTrace();
						returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
					}
				finally
					{
						try
							{
								if (rs != null)
									{
										rs.close();
									}
								if (statement != null)
									{
										statement.close();
									}
								if (connection != null)
									{
										connection.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				if (jarray.length() == 0)
					{
						jarray.put(returnMessage);
						result = jarray.toString();
					}
				else
					{
						result = jarray.toString();
					}
				return result;
			}


		public Boolean validateClient(String client_id, String token, String apiName, Connection connection) throws JSONException
			{
				System.out.println("Inside validateClient method LOWER(client_id) is " + client_id.toLowerCase() + " token is " + token);
				JSONArray jarray = new JSONArray();
				ResultSet rs = null;
				Statement statement = null;
				String query = "";
				Boolean flag = false;
				// String current_time = null;
				DatabaseUtil dbUtil = new DatabaseUtil();
				try
					{
						System.out.println("Validate Connection Accept : " + connection);
						if (connection == null || connection.isClosed())
							{
								connection = dbUtil.getConnection();
							}
						// Date currDate = new Date();
						//SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						//formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
						// current_time = formatter.format(currDate);
						if (!client_id.equals(""))
							{
								if (!token.equals(""))
									{
										
										/*  query =
										  "select client_id,token from participant_token_details where LOWER(client_id)='"
										  + client_id.toLowerCase() +
										  "' and token='" + token +
										  "' and (SELECT timestampdiff (4, char(timestamp(p.expiry_time)-timestamp('"
										  + "' and (SELECT datediff(mi, '" +
										  "current_time" + "', p.expiry_time) " +
										  "FROM participant_token_details p where LOWER(p.client_id)='"
										  + client_id.toLowerCase() +
										  "' and p.token='" + token + "') >0";*/
										  // For SQL OLD
										/*
										 * query =
										 * "select client_id, token from participant_token_details "
										 * + "where LOWER(client_id)='" +
										 * client_id.toLowerCase() +
										 * "' and token ='" + token +
										 * "'  and  EXPIRY_TIME > CURRENT_TIMESTAMP"
										 * ;
										 */ // For SQL
										query = "select client_id, token from participant_token_details " + "where client_id='" + client_id + "' and token ='" + token + "'"; // For
																																																													// DB2
										System.out.println("VALIDATE_____________" + query);
										statement = connection.createStatement();
										rs = statement.executeQuery(query);
										while (rs.next())
											{
												System.out.println("****************************************************");
												JSONObject jobj = new JSONObject();
												//System.out.println("client_id from DB::" + rs.getString(1));
												//System.out.println("token from DB::" + rs.getString(2));
												jobj.put("client_id", rs.getString(1));
												jobj.put("token", rs.getString(2));
												jarray.put(jobj);
											}
										/*
										 * while (rs.next()) {
										 * System.out.println("From DB2::" +
										 * rs.getString(1)); }
										 */
										if (jarray.length() != 0)
											{
												flag = true;
												setApiUsageStatus(client_id, apiName, connection);
											}
										else
											{
												returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
												jarray.put(returnMessage);
											}
										System.out.println("validate flag-" + flag);
										return flag;
									}
								else
									{
										System.out.println("Inside validateClient(..) method ---> token input is found blank");
										return flag;
									}
							}
						else
							{
								System.out.println("Inside validateClient(..) method ---> client_id id input is not set");
								return flag;
							}
					}
				catch (SQLException e)
					{
						e.printStackTrace();
						returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
						return flag;
					}
				catch (Exception e)
					{
						e.printStackTrace();
						return flag;
					}
				finally
					{
						try
							{
								if (rs != null)
									{
										rs.close();
									}
								if (statement != null)
									{
										statement.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
			}


		public Boolean authenticateCustId(String custid, String client_id, Connection connection)
			{
				System.out.println("------------ authenticateCustId--------------Account No : " + custid);
				String query = "Select CUSTID from PARTICIPANT_MASTER  where LOWER(CLIENT_ID)='" + client_id.toLowerCase() + "'"; // For
																																			// DB2
				/*
				 * String query=
				 * "Select CUSTID from PARTICIPANT_MASTER  where LOWER(CLIENT_ID)='"
				 * + client_id.toLowerCase()+"'";
				 */ // For SQL
				DatabaseUtil util = new DatabaseUtil();
				String cust_ids = null;
				Statement statement = null;
				ResultSet rs = null;
				try
					{
						if (connection == null || connection.isClosed())
							{
								System.out.println("Inside authenticateCustidOnly connection open : " + connection);
								connection = util.getConnection();
							}
						statement = connection.createStatement();
						rs = statement.executeQuery(query);
						while (rs.next())
							{
								cust_ids = rs.getString("CUSTID");
							}
						System.out.println("cust_ids : " + cust_ids);
						if (cust_ids.contains(custid))
							{
								System.out.println("Cust ID Successfully validated..");
								return true;
							}
						else
							{
								System.out.println("Cust ID not validated..");
								return false;
							}
					}
				catch (SQLException e)
					{
						e.printStackTrace();
						return false;
					}
				finally
					{
						try
							{
								if (rs != null)
									{
										rs.close();
									}
								if (statement != null)
									{
										statement.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
			}


		public Boolean validateCardDetails(String cardType, String cardNo, String expDate, String cvvNo) throws JSONException
			{
				JSONArray jarray = new JSONArray();
				Boolean isValidDetails = false;
				ArrayList<String> cardTypeList = new ArrayList<String>();
				cardTypeList.add("MASTERCARD");
				cardTypeList.add("VISA");
				cardTypeList.add("PLATINUM");
				cardTypeList.add("SIGNATURE");
				// Card Type
				if (cardType != null && !cardType.isEmpty() && cardTypeList.contains(cardType))
					{
						isValidDetails = true;
					}
				else
					{
						System.out.println("Invalid Card Type!");
						returnMessage = getJsonErr(400, "Bad request. Invalid Request parameter", "Invalid Card Type");
						jarray.put(returnMessage);
						isValidDetails = false;
						return isValidDetails;
					}
				// Card No
				if (cardNo != null && !cardNo.isEmpty() && cardNo.length() == 4 && cardNo.matches("[0-9]+"))
					{
						isValidDetails = true;
					}
				else
					{
						System.out.println("Invalid Card Number!");
						returnMessage = getJsonErr(400, "Bad request. Invalid Request parameter", "Invalid Card Number");
						jarray.put(returnMessage);
						isValidDetails = false;
						return isValidDetails;
					}
				// Expiry Date
				if (expDate != null && !expDate.isEmpty() && expDate.length() == 5 && expDate.charAt(2) == '-')
					{
						String sMnth = expDate.split("-")[0];
						String sYr = expDate.split("-")[1];
						if (sMnth.matches("[0-9]+") && sYr.matches("[0-9]+"))
							{
								Integer mnth = Integer.parseInt(sMnth);
								Integer yr = Integer.parseInt(sYr);
								Calendar c = Calendar.getInstance();
								Integer currMnth = c.get(Calendar.MONTH) + 1;
								Integer currYr = c.get(Calendar.YEAR) % 100;
								if ((yr == currYr && mnth > currMnth && mnth < 13) || (yr > currYr && mnth >= 1 && mnth < 13))
									{
										isValidDetails = true;
									}
								else
									{
										System.out.println("Invalid Expiry Date!" + mnth + " " + yr);
										returnMessage = getJsonErr(400, "Bad request. Invalid Request parameter", "Expiry Date should be in MM-YY format and should be greater than current date");
										jarray.put(returnMessage);
										isValidDetails = false;
										return isValidDetails;
									}
							}
						else
							{
								System.out.println("Invalid Expiry Date!");
								returnMessage = getJsonErr(400, "Bad request. Invalid Request parameter", "Expiry Date should be in MM-YY format and should be greater than current date");
								jarray.put(returnMessage);
								isValidDetails = false;
								return isValidDetails;
							}
					}
				else
					{
						System.out.println("Invalid Expiry Date!!");
						returnMessage = getJsonErr(400, "Bad request. Invalid Request parameter", "Expiry Date should be in MM-YY format and should be greater than current date");
						jarray.put(returnMessage);
						isValidDetails = false;
						return isValidDetails;
					}
				// CVV Number
				if (!cvvNo.isEmpty() && cvvNo.length() == 3 && cvvNo.matches("[0-9]+"))
					{
						isValidDetails = true;
					}
				else
					{
						System.out.println("Invalid CVV Number!! " + cvvNo);
						returnMessage = getJsonErr(400, "Bad request. Invalid Request parameter", "Invalid CVV Number");
						jarray.put(returnMessage);
						isValidDetails = false;
						return isValidDetails;
					}
				return isValidDetails;
			}


		public Boolean validateCreditLimit(String creditLimit) throws JSONException
			{
				JSONArray jarray = new JSONArray();
				Boolean isValidDetails;
				if (creditLimit != null && !creditLimit.isEmpty() && creditLimit.matches("[0-9]+"))
					{
						if (Integer.parseInt(creditLimit) > 40000)
							{
								isValidDetails = true;
							}
						else
							{
								System.out.println("Invalid Credit Limit!");
								returnMessage = getJsonErr(400, "Bad request. Invalid Request parameter", "Credit Limit should contain numbers only and should be greater than 40000");
								jarray.put(returnMessage);
								isValidDetails = false;
								return isValidDetails;
							}
						if (Integer.parseInt(creditLimit) < 100000)
							{
								isValidDetails = true;
							}
						else
							{
								System.out.println("Invalid Credit Limit!");
								returnMessage = getJsonErr(400, "Bad request. Invalid Request parameter", "Credit Limit should contain numbers only and should be less than 100000");
								jarray.put(returnMessage);
								isValidDetails = false;
								return isValidDetails;
							}
						isValidDetails = true;
					}
				else
					{
						System.out.println("Invalid Credit Limit!");
						returnMessage = getJsonErr(400, "Bad request. Invalid Request parameter", "Credit Limit should contain numbers only and should be less than 100000");
						jarray.put(returnMessage);
						isValidDetails = false;
						return isValidDetails;
					}
				return isValidDetails;
			}


		public Boolean validateFlag(String overseaasFlag)
			{
				Boolean isValid = false;
				if (overseaasFlag != null && !overseaasFlag.isEmpty() && (overseaasFlag.equals("Y") || overseaasFlag.equals("N")))
					{
						isValid = true;
					}
				else
					{
						isValid = false;
					}
				System.out.println("validate flag:::" + isValid);
				return isValid;
			}


		public void setApiUsageStatus(String client_id, String apiName, Connection connection)
			{
				String query = "";
				PreparedStatement pstatement = null;
				String current_time = null;
				// log.info("Inside setApiUsageStatus client_id is " + client_id
				// + " api_name is " + api_name);
				try
					{
						if (connection == null || connection.isClosed())
							{
								connection = new DatabaseUtil().getConnection();
								System.out.println("Inside setApiUsageStatus Passed connection not found hense instantiated new");
							}
						Date currdate = new Date();
						SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
						current_time = formatter.format(currdate);
						query = "insert into participant_apiusage_rev(client_id,api_name,time) values(?,?,?)";
						pstatement = connection.prepareStatement(query);
						pstatement.setString(1, client_id);
						// pstatement.setString(2, userid);
						pstatement.setString(2, apiName);
						pstatement.setString(3, current_time);
						pstatement.execute();
						connection.commit();
						// log.info("Inside setApiUsageStatus Insert Status : "
						// + returnValue);
					}
				catch (Exception e)
					{
						e.printStackTrace();
						// log.warning("Exception in setApiUsageStatus : " +
						// e.getMessage());
					}
				finally
					{
						try
							{
								if (pstatement != null)
									{
										pstatement.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
			}


		public JSONObject getJsonErr(int errCd, String errMsg, String errDesc) throws JSONException
			{
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("code", errCd);
				if (errCd == 400)
					{
						jsonObject.put("message", "Bad request. Invalid Request parameter");
					}
				else
					if (errCd == 501)
						{
							jsonObject.put("message", "Processing error � One or more of internal systems gave an error while processing the request");
						}
					else
						if (errCd == 503)
							{
								jsonObject.put("message", "No Data Found");
							}
						else
							{
								jsonObject.put("message", errMsg);
							}
				jsonObject.put("description", errDesc);
				System.out.println("getJsonErr() -->" + jsonObject.toString());
				return jsonObject;
			}
	}
