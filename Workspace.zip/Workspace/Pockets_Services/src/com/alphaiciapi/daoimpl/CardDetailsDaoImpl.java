package com.alphaiciapi.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.alphaiciapi.model.CardDetails;
import com.alphaiciapi.model.SearchCriteria;
import com.alphaiciapi.util.DatabaseUtil;


public class CardDetailsDaoImpl  {

	private Connection connection;

    public CardDetailsDaoImpl() {
        connection = DatabaseUtil.getConnection();
        System.out.println("connection object:"+connection);
    }

	
	
	public List<CardDetails> getCardDetails(SearchCriteria searchCriteria) {

		System.out.println("Starting of  getCardDetails() of CardDetailsDaoImpl");
		List<CardDetails> cardDetailsList = null;
		try {
			cardDetailsList = new ArrayList<CardDetails>();

			String cardAccNo = searchCriteria.getCardNumber();
			String selectSQL = "";
			if(cardAccNo.length()==16)
				/*selectSQL = "SELECT CARD_TYPE,CARD_STATUS,DATE_OF_ENROLMENT,MONTH_DELINQUENCY,AMOUNT,custid,CARD_ACC_NUMBER,EXPIRY_DATE,AVAIL_LMT FROM fnpbbmor.RTL_Card_Details where CARD_NUMBER=? ";*/
				selectSQL = "SELECT CARD_TYPE,CARD_STATUS,DATE_OF_ENROLMENT,MONTH_DELINQUENCY,AMOUNT,custid,CARD_ACC_NUMBER,CARD_EXPIRY_DATE,AVAIL_LMT,CARD_NUMBER FROM RTL_Card_Details where CARD_NUMBER=? ";
			else
				/*selectSQL = "SELECT CARD_TYPE,CARD_STATUS,DATE_OF_ENROLMENT,MONTH_DELINQUENCY,AMOUNT,custid,CARD_ACC_NUMBER,EXPIRY_DATE,AVAIL_LMT FROM fnpbbmor.RTL_Card_Details where custid=? ";*/
				selectSQL = "SELECT CARD_TYPE,CARD_STATUS,DATE_OF_ENROLMENT,MONTH_DELINQUENCY,AMOUNT,custid,CARD_ACC_NUMBER,CARD_EXPIRY_DATE,AVAIL_LMT,CARD_NUMBER FROM RTL_Card_Details where custid=? ";
			
		    PreparedStatement preparedStatement = connection.prepareStatement(selectSQL);
		    System.out.println("Card no:"+searchCriteria.getCardNumber());
		    preparedStatement.setString(1, searchCriteria.getCardNumber());
		    ResultSet rs = preparedStatement.executeQuery();
		   // ResultSet rs = preparedStatement.executeQuery();
		    
		    while (rs.next()) {
		    	
		    	CardDetails cDetails = new CardDetails();
		    	
		    	//CARD_TYPE,CARD_STATUS,DATE_OF_ENROLMENT,MONTH_DELINQUENCY,AMOUNT
		    	String cardType = rs.getString("CARD_TYPE");
		    	String cardStatus = rs.getString("CARD_STATUS");
		    	String dateOfEnrollment = rs.getString("DATE_OF_ENROLMENT");
		    	String monthDelinquency = rs.getString("MONTH_DELINQUENCY");
		    	Double amount = rs.getDouble("AMOUNT");
		    	String custId = rs.getString("custid");
		    	String card_No = rs.getString("CARD_NUMBER");
		    	String expiry_date = rs.getString("CARD_EXPIRY_DATE");
		    	String avail_lmt = rs.getString("AVAIL_LMT");
		    	
		    	//SimpleDateFormat sd1 = new SimpleDateFormat("dd/mm/yyyy");
		    	//String od1 = sd1.format(dateOfEnrollment);
		    	
		    	cDetails.setCardType(cardType);
		    	cDetails.setCardStatus(cardStatus);
		    	cDetails.setDate_of_enrolemnt(dateOfEnrollment);
		    	cDetails.setMonth_delinquency(monthDelinquency);
		    	cDetails.setCurrent_balance(amount);
		    	cDetails.setCustId(custId);
		    	cDetails.setCardNumber(card_No);
		    	cDetails.setExpiry_date(expiry_date);
		    	cDetails.setAvail_lmt(avail_lmt);
		    	
		    	cardDetailsList.add(cDetails);
		    }
		    System.out.println("Size of cardDetailsList"+cardDetailsList);
				} catch (Exception e) {
					e.printStackTrace();
				}
		
				return cardDetailsList;
			}

}
