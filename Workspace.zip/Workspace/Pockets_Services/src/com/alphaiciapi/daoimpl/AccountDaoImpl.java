package com.alphaiciapi.daoimpl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.tree.RowMapper;









import com.alphaiciapi.dao.LoanDaoI;
import com.alphaiciapi.exp.BussinessException;
import com.alphaiciapi.model.Account;
import com.alphaiciapi.model.CardDetails;
import com.alphaiciapi.model.Loan;
import com.alphaiciapi.model.SearchCriteria;
import com.alphaiciapi.util.DatabaseUtil;


public class AccountDaoImpl  {

	private Connection connection;

    public AccountDaoImpl() {
        connection = DatabaseUtil.getConnection();
        System.out.println("connection object:"+connection);
    }

    
	public String creditAmount(SearchCriteria account) {
		
		//jdbcTeSystem.out.println("Starting of  debitAmount() of AccountDaoImpl");
		System.out.println("Account number:=>"+account.getAccountNumber());
		System.out.println("Amount:=>"+account.getAmount());
		Double balance=0.0;
		String status="NA";
		try {
			//long balance =  jdbcTemplate.queryForLong("select AMOUNT from LOAN_USERS WHERE ACCOUNT_NUMBER = ? ", new Object[]{account.getAccountNumber()});;
			
			
				Double newBalance=balance+account.getAmount();
				//jdbcTemplate.update("UPDATE LOAN_USERS SET AMOUNT = (AMOUNT - ?) WHERE ACCOUNT_NUMBER = ?",new Object[]{account.getAmount(),account.getAccountNumber()});
				   
			    String updateTableSQL="UPDATE LOGIN_USERS SET AMOUNT = ? WHERE ACCOUNT_NUMBER = ?";
			    PreparedStatement preparedStatement = connection.prepareStatement(updateTableSQL);

				preparedStatement.setDouble(1, newBalance);
				preparedStatement.setString(2, account.getAccountNumber());

				// execute update SQL stetement
				int updateStatus = preparedStatement.executeUpdate();
				if(updateStatus==1){
					System.out.println("Record is updated successfully");
					status=account.getAmount()+" Rs  is successfully credited";
				}else{
					System.out.println("Error in updating the record");
					status="Your request cannot be processed at this time";
				}
			
		 
		    	
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
		//mplate.update("UPDATE LOAN_USERS SET AMOUNT = (AMOUNT + ?) WHERE ACCOUNT_NUMBER = ?",new Object[]{account.getAmount(),account.getAccountNumber()});
		
	}

	
	public String debitAmount(SearchCriteria account)  {
		
		System.out.println("Starting of  debitAmount() of AccountDaoImpl");
		System.out.println("Account number:=>"+account.getAccountNumber());
		System.out.println("Amount:=>"+account.getAmount());
		Double balance=null;
		String status="NA";
		try {
			//long balance =  jdbcTemplate.queryForLong("select AMOUNT from LOAN_USERS WHERE ACCOUNT_NUMBER = ? ", new Object[]{account.getAccountNumber()});;
			
			String selectSQL = "select AMOUNT from LOGIN_USERS WHERE ACCOUNT_NUMBER = ? ";
		    PreparedStatement preparedStatement = connection.prepareStatement(selectSQL);
		    
		    preparedStatement.setString(1, account.getAccountNumber());
		    ResultSet rs = preparedStatement.executeQuery();
		    
		    while (rs.next()) {
		    	balance=rs.getDouble("AMOUNT");
		    }
		    
		    if(balance<0 || account.getAmount() > balance){
				status="Not_Sufficent_Balnce";
				
			}else{
				Double remainingBalance=balance-account.getAmount();
				//jdbcTemplate.update("UPDATE LOAN_USERS SET AMOUNT = (AMOUNT - ?) WHERE ACCOUNT_NUMBER = ?",new Object[]{account.getAmount(),account.getAccountNumber()});
				   
			    String updateTableSQL="UPDATE LOGIN_USERS SET AMOUNT = ? WHERE ACCOUNT_NUMBER = ?";
			    preparedStatement = connection.prepareStatement(updateTableSQL);

				preparedStatement.setDouble(1, remainingBalance);
				preparedStatement.setString(2, account.getAccountNumber());

				// execute update SQL stetement
				int updateStatus = preparedStatement.executeUpdate();
				if(updateStatus==1){
					System.out.println("Record is updated successfully");
					status=account.getAmount()+" Rs  is successfully debited";
				}else{
					System.out.println("Error in updating the record");
					status="Your request cannot be processed at this time";
				}
			}
		 
		    	
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}
	
	public List<CardDetails> getCardDetails(SearchCriteria searchCriteria) {

		System.out.println("Starting of  getCardDetails() of CardDetailsDaoImpl");
		List<CardDetails> cardDetailsList = null;
		try {
			cardDetailsList = new ArrayList<CardDetails>();
			String selectSQL = "SELECT CARD_TYPE,CARD_STATUS,DATE_OF_ENROLMENT,MONTH_DELINQUENCY,AMOUNT FROM CARD_DETAILS where CARD_NUMBER=? ";
		    PreparedStatement preparedStatement = connection.prepareStatement(selectSQL);
		    System.out.println("Card no:"+searchCriteria.getCardNumber());
		    preparedStatement.setString(1, searchCriteria.getCardNumber());
		    ResultSet rs = preparedStatement.executeQuery();
		   // ResultSet rs = preparedStatement.executeQuery();
		    
		    while (rs.next()) {
		    	CardDetails cDetails = new CardDetails();
		    	//CARD_TYPE,CARD_STATUS,DATE_OF_ENROLMENT,MONTH_DELINQUENCY,AMOUNT
		    	String cardType = rs.getString("CARD_TYPE");
		    	String cardStatus = rs.getString("CARD_STATUS");
		    	String dateOfEnrollment = rs.getString("DATE_OF_ENROLMENT");
		    	String monthDelinquency = rs.getString("MONTH_DELINQUENCY");
		    	Double amount = rs.getDouble("AMOUNT");
		    	
		    	
		    	cDetails.setCardType(cardType);
		    	cDetails.setCardStatus(cardStatus);
		    	cDetails.setDate_of_enrolemnt(dateOfEnrollment);
		    	cDetails.setMonth_delinquency(monthDelinquency);
		    	cDetails.setCurrent_balance(amount);
		    	
		    	cardDetailsList.add(cDetails);
		    }
		    System.out.println("Size of cardDetailsList"+cardDetailsList);
				} catch (Exception e) {
					e.printStackTrace();
				}
		
				return cardDetailsList;
			}
	
	
	

}
