package com.alphaiciapi.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import com.alphaiciapi.model.Loan;
import com.alphaiciapi.model.LoanReqDetails;
import com.alphaiciapi.model.LoanResTransModel;
import com.alphaiciapi.model.SearchCriteria;
import com.alphaiciapi.util.DatabaseUtil;
import com.google.gson.JsonObject;


public class LoanDaoImpl  {


	private static final Logger logger = Logger.getLogger(LoanDaoImpl.class.getName());

	public JsonObject getCustomerDetails(LoanReqDetails loanDetails) {

		Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet res=null;
		//List<Object> loanList=null;
		//LoanResCustModel loan=null;
		JsonObject jsonObject = new JsonObject();
		try { 
			//loanList = new ArrayList<Object>();
			String sql = "SELECT * FROM LOAN_CUSTOMER_DETAILS where MOBILE_NO=?";
			con = DatabaseUtil.getConnection();
			pstmt = con.prepareStatement(sql) ;
			pstmt.setObject(1, loanDetails.getMobileno());
			res = pstmt.executeQuery();
			while(res.next()){
				/* loan = new LoanResCustModel();
				loan.setName(res.getString("CUSTOMER_NAME"));
				loan.setDob(res.getString("DOB"));
				loan.setNo_of_depenants(res.getString("NO_OF_DEPENDANTS"));
				loan.setSalary_details(res.getString("GROSS_MONTHLY_SAL"));		*/
				
				jsonObject.addProperty("name", res.getString("CUSTOMER_NAME"));
				jsonObject.addProperty("dob",res.getString("DOB"));
				jsonObject.addProperty("no_of_depenants", res.getString("NO_OF_DEPENDANTS"));
				jsonObject.addProperty("salary_details",res.getString("GROSS_MONTHLY_SAL"));
				
				//loanList.add(loan);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return jsonObject;
	}

	public JsonObject getLoanSummaryDetails(LoanReqDetails loanReqDet) {
		Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet res=null;
		//List<Object> loanList=null;
		//LoanResSumModel loan=null;
		JsonObject jsonObject = new JsonObject();

		try { 
			//loanList = new ArrayList<Object>();
			String sql = "SELECT * FROM fnpbbmor.LOAN_DETAILS where LAN_NO=? and AGREEMENT_ID=? ";
			con = DatabaseUtil.getConnection();
			pstmt = con.prepareStatement(sql) ;
			pstmt.setObject(1, loanReqDet.getLoan_no());
			pstmt.setObject(2, loanReqDet.getAgreeID());
			res = pstmt.executeQuery();
			while(res.next()){
			/*	loan = new LoanResSumModel();
				loan.setLAN_No(res.getString("LAN_NO"));
				loan.setProdcut(res.getString("PRODUCT"));
				loan.setAmount_Finanaced(res.getString("AMT_FIN"));
				loan.setTenure(res.getString("TENURE"));
				loan.setRate_of_Interest(res.getString("ROI"));*/
				
				jsonObject.addProperty("LAN_No", res.getString("LAN_NO"));
				jsonObject.addProperty("Prodcut",res.getString("PRODUCT"));
				jsonObject.addProperty("Amount_Finanaced", res.getString("AMT_FIN"));
				jsonObject.addProperty("Tenure",res.getString("TENURE"));
				jsonObject.addProperty("Rate_of_Interest",res.getString("ROI"));

			//	loanList.add(loan);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return jsonObject;
	}
	
	public JsonObject getEMIDetails(LoanReqDetails loanReqDet) {
		Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet res=null;
		//List<Object> loanList=null;
		//LoanResEmiModel loan=null;
		JsonObject jsonObject = new JsonObject();
		try { 
		//	loanList = new ArrayList<Object>();
			String sql = "SELECT * FROM LOAN_EMI_TRANS_DETAILS where LAN_NO=? and AGREEMENT_ID=? ";
			con = DatabaseUtil.getConnection();
			pstmt = con.prepareStatement(sql) ;
			pstmt.setObject(1, loanReqDet.getLoan_no());
			pstmt.setObject(2, loanReqDet.getAgreeID());
			res = pstmt.executeQuery();
			String emis="";
			while(res.next()){
				//loan = new LoanResEmiModel();
				emis=res.getString("EMI1")+","+res.getString("EMI2")+","+res.getString("EMI3");
				/*loan.setNo_of_EMIs(res.getString("NO_OF_EMI"));
				loan.setEMI_Dates("01/01/2016,01/02/2016,01/03/2016");
				loan.setLast_three_EMIs(emis);*/
				
				jsonObject.addProperty("No_of_EMIs", res.getString("NO_OF_EMI"));
				jsonObject.addProperty("EMI_Dates","01/01/2017,01/02/2017,01/03/2017");
				jsonObject.addProperty("Last_three_EMIs", emis);
			
				//loanList.add(loan);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return jsonObject;
	}
	
	public JsonObject getTransactionDetails(LoanReqDetails loanReqDet) {
		Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet res=null;
		//List<Object> loanList=null;
		LoanResTransModel loan=null;
		JsonObject jsonObject = new JsonObject();
		try { 
			//loanList = new ArrayList<Object>();
			String sql = "SELECT * FROM LOAN_EMI_TRANS_DETAILS where LAN_NO=? and AGREEMENT_ID=? ";
			con = DatabaseUtil.getConnection();
			pstmt = con.prepareStatement(sql) ;
			pstmt.setObject(1, loanReqDet.getLoan_no());
			pstmt.setObject(2, loanReqDet.getAgreeID());
			res = pstmt.executeQuery();
			while(res.next()){
				jsonObject.addProperty("last_payments_made", res.getString("EMI3"));
				jsonObject.addProperty("Payment_mode",res.getString("PAYMENT_MODE"));
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return jsonObject;
	}
	
public List<Loan> getLoanDetails(SearchCriteria searchCriteria) {
		
		System.out.println("Starting of getLoanDetails()");
		System.out.println("Account no:"+searchCriteria.getAccountNumber());

		List<Loan> loanList = null;
		Connection connection=null;
		String loanAccNO = null;
		boolean flag = false;
		
		String loanNo = "";
		String agreeId = "";
		
		try 
		{
			loanList = new ArrayList<Loan>();
			
			connection = DatabaseUtil.getConnection();
	            
			String accNo = searchCriteria.getAccountNumber();
			
			
			
			if(!accNo.startsWith("LACRM"))
			{
				logger.info("Cust Id::" + accNo);
				String selectSQL1 = "SELECT LOAN_ACCOUNT_NO FROM RTL_LOGIN_USERS WHERE CUSTID=?";
				PreparedStatement preparedStatement1 = connection.prepareStatement(selectSQL1);
				preparedStatement1.setString(1, searchCriteria.getAccountNumber());
				logger.info("selectSQL1::" + selectSQL1);
	            ResultSet rs1 = preparedStatement1.executeQuery();
	            
	            if(rs1.next()) 
	            {	
	            	loanAccNO = rs1.getString("LOAN_ACCOUNT_NO");
	            	
	            	if(loanAccNO!=null || !loanAccNO.equals(""))
	            	{
	            		loanAccNO = loanAccNO.replace("||", ",");
	            	}
	            }
	            
	            String selectSQL2 = "SELECT LAN_NO, AGREEMENT_ID FROM LOAN_EMI_TRANS_DETAILS WHERE CURRENCY=?";
	            PreparedStatement preparedStatement2 = connection.prepareStatement(selectSQL2);
				preparedStatement2.setString(1, searchCriteria.getAccountNumber());
				
				logger.info("selectSQL2::" + selectSQL2);
	            ResultSet rs2 = preparedStatement2.executeQuery();
	            
	            if(rs2.next()) {
	            	loanNo = rs2.getString("LAN_NO");
	            	agreeId = rs2.getString("AGREEMENT_ID");
	            	logger.info("Loan_no::" + loanNo);
		            logger.info("agreeId::" + agreeId);
	            }
	            
	            
	            flag = true;
			}
			else
			{
				logger.info("Loan Account No::" + accNo);
				loanAccNO = accNo;
				String custId = "";
				String selectSQLQuery1 = "SELECT CUSTID FROM RTL_LOGIN_USERS WHERE LOAN_ACCOUNT_NO=?";
				PreparedStatement ps1 = connection.prepareStatement(selectSQLQuery1);
				ps1.setString(1, loanAccNO);
				logger.info("selectSQLQuery::" + selectSQLQuery1);
	            ResultSet rs1 = ps1.executeQuery();
	            
	            if(rs1.next()) 
	            {	
	            	custId = rs1.getString("CUSTID");
	            	
	            }
	            
	            String selectSQLQuery2 = "SELECT LAN_NO, AGREEMENT_ID FROM LOAN_EMI_TRANS_DETAILS WHERE CURRENCY=?";
	            PreparedStatement ps2 = connection.prepareStatement(selectSQLQuery2);
				ps2.setString(1, custId);
				
				logger.info("selectSQLQuery2::" + selectSQLQuery2);
	            ResultSet rs2 = ps2.executeQuery();
	            
	            if(rs2.next()) {
	            	loanNo = rs2.getString("LAN_NO");
	            	agreeId = rs2.getString("AGREEMENT_ID");
	            	logger.info("Loan_no::" + loanNo);
		            logger.info("agreeId::" + agreeId);
	            }
	            
	            
			}
			
			System.out.println("Loan Acc no:::>>>>>"+loanAccNO);
			StringBuilder builder=new StringBuilder();

			String arr[]=null;
			String queryParams="";
			
			if(loanAccNO.contains(","))
			{
				arr = loanAccNO.split(",");
				for(int i=0;i<arr.length;i++){
					builder.append("?,");
				}
			
				 queryParams=builder.deleteCharAt(builder.length()-1).toString();
			}else{
				queryParams="?";
			}
			
			String selectSQL = "";
			
			if(flag)
			{
	            selectSQL = "select ID, LOAN_POS, LOAN_PRINCIPAL_OUTSTANDING, DATE_OF_LOAN, TYEP_OF_LOAN, LOAN_ROI, MONTH_DELINQUENCY, CUSTOMER_NAME, LOAN_AMOUNT, CUSTID, LOAN_ACCOUNT_NO from RTL_LOAN_MASTER where LOAN_ACCOUNT_NO in ("+queryParams+")";
			}
			else
			{
				selectSQL = "select ID, LOAN_POS, LOAN_PRINCIPAL_OUTSTANDING, DATE_OF_LOAN, TYEP_OF_LOAN, LOAN_ROI, MONTH_DELINQUENCY, CUSTOMER_NAME, LOAN_AMOUNT, CUSTID, LOAN_ACCOUNT_NO from RTL_LOAN_MASTER where LOAN_ACCOUNT_NO = "+queryParams;
			}
	           
			System.out.println("sql"+selectSQL);
			PreparedStatement preparedStatement = connection.prepareStatement(selectSQL);
	            
			if(loanAccNO.contains(",")){
				for(int i=0;i<arr.length;i++){
					preparedStatement.setString((i+1), arr[i]);
				}
				
			} else {
				
				preparedStatement.setString(1, loanAccNO);
			}
	            
	            ResultSet rs = preparedStatement.executeQuery();
	            
	            
	            while (rs.next()) 
	            {
	            	System.out.println("Inside:::>>>>>>");
	            	
	            	Loan loan = new Loan();
	            	
	            	Integer id = rs.getInt("ID");
	            	String loanPos = rs.getString("LOAN_POS");
	            	String loanPrinOutstanding = rs.getString("LOAN_PRINCIPAL_OUTSTANDING");
	            	String dateOfLoan = rs.getString("DATE_OF_LOAN");
	            	String typeOfLoan = rs.getString("TYEP_OF_LOAN");
	            	String loanRoi = rs.getString("LOAN_ROI");
	            	String monthDelin = rs.getString("MONTH_DELINQUENCY");
	            	String customerName = rs.getString("CUSTOMER_NAME");
	            	String custId = rs.getString("CUSTID");
	            	String loanAmount = rs.getString("LOAN_AMOUNT");
	            	String loanAcc_No = rs.getString("LOAN_ACCOUNT_NO");
	            	System.out.println("customerName:::::>>>>"+customerName);
	            	
	            	loan.setID(id);
	            	loan.setPos(loanPos);
	            	loan.setPrincipal_outstanding(loanPrinOutstanding);
	            	loan.setDate_of_loan(dateOfLoan);
	            	loan.setType_of_loan(typeOfLoan);
	            	loan.setRoi(loanRoi);
	            	loan.setMonth_delinquency(monthDelin);
	            	loan.setCustomerName(customerName);
	            	loan.setLoanAmount(loanAmount);
	            	loan.setCustId(custId);
	            	loan.setAgreeId(agreeId);
	            	loan.setLoanNo(loanNo);
	            	
	            	if(flag)
	            		loan.setLoanAccounNo(loanAcc_No);
	            	
	            	loanList.add(loan);
	            
	            }
	            System.out.println("Size of loanList"+loanList);

		} catch (Exception e) {
			System.out.println(e.getMessage());
			
			
			
		}

		return loanList;
	}

	

}
