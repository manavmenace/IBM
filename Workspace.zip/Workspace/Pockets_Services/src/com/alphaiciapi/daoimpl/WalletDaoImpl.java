package com.alphaiciapi.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.alphaiciapi.exp.PersistanceException;
import com.alphaiciapi.model.Wallet;
import com.alphaiciapi.model.WalletLoginUser;
import com.alphaiciapi.model.WalletLoginUserReturn;
import com.alphaiciapi.model.WalletResponse;
import com.alphaiciapi.model.WalletStmtRes;
import com.alphaiciapi.util.CommmonUtils;
import com.alphaiciapi.util.DatabaseUtil;
import com.alphaiciapi.util.StringUtils;
import com.google.gson.JsonObject;


public class WalletDaoImpl {

	
	String insertTransQuery= "INSERT INTO RTL_WALLET_TRANS_DETAILS (ID_TYPE ,ID_VALUE ,AUTH_TYPE ,AUTH_DATA ,"
			+ " LATITUDE ,LONGITUDE ,IP_ADDRESS ,MOBILE ,OS ,DEVICE_ID ,IMEI ,WT_TXN_DATE ,"
			+ " WT_AMOUNT,WT_TXN_TYPE ,WT_STATUS,WT_REMARKS ,WT_TXN_ID ,WT_PROMO_CD ,"
			+ "WT_SUB_MERCHNT ,WT_BANK_TXN_ID)  VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	
    public WalletDaoImpl() {
    }

	
	/*public Wallet checkUser(String userId,String accessId) {
		Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		Wallet wallet=null;
		try { 
			String sql = "SELECT WM_USER_ID,WM_ACC_NO FROM RTL_WALLET_MASTER where WM_USER_ID=? ";
			con = DatabaseUtil.getConnection();
			con.setAutoCommit(false); 
			pstmt = con.prepareStatement(sql) ;
			pstmt.setObject(1, userId);
			rs = pstmt.executeQuery();
			if(rs.next()){
			}else{
			}
			
			if(rs!=null && rs.next()){
				 wallet = new Wallet();
				 wallet.setWalletAcNo(rs.getString("WM_ACC_NO"));
				 wallet.setStatus("Wallet Already Exist");
				 System.out.println("test");
			}else{
				System.out.println("fsdfsdfsdf");
				 sql = "INSERT INTO RTL_WALLET_MASTER (WM_ACC_NO,WM_AMOUNT,WM_MAPPED_AC_NO,CREATED_DATE,WM_USER_ID,WM_STATUS) VALUES (?,?,?,?,?,?) ";
				 pstmt = con.prepareStatement(sql) ;
				 pstmt.setObject(1, "675678981"+StringUtils.getRandomValue());
				 pstmt.setObject(2, 0);
				 pstmt.setObject(3, "12312311230");
				 pstmt.setObject(4, CommmonUtils.convertDateToSQLDate(new Date()));
				 pstmt.setObject(5, userId);
				 pstmt.setObject(6, "A");
				 pstmt.executeUpdate();
				 con.commit();
				 
				 System.out.println("Insert Success");
				 wallet = new Wallet();
				 System.out.println("Insert Succes33333333333s");
				 wallet.setWalletAcNo("675678981"+StringUtils.getRandomValue());
				 wallet.setStatus("Wallet Created Successfully");
				 wallet.setAmount(120);
				 
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return wallet;
	}*/
	
	public WalletLoginUserReturn checkNewUser(WalletLoginUser wlUser) {
		
		Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		WalletLoginUserReturn retUser =null;
		try { 
			String sql = "SELECT MOBILE,ACCESS_TOKEN FROM RTL_WALLET_LOGIN_USERS WHERE  MOBILE=?";
			con = DatabaseUtil.getConnection();
			//walletUser = new WalletLoginUser();
			retUser = new WalletLoginUserReturn();
			con.setAutoCommit(false); 
			pstmt = con.prepareStatement(sql) ;
			
				pstmt.setString(1,wlUser.getMobile());
				rs = pstmt.executeQuery();
			
			
			
			if(rs!=null && rs.next()){
				System.out.println("wallet already exists");
				
				//wlUser.setCreationStatus("Wallet Already Exist");
				//wlUser.setAuth_data(rs.getString("ACCESS_TOKEN"));
				
				retUser.setCreationStatus("Wallet Already Exist");
				retUser.setAuth_data(rs.getString("ACCESS_TOKEN"));
				
			}else{
				System.out.println("wallet doesnot  exist");
				String accessToken = CommmonUtils.randomStringOfLength20();
				 sql = "INSERT INTO RTL_WALLET_LOGIN_USERS (MERCHANT_ID,SCOPE,FIRST_NAME,LAST_NAME,EMAIL,MOBILE,DOB,GENDER,IP_ADDRESS,OS,DEVICE_ID,STATE,ACCESS_TOKEN) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
				 pstmt = con.prepareStatement(sql) ;
				 pstmt.setString(1, wlUser.getMerchant_id());
				 pstmt.setString(2, wlUser.getScope());
				 pstmt.setString(3, wlUser.getFirst_name());
				 pstmt.setString(4, wlUser.getLast_name());
				 pstmt.setString(5, wlUser.getEmail());
				 pstmt.setString(6, wlUser.getMobile());
				 pstmt.setString(7, wlUser.getDob());
				 pstmt.setString(8, wlUser.getGender());
				 pstmt.setString(9, wlUser.getIp_address());
				 pstmt.setString(10, wlUser.getOs());
				 pstmt.setString(11, wlUser.getDevice_id());
				 pstmt.setString(12, wlUser.getState());
				 pstmt.setString(13, accessToken);
				 //pstmt.setString(14, wlUser.getCreationStatus());
				 
				 int insertStatus = pstmt.executeUpdate();
				 con.commit();
				 if(insertStatus==1){
					 System.out.println("Insert Success in RTL_WALLET_LOGIN_USERS");
					 
					 retUser.setCreationStatus("Wallet Created Successfully");
					 retUser.setAuth_data(accessToken);
						
					 wlUser.setAuth_data(accessToken);
					 wlUser.setCreationStatus("Wallet Created Successfully");
					 
					 wlUser.setAuth_type("TOKEN");
					 wlUser.setCreated_date(StringUtils.converDateToString(new Date()));
					 wlUser.setId_type("TOKEN");
					 wlUser.setId_value(accessToken);
					 wlUser.setImei("35550702720000");
					 wlUser.setLatitude("19.11376955");
					 wlUser.setLongitude("73.8500124");
					 wlUser.setWm_acc_no("456987");
					 wlUser.setWm_amount("0");
					 wlUser.setWm_mapped_ac_no("569841");
					 wlUser.setWm_status("A");
					 wlUser.setWm_user_id("1236");
					 
					 insertWalletMasterNew(wlUser);
				 }
				 
				 
			}
		} catch (Exception e) {
			e.printStackTrace();
		}


		
		return retUser;
	}

	public JsonObject getWalletBalance(Wallet wallet) throws PersistanceException {
		Connection con = null;
		PreparedStatement walletTransaction = null;
		ResultSet rs = null;
		JsonObject jsonObject = new JsonObject();
		String selectSQL = null;
		try {
			selectSQL = "SELECT WM_AMOUNT FROM RTL_WALLET_MASTER WHERE AUTH_DATA=? ";
			
			String refNo = StringUtils.getRandomValue();
			con = DatabaseUtil.getConnection();
			walletTransaction = con.prepareStatement(selectSQL);
			walletTransaction.setObject(1, wallet.getAuth_data());
			rs = walletTransaction.executeQuery();

			if (rs.next()) {
				double currentBalance = rs.getDouble("WM_AMOUNT");
				jsonObject.addProperty("amount", String.format("%.2f", currentBalance));
				jsonObject.addProperty("bank_txn_id", refNo);
				
				wallet.setTransType("E");
				walletTransaction = con.prepareStatement(insertTransQuery);
				insertTransaction(wallet, walletTransaction,refNo);
				
			}
		} catch (Exception e) {
			throw new PersistanceException("SQL_ERROR");
		}

		return jsonObject;
	}

public WalletStmtRes getWalletStatement(Wallet wallet) throws PersistanceException{
	Connection con = null;
	PreparedStatement walletTransaction = null;
	ResultSet rs = null;
	List<WalletResponse> walletList = null;
	String selectSQL=null;
	WalletStmtRes walletStmtRes=null;
	try {
		con = DatabaseUtil.getConnection();
		String refNo = StringUtils.getRandomValue();
		walletList = new ArrayList<WalletResponse>();
		wallet.setTransType("S");
		walletTransaction = con.prepareStatement(insertTransQuery);
		int i =insertTransaction(wallet, walletTransaction,refNo);
		
		walletStmtRes = new WalletStmtRes();
		walletStmtRes.setBank_txn_id(refNo);
		
		if(i!=0){
		selectSQL = "SELECT WM_ACC_NO,WT.WT_TXN_DATE,WT.WT_AMOUNT,WT.WT_TXN_TYPE,WT.WT_REMARKS,"
				+ " WT.WT_TXN_ID,WT.WT_BANK_TXN_ID FROM RTL_WALLET_TRANS_DETAILS WT"
				+ " JOIN RTL_WALLET_MASTER WM ON (WM.AUTH_DATA = WT.AUTH_DATA) where WM.AUTH_DATA=? AND WT_TXN_TYPE IN('C','D') ";
		
		
		walletTransaction = con.prepareStatement(selectSQL);
		walletTransaction.setObject(1, wallet.getAuth_data());
		rs = walletTransaction.executeQuery();
			while (rs.next()) {
				WalletResponse walletData = new WalletResponse();
				walletData.setTxn_id(rs.getString("WT_TXN_ID"));
				walletData.setBank_txn_id(rs.getString("WT_BANK_TXN_ID"));
				walletData.setTransDate(rs.getString("WT_TXN_DATE"));
				walletData.setTransType((rs.getString("WT_TXN_TYPE")!=null && "C".equals(rs.getString("WT_TXN_TYPE")))?"CREDIT AMOUNT":"DEBIT AMOUNT");
				walletData.setAmount(rs.getDouble("WT_AMOUNT"));
				walletData.setRemarks(rs.getString("WT_REMARKS"));
				walletData.setWalletAcNo(rs.getString("WM_ACC_NO"));
				walletList.add(walletData);
			}	
		}
		
		walletStmtRes.setWalletStatement(walletList);
		
	} catch (Exception e) {
		throw new PersistanceException("SQL_ERROR");
	}
	return walletStmtRes;
}

public JsonObject creditWalletAmount(Wallet wallet) throws PersistanceException {
	PreparedStatement walletTransaction = null;
	PreparedStatement insertTrans = null;
	ResultSet rs = null;
	Connection con = null;
	String selectSQL = null;
	JsonObject jsonObject = new JsonObject();
	try {
		String refNo = StringUtils.getRandomValue();
		con = DatabaseUtil.getConnection();
		con.setAutoCommit(false);
		selectSQL = "SELECT WM_AMOUNT FROM RTL_WALLET_MASTER WHERE AUTH_DATA = ?";
		walletTransaction = con.prepareStatement(selectSQL);
		walletTransaction.setObject(1, wallet.getAuth_data());
		rs = walletTransaction.executeQuery();
	
		double balance = 0;
		if (rs.next()) {
			balance = rs.getDouble("WM_AMOUNT");
			balance = balance + wallet.getAmount();
			if(balance >10000){
				throw new PersistanceException("MAX_WALLET_BALANCE");
			}
		}else{
			throw new PersistanceException("NO_WALLET");
		}
		
		System.out.println("Balance========="+balance);
		
		selectSQL = "UPDATE RTL_WALLET_MASTER SET WM_AMOUNT =? WHERE AUTH_DATA = ?";
		walletTransaction = con.prepareStatement(selectSQL);
		walletTransaction.setDouble(1, balance);
		walletTransaction.setString(2, wallet.getAuth_data());
		int i = walletTransaction.executeUpdate();
		walletTransaction.close();
		
		if (i != 0) {
			
			wallet.setTransType("C");
			insertTrans = con.prepareStatement(insertTransQuery);
		    insertTransaction(wallet, insertTrans,refNo);

		    
		    
			selectSQL = "SELECT WM_ACC_NO ,WM.WM_AMOUNT,WT_BANK_TXN_ID,WT_TXN_TYPE,"
					+ " WT_AMOUNT,WT_REMARKS FROM RTL_WALLET_MASTER WM"
					+ " JOIN RTL_WALLET_TRANS_DETAILS WT ON (WM.AUTH_DATA=WT.AUTH_DATA) WHERE WT_BANK_TXN_ID=? AND WM.AUTH_DATA=? ";
			walletTransaction = con.prepareStatement(selectSQL);
			walletTransaction.setObject(1, refNo);
			walletTransaction.setObject(2, wallet.getAuth_data());
			rs = walletTransaction.executeQuery();
			while (rs.next()) {
				jsonObject.addProperty("amount", String.format("%.2f", rs.getDouble("WM_AMOUNT")));
				jsonObject.addProperty("txn_id", wallet.getTxn_id());
				jsonObject.addProperty("bank_txn_id", refNo);
			}
		}
		con.commit();
	} catch (SQLException e) {
		System.out.println("SQL Error" + e.getMessage());
		throw new PersistanceException("SQL_ERROR"+e.getMessage());
	} finally {
     
	}
	return jsonObject;
}

public JsonObject debitWalletAmount(Wallet wallet) throws PersistanceException {
	PreparedStatement walletTransaction = null;
	PreparedStatement insertTrans = null;
	ResultSet rs = null;
	Connection connection = null;
	JsonObject jsonObject = null;
	try {
		connection = DatabaseUtil.getConnection();
		connection.setAutoCommit(false);
		String refNo = StringUtils.getRandomValue();
		String selectSQL = null;

		selectSQL = "SELECT WM_AMOUNT FROM RTL_WALLET_MASTER WHERE AUTH_DATA = ?";
		walletTransaction = connection.prepareStatement(selectSQL);
		walletTransaction.setObject(1, wallet.getAuth_data());
		rs = walletTransaction.executeQuery();
	
		double balance = 0;
		if (rs.next()) {
			balance = rs.getDouble("WM_AMOUNT");
			if (wallet.getAmount() > balance) {
				throw new PersistanceException("NO_BALANCE");
			}
		}else{
			throw new PersistanceException("NO_WALLET");
		}
		balance = balance-wallet.getAmount();
		System.out.println("Debit amunt"+balance);
		selectSQL = "UPDATE RTL_WALLET_MASTER SET WM_AMOUNT =? WHERE AUTH_DATA = ?";
		walletTransaction = connection.prepareStatement(selectSQL);
		walletTransaction.setObject(1, balance);
		walletTransaction.setObject(2, wallet.getAuth_data());
		int i = walletTransaction.executeUpdate();
		
		if (i != 0) {
			wallet.setTransType("D");
			insertTrans = connection.prepareStatement(insertTransQuery);
		    insertTransaction(wallet, insertTrans,refNo);

			selectSQL = "SELECT WM_ACC_NO ,WM.WM_AMOUNT,WT_BANK_TXN_ID,WT_TXN_TYPE,"
					+ " WT_AMOUNT,WT_REMARKS FROM RTL_WALLET_MASTER WM"
					+ " JOIN RTL_WALLET_TRANS_DETAILS WT ON (WM.AUTH_DATA=WT.AUTH_DATA) WHERE WT_BANK_TXN_ID=? AND WM.AUTH_DATA=? ";
			walletTransaction = connection.prepareStatement(selectSQL);
			walletTransaction.setObject(1, refNo);
			walletTransaction.setObject(2, wallet.getAuth_data());
			rs = walletTransaction.executeQuery();
			while (rs.next()) {
				jsonObject = new JsonObject();
				jsonObject.addProperty("amount", String.format("%.2f", rs.getDouble("WM_AMOUNT")));
				jsonObject.addProperty("txn_id", wallet.getTxn_id());
				jsonObject.addProperty("bank_txn_id", refNo);
			}
		}
		connection.commit();
	} catch (SQLException e) {
		System.out.println("SQL Error" + e.getMessage());
		throw new PersistanceException("SQL_ERROR"+e.getMessage());
	} finally {
       
	}
	return jsonObject;

}

private int insertTransaction(Wallet wallet,PreparedStatement walletTransaction,String refNo) throws PersistanceException{
	int i=0;
	try {
		walletTransaction.setObject(1, wallet.getId_type());
		walletTransaction.setObject(2, wallet.getId_value());
		walletTransaction.setObject(3, wallet.getAuth_type());
		walletTransaction.setObject(4, wallet.getAuth_data());
		walletTransaction.setObject(5, wallet.getLatitude());
		walletTransaction.setObject(6, wallet.getLongitude());
		walletTransaction.setObject(7, wallet.getIp_address());
		walletTransaction.setObject(8, wallet.getMobileNo());
		walletTransaction.setObject(9, wallet.getOs());
		walletTransaction.setObject(10, wallet.getDevice_id());
		walletTransaction.setObject(11, wallet.getImei());
		walletTransaction.setObject(12,CommmonUtils.convertDateToSQLDate(new Date()));
		walletTransaction.setObject(13, wallet.getAmount());
		walletTransaction.setObject(14, wallet.getTransType());
		walletTransaction.setObject(15, "A");
		walletTransaction.setObject(16, wallet.getRemarks());
		walletTransaction.setObject(17, wallet.getTxn_id());
		walletTransaction.setObject(18, wallet.getPromocode());
		walletTransaction.setObject(19, wallet.getSub_merchant());
		walletTransaction.setObject(20, refNo);
		 i = walletTransaction.executeUpdate();
	} catch (SQLException e) {
		e.printStackTrace();
		throw new PersistanceException("SQL_ERROR"+e.getMessage());
	}
	return i;
}

private int insertWalletMasterNew(WalletLoginUser wlUserNew){
	
	
	Connection con=null;
	PreparedStatement pstmt=null;
	
	try { 
			con = DatabaseUtil.getConnection();
			
			String insertWalletMasterNew= "INSERT INTO RTL_WALLET_MASTER (AUTH_DATA,AUTH_TYPE,CREATED_DATE,DEVICE_ID,ID_TYPE,ID_VALUE ,"
					+ " IMEI,IP_ADDRESS,LATITUDE,LONGITUDE,MOBILE,OS,WM_ACC_NO,WM_AMOUNT ,"
					+ " WM_MAPPED_AC_NO,WM_STATUS,WM_USER_ID )  VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			
			 pstmt = con.prepareStatement(insertWalletMasterNew) ;
			 pstmt.setObject(1, wlUserNew.getAuth_data());
			 pstmt.setObject(2, wlUserNew.getAuth_type());
			 pstmt.setObject(3, wlUserNew.getCreated_date());
			 pstmt.setObject(4, wlUserNew.getDevice_id());
			 pstmt.setObject(5, wlUserNew.getId_type());
			 pstmt.setObject(6, wlUserNew.getId_value());
			 pstmt.setObject(7, wlUserNew.getImei());
			 pstmt.setObject(8, wlUserNew.getIp_address());
			 pstmt.setObject(9, wlUserNew.getLongitude());
			 pstmt.setObject(10, wlUserNew.getLatitude());
			 pstmt.setObject(11, wlUserNew.getMobile());
			 pstmt.setObject(12, wlUserNew.getOs());
			 pstmt.setObject(13, wlUserNew.getWm_acc_no());
			 pstmt.setObject(14, wlUserNew.getWm_amount());
			 pstmt.setObject(15, wlUserNew.getWm_mapped_ac_no());
			 pstmt.setObject(16, wlUserNew.getWm_status());
			 pstmt.setObject(17, wlUserNew.getWm_user_id());
			 
			 //pstmt.setObject(13, CommmonUtils.randomStringOfLength20());
			 //pstmt.setString(14, wlUser.getCreationStatus());
			 
			 int status = pstmt.executeUpdate();
			 con.commit();
			 if(status==1){
				 System.out.println("Insert Success in insertWalletMasterNew");
				 
			 }
			 return status;
			 
		
	} catch (Exception e) {
		e.printStackTrace();
		return 0;
	}
	
	
	
}
	

}
