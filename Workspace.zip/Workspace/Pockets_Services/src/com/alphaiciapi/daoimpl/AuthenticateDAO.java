package com.alphaiciapi.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import com.alphaiciapi.util.DatabaseUtil;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;


public class AuthenticateDAO {

	public boolean validateClient(String client_id,String token,String api_name) {
		Connection connection = null;
		
		JsonArray jarray = new JsonArray();
		ResultSet rs = null;
		Statement statement = null;
		//		String client_id = "";
		String query  = "";
		boolean flag = false;
		String current_time = null;
		
		System.out.println("Inside validateClient(..) method client_id is "+client_id+" token is "+token);
		try {
			connection = DatabaseUtil.getConnection();
			Date currdate = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
			current_time = formatter.format(currdate);
			//			}
			if (!client_id.equals("")) {
				if(!token.equals("")){
					//					query = "select client_id,token from participant_token_details where client_id='"+client_id+"' and token='"+token+"' and (SELECT MINUTE(expiry_time) - MINUTE('"+current_time+"') FROM SYSIBM.SYSDUMMY1) > 0";
					query = "select client_id,token from participant_token_details "+
							"where client_id='"+client_id +"' and token = '"+token+"' and  EXPIRY_TIME>CURRENT_TIMESTAMP";

					System.out.println("VALIDATE_____________"+query);
					statement = connection.createStatement();
					rs = statement.executeQuery(query);

					while (rs.next()) {
						System.out.println("****************************************************");
						JsonObject jobj = new JsonObject();
						jobj.addProperty("client_id", rs.getString(1));
						jobj.addProperty("token", rs.getString(2));
						jarray.add(jobj);
					}
					if(jarray.size() != 0){
						flag = true;
						//update validity of token 01-03-2016
						updateTokenValidity(client_id, token);
						setApiUsageStatus(client_id, api_name);
					}
					System.out.println("validate-"+flag);
					return flag;
				}
				else{
					System.out.println("Inside validateClient(..) method ---> token inaddProperty is found blank");
					return flag;
				}
			}
			else{
				System.out.println("Inside validateClient(..) method ---> client_id id inaddProperty is not set");
				return flag;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return flag;
		}
		catch(Exception e){
			e.printStackTrace();
			return flag;
		}
	}
public void setApiUsageStatus(String client_id,String api_name){
	String query = ""; 
	Connection connection = null;
	PreparedStatement pstatement = null;
	//		String client_id = "";
	boolean returnValue = false;
	String current_time = null;
	System.out.println("Inside setApiUsageStatus(..) method client_id is "+client_id+" api_name is "+api_name);
	try {
		connection = DatabaseUtil.getConnection();
		Date currdate = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
		current_time = formatter.format(currdate);
		query = "insert into participant_apiusage_rev(client_id,api_name,time) values(?,?,?)";
		pstatement = connection.prepareStatement(query);
		pstatement.setString(1,client_id);
		pstatement.setString(2, api_name);
		pstatement.setString(3, current_time);
		returnValue=pstatement.execute();
		System.out.println("Inside setApiUsageStatus(..) method insert result"+returnValue);
	}
	catch(Exception e){
		e.printStackTrace();
		System.out.println("Exception in setApiUsageStatus() method"+e.getMessage());
	}

}


public JsonArray updateTokenValidity(String client_id,String token){
	Connection connection = null;
	JsonArray jarray = new JsonArray();
	Statement statement = null;
	String current_time = null;
	String exp_time = null;

	try{
		Date currdate = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
		current_time = formatter.format(currdate);

		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MINUTE, 86400);//24 hours in minutes :  60 min = 1 hour
		exp_time = formatter.format(cal.getTime());

		System.out.println("Inside updateTokenValidity---"+current_time+"***"+exp_time);

		connection = DatabaseUtil.getConnection();
		//update token_details with token
		String query1 = "update participant_token_details set expiry_time = '"+exp_time+"' where client_id ='"+client_id+"' AND token='"+token+"'";
		statement = connection.createStatement();
		System.out.println("update query:"+query1);
		statement.execute(query1);
		connection.commit();
		JsonObject jobj = new JsonObject();
		jobj.addProperty("token", token);
		jarray.add(jobj);
	}
	catch(Exception e){
		e.printStackTrace();
		System.out.println("Exception in  updateTokenValidity---"+e.getMessage());
	}
	return jarray;
}

}
