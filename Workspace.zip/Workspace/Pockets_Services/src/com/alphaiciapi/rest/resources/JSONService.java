package com.alphaiciapi.rest.resources;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.alphaiciapi.model.Track;



@Path("/json/metallica")
public class JSONService {
	
	/*
	@GET
	@Path("/get")
	@Produces
	public String getMessage(){
		
		JSONObject jobj = new JSONObject();
		jobj.put("code", 200);
		jobj.put("accountno", "1234567890");
		return jobj.toString();
	}*/
			

	@GET
	
	@Produces(MediaType.APPLICATION_JSON)
	public List<Track> getTrackInJSON() {

		Track track = new Track();
		track.setTitle("Enter Sandman");
		track.setSinger("Metallica");
		
		Track track1 = new Track();
		track1.setTitle("Enter Sandman1");
		track1.setSinger("Metallica1");

		List<Track> tcList =  new ArrayList<Track>();
		tcList.add(track);
		tcList.add(track1);
		return tcList;

	}

	@POST
	@Path("/post")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response createTrackInJSON(Track track) {

		String result = "Track saved : " + track;
		return Response.status(201).entity(result).build();
		
	}
	
}