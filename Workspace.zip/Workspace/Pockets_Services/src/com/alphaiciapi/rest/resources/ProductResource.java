package com.alphaiciapi.rest.resources;

/*import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.model.Product;



@Path("/SpringRest")
public class ProductResource {

	
	@Autowired
	Product product;
	
	@Path("/getData")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_PLAIN)
	@GET
	public String getValue() {

		System.out.println("swamy========="+product);

		return "Swamy";
	}

	@Path("/editProduct")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@POST
	public Product editProduct(Product product) {
		String data = null;
		try {
			System.out.println("data===" + product.getProductCategory());
			System.out.println("data===" + product.getProductName());
			System.out.println("data===" + product.getProductId());

			ObjectMapper mapper = new ObjectMapper();
			data = mapper.writeValueAsString(product);
			System.out.println(product+"==Swamy======== :" + data);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return product;
	}
}
*/