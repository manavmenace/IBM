package com.alphaiciapi.rest.resources;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.UriInfo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.alphaiciapi.model.Wallet;
import com.alphaiciapi.model.WalletLoginUser;
import com.alphaiciapi.model.WalletLoginUserReturn;
import com.alphaiciapi.model.WalletResponse;
import com.alphaiciapi.service.AuthenticateService;
import com.alphaiciapi.service.WalletService;
import com.alphaiciapi.util.ErrorCodeConstants;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

@Path("/icici")
public class WalletResource {
	
	
	@GET
	@Path("/test")
	@Produces
	public String test()
	{
		return "OK";
	}
	
	JsonObject jsonObject =  new JsonObject();
	JsonObject jsonObject1 =  new JsonObject();
	WalletService walletService=new WalletService();
	AuthenticateService authenticateService=new AuthenticateService();
	JSONObject jobj          = new JSONObject();
	JSONArray  jarray        = new JSONArray();
	ArrayList<JsonObject> al = new ArrayList<JsonObject>();
	
	
	@GET
	@Path("/createWallet")
	@Produces
	public String createNewWallet(@Context UriInfo uriInfo,
			   @QueryParam("merchant_id") String merchant_id,
			   @QueryParam("scope") String scope,
				@QueryParam("first_name") String first_name,
				@QueryParam("last_name") String last_name,
				@QueryParam("email") String email,
				@QueryParam("mobile") String mobile,
				@QueryParam("dob") String dob,
				@QueryParam("gender") String gender,
				@QueryParam("ip_address") String ip_address,
				@QueryParam("os") String os,
				@QueryParam("device_id") String device_id,
				@QueryParam("state") String state,
				@QueryParam("client_id") String clientId, 
				@QueryParam("token") String authToken) throws JSONException{
		
		HashSet<String> set = new HashSet<String>();
		set.add("merchant_id");
		set.add("scope");
		set.add("first_name");
		set.add("last_name");
		set.add("email");
		set.add("mobile");
		set.add("dob");
		set.add("gender");
		set.add("os");
		set.add("device_id");
		set.add("state");
		set.add("client_id");
		set.add("token");
		
		String data = keyvalidation(uriInfo, set);
		if (data.equalsIgnoreCase("ok"))
		  {
		
		WalletLoginUser wlUser = new WalletLoginUser();
		wlUser.setMerchant_id(merchant_id);
		wlUser.setScope(scope);
		wlUser.setFirst_name(first_name);
		wlUser.setLast_name(last_name);
		wlUser.setEmail(email);
		wlUser.setMobile(mobile);
		wlUser.setDob(dob);
		wlUser.setGender(gender);
		wlUser.setIp_address(ip_address);
		wlUser.setOs(os);
		wlUser.setDevice_id(device_id);
		wlUser.setState(state);
		
		boolean authFlag=false;
		try {
			System.out.println("client Id:"+clientId);
			System.out.println("Auth token"+authToken);
			jsonObject = new JsonObject();
			jsonObject1 = new JsonObject();
			System.out.println("merchant_id"+merchant_id);
			if (!merchant_id.equals("")){
				if(!scope.equals("")){
					if(!first_name.equals("")){
						if(!last_name.equals("")){
							if(!email.equals("")){
								if(!mobile.equals("")){
									if(!dob.equals("")){
										if(!gender.equals("")){
											if(!ip_address.equals("")){
												if(!os.equals("")){
													if(!device_id.equals("")){
														if(!state.equals("")){
															
														
			
			authFlag = authenticateService.validateClient(clientId, authToken, "createWallet");
			
			System.out.println("createNewWallet Authenticate Flag==="+authFlag);
			
			WalletLoginUserReturn listData = new WalletLoginUserReturn();
			/*if(!authFlag){
				jsonObject.addProperty("errorCode", ErrorCodeConstants.VALIDATE_AUTHTOKEN);
				jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.VALIDATE_AUTHTOKEN_DESC);
				return jsonObject.toString();
			}*/
			
			if(!authFlag){
				jsonObject.addProperty("Code", ErrorCodeConstants.VALIDATE_AUTHTOKEN);
				jsonObject.addProperty("Message", ErrorCodeConstants.VALIDATE_AUTHTOKEN_DESC);
				return jsonObject.toString();
			}
		//try {
			/*jsonObject.addProperty("errorCode", ErrorCodeConstants.SUCCESS_CODE);
        	jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.SUCCESS_DESC);
        	jsonObject.add("WalletDetails", new Gson().toJsonTree(walletService.createNewWallet(wlUser) ));
			 return jsonObject.toString();*/
			jsonObject.addProperty("Code", ErrorCodeConstants.SUCCESS_CODE);
        	//jsonObject.addProperty("Message", ErrorCodeConstants.SUCCESS_DESC);
        	//jsonObject.add("WalletDetails", new Gson().toJsonTree(walletService.createNewWallet(wlUser) ));
        	listData = walletService.createNewWallet(wlUser);
        	jsonObject1.addProperty("creationStatus", listData.getCreationStatus());
        	jsonObject1.addProperty("auth_data", listData.getAuth_data());
        	al.add(jsonObject);
        	al.add(jsonObject1);
        	return al.toString();
			}else{
				jsonObject.addProperty("Code", "400");
				jsonObject.addProperty("Message", "Please provide state");
				return jsonObject.toString();
			}	
													}else{
														jsonObject.addProperty("Code", "400");
														jsonObject.addProperty("Message", "Please provide Device Id");
														return jsonObject.toString();
													}
												}else{
													jsonObject.addProperty("Code", "400");
													jsonObject.addProperty("Message", "Please provide OS");
													return jsonObject.toString();
												}
											}else{
												jsonObject.addProperty("Code", "400");
												jsonObject.addProperty("Message", "Please provide IP Address");
												return jsonObject.toString();
											}
										}else{
											jsonObject.addProperty("Code", "400");
											jsonObject.addProperty("Message", "Please provide Gender");
											return jsonObject.toString();
										}
									}else{
										jsonObject.addProperty("Code", "400");
										jsonObject.addProperty("Message", "Please provide Date Of Birth");
										return jsonObject.toString();
									}
								}else{
									jsonObject.addProperty("Code", "400");
									jsonObject.addProperty("Message", "Please provide Mobile Number");
									return jsonObject.toString();
								}
							}else{
								jsonObject.addProperty("Code", "400");
								jsonObject.addProperty("Message", "Please provide Email Id");
								return jsonObject.toString();
							}
						}else{
							jsonObject.addProperty("Code", "400");
							jsonObject.addProperty("Message", "Please provide Last Name");
							return jsonObject.toString();
						}
					}else{
						jsonObject.addProperty("Code", "400");
						jsonObject.addProperty("Message", "Please provide First Name");
						return jsonObject.toString();
					}
				}else{
					jsonObject.addProperty("Code", "400");
					jsonObject.addProperty("Message", "Please provide Scope");
					return jsonObject.toString();
				}
			}else{
				jsonObject.addProperty("Code", "400");
				jsonObject.addProperty("Message", "Please provide merchant_id");
				return jsonObject.toString();
			}
			
			
		} catch(Exception e){
			System.out.println("Exception==>>"+e.getMessage());
			jsonObject.addProperty("errorCode", ErrorCodeConstants.SUCCESS_CODE);
        	jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.SUCCESS_DESC);
        	
			 return jsonObject.toString();
		}
		  } else
		  {
			jobj.put("code", 454);
			jobj.put("description", "Invalid Parameter");
			jobj.put("message", data);
			jarray.put(jobj);
			System.out.println(jarray.toString());
			
			return jarray.toString();
		  }
		
		
	}
	
	@GET
	@Path("/getWalletBalance")
	@Produces
	
	
	public String getWalletBalance(@Context UriInfo uriInfo,
			@QueryParam("id_type") String id_type,
			@QueryParam("id_value") String id_value,
			@QueryParam("auth_type") String auth_type,
			@QueryParam("auth_data") String auth_data,
			@QueryParam("latitude") double latitude,
			@QueryParam("longitude") double longitude,
			@QueryParam("imei") String imei,
			@QueryParam("device_id") String device_id,
			@QueryParam("ip_address") String ip_address,
			@QueryParam("os") String os,
			@QueryParam("client_id") String clientID,
			@QueryParam("token") String authToken
			) throws JSONException {
		HashSet<String> set = new HashSet<String>();
		set.add("id_type");
		set.add("id_value");
		set.add("auth_type");
		set.add("auth_data");
		set.add("latitude");
		set.add("longitude");
		set.add("device_id");
		set.add("ip_address");
		set.add("os");
		set.add("client_id");
		set.add("token");
		
		String data = keyvalidation(uriInfo, set);
		if (data.equalsIgnoreCase("ok"))
		  {
		
		Wallet searchCriteria = new Wallet();
		searchCriteria.setId_type(id_type);
		searchCriteria.setId_value(id_value);
		searchCriteria.setAuth_type(auth_type);
		searchCriteria.setAuth_data(auth_data);
		searchCriteria.setLatitude(latitude);
		searchCriteria.setLongitude(longitude);
		searchCriteria.setImei(imei);
		searchCriteria.setDevice_id(device_id);
		searchCriteria.setIp_address(ip_address);
		searchCriteria.setOs(os);
		searchCriteria.setClientID(clientID);
		searchCriteria.setAuthToken(authToken);
		String js = null;
		boolean authFlag=false;
		try {
			System.out.println("client Id no:"+searchCriteria.getClientID());
			System.out.println("auth token no:"+searchCriteria.getAuthToken());
			jsonObject = new JsonObject();
			if (!id_type.equals("")){
				if(!id_value.equals("")){
					if(!auth_type.equals("")){
						if(!auth_data.equals("")){
								if(!imei.equals("")){
										if(!device_id.equals("")){
											if(!ip_address.equals("")){
												if(!os.equals("")){
													if(!clientID.equals("")){
														if(!authToken.equals("")){
			authFlag = authenticateService.validateClient(searchCriteria.getClientID(), searchCriteria.getAuthToken(), "getWalletBalance");
			System.out.println("getWalletBalance Authenticate Flag==="+authFlag);
			if(!authFlag){
				jsonObject.addProperty("errorCode", ErrorCodeConstants.VALIDATE_AUTHTOKEN);
				jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.VALIDATE_AUTHTOKEN_DESC);
				return jsonObject.toString();
			}
			js = walletService.getWalletBalance(searchCriteria);
			return js;
														}else{
															jsonObject.addProperty("Code", "400");
															jsonObject.addProperty("Message", "Please provide authToken");
															return jsonObject.toString();
														}
													}else{
														jsonObject.addProperty("Code", "400");
														jsonObject.addProperty("Message", "Please provide clientID");
														return jsonObject.toString();
													}
												}else{
													jsonObject.addProperty("Code", "400");
													jsonObject.addProperty("Message", "Please provide os");
													return jsonObject.toString();
												}
											}else{
												jsonObject.addProperty("Code", "400");
												jsonObject.addProperty("Message", "Please provide ip_address");
												return jsonObject.toString();
											}
										}else{
											jsonObject.addProperty("Code", "400");
											jsonObject.addProperty("Message", "Please provide device_id");
											return jsonObject.toString();
										}
									}else{
										jsonObject.addProperty("Code", "400");
										jsonObject.addProperty("Message", "Please provide imei");
										return jsonObject.toString();
									}
								}else{
									jsonObject.addProperty("Code", "400");
									jsonObject.addProperty("Message", "Please provide auth_data");
									return jsonObject.toString();
								}
							}else{
								jsonObject.addProperty("Code", "400");
								jsonObject.addProperty("Message", "Please provide auth_type");
								return jsonObject.toString();
							}
						}else{
							jsonObject.addProperty("Code", "400");
							jsonObject.addProperty("Message", "Please provide id_value");
							return jsonObject.toString();
						}
			}else{
				jsonObject.addProperty("Code", "400");
				jsonObject.addProperty("Message", "Please provide id_type");
				return jsonObject.toString();
			}
		} catch (Exception e) {
			jsonObject = new JsonObject();
			jsonObject.addProperty("errorCode", ErrorCodeConstants.INTERNAL_ERROR);
			jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.INTERNAL_ERROR_DESC);
		}
		  } else
		  {
			jobj.put("code", 454);
			jobj.put("description", "Invalid Parameter");
			jobj.put("message", data);
			jarray.put(jobj);
			System.out.println(jarray.toString());
			
			return jarray.toString();
		  }
		return jsonObject.toString();
	}
		
	@GET
	@Path("/creditWalletAmount")
	@Produces
	
	public String creditWalletAmount(@Context UriInfo uriInfo,
			@QueryParam("id_type") String id_type,
			@QueryParam("id_value") String id_value,
			@QueryParam("auth_type") String auth_type,
			@QueryParam("auth_data") String auth_data,
			@QueryParam("txn_id") String txn_id,
			@QueryParam("amount") double amount,
			@QueryParam("promocode") String promocode,
			@QueryParam("remarks") String remarks,
			@QueryParam("sub_merchant") String sub_merchant,
			@QueryParam("latitude") double latitude,
			@QueryParam("longitude") double longitude,
			@QueryParam("imei") String imei,
			@QueryParam("device_id") String device_id,
			@QueryParam("ip_address") String ip_address,
			@QueryParam("os") String os,
			@QueryParam("client_id") String clientID,
			@QueryParam("token") String authToken
			) throws JSONException{
		HashSet<String> set = new HashSet<String>();
		set.add("id_type");
		set.add("id_value");
		set.add("auth_type");
		set.add("auth_data");
		set.add("txn_id");
		set.add("amount");
		set.add("promocode");
		set.add("remarks");
		set.add("sub_merchant");
		set.add("latitude");
		set.add("longitude");
		set.add("imei");
		set.add("device_id");
		set.add("ip_address");
		set.add("os");
		set.add("client_id");
		set.add("token");
		
		String data = keyvalidation(uriInfo, set);
		if (data.equalsIgnoreCase("ok"))
		  {
		
		
		Wallet searchCriteria = new Wallet();
		searchCriteria.setId_type(id_type);
		searchCriteria.setId_value(id_value);
		searchCriteria.setAuth_type(auth_type);
		searchCriteria.setAuth_data(auth_data);
		searchCriteria.setTxn_id(txn_id);
		searchCriteria.setAmount(amount);
		searchCriteria.setPromocode(promocode);
		searchCriteria.setRemarks(remarks);
		searchCriteria.setSub_merchant(sub_merchant);
		searchCriteria.setLatitude(latitude);
		searchCriteria.setLongitude(longitude);
		searchCriteria.setImei(imei);
		searchCriteria.setDevice_id(device_id);
		searchCriteria.setIp_address(ip_address);
		searchCriteria.setOs(os);
		searchCriteria.setClientID(clientID);
		searchCriteria.setAuthToken(authToken);
		String ja = null;
		boolean authFlag=false;
		try {
			System.out.println("client Id no:"+searchCriteria.getClientID());
			System.out.println("auth token no:"+searchCriteria.getAuthToken());
			jsonObject = new JsonObject();
			
			if (!id_type.equals("")){
				if(!id_value.equals("")){
					if(!auth_type.equals("")){
						if(!auth_data.equals("")){
								if(!txn_id.equals("")){
										if(!promocode.equals("")){
											if(!remarks.equals("")){
												if(!sub_merchant.equals("")){
													if(!imei.equals("")){
														if(!device_id.equals("")){
															if(!ip_address.equals("")){
																if(!os.equals("")){
																	if(!clientID.equals("")){
																		if(!authToken.equals("")){
			authFlag = authenticateService.validateClient(searchCriteria.getClientID(), searchCriteria.getAuthToken(),"Hackathon");
			System.out.println("creditWalletAmount Authenticate Flag==="+authFlag);
			
			if(!authFlag){
				jsonObject.addProperty("errorCode", ErrorCodeConstants.VALIDATE_AUTHTOKEN);
				jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.VALIDATE_AUTHTOKEN_DESC);
				return jsonObject.toString();
			}
			if(searchCriteria.getAmount()<0){
				jsonObject.addProperty("errorCode", ErrorCodeConstants.NAGITIVE_AMOUNT);
				jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.NAGITIVE_AMOUNT_DESC);
			}else if(searchCriteria.getAmount()>5000){
				jsonObject.addProperty("errorCode", ErrorCodeConstants.CREDIT_AMOUNT);
				jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.CREDIT_AMOUNT_DESC);
			}else{
				ja = walletService.creditWalletAmount(searchCriteria);
				return ja;
			}
				}else{
					jsonObject.addProperty("Code", "400");
					jsonObject.addProperty("Message", "Please provide authToken");
					return jsonObject.toString();
					}
																	}else{
																		jsonObject.addProperty("Code", "400");
																		jsonObject.addProperty("Message", "Please provide Client Id");
																		return jsonObject.toString();
																	}
																}else{
																	jsonObject.addProperty("Code", "400");
																	jsonObject.addProperty("Message", "Please provide os");
																	return jsonObject.toString();
																}
															}else{
																jsonObject.addProperty("Code", "400");
																jsonObject.addProperty("Message", "Please provide IP Address");
																return jsonObject.toString();
															}
														}else{
															jsonObject.addProperty("Code", "400");
															jsonObject.addProperty("Message", "Please provide Device Id");
															return jsonObject.toString();
														}
													}else{
														jsonObject.addProperty("Code", "400");
														jsonObject.addProperty("Message", "Please provide IMEI");
														return jsonObject.toString();
													}
												}else{
													jsonObject.addProperty("Code", "400");
													jsonObject.addProperty("Message", "Please provide sub_merchant");
													return jsonObject.toString();
												}
											}else{
												jsonObject.addProperty("Code", "400");
												jsonObject.addProperty("Message", "Please provide Remarks");
												return jsonObject.toString();
											}
										}else{
											jsonObject.addProperty("Code", "400");
											jsonObject.addProperty("Message", "Please provide promocode");
											return jsonObject.toString();
										}
								}else{
									jsonObject.addProperty("Code", "400");
									jsonObject.addProperty("Message", "Please provide txn_id");
									return jsonObject.toString();
								}
						}else{
							jsonObject.addProperty("Code", "400");
							jsonObject.addProperty("Message", "Please provide auth_data");
							return jsonObject.toString();
						}
					}else{
						jsonObject.addProperty("Code", "400");
						jsonObject.addProperty("Message", "Please provide auth_type");
						return jsonObject.toString();
					}
				}else{
					jsonObject.addProperty("Code", "400");
					jsonObject.addProperty("Message", "Please provide id_Value");
					return jsonObject.toString();
				}
			}else{
				jsonObject.addProperty("Code", "400");
				jsonObject.addProperty("Message", "Please provide id_type");
				return jsonObject.toString();
			}
		} catch (Exception e) {
			jsonObject = new JsonObject();
			jsonObject.addProperty("errorCode", ErrorCodeConstants.INTERNAL_ERROR);
			jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.INTERNAL_ERROR_DESC);
		}
		return jsonObject.toString();
		  } else
		  {
			jobj.put("code", 454);
			jobj.put("description", "Invalid Parameter");
			jobj.put("message", data);
			jarray.put(jobj);
			System.out.println(jarray.toString());
			
			return jarray.toString();
		  }
	}

	@GET
	@Path("/getWalletStatementDetails")
	@Produces
	
	public String getWalletStatDetails(@Context UriInfo uriInfo,
			@QueryParam("id_type") String id_type,
			@QueryParam("id_value") String id_value,
			@QueryParam("auth_type") String auth_type,
			@QueryParam("auth_data") String auth_data,
			@QueryParam("latitude") double latitude,
			@QueryParam("longitude") double longitude,
			@QueryParam("imei") String imei,
			@QueryParam("device_id") String device_id,
			@QueryParam("ip_address") String ip_address,
			@QueryParam("os") String os,
			@QueryParam("client_id") String clientID,
			@QueryParam("token") String authToken
			) throws JSONException{
		

HashSet<String> set = new HashSet<String>();
			set.add("id_type");
			set.add("id_value");
			set.add("auth_type");
			set.add("auth_data");
			set.add("latitude") ;
			set.add("longitude") ;
			set.add("imei");
			set.add("device_id");
			set.add("ip_address");
			set.add("os") ;
			set.add("client_id") ;
			set.add("token") ;
			String data = keyvalidation(uriInfo, set);
			if (data.equalsIgnoreCase("ok"))
			  {
		
		JsonObject jsonoject =new JsonObject();
		JsonArray jarray = new JsonArray();
		List<WalletResponse> result = null;
		Wallet wallet =new Wallet();
		wallet.setId_type(id_type);
		wallet.setId_value(id_value);
		wallet.setAuth_type(auth_type);
		wallet.setAuth_data(auth_data);
		wallet.setLatitude(latitude);
		wallet.setLongitude(longitude);
		wallet.setImei(imei);
		wallet.setDevice_id(device_id);
		wallet.setIp_address(ip_address);
		wallet.setOs(os);
		wallet.setClientID(clientID);
		wallet.setAuthToken(authToken);
		
		try {
			System.out.println("client Id no:"+wallet.getClientID());
			System.out.println("auth token no:"+wallet.getAuthToken());
			jsonObject = new JsonObject();
			if (!id_type.equals("")){
				if(!id_value.equals("")){
					if(!auth_type.equals("")){
						if(!auth_data.equals("")){
							if(!imei.equals("")){
								if(!device_id.equals("")){
									if(!ip_address.equals("")){
										if(!os.equals("")){
											if(!clientID.equals("")){
												if(!authToken.equals("")){
													
			boolean authFlag = false;
			result = new ArrayList<WalletResponse>();
			authFlag = authenticateService.validateClient(wallet.getClientID(), wallet.getAuthToken(),"Hackathon");
			System.out.println("getWalletStatDetails Authenticate Flag==="+authFlag);
			if (!authFlag) {
				result.add(new WalletResponse());
				//result.add(CommmonUtils.getErrorInfo(ErrorCodeConstants.VALIDATE_AUTHTOKEN,ErrorCodeConstants.VALIDATE_AUTHTOKEN_DESC));
			} else {
				result = walletService.getWalletStatementDetails(wallet);
				for ( WalletResponse wr : result){
					jsonoject =new JsonObject();
					jsonoject.addProperty("bank_txn_id", wr.getBank_txn_id());
					jsonoject.addProperty("txn_id", wr.getTxn_id());
					jsonoject.addProperty("amount", wr.getAmount());
					jsonoject.addProperty("transDate", wr.getTransDate());
					jsonoject.addProperty("transType", wr.getTransType());
					jsonoject.addProperty("remarks", wr.getRemarks());
					jsonoject.addProperty("walletAcNo", wr.getWalletAcNo());
					jarray.add(jsonoject);
				}
			}
												}else{
													jsonObject.addProperty("Code", "400");
													jsonObject.addProperty("Message", "Please provide authToken");
													return jsonObject.toString();
													}
																									}else{
																										jsonObject.addProperty("Code", "400");
																										jsonObject.addProperty("Message", "Please provide Client Id");
																										return jsonObject.toString();
																									}
																								}else{
																									jsonObject.addProperty("Code", "400");
																									jsonObject.addProperty("Message", "Please provide os");
																									return jsonObject.toString();
																								}
																							}else{
																								jsonObject.addProperty("Code", "400");
																								jsonObject.addProperty("Message", "Please provide IP Address");
																								return jsonObject.toString();
																							}
																						}else{
																							jsonObject.addProperty("Code", "400");
																							jsonObject.addProperty("Message", "Please provide Device Id");
																							return jsonObject.toString();
																						}
																					}else{
																						jsonObject.addProperty("Code", "400");
																						jsonObject.addProperty("Message", "Please provide IMEI");
																						return jsonObject.toString();
																					}
																				}else{
																					jsonObject.addProperty("Code", "400");
																					jsonObject.addProperty("Message", "Please provide auth_data");
																					return jsonObject.toString();
																				}
																			}else{
																				jsonObject.addProperty("Code", "400");
																				jsonObject.addProperty("Message", "Please provide auth_type");
																				return jsonObject.toString();
																			}
																		}else{
																			jsonObject.addProperty("Code", "400");
																			jsonObject.addProperty("Message", "Please provide ID Value");
																			return jsonObject.toString();
																		}
																}else{
																	jsonObject.addProperty("Code", "400");
																	jsonObject.addProperty("Message", "Please provide ID Type");
																	return jsonObject.toString();
																}

		} catch (Exception e) {
			result.add(new WalletResponse());
			//result.add(CommmonUtils.getErrorInfo(ErrorCodeConstants.INTERNAL_ERROR,ErrorCodeConstants.INTERNAL_ERROR_DESC));
		}
			  } else
			  {
				jobj.put("code", 454);
				jobj.put("description", "Invalid Parameter");
				jobj.put("message", data);
				jarray.put(jobj);
				System.out.println(jarray.toString());
				
				return jarray.toString();
			  }
			  
		return jarray.toString();
		
	}

	@GET
	@Path("/debitWalletAmount")
	@Produces
	
	public String debitWalletAmount(@Context UriInfo uriInfo,
			@QueryParam("id_type") String id_type,
			@QueryParam("id_value") String id_value,
			@QueryParam("auth_type") String auth_type,
			@QueryParam("auth_data") String auth_data,
			@QueryParam("txn_id") String txn_id,
			@QueryParam("amount") double amount,
			@QueryParam("promocode") String promocode,
			@QueryParam("remarks") String remarks,
			@QueryParam("sub_merchant") String sub_merchant,
			@QueryParam("latitude") double latitude,
			@QueryParam("longitude") double longitude,
			@QueryParam("imei") String imei,
			@QueryParam("device_id") String device_id,
			@QueryParam("ip_address") String ip_address,
			@QueryParam("os") String os,
			@QueryParam("client_id") String clientID,
			@QueryParam("token") String authToken
			) throws JSONException{
		HashSet<String> set = new HashSet<String>();
		set.add("id_type");
		set.add("id_value");
		set.add("auth_type");
		set.add("auth_data");
		set.add("txn_id") ;
		set.add("amount") ;
		set.add("promocode");
		set.add("remarks");
		set.add("sub_merchant");
		set.add("latitude") ;
		set.add("longitude") ;
		set.add("imei") ;
		set.add("device_id");
		set.add("ip_address");
		set.add("os");
		set.add("client_id") ;
		set.add("token") ;
		String data = keyvalidation(uriInfo, set);
		if (data.equalsIgnoreCase("ok"))
		  {
		
		
		Wallet searchCriteria = new Wallet();
		searchCriteria.setId_type(id_type);
		searchCriteria.setId_value(id_value);
		searchCriteria.setAuth_type(auth_type);
		searchCriteria.setAuth_data(auth_data);
		searchCriteria.setTxn_id(txn_id);
		searchCriteria.setAmount(amount);
		searchCriteria.setPromocode(promocode);
		searchCriteria.setRemarks(remarks);
		searchCriteria.setSub_merchant(sub_merchant);
		searchCriteria.setLatitude(latitude);
		searchCriteria.setLongitude(longitude);
		searchCriteria.setImei(imei);
		searchCriteria.setDevice_id(device_id);
		searchCriteria.setIp_address(ip_address);
		searchCriteria.setOs(os);
		searchCriteria.setClientID(clientID);
		searchCriteria.setAuthToken(authToken);
		
		String ja = null;
		
		boolean authFlag=false;
		try {
			System.out.println("client Id no:"+searchCriteria.getClientID());
			System.out.println("auth token no:"+searchCriteria.getAuthToken());
			jsonObject = new JsonObject();
			if (!id_type.equals("")){
				if(!id_value.equals("")){
					if(!auth_type.equals("")){
						if(!auth_data.equals("")){
								if(!txn_id.equals("")){
										if(!promocode.equals("")){
											if(!remarks.equals("")){
												if(!sub_merchant.equals("")){
													if(!imei.equals("")){
														if(!device_id.equals("")){
															if(!ip_address.equals("")){
																if(!os.equals("")){
																	if(!clientID.equals("")){
																		if(!authToken.equals("")){
			authFlag = authenticateService.validateClient(searchCriteria.getClientID(), searchCriteria.getAuthToken(), "Hackathon");
			System.out.println("debitWalletAmount Authenticate Flag==="+authFlag);
			if(!authFlag){
				jsonObject.addProperty("errorCode", ErrorCodeConstants.VALIDATE_AUTHTOKEN);
				jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.VALIDATE_AUTHTOKEN_DESC);
				return jsonObject.toString();
			}
			if(searchCriteria.getAmount()<0){
				jsonObject.addProperty("errorCode", ErrorCodeConstants.NAGITIVE_AMOUNT);
				jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.NAGITIVE_AMOUNT_DESC);
			}else{
				ja = walletService.debitWalletAmount(searchCriteria);
				return ja;
			}
																		}else{
																			jsonObject.addProperty("Code", "400");
																			jsonObject.addProperty("Message", "Please provide authToken");
																			return jsonObject.toString();
																			}
																															}else{
																																jsonObject.addProperty("Code", "400");
																																jsonObject.addProperty("Message", "Please provide Client Id");
																																return jsonObject.toString();
																															}
																														}else{
																															jsonObject.addProperty("Code", "400");
																															jsonObject.addProperty("Message", "Please provide os");
																															return jsonObject.toString();
																														}
																													}else{
																														jsonObject.addProperty("Code", "400");
																														jsonObject.addProperty("Message", "Please provide IP Address");
																														return jsonObject.toString();
																													}
																												}else{
																													jsonObject.addProperty("Code", "400");
																													jsonObject.addProperty("Message", "Please provide Device Id");
																													return jsonObject.toString();
																												}
																											}else{
																												jsonObject.addProperty("Code", "400");
																												jsonObject.addProperty("Message", "Please provide IMEI");
																												return jsonObject.toString();
																											}
																										}else{
																											jsonObject.addProperty("Code", "400");
																											jsonObject.addProperty("Message", "Please provide sub_merchant");
																											return jsonObject.toString();
																										}
																									}else{
																										jsonObject.addProperty("Code", "400");
																										jsonObject.addProperty("Message", "Please provide Remarks");
																										return jsonObject.toString();
																									}
																								}else{
																									jsonObject.addProperty("Code", "400");
																									jsonObject.addProperty("Message", "Please provide promocode");
																									return jsonObject.toString();
																								}
																						}else{
																							jsonObject.addProperty("Code", "400");
																							jsonObject.addProperty("Message", "Please provide txn_id");
																							return jsonObject.toString();
																						}
																				}else{
																					jsonObject.addProperty("Code", "400");
																					jsonObject.addProperty("Message", "Please provide auth_data");
																					return jsonObject.toString();
																				}
																			}else{
																				jsonObject.addProperty("Code", "400");
																				jsonObject.addProperty("Message", "Please provide auth_type");
																				return jsonObject.toString();
																			}
																		}else{
																			jsonObject.addProperty("Code", "400");
																			jsonObject.addProperty("Message", "Please provide id_Value");
																			return jsonObject.toString();
																		}
																	}else{
																		jsonObject.addProperty("Code", "400");
																		jsonObject.addProperty("Message", "Please provide id_type");
																		return jsonObject.toString();
																	}
		} catch (Exception e) {
			jsonObject = new JsonObject();
			jsonObject.addProperty("errorCode", ErrorCodeConstants.INTERNAL_ERROR);
			jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.INTERNAL_ERROR_DESC);
		}
		  } else
		  {
			jobj.put("code", 454);
			jobj.put("description", "Invalid Parameter");
			jobj.put("message", data);
			jarray.put(jobj);
			System.out.println(jarray.toString());
			
			return jarray.toString();
		  }
		return jsonObject.toString();
	}
	
	
	public String keyvalidation(UriInfo uriInfo, HashSet<String> set)
	  {
		StringBuilder sb = new StringBuilder();
		try
		  {
			System.out.println(uriInfo.getQueryParameters());
			
			MultivaluedMap<String, String> params = uriInfo.getQueryParameters();
			System.out.println("fixd keys : " + set);
			
			System.out.println(params.keySet().containsAll(set));
			
			for (String d : set)
			  {
				if (params.keySet().containsAll(set))
				  {
					return "ok";
				  }
				System.out.println();
				if (!params.containsKey(d))
				  {
					sb.append(d + "----");
				  }
			  }
			return "key issue for " + sb.toString();
			
		  } catch (Exception e)
		  {
			
			System.err.println(e.getMessage());
		  }
		return "please Check all key it should be " + set + " only";
	  }
}