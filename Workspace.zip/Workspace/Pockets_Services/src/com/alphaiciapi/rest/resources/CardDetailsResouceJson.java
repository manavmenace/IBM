package com.alphaiciapi.rest.resources;

import java.util.HashSet;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.UriInfo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.alphaiciapi.model.CardDetails;
import com.alphaiciapi.model.SearchCriteria;
import com.alphaiciapi.service.AuthenticateService;
import com.alphaiciapi.service.CardDetailsService;
import com.alphaiciapi.util.ErrorCodeConstants;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

@Path("/Card")
public class CardDetailsResouceJson {
	JSONObject jobj          = new JSONObject();
	JSONArray  jarray        = new JSONArray();
	
		AuthenticateService authenticateService=new AuthenticateService();
		
		/*@GET
		@Path("getCardDetails/{cardNumber}/{clientId}/{authToken}")
		@Produces
		public String getCardDetails(@PathParam("cardNumber") String cardNumber,
				@PathParam("clientId") String clientId, 
				@PathParam("authToken") String authToken) {*/
		
		@GET
		@Path("/getCardDetails")
		@Produces
		public String getCardDetails(@Context UriInfo uriInfo,@QueryParam("cardNumber") String cardNumber,
				@QueryParam("client_id") String clientId, 
				@QueryParam("authToken") String authToken) throws JSONException {
			HashSet<String> set = new HashSet<String>();
			set.add("cardNumber");
			set.add("client_id");
			set.add("authToken");
			String data = keyvalidation(uriInfo, set);
			if (data.equalsIgnoreCase("ok"))
			  {
				
			
			

			System.out.println("Starting of getCardDetails() of WalletResource ");
			System.out.println("card no:"+cardNumber);
			System.out.println("client Id:"+clientId);
			System.out.println("Auth token"+authToken);
			
			
			CardDetailsService cdService =  new CardDetailsService();
	    	List<CardDetails> cardDetailsList = null;
	    	JsonObject jsonObject =  new JsonObject();
	    	JsonObject jsonObject1 =  new JsonObject();
	    	JsonArray jsonArray =  new JsonArray();
			
	    	String statusString = "";
			String jsonResString="";
			String returnString="";
			
			boolean authFlag=false;
			try {
				jsonObject = new JsonObject();
				authFlag = authenticateService.validateClient(clientId, authToken, "getCardDetails");
				System.out.println("createNewWallet Authenticate Flag==="+authFlag);
				if(!authFlag){
					jsonObject.addProperty("code", ErrorCodeConstants.VALIDATE_AUTHTOKEN);
					jsonObject.addProperty("description", ErrorCodeConstants.VALIDATE_AUTHTOKEN_DESC);
					return jsonObject.toString();
				}
				
		    	/*if( !(ValidationUtil.isCreditCardLengthValid(accountNumber))){
					
		    		errorCode.setErrorCode(ErrorCodeConstants.INVALID_ACCOUNT);
		    		errorCode.setErrorDescripttion(ErrorCodeConstants.INVALID_ACCOUNT_DESC);
		    		statusString = gson.toJson(errorCode);
		    		return statusString;
				}
		    	
		    	if( !(ValidationUtil.isAmountNumeric(String.valueOf(amount)))){
					
		    		errorCode.setErrorCode(ErrorCodeConstants.INVALID_AMOUNT);
		    		errorCode.setErrorDescripttion(ErrorCodeConstants.INVALID_AMOUNT_DESC);
		    		statusString = gson.toJson(errorCode);
		    		return statusString;
				}*/
		    	
				
				SearchCriteria searchCriteria = new SearchCriteria();
				searchCriteria.setCardNumber(cardNumber);
				//wallet.setAmount(amount);
				
		    	
				cardDetailsList = cdService.getCardDetails(searchCriteria);
				
				System.out.println("Size of cardDetailsList in CardDetailsResouce==>>"+cardDetailsList.size());
				
					/*if(cardDetailsList.size()>0 && !(cardDetailsList.isEmpty())){
						jsonObject.addProperty("code", ErrorCodeConstants.SUCCESS_CODE);
			        	jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.SUCCESS_DESC);
			        	jsonObject.add("cardDetails", new Gson().toJsonTree(cardDetailsList ));
			    		return jsonObject.toString();
					} else if(cardDetailsList.size()==0 && cardDetailsList.isEmpty()) {
						jsonObject.addProperty("errorCode", ErrorCodeConstants.RECORD_NOT_FOUNT);
			        	jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.RECORD_NOT_FOUNT_DESC);
			        	return jsonObject.toString();
					} else {
						jsonObject.addProperty("errorCode", ErrorCodeConstants.INTERNAL_ERROR);
			        	jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.INTERNAL_ERROR_DESC);
			        	return jsonObject.toString();
					}*/
					
				if(cardDetailsList.size()>0 && !(cardDetailsList.isEmpty())) {
					jsonObject1.addProperty("code", ErrorCodeConstants.SUCCESS_CODE);
					jsonArray.add(jsonObject1);
		        	
					for (CardDetails dtls : cardDetailsList) {
						jsonObject.addProperty("card_no", dtls.getCardNumber());
						jsonObject.addProperty("cardType", dtls.getCardType());
						jsonObject.addProperty("cardStatus", dtls.getCardStatus());
						/*jsonObject.addProperty("current_balance", dtls.getCurrent_balance());*/
						jsonObject.addProperty("current_balance", 400.00);
						jsonObject.addProperty("date_of_enrolemnt", dtls.getDate_of_enrolemnt());
						//jsonObject.addProperty("month_delinquency", dtls.getMonth_delinquency());
						jsonObject.addProperty("custId", dtls.getCustId());
						jsonObject.addProperty("expiry_date", dtls.getExpiry_date());
						jsonObject.addProperty("avail_lmt", dtls.getAvail_lmt());
					}
					jsonArray.add(jsonObject);
		    		return jsonArray.toString();
				} else if(cardDetailsList.size()==0 && cardDetailsList.isEmpty()) {
					jsonObject.addProperty("code", ErrorCodeConstants.RECORD_NOT_FOUNT);
		        	jsonObject.addProperty("message", ErrorCodeConstants.RECORD_NOT_FOUNT_DESC);
		        	jsonObject.addProperty("description", ErrorCodeConstants.INVALID_REQUEST_DESC);
		        	return jsonObject.toString();
				} else {
					jsonObject.addProperty("code", ErrorCodeConstants.INTERNAL_ERROR);
		        	jsonObject.addProperty("message", ErrorCodeConstants.INTERNAL_ERROR_MSG);
		        	jsonObject.addProperty("description", ErrorCodeConstants.INTERNAL_ERROR_DESC);
		        	return jsonObject.toString();
				}
			
			} catch (Exception e) {
				System.out.println("Exception==>>"+e.getMessage());
				jsonObject.addProperty("code", ErrorCodeConstants.INTERNAL_ERROR);
	        	jsonObject.addProperty("message", ErrorCodeConstants.INTERNAL_ERROR_MSG);
	        	jsonObject.addProperty("description", ErrorCodeConstants.INTERNAL_ERROR_DESC);
	        	return jsonObject.toString();
				
			}finally{
				
				if(statusString !=null){
					statusString =null;
				}
				if(jsonResString !=null){
					jsonResString = null;
				}
				if(returnString !=null){
					returnString = null;
				}

			}
			  } else
			  {
				jobj.put("code", 454);
				jobj.put("description", "Invalid Parameter");
				jobj.put("message", data);
				jarray.put(jobj);
				System.out.println(jarray.toString());
				
				return jarray.toString();
			  }
		}
		
		public String keyvalidation(UriInfo uriInfo, HashSet<String> set)
		  {
			StringBuilder sb = new StringBuilder();
			try
			  {
				System.out.println(uriInfo.getQueryParameters());
				
				MultivaluedMap<String, String> params = uriInfo.getQueryParameters();
				System.out.println("fixd keys : " + set);
				
				System.out.println(params.keySet().containsAll(set));
				
				for (String d : set)
				  {
					if (params.keySet().containsAll(set))
					  {
						return "ok";
					  }
					System.out.println();
					if (!params.containsKey(d))
					  {
						sb.append(d + "----");
					  }
				  }
				return "key issue for " + sb.toString();
				
			  } catch (Exception e)
			  {
				
				System.err.println(e.getMessage());
			  }
			return "please Check all key it should be " + set + " only";
		  }
		
}
