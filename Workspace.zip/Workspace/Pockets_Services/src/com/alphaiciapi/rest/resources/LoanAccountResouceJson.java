package com.alphaiciapi.rest.resources;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import com.alphaiciapi.model.ErrorCode;
import com.alphaiciapi.model.Loan;
import com.alphaiciapi.model.SearchCriteria;
import com.alphaiciapi.service.LoanAccountService;
import com.alphaiciapi.util.ErrorCodeConstants;
import com.alphaiciapi.util.ValidationUtil;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

@Path("/Loan/getLoanDetails1212")
public class LoanAccountResouceJson {
	
	
	

	@GET
	
	@Path("/{param}")
	@Produces
	
	public String getLoanDetails(@PathParam("param") String accountNumber) {
		
		System.out.println("Account no:"+accountNumber);
		//Test t = new Test();
		ErrorCode errorCode = new ErrorCode();
		SearchCriteria searchCriteria= new SearchCriteria();
		LoanAccountService lnAccService=new LoanAccountService();
		JsonObject jsonObject =  new JsonObject();
		List<Loan> loanLists;
		Gson gson = new Gson();
    	String statusString = "";
		String jsonResString="";
		String returnString="";
		try {
			
    	if( !(ValidationUtil.isLoanAccoutLengthValid(accountNumber))){
			
    		
    		jsonObject.addProperty("errorCode", ErrorCodeConstants.INVALID_ACCOUNT);
        	jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.INVALID_ACCOUNT_DESC);
    		
    		return jsonObject.toString();
		}
    	searchCriteria.setAccountNumber(accountNumber);
		
    	
    		loanLists = null;//lnAccService.getLoanDetails(searchCriteria);
    		//loanLists = t.getTempList(searchCriteria);
			
			if(loanLists.size()>0 && !(loanLists.isEmpty())){
				
				jsonObject.addProperty("errorCode", ErrorCodeConstants.SUCCESS_CODE);
	        	jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.SUCCESS_DESC);
	        	jsonObject.add("loanDetails", new Gson().toJsonTree(loanLists ));
	    		return jsonObject.toString();
	    		
				
			}else if(loanLists.size()==0 && loanLists.isEmpty()){
				
				jsonObject.addProperty("errorCode", ErrorCodeConstants.RECORD_NOT_FOUNT);
	        	jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.RECORD_NOT_FOUNT_DESC);
	        	return jsonObject.toString();
				
			}else{
				jsonObject.addProperty("errorCode", ErrorCodeConstants.INTERNAL_ERROR);
	        	jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.INTERNAL_ERROR_DESC);
	        	return jsonObject.toString();
			}
			
			
		
		} catch (Exception e) {
			System.out.println("Exception==>>"+e.getMessage());
			jsonObject.addProperty("errorCode", ErrorCodeConstants.INTERNAL_ERROR);
        	jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.INTERNAL_ERROR_DESC);
        	
    		return jsonObject.toString();
		}finally{
			
			if(statusString !=null){
				statusString =null;
			}
			if(jsonResString !=null){
				jsonResString = null;
			}
			if(returnString !=null){
				returnString = null;
			}

		}
		
	}
}
