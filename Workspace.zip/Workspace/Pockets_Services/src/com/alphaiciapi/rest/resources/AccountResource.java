package com.alphaiciapi.rest.resources;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;




@Path("/Account")
//@Component("accountResource")
public class AccountResource {

/*
	@Autowired
	AccountService  accountService;
	

	
	
	@Path("/getData")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_PLAIN)
	@GET
	public String getValue() {


		return "Test...";
	}

	@Path("/getAccountDetails")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@POST
	public List<Account> getAccountDetails(SearchCriteria account) {
		//AccountService  accountService=null;
		try {
			System.out.println("account.getMobileNO()===" + account.getMobileNO());
			System.out.println("account.getToken()===" + account.getToken());
			//accountService = new AccountService();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return accountService.getAccounts(account);
	}
	
	
	@Path("/getBalanceDetails")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@POST
	public List<AccountInfo> getBalanceDetails(SearchCriteria account) {
		AccountService  accountService=null;
		try {
			System.out.println("account.getAccountNumber()===" + account.getAccountNumber());
			System.out.println("account.getToken()===" + account.getToken());
			accountService = new AccountService();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return accountService.getBalanceDetails(account);
	}
	
	
	@Path("/getTransactionHistory")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@POST
	public List<TransactinDetails> getTransactionHistory(SearchCriteria account) {
		AccountService  accountService=null;
		try {
			System.out.println("account.getAccountNumber()===" + account.getAccountNumber());
			System.out.println("account.getToken()===" + account.getToken());
			accountService = new AccountService();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return accountService.getTransactinDetails(account);
	}
	
	
	@Path("/creditAmount")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@POST
	public MessageStatus creditAmount(Account account) {
		AccountService  accountService=null;
		try {
			System.out.println("account.getAccountNumber()===" + account.getAccountNumber());
			System.out.println("account.getAmount()===" + account.getAmount());
			accountService = new AccountService();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return accountService.creditAmount(account);
	}
	
	@Path("/creditAmountGet")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@GET
	public MessageStatus creditAmountGet(@QueryParam("inputData") String jsonInString) {
		AccountService  accountService=null;
		Account account = null;
		try {
			
			ObjectMapper mapper = new ObjectMapper();

			//JSON from String to Object
			account = mapper.readValue(jsonInString, Account.class);
			System.out.println("account.getAccountNumber()===" + account.getAccountNumber());
			System.out.println("account.getAmount()===" + account.getAmount());
			
			accountService = new AccountService();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return accountService.creditAmount(account);
	}
	
	
	@Path("/creditAmountGetHead")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@GET
	public MessageStatus creditAmountGetHead(@HeaderParam("inputData") String jsonInString) {
		AccountService  accountService=null;
		Account account=null;
		try {
			
			LoadiViewProperties loadProps = LoadiViewProperties.getInstance();
			
			
			ObjectMapper mapper = new ObjectMapper();

			//JSON from String to Object
			account = mapper.readValue(jsonInString, Account.class);
			System.out.println("account.getAccountNumber()===" + account.getAccountNumber());
			System.out.println("account.getAmount()===" + account.getAmount());
			
		
			
			accountService = new AccountService();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return accountService.creditAmount(account);
	}
	
	
	  
	
	@Path("/debitAmount")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@POST
	public MessageStatus debitAmount(Account account) {
		AccountService  accountService=null;
		try {
			System.out.println("account.getAccountNumber()===" + account.getAccountNumber());
			System.out.println("account.getAmount()===" + account.getAmount());
			accountService = new AccountService();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return accountService.debidtAmount(account);
	}
	
	
	@Path("/getCurentBalance")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@POST
	public Account getCurentBalance(CardDetails cardDetails) {
		AccountService  accountService=null;
		try {
			System.out.println("cardDetails.getCardNumber()===" + cardDetails.getCardNumber());
			accountService = new AccountService();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return accountService.getCurentBalance(cardDetails);
	}
	
	@Path("/getDateofActivation")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@POST
	public Account getDateofActivation(CardDetails cardDetails) {
		AccountService  accountService=null;
		try {
			System.out.println("cardDetails.getCardNumber()===" + cardDetails.getCardNumber());
			accountService = new AccountService();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return accountService.getDateofActivation(cardDetails);
	}*/

}
