package com.alphaiciapi.rest.resources;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;

//import org.apache.log4j.Logger;

import com.alphaiciapi.model.Loan;
import com.alphaiciapi.model.LoanReqDetails;
import com.alphaiciapi.model.SearchCriteria;
import com.alphaiciapi.service.AuthenticateService;
import com.alphaiciapi.service.LoanAccountService;
import com.alphaiciapi.util.ErrorCodeConstants;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

@Path("/Loan")
public class LoanAccountResource {

	/*LoadiViewProperties props = LoadiViewProperties.getInstance();
	String merchantID = props.getProperty("merchantID");
	String authorization = props.getProperty("authorization");*/
	
	/*static final Logger logger = Logger.getLogger(LoanAccountResource.class);*/


	boolean isValid = false;
	
	@Context
	HttpHeaders headers;

	LoanAccountService loanAccountService= new LoanAccountService();
	AuthenticateService authenticateService=new AuthenticateService();

	
	/*@Path("/customerDetails/{mobileno}/{clientId}/{authToken}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@GET
	public String customerDetails(@PathParam("mobileno") Long mobileno,
			@PathParam("clientId") String clientId, 
			@PathParam("authToken") String authToken) {*/
	
	@Path("/customerDetails")
	@Produces(MediaType.APPLICATION_JSON)
	@GET
	public String customerDetails(@QueryParam("mobileno") String mobileno,
			@QueryParam("clientId") String clientId, 
			@QueryParam("authToken") String authToken) {
	
			LoanReqDetails loanReq = new LoanReqDetails();
			JsonObject jsonObject =  new JsonObject();
			JsonObject jsonObject1 =  new JsonObject();
			JsonArray jsonArray =  new JsonArray();
			
			boolean authFlag = false;
			try {
				
				jsonObject = new JsonObject();
				authFlag = authenticateService.validateClient(clientId, authToken, "Hackathon");
				System.out.println("createNewWallet Authenticate Flag==="+authFlag);
				if(!authFlag) {
					jsonObject.addProperty("errorCode", ErrorCodeConstants.VALIDATE_AUTHTOKEN);
					jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.VALIDATE_AUTHTOKEN_DESC);
					return jsonObject.toString();
				}

				if(!mobileno.matches("[0-9]+") || mobileno.length()!=10 || mobileno.equals("")) {
					
					jsonObject.addProperty("errorCode", ErrorCodeConstants.INVALID_MOBILE);
					jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.INVALID_MOBILE_DESC);
					return jsonObject.toString();
				} else {
					loanReq.setMobileno(mobileno);	
				}
				
				jsonObject1.addProperty("code", ErrorCodeConstants.SUCCESS_CODE);
				jsonArray.add(jsonObject1);
				jsonObject = loanAccountService.getCustDetails(loanReq);
				jsonArray.add(jsonObject);
				
		        	
		        	
		        		
		} catch (Exception e) {
			e.printStackTrace();
		   // logger.info("Exception in customerDetails:::::::::::::"+e);
		}
		return jsonArray.toString();
	}
	
	@Path("/loanSummaryDetails/{loan_no}/{agreeID}/{clientId}/{authToken}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@GET
	public String loanSummaryDetails(@PathParam("loan_no") String loan_no,@PathParam("agreeID") String agreeID,
			@PathParam("clientId") String clientId, 
			@PathParam("authToken") String authToken) {
		//	logger.info("loanSummaryDetails>>>>>>>>>>>>>>>>>>>>>>>>");
			LoanReqDetails loanReq=new LoanReqDetails();
			JsonObject jsonObject =  new JsonObject();
			boolean authFlag=false;
			try {
				jsonObject = new JsonObject();
				authFlag = authenticateService.validateClient(clientId, authToken, "Hackathon");
				System.out.println("createNewWallet Authenticate Flag==="+authFlag);
				if(!authFlag){
					jsonObject.addProperty("errorCode", ErrorCodeConstants.VALIDATE_AUTHTOKEN);
					jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.VALIDATE_AUTHTOKEN_DESC);
					return jsonObject.toString();
				}
				loanReq.setAgreeID(agreeID);
				loanReq.setLoan_no(loan_no);
				jsonObject=loanAccountService.getLoanSumDetails(loanReq);
			
		} catch (Exception e) {
			e.printStackTrace();
		 //   logger.info("Exception in customerDetails:::::::::::::"+e);
		}
		return jsonObject.toString();
	}
	
	
	/*@Path("/EMIDetails/{loan_no}/{agreeID}/{clientId}/{authToken}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@GET
	public String eMIDetails(@PathParam("loan_no") String loan_no,@PathParam("agreeID") String agreeID,
			@PathParam("clientId") String clientId, 
			@PathParam("authToken") String authToken) {*/
	
	@Path("/EMIDetails")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@GET
	public String eMIDetails(@QueryParam("loan_no") String loan_no,@QueryParam("agreeID") String agreeID,
			@QueryParam("clientId") String clientId, 
			@QueryParam("authToken") String authToken) {
		
			LoanReqDetails loanReq=new LoanReqDetails();
			JsonObject jsonObject =  new JsonObject();
			JsonObject jsonObject1 =  new JsonObject();
			JsonArray jsonArray =  new JsonArray();
			boolean authFlag=false;

			try {
				jsonObject = new JsonObject();
				authFlag = authenticateService.validateClient(clientId, authToken, "Hackathon");
				System.out.println("createNewWallet Authenticate Flag==="+authFlag);
				if(!authFlag){
					jsonObject.addProperty("errorCode", ErrorCodeConstants.VALIDATE_AUTHTOKEN);
					jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.VALIDATE_AUTHTOKEN_DESC);
					return jsonObject.toString();
				}
				
				if (loan_no == null || loan_no.equals("")) {
					
					jsonObject.addProperty("code", ErrorCodeConstants.RECORD_NOT_FOUNT);
		        	jsonObject.addProperty("message", "Loan Number cannot be blank");
		        	jsonObject.addProperty("description", ErrorCodeConstants.INVALID_REQUEST_DESC);
		        	return jsonObject.toString();
					
				} else if (!loan_no.startsWith("L") || loan_no.length()!=5)  {
					
					jsonObject.addProperty("code", ErrorCodeConstants.INVALID_REQUEST);
		        	jsonObject.addProperty("message", "Invalid Loan Number");
		        	jsonObject.addProperty("description", ErrorCodeConstants.INVALID_REQUEST_DESC);
		        	return jsonObject.toString();
		        	
				} else if (agreeID == null || agreeID.equals(""))  {
					
					jsonObject.addProperty("code", ErrorCodeConstants.RECORD_NOT_FOUNT);
		        	jsonObject.addProperty("message", "Agreement ID cannot be blank");
		        	jsonObject.addProperty("description", ErrorCodeConstants.INVALID_REQUEST_DESC);
		        	return jsonObject.toString();
				
				} else if (!agreeID.startsWith("A") || agreeID.length() != 10)  {
					
					jsonObject.addProperty("code", ErrorCodeConstants.INVALID_REQUEST);
		        	jsonObject.addProperty("message", "Invalid Agreement ID");
		        	jsonObject.addProperty("description", ErrorCodeConstants.INVALID_REQUEST_DESC);
		        	return jsonObject.toString();
		        	
				} else {

					loanReq.setAgreeID(agreeID);
					loanReq.setLoan_no(loan_no);
					
					if (!jsonObject.toString().equals("")) {
						
						jsonObject1.addProperty("code", ErrorCodeConstants.SUCCESS_CODE);
						jsonArray.add(jsonObject1);
						jsonObject = loanAccountService.getEMIDetails(loanReq);
						
					} else {
						jsonObject.addProperty("code", ErrorCodeConstants.RECORD_NOT_FOUNT);
			        	jsonObject.addProperty("message", ErrorCodeConstants.RECORD_NOT_FOUNT_DESC);
			        	jsonObject.addProperty("description", ErrorCodeConstants.INVALID_REQUEST_DESC);
					}
					
					jsonArray.add(jsonObject);

					
				}
			 }catch (Exception e) {
					e.printStackTrace();
				 //   logger.info("Exception in customerDetails:::::::::::::"+e);
		     }
		return jsonArray.toString();
	}
	
	
	/*@Path("/transDetails/{loan_no}/{agreeID}/{clientId}/{authToken}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@GET
	public String transactionDetails(@PathParam("loan_no") String loan_no,@PathParam("agreeID") String agreeID,
			@PathParam("clientId") String clientId, 
			@PathParam("authToken") String authToken) {*/
		
		
	@Path("/transDetails")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@GET
	public String transactionDetails(@QueryParam("loan_no") String loan_no,@QueryParam("agreeID") String agreeID,
			@QueryParam("clientId") String clientId, 
			@QueryParam("authToken") String authToken) {
		

			LoanReqDetails loanReq=new LoanReqDetails();
			JsonObject jsonObject =  new JsonObject();
			JsonObject jsonObject1 =  new JsonObject();
			JsonArray jsonArray =  new JsonArray();
			boolean authFlag=false;


			try {
				jsonObject = new JsonObject();
				authFlag = authenticateService.validateClient(clientId, authToken, "Hackathon");
				System.out.println("createNewWallet Authenticate Flag==="+authFlag);
				if(!authFlag){
					jsonObject.addProperty("errorCode", ErrorCodeConstants.VALIDATE_AUTHTOKEN);
					jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.VALIDATE_AUTHTOKEN_DESC);
					return jsonObject.toString();
				}
				
				if (loan_no == null || loan_no.equals("")) {
					
					jsonObject.addProperty("code", ErrorCodeConstants.RECORD_NOT_FOUNT);
		        	jsonObject.addProperty("message", "Loan Number cannot be blank");
		        	jsonObject.addProperty("description", ErrorCodeConstants.INVALID_REQUEST_DESC);
		        	return jsonObject.toString();
		        	
				} else if (!loan_no.startsWith("L") || loan_no.length()!=5)  {
					
					jsonObject.addProperty("code", ErrorCodeConstants.INVALID_REQUEST);
		        	jsonObject.addProperty("message", "Invalid Loan Number");
		        	jsonObject.addProperty("description", ErrorCodeConstants.INVALID_REQUEST_DESC);
		        	return jsonObject.toString();
		        	
				} else if (agreeID == null || agreeID.equals(""))  {
					
					jsonObject.addProperty("code", ErrorCodeConstants.RECORD_NOT_FOUNT);
		        	jsonObject.addProperty("message", "Agreement ID cannot be blank");
		        	jsonObject.addProperty("description", ErrorCodeConstants.INVALID_REQUEST_DESC);
		        	return jsonObject.toString();
		        	
				} else if (!agreeID.startsWith("A") || agreeID.length() != 10)  {
					
					jsonObject.addProperty("code", ErrorCodeConstants.INVALID_REQUEST);
		        	jsonObject.addProperty("message", "Invalid Agreement ID");
		        	jsonObject.addProperty("description", ErrorCodeConstants.INVALID_REQUEST_DESC);
		        	return jsonObject.toString();
		        	
				} else {
					
					loanReq.setAgreeID(agreeID);
					loanReq.setLoan_no(loan_no);
					
					if (!jsonObject.toString().equals("")) {
						
						jsonObject1.addProperty("code", ErrorCodeConstants.SUCCESS_CODE);
						jsonArray.add(jsonObject1);
						jsonObject=loanAccountService.getTransDetails(loanReq);
						
					} else {
						jsonObject.addProperty("code", ErrorCodeConstants.RECORD_NOT_FOUNT);
			        	jsonObject.addProperty("message", ErrorCodeConstants.RECORD_NOT_FOUNT_DESC);
			        	jsonObject.addProperty("description", ErrorCodeConstants.INVALID_REQUEST_DESC);
					}

					jsonArray.add(jsonObject);
				}
			} catch (Exception e) {
				e.printStackTrace();
		//	    logger.info("Exception in customerDetails:::::::::::::"+e);
			}
			//jsonObject = loanAccountService.getTransDetails(loanReq);
	
		return jsonArray.toString();
	}

	
	/*@Path("getLoanDetails/{param}/{clientId}/{authToken}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@GET
	
	public String getLoanDetails(@PathParam("param") String accountNumber,
			@PathParam("clientId") String clientId, 
			@PathParam("authToken") String authToken) {*/


	@Path("getLoanDetails")
	@Produces(MediaType.APPLICATION_JSON)
	@GET
	
	public String getLoanDetails(@QueryParam("param") String accountNumber,
			@QueryParam("clientId") String clientId, 
			@QueryParam("authToken") String authToken) {
		
		System.out.println("Account no:"+accountNumber);

		SearchCriteria searchCriteria= new SearchCriteria();
		LoanAccountService lnAccService=new LoanAccountService();
		JsonObject jsonObject =  new JsonObject();
		JsonObject jsonObject1 =  new JsonObject();
		JsonArray jsonArray =  new JsonArray();
		List<Loan> loanLists;
		
    	String statusString="";
		String jsonResString="";
		String returnString="";
		boolean authFlag=false;
		try {
			
			System.out.println("client Id:"+clientId);
			System.out.println("Auth token"+authToken);
			
			jsonObject = new JsonObject();
			authFlag = authenticateService.validateClient(clientId, authToken, "getLoanDetails");
			System.out.println("createNewWallet Authenticate Flag==="+authFlag);
			if(!authFlag){
				jsonObject.addProperty("code", ErrorCodeConstants.VALIDATE_AUTHTOKEN);
				jsonObject.addProperty("descripttion", ErrorCodeConstants.VALIDATE_AUTHTOKEN_DESC);
				return jsonObject.toString();
			}
			
			searchCriteria.setAccountNumber(accountNumber);
		    
    		loanLists = lnAccService.getLoanDetails(searchCriteria);
    		
			/*if(loanLists.size()>0 && !(loanLists.isEmpty())) {
				
				jsonObject.addProperty("errorCode", ErrorCodeConstants.SUCCESS_CODE);
	        	jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.SUCCESS_DESC);
	        	jsonObject.add("loanDetails", new Gson().toJsonTree(loanLists ));
	    		return jsonObject.toString();
				
			} else if(loanLists.size()==0 && loanLists.isEmpty()) {
				
				jsonObject.addProperty("errorCode", ErrorCodeConstants.RECORD_NOT_FOUNT);
	        	jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.RECORD_NOT_FOUNT_DESC);
	        	return jsonObject.toString();
				
			}else{
				jsonObject.addProperty("errorCode", ErrorCodeConstants.INTERNAL_ERROR);
	        	jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.INTERNAL_ERROR_DESC);
	        	return jsonObject.toString();
			}*/
			
    		
    		if(loanLists.size()>0 && !(loanLists.isEmpty())) {
				
    			jsonObject1.addProperty("code", ErrorCodeConstants.SUCCESS_CODE);
				jsonArray.add(jsonObject1);
	        	
	        	for (Loan loan : loanLists) {
	        		
	        		jsonObject =  new JsonObject();
	        		
	        		jsonObject.addProperty("ID", loan.getID());
	        		if (!accountNumber.startsWith("LACRM")) {
	        			jsonObject.addProperty("loanAccountNo", loan.getLoanAccounNo());
	        		}
	        		jsonObject.addProperty("customerName", loan.getCustomerName());
	        		jsonObject.addProperty("pos", loan.getPos());
	        		jsonObject.addProperty("principal_outstanding", loan.getPrincipal_outstanding());
	        		jsonObject.addProperty("date_of_loan", loan.getDate_of_loan().toString());
	        		jsonObject.addProperty("type_of_loan", loan.getType_of_loan());
	        		jsonObject.addProperty("roi", loan.getRoi());
	        		jsonObject.addProperty("month_delinquency", loan.getMonth_delinquency());
	        		jsonObject.addProperty("loanAmount", loan.getLoanAmount());
	        		jsonObject.addProperty("custId", loan.getCustId());
	        		jsonObject.addProperty("loan_no", loan.getLoanNo());
	        		jsonObject.addProperty("agreementId", loan.getAgreeId());
	        		jsonArray.add(jsonObject);
	        	}
	        	
	    		return jsonArray.toString();
				
			} else if(loanLists.size()==0 && loanLists.isEmpty()) {
				
				jsonObject.addProperty("code", ErrorCodeConstants.RECORD_NOT_FOUNT);
	        	jsonObject.addProperty("message", ErrorCodeConstants.RECORD_NOT_FOUNT_DESC);
	        	jsonObject.addProperty("description", ErrorCodeConstants.INVALID_REQUEST_DESC);

	        	return jsonObject.toString();
				
			} else {
				jsonObject.addProperty("code", ErrorCodeConstants.INTERNAL_ERROR);
	        	jsonObject.addProperty("message", ErrorCodeConstants.INTERNAL_ERROR_MSG);
	        	jsonObject.addProperty("description", ErrorCodeConstants.INTERNAL_ERROR_DESC);
	        	
	        	return jsonObject.toString();
			}
    		
		
		} catch (Exception e) {
			System.out.println("Exception==>>"+e.getMessage());
			jsonObject.addProperty("code", ErrorCodeConstants.INTERNAL_ERROR);
        	jsonObject.addProperty("message", ErrorCodeConstants.INTERNAL_ERROR_MSG);
        	jsonObject.addProperty("description", ErrorCodeConstants.INTERNAL_ERROR_DESC);
        	
    		return jsonObject.toString();
		}finally{
			
			if(statusString !=null){
				statusString =null;
			}
			if(jsonResString !=null){
				jsonResString = null;
			}
			if(returnString !=null){
				returnString = null;
			}

		}
		
	}
	
}

