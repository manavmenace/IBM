/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.alphaiciapi.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alphaiciapi.daoimpl.AccountDaoImpl;
import com.alphaiciapi.daoimpl.CardDetailsDaoImpl;
import com.alphaiciapi.model.CardDetails;
import com.alphaiciapi.model.SearchCriteria;

/**
 * 
 * @author AnaMihalceanu
 */
public class AccountController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String INSERT_OR_EDIT = "/department.jsp";
	private static final String LIST_LOAN = "/listLoans.jsp";
	private static final String LIST_CARD_DETAILS="/listCardDetails.jsp";
	private static final String STATUS="/transactionstatus.jsp";
	private final AccountDaoImpl dao;

	public AccountController() {
		super();
		dao = new AccountDaoImpl();
	}

	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String forward = "";
		String action = request.getParameter("action");

		//GetCardDetails()
		 if (action.equalsIgnoreCase("debitAmount")) {
			 
			SearchCriteria searchCriteria= new SearchCriteria();
	    	searchCriteria.setAccountNumber("345678912334");
	    	searchCriteria.setAmount(5);
			
	    	String status = dao.debitAmount(searchCriteria);
			forward = STATUS;
			request.setAttribute("status", status);
			
		} else if (action.equalsIgnoreCase("creditAmount")) {
			 
			SearchCriteria searchCriteria= new SearchCriteria();
	    	searchCriteria.setAccountNumber("345678912334");
	    	searchCriteria.setAmount(10);
			
	    	String status = dao.creditAmount(searchCriteria);
			forward = STATUS;
			request.setAttribute("status", status);
			
		}
		

		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request,response);
		
		/*Department dept = new Department();
		dept.setName(request.getParameter("name"));
		dept.setManagerId(Integer.parseInt(request.getParameter("managerId")));
		String deptId = request.getParameter("deptId");*/
		/*dept.setId(Integer.parseInt(deptId));
		if (request.getParameter("action").toString().equals("insert")) {
			dao.addDepartment(dept);
		} else {
			dao.updateDepartment(dept);
		}
		RequestDispatcher view = request.getRequestDispatcher(LIST_DEPT);
		request.setAttribute("depts", dao.getAllDepartments());*/
		//view.forward(request, response);
	}
}
