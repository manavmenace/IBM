package com.alphaiciapi.exp;

public class PersistanceException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PersistanceException(String exp) {
		super(exp);
	}
	

}
