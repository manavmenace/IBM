package com.alphaiciapi.exp;

public class BussinessException extends Exception {
	
	
	public BussinessException(String exp) {
		super(exp);
	}
	

}
