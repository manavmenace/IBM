package com.alphaiciapi.util;

public class JsonUtil {
	
	/*public JSONObject getJsonErr(int errCd, String errMsg, String errDesc) {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("code", errCd);

		if (errCd == 400) {
		jsonObject.put("message", "Bad request. Invalid Request parameter");
		} else if (errCd == 501) {
		jsonObject.put("message","Processing error � One or more of internal systems gave an error while processing the request");
		} else if (errCd == 503) {
		jsonObject.put("message", "No Data Found");
		} else {
		jsonObject.put("message", errMsg);

		}
		jsonObject.put("description", errDesc);
		//log.info("getJsonErr() -->" + jsonObject.toString());
		return jsonObject;
		}*/

}
