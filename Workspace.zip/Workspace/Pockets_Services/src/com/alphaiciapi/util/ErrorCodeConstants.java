package com.alphaiciapi.util;

public class ErrorCodeConstants {

	public static final String SUCCESS_CODE="200";
	public static final String SUCCESS_DESC="success";
	public static final String FAILURE_CODE="100";
	public static final String FAILURE_DESC="failure";
	public static final String RECORD_NOT_FOUNT="101";
	public static final String RECORD_NOT_FOUNT_DESC="Record not found";
	public static final String INVALID_REQUEST="102";
	public static final String INVALID_REQUEST_DESC="Invalid Request";
	public static final String INTERNAL_ERROR="103";
	public static final String INTERNAL_ERROR_MSG="Internal Error";
	public static final String INTERNAL_ERROR_DESC="Processing Error - one or more of internal systems gave an error while processing the request";
	
	public static final String INVALID_ACCOUNT="104";
	public static final String INVALID_ACCOUNT_DESC="Invalid Account Number";
	
	public static final String INVALID_AMOUNT="104";
	public static final String INVALID_AMOUNT_DESC="Invalid Account Number";
	
	public static final String AUTH_TOKEN_CODE="108";
	public static final String AUTH_TOKEN_DESC="Auth token cannot be empty";
	
	public static final String INVALID_MOBILE="109";
	public static final String INVALID_MOBILE_DESC="Invalid mobile Number";
	
	public static final String INSUFFICIENT_BALANCE_CODE="110";
	public static final String INSUFFICIENT_BALANCE_DESC="Insufficient Balance";
	

	public final static String NAGITIVE_AMOUNT="111";
	public static final String NAGITIVE_AMOUNT_DESC="Invalid amount ";
	
	
	public static final String CREDIT_AMOUNT="112";
	public static final String CREDIT_AMOUNT_DESC="Credit Amount should not greater than 5000";
	
	public static final String NO_WALLET="113";
	public static final String NO_WALLET_DESC="Wallet Account Doesn't exist";
	
	public static final String WALLET_MAX_AMOUNT="114";
	public static final String WALLET_MAX_AMOUNT_DESC="Wallet Amount limit exceeded";
	
	public static final String VALIDATE_AUTHTOKEN="115";
	public static final String VALIDATE_AUTHTOKEN_DESC="Authentication failed";
	
	
}
