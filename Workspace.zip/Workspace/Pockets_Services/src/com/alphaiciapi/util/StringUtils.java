package com.alphaiciapi.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class StringUtils {

	public static void main(String[] args) {
		System.out.println(converDateToString(new Date()));
	}
	
	
	public static String converDateToString(Date date){
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		String reportDate = df.format(date);
		return reportDate;
	}
	
	public static String getRandomValue()
	{
		char[] alphNum = "0123456789".toCharArray();

		Random rnd = new Random();

		StringBuilder sb = new StringBuilder((100000 + rnd.nextInt(900000)));
		for (int i = 0; i < 5; i++)
		    sb.append(alphNum[rnd.nextInt(alphNum.length)]);

		return sb.toString();

	}
}
