package com.alphaiciapi.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

 

public class ValidationUtil {

                

                public static boolean isEmpty(String value){

                                if(value == null || "".equals(value.trim())){

                                                return true;

                                }

                                return false;

                }

                

                public static boolean isNumeric(String value){

                                Pattern pattern = Pattern.compile("^[0-9]+$");

                                Matcher match = pattern.matcher(value);

                                return match.find();

                }
                
                public static boolean isAmountNumeric(String value){

                    Pattern pattern = Pattern.compile("^[1-9]+$");

                    Matcher match = pattern.matcher(value);

                    return match.find();

                }

                

                public static boolean isPanValid(String panValue){

                                Pattern pattern = Pattern.compile("^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}$");

                                Matcher match = pattern.matcher(panValue);

                                return match.find();

                }

                

                public static boolean isOnlyCharacter(String onlyCharValue){

                                Pattern pattern = Pattern.compile("^[a-zA-Z]*$");

                                Matcher match = pattern.matcher(onlyCharValue);

                                return match.find();

                }

                

                public static boolean isAlphaOrNumeric(String value){

                                Pattern pattern = Pattern.compile("^[a-zA-z_0-9]+$");

                                Matcher match = pattern.matcher(value);

                                return match.find();

                }

                

                public static boolean isAccountLengthValid(String accno){

                                Pattern pattern = Pattern.compile("^([0-9]){12}$");

                                Matcher match = pattern.matcher(accno);

                                return match.find();

                }
                
                public static boolean isCreditCardLengthValid(String accno){

                    Pattern pattern = Pattern.compile("^([0-9]){16}$");

                    Matcher match = pattern.matcher(accno);

                    return match.find();

                }
                public static boolean isLoanAccoutLengthValid(String accno){

                    Pattern pattern = Pattern.compile("^([a-zA-Z0-9]){14}$");

                    Matcher match = pattern.matcher(accno);

                    return match.find();

                }

                public static boolean isCustIDValid(String custValue){

                    Pattern pattern = Pattern.compile("^([0-9]){8}$");

                    Matcher match = pattern.matcher(custValue);

                    return match.find();

                }

                public static boolean isMobileValid(String mobileValue){

                                Pattern pattern = Pattern.compile("^([0-9]){10}$");

                                Matcher match = pattern.matcher(mobileValue);

                                return match.find();

                }

                

                public static boolean isIFSCValid(String mobileValue){

                                Pattern pattern = Pattern.compile("^([a-zA-Z0-9]){11}$");

                                Matcher match = pattern.matcher(mobileValue);

                                return match.find();

                }

                

                public static boolean isNameValid(String name){

                                Pattern pattern = Pattern.compile("^[a-zA-Z\\s]+$");

                                Matcher match = pattern.matcher(name);

                                return match.find();

                }

                

                public static boolean isRemarkValid(String remarks){

                                Pattern pattern = Pattern.compile("^[~\\\\! @ * _ = { } / |: , . ? a-zA-Z0-9\\s]+$");

                                Matcher match = pattern.matcher(remarks);

                                return match.find();

                }

                

                public static boolean isNotRemarkValid(String remarks){

                                Pattern pattern = Pattern.compile("[^~\\\\! @ * _ = { } / |: , . ? a-zA-Z0-9\\s]+$");

                                Matcher match = pattern.matcher(remarks);

                                return match.find();

                }

                

                public static boolean isEmailValid(String email){

                                Pattern pattern = Pattern.compile("^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");

                                Matcher match = pattern.matcher(email);

                                return match.find();

                }

                

                public static boolean isNegativeValue(String amount){

                                Pattern pattern = Pattern.compile("^\\d*\\.?\\d+$");

                                Matcher match = pattern.matcher(amount);

                                return match.find();

                }

                

                public static boolean amountNotZero(String amount){

                                Pattern pattern = Pattern.compile("^(?=.*[1-9].*)[0-9]{1,50}$");

                                Matcher match = pattern.matcher(amount);

                                return match.find();

                }

                

                public static boolean noOfDayValid(String fromDate, String toDate) {

                                Date fromDateTemp = null, toDateTemp = null;

                                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

                                try {

                                                fromDateTemp = sdf.parse(fromDate);

                                                toDateTemp = sdf.parse(toDate);

                                } catch (ParseException e) {

                                                e.printStackTrace();

                                                return false;

                                }

                                long noofDays = toDateTemp.getTime() - fromDateTemp.getTime();

        noofDays = (noofDays / (24 * 60 * 60 * 1000))+1;

        if(noofDays < 30 ){

                return true;

        } else {

                return false;

        }

                }

                

                public static boolean ischequeNumberValid(String number){

                                Pattern pattern = Pattern.compile("^([0-9][0-9][0-9][0-9][0-9][0-9])$");

                                Matcher match = pattern.matcher(number);

                                return match.find();

                } 

                

                 public static boolean isNotEmpty(String value){

                                                if(value == null || "".equals(value.trim())){

                                                                return false;

                                                }

                                                return true;

                                }

                

                 

                

                

                /*public static boolean isFromDateToDateValid(String fromDate, String toDate){

                                SimpleDateFormat sdfFrom = new SimpleDateFormat("");

                                return false;

                }*/

                

                /*public static void main(String[] args){

                                System.out.println(noOfDayValid("12/2/2015","15/3/2015"));

                }*/

                

                

}

