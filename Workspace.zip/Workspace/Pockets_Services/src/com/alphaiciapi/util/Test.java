package com.alphaiciapi.util;

import com.alphaiciapi.model.WalletLoginUser;
import com.google.gson.JsonObject;

public class Test{
	
	public static void main(String[] args) {
		WalletLoginUser wsu = new WalletLoginUser();
		//wsu.setAccessToken("abcddsafda");
		JsonObject jsonObject =  new JsonObject();
		//jsonObject.add("WalletStatus", wsu);
	}
	
}

/*public class Test {

	JSONObject returnMessage = new JSONObject();

	// balanceinq?accountno=
	@GET
	@Path("/balanceenquiry")
	@Produces
	public String getMessage(@QueryParam("accountno") String accountno) {

	log.info("###---- Balance Inquiry ----###");

	Connection connection;
	Statement statement;
	ResultSet rs = null;

	String result = "";
	// JSONObject returnMessage= new JSONObject();
	JSONObject jobj = new JSONObject();

	log.info("Initiate Balance Inquiry for Account No. :" + accountno);

	String regex = "[0-9]+";
	if (!accountno.equals("")) {
	if (accountno.length() == 4) {
	if (accountno.matches(regex)) {
	DateFormat dateFormat = new SimpleDateFormat(
	"dd-MM-yyyy HH:mm:ss");
	Date date = new Date();
	System.out.println(dateFormat.format(date)); // 2014/08/06

	connection = DatabaseUtil.getConnection();

	Date today = new Date();

	// displaying this date on IST timezone
	DateFormat df = new SimpleDateFormat("dd-MM-yy HH:mm:SS z");
	df.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
	String IST = df.format(today);
	System.out
	.println("Date in Indian Timezone (IST) : " + IST);

	try {
	statement = connection.createStatement();
	rs = statement
	.executeQuery("select balance,accountType from 
	user09768.Rtl_Account_Master where accountNo="
	+ accountno);

	if (rs.next()) {
	result = rs.getString("balance");
	jobj.put("code", 200);
	jobj.put("accountno", accountno);
	jobj.put("balancetime", IST);
	jobj.put("accounttype", rs.getString("accountType"));
	jobj.put("balance",
	Double.parseDouble(rs.getString("balance")));

	log.info("Balance for Account No. :" + accountno
	+ " is " + result);

	} else {
	// returnMessage = getJsonErr(400,"",
	// "Account Number does not exist");
	returnMessage = getJsonErr(503, "No Data found",
	"Account Number does not exist");
	log.info(result + " -- " + accountno);

	}
	} catch (SQLException e) {
	e.printStackTrace();
	returnMessage = getJsonErr(
	501,
	"Processing error � One or more of internal systems gave an error while 
	processing the request",
	"Database Error. Please try after some time");

	log.info(jobj.toString() + " -- " + accountno);
	} catch (Exception ex) {
	ex.printStackTrace();
	returnMessage = getJsonErr(
	501,
	"Processing error � One or more of internal systems gave an error while 
	processing the request",
	"Database Error. Please try after some time");

	log.info(jobj.toString() + " -- " + accountno);
	} finally {
	try {
	connection.close();
	rs.close();
	rs = null;
	} catch (SQLException e) {
	e.printStackTrace();
	}
	}
	} else {

	returnMessage = getJsonErr(
	400,
	"Bad request. If request parameter are not provided.",
	"Account Number should contain only Numbers");
	log.info(returnMessage.toString() + " -- " + accountno);
	}

	} else {

	returnMessage = getJsonErr(400,
	"Bad request. If request parameter are not provided.",
	"Account Number should be 4 digits");
	log.info(returnMessage.toString() + " -- " + accountno);
	}
	} else {
	returnMessage = getJsonErr(400,
	"Bad request. If request parameter are not provided.",
	"Account Number cannot be Empty");

	log.info(returnMessage.toString() + " -- " + accountno);
	}

	if (jobj.size() == 0) {
	result = returnMessage.toString();
	} else {
	result = jobj.toString();
	}
	return result;
	}
	public JSONObject getJsonErr(int errCd, String errMsg, String errDesc) {
	JSONObject jsonObject = new JSONObject();
	jsonObject.put("code", errCd);

	if (errCd == 400) {
	jsonObject.put("message", "Bad request. Invalid Request parameter");
	} else if (errCd == 501) {
	jsonObject
	.put("message",
	"Processing error � One or more of internal systems gave an error while 
	processing the request");
	} else if (errCd == 503) {
	jsonObject.put("message", "No Data Found");
	} else {
	jsonObject.put("message", errMsg);

	}
	jsonObject.put("description", errDesc);
	log.info("getJsonErr() -->" + jsonObject.toString());
	return jsonObject;
	}
}*/
