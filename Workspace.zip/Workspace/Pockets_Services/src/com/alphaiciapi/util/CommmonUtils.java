package com.alphaiciapi.util;

import java.sql.Date;
import java.util.UUID;

import com.alphaiciapi.model.ErrorCode;

public class CommmonUtils {

	
	public static ErrorCode getErrorInfo(String code,String desc){
		ErrorCode errorCode=null;
		errorCode = new ErrorCode();
		errorCode.setErrorCode(code);
    	errorCode.setErrorDescripttion(desc);
    	return errorCode;
	}
	
	public static java.sql.Date convertDateToSQLDate(
            java.util.Date javaDate) {
        java.sql.Date sqlDate = null;
        if (javaDate != null) {
            sqlDate = new Date(javaDate.getTime());
        }
        return sqlDate;
    }
	
	public static String randomStringOfLength20() {
		
		int length=20;
	    StringBuffer buffer = new StringBuffer();
	    while (buffer.length() < length) {
	        buffer.append(uuidString());
	    }

	    //this part controls the length of the returned string
	    return buffer.substring(0, length);  
	}


	private static String uuidString() {
	    return UUID.randomUUID().toString().replaceAll("-", "");
	}
	
}
