package com.alphaiciapi.model;

import java.sql.Date;

public class CardDetails {

	
	private String cardNumber;
	private String cardType;
	private String cardStatus;
	
	private double current_balance;
	private String date_of_enrolemnt; 
	
	private String month_delinquency;
	private String custId;
	private String card_acc_number;
	private String expiry_date;
	private String avail_lmt;
	
	
	
	public String getDate_of_enrolemnt() {
		return date_of_enrolemnt;
	}
	public void setDate_of_enrolemnt(String date_of_enrolemnt) {
		this.date_of_enrolemnt = date_of_enrolemnt;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public String getCardStatus() {
		return cardStatus;
	}
	public void setCardStatus(String cardStatus) {
		this.cardStatus = cardStatus;
	}
	public double getCurrent_balance() {
		return current_balance;
	}
	public void setCurrent_balance(double current_balance) {
		this.current_balance = current_balance;
	}
	public String getMonth_delinquency() {
		return month_delinquency;
	}
	public void setMonth_delinquency(String month_delinquency) {
		this.month_delinquency = month_delinquency;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getCard_acc_number() {
		return card_acc_number;
	}
	public void setCard_acc_number(String card_acc_number) {
		this.card_acc_number = card_acc_number;
	}
	public String getExpiry_date() {
		return expiry_date;
	}
	public void setExpiry_date(String expiry_date) {
		this.expiry_date = expiry_date;
	}
	public String getAvail_lmt() {
		return avail_lmt;
	}
	public void setAvail_lmt(String avail_lmt) {
		this.avail_lmt = avail_lmt;
	}
}
