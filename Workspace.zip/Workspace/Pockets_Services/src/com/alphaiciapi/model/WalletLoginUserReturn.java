package com.alphaiciapi.model;

public class WalletLoginUserReturn {

	//AUTH_DATA,AUTH_TYPE,CREATED_DATE,DEVICE_ID,ID_TYPE,ID_VALUE,IMEI,IP_ADDRESS,LATITUDE,LONGITUDE,MOBILE,OS,WM_ACC_NO,WM_AMOUNT,WM_MAPPED_AC_NO,WM_STATUS,WM_USER_ID)
	
	private String creationStatus;
	private String auth_data;
	public String getCreationStatus() {
		return creationStatus;
	}
	public void setCreationStatus(String creationStatus) {
		this.creationStatus = creationStatus;
	}
	public String getAuth_data() {
		return auth_data;
	}
	public void setAuth_data(String auth_data) {
		this.auth_data = auth_data;
	}
	
}
