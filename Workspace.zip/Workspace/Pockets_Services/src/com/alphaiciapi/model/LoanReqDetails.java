package com.alphaiciapi.model;

public class LoanReqDetails {

	private String loan_no;
	private String agreeID;
	private String mobileno;
	
		
	
	public String getLoan_no() {
		return loan_no;
	}
	public void setLoan_no(String loan_no) {
		this.loan_no = loan_no;
	}
	public String getAgreeID() {
		return agreeID;
	}
	public void setAgreeID(String agreeID) {
		this.agreeID = agreeID;
	}
	
	public String getMobileno() {
			return mobileno;
	}
	
	public void setMobileno(String mobileno) {
			this.mobileno = mobileno;
	}
	
	
	
	
	
	

}
