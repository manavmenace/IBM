package com.alphaiciapi.model;

/**
 * @author BAN67711
 *
 */
public class Wallet extends WalletResponse {
	
	private String id_type;
	private String id_value;
	private String auth_type;
	private String auth_data;
	private double latitude;
	private double longitude;
	private String ip_address;
	private String os;
	private String device_id;
	private String imei;
	private String  promocode;
	private String  sub_merchant;
	private String  status;
	private String  mappedAccountNo;
	private String  mobileNo;
	
	private String clientID;
	private String authToken;
	
	public String getId_type() {
		return id_type;
	}
	public void setId_type(String id_type) {
		this.id_type = id_type;
	}
	public String getId_value() {
		return id_value;
	}
	public void setId_value(String id_value) {
		this.id_value = id_value;
	}
	public String getAuth_type() {
		return auth_type;
	}
	public void setAuth_type(String auth_type) {
		this.auth_type = auth_type;
	}
	public String getAuth_data() {
		return auth_data;
	}
	public void setAuth_data(String auth_data) {
		this.auth_data = auth_data;
	}
	public double getLatitude() {
		return latitude;
	}
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}
	public double getLongitude() {
		return longitude;
	}
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
	public String getIp_address() {
		return ip_address;
	}
	public void setIp_address(String ip_address) {
		this.ip_address = ip_address;
	}
	public String getOs() {
		return os;
	}
	public void setOs(String os) {
		this.os = os;
	}
	public String getDevice_id() {
		return device_id;
	}
	public void setDevice_id(String device_id) {
		this.device_id = device_id;
	}
	public String getImei() {
		return imei;
	}
	public void setImei(String imei) {
		this.imei = imei;
	}
	
	public String getPromocode() {
		return promocode;
	}
	public void setPromocode(String promocode) {
		this.promocode = promocode;
	}
	
	public String getSub_merchant() {
		return sub_merchant;
	}
	public void setSub_merchant(String sub_merchant) {
		this.sub_merchant = sub_merchant;
	}
	
	public String getMappedAccountNo() {
		return mappedAccountNo;
	}
	public void setMappedAccountNo(String mappedAccountNo) {
		this.mappedAccountNo = mappedAccountNo;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getClientID() {
		return clientID;
	}
	public void setClientID(String clientID) {
		this.clientID = clientID;
	}
	public String getAuthToken() {
		return authToken;
	}
	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}
	
	
}
