package com.alphaiciapi.model;

public class LoanResTransModel {

	private String last_payments_made;
	private String payment_mode;
	
	public String getLast_payments_made() {
		return last_payments_made;
	}
	public void setLast_payments_made(String last_payments_made) {
		this.last_payments_made = last_payments_made;
	}
	public String getPayment_mode() {
		return payment_mode;
	}
	public void setPayment_mode(String payment_mode) {
		this.payment_mode = payment_mode;
	}
	
	

}
