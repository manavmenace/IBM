package com.alphaiciapi.model;

import java.sql.Date;

/**
 * @author BAN67711
 *
 */
public class WalletResponse {
	
	private String bank_txn_id;
	private String txn_id;
	private double amount;
	private String transDate;
	private String transType;
	private String remarks;
	private String  walletAcNo;
	public String getBank_txn_id() {
		return bank_txn_id;
	}
	public void setBank_txn_id(String bank_txn_id) {
		this.bank_txn_id = bank_txn_id;
	}
	
	public String getTxn_id() {
		return txn_id;
	}
	public void setTxn_id(String txn_id) {
		this.txn_id = txn_id;
	}
	public String getTransDate() {
		return transDate;
	}
	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}
	public String getTransType() {
		return transType;
	}
	public void setTransType(String transType) {
		this.transType = transType;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getWalletAcNo() {
		return walletAcNo;
	}
	public void setWalletAcNo(String walletAcNo) {
		this.walletAcNo = walletAcNo;
	}

}

