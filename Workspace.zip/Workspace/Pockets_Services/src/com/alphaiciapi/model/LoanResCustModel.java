package com.alphaiciapi.model;

public class LoanResCustModel {

	private String name;
	private String dob;
	private String no_of_depenants;
	private String salary_details;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getNo_of_depenants() {
		return no_of_depenants;
	}
	public void setNo_of_depenants(String no_of_depenants) {
		this.no_of_depenants = no_of_depenants;
	}
	public String getSalary_details() {
		return salary_details;
	}
	public void setSalary_details(String salary_details) {
		this.salary_details = salary_details;
	}
	
	
	

}
