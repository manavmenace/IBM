package com.alphaiciapi.model;

public class LoanResSumModel {

	private String LAN_No;
	private String Prodcut;
	private String Amount_Finanaced;
	private String Tenure;
	private String Rate_of_Interest;
	
	
	public String getLAN_No() {
		return LAN_No;
	}
	public void setLAN_No(String lAN_No) {
		LAN_No = lAN_No;
	}
	public String getProdcut() {
		return Prodcut;
	}
	public void setProdcut(String prodcut) {
		Prodcut = prodcut;
	}
	public String getAmount_Finanaced() {
		return Amount_Finanaced;
	}
	public void setAmount_Finanaced(String amount_Finanaced) {
		Amount_Finanaced = amount_Finanaced;
	}
	public String getTenure() {
		return Tenure;
	}
	public void setTenure(String tenure) {
		Tenure = tenure;
	}
	public String getRate_of_Interest() {
		return Rate_of_Interest;
	}
	public void setRate_of_Interest(String rate_of_Interest) {
		Rate_of_Interest = rate_of_Interest;
	}
	
	
	
	
	


}
