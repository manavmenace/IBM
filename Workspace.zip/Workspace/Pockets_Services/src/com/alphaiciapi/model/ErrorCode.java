package com.alphaiciapi.model;

public class ErrorCode {

	
	
	String errorCode;
	String errorDescripttion;
	
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	
	public String getErrorDescripttion() {
		return errorDescripttion;
	}
	public void setErrorDescripttion(String errorDescripttion) {
		this.errorDescripttion = errorDescripttion;
	}

	
}
