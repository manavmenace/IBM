package com.alphaiciapi.model;

public class LoanResponseModel {

	private String name;
	private String dob;
	private String no_of_depenants;
	private String salary_details;
	private String error;
	private String status;
	private String loanNum;
	private String product;
	private String amtFin;
	private String tenure;
	private String roi;
	private String eMIS;
	private String eMI3;
	private String payment1;
	private String payment2;
	private String payment3;
	private String paymentMode;
	private String emiDates;
	private String noEMIs;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getNo_of_depenants() {
		return no_of_depenants;
	}
	public void setNo_of_depenants(String no_of_depenants) {
		this.no_of_depenants = no_of_depenants;
	}
	public String getSalary_details() {
		return salary_details;
	}
	public void setSalary_details(String salary_details) {
		this.salary_details = salary_details;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getLoanNum() {
		return loanNum;
	}
	public void setLoanNum(String loanNum) {
		this.loanNum = loanNum;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getAmtFin() {
		return amtFin;
	}
	public void setAmtFin(String amtFin) {
		this.amtFin = amtFin;
	}
	public String getTenure() {
		return tenure;
	}
	public void setTenure(String tenure) {
		this.tenure = tenure;
	}
	public String getRoi() {
		return roi;
	}
	public void setRoi(String roi) {
		this.roi = roi;
	}
	
	public String geteMIS() {
		return eMIS;
	}
	public void seteMIS(String eMIS) {
		this.eMIS = eMIS;
	}
	public String getPayment1() {
		return payment1;
	}
	public void setPayment1(String payment1) {
		this.payment1 = payment1;
	}
	public String getPayment2() {
		return payment2;
	}
	public void setPayment2(String payment2) {
		this.payment2 = payment2;
	}
	public String getPayment3() {
		return payment3;
	}
	public void setPayment3(String payment3) {
		this.payment3 = payment3;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getEmiDates() {
		return emiDates;
	}
	public void setEmiDates(String emiDates) {
		this.emiDates = emiDates;
	}
	public String geteMI3() {
		return eMI3;
	}
	public void seteMI3(String eMI3) {
		this.eMI3 = eMI3;
	}
	public String getNoEMIs() {
		return noEMIs;
	}
	public void setNoEMIs(String noEMIs) {
		this.noEMIs = noEMIs;
	}
	
	

}
