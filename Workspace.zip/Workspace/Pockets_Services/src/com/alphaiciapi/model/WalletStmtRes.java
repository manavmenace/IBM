package com.alphaiciapi.model;

import java.util.List;

/**
 * @author BAN67711
 *
 */
public class WalletStmtRes {
	
	private String bank_txn_id;
	
	List<WalletResponse>  walletStatement;
	public String getBank_txn_id() {
		return bank_txn_id;
	}
	public void setBank_txn_id(String bank_txn_id) {
		this.bank_txn_id = bank_txn_id;
	}
	
	public List<WalletResponse> getWalletStatement() {
		return walletStatement;
	}
	public void setWalletStatement(List<WalletResponse> walletStatement) {
		this.walletStatement = walletStatement;
	}
	
}
