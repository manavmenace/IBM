package com.alphaiciapi.model;

import java.util.Date;

public class SearchCriteria {

	private String accountNumber;
	private String token;
	private int nofDays;
	private Date startDate;
	private Date endDate;
	private long mobileNO;
	private String  cardNumber;
	private double amount;
	private String remarks;
	
	
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public int getNofDays() {
		return nofDays;
	}
	public void setNofDays(int nofDays) {
		this.nofDays = nofDays;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public long getMobileNO() {
		return mobileNO;
	}
	public void setMobileNO(long mobileNO) {
		this.mobileNO = mobileNO;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	
	
}
