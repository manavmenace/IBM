package com.alphaiciapi.model;

public class LoanResEmiModel {

	private String no_of_EMIs;
	private String EMI_Dates;
	private String Last_three_EMIs;
	
	public String getNo_of_EMIs() {
		return no_of_EMIs;
	}
	public void setNo_of_EMIs(String no_of_EMIs) {
		this.no_of_EMIs = no_of_EMIs;
	}
	public String getEMI_Dates() {
		return EMI_Dates;
	}
	public void setEMI_Dates(String eMI_Dates) {
		EMI_Dates = eMI_Dates;
	}
	public String getLast_three_EMIs() {
		return Last_three_EMIs;
	}
	public void setLast_three_EMIs(String last_three_EMIs) {
		Last_three_EMIs = last_three_EMIs;
	}
	
	
	
	

}
