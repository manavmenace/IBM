package com.alphaiciapi.model;

public class WalletLoginUser {

	//AUTH_DATA,AUTH_TYPE,CREATED_DATE,DEVICE_ID,ID_TYPE,ID_VALUE,IMEI,IP_ADDRESS,LATITUDE,LONGITUDE,MOBILE,OS,WM_ACC_NO,WM_AMOUNT,WM_MAPPED_AC_NO,WM_STATUS,WM_USER_ID)
	private String merchant_id;
	private String scope;
	private String redirect_url;
	private String first_name;
	private String last_name;
	private String email;
	private String mobile;
	private String dob;
	private String gender;
	private String ip_address;
	private String os;
	private String device_id;
	private String imei;
	private String state;
	
	private String accessTokenValidTill;
	private String creationStatus;
	private String auth_data;
	private String auth_type;
	private String created_date;
	
	private String id_type;
	private String id_value;
	
	private String latitude;
	private String longitude;
	
	private String wm_acc_no;
	private String wm_amount;
	private String wm_mapped_ac_no;
	private String wm_status;
	private String wm_user_id;
	
	public String getMerchant_id() {
		return merchant_id;
	}
	public void setMerchant_id(String merchant_id) {
		this.merchant_id = merchant_id;
	}
	public String getScope() {
		return scope;
	}
	public void setScope(String scope) {
		this.scope = scope;
	}
	public String getRedirect_url() {
		return redirect_url;
	}
	public void setRedirect_url(String redirect_url) {
		this.redirect_url = redirect_url;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getIp_address() {
		return ip_address;
	}
	public void setIp_address(String ip_address) {
		this.ip_address = ip_address;
	}
	public String getOs() {
		return os;
	}
	public void setOs(String os) {
		this.os = os;
	}
	public String getDevice_id() {
		return device_id;
	}
	public void setDevice_id(String device_id) {
		this.device_id = device_id;
	}
	public String getImei() {
		return imei;
	}
	public void setImei(String imei) {
		this.imei = imei;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	public String getAccessTokenValidTill() {
		return accessTokenValidTill;
	}
	public void setAccessTokenValidTill(String accessTokenValidTill) {
		this.accessTokenValidTill = accessTokenValidTill;
	}
	public String getCreationStatus() {
		return creationStatus;
	}
	public void setCreationStatus(String creationStatus) {
		this.creationStatus = creationStatus;
	}
	public String getAuth_data() {
		return auth_data;
	}
	public void setAuth_data(String auth_data) {
		this.auth_data = auth_data;
	}
	public String getAuth_type() {
		return auth_type;
	}
	public void setAuth_type(String auth_type) {
		this.auth_type = auth_type;
	}
	public String getCreated_date() {
		return created_date;
	}
	public void setCreated_date(String created_date) {
		this.created_date = created_date;
	}
	public String getId_type() {
		return id_type;
	}
	public void setId_type(String id_type) {
		this.id_type = id_type;
	}
	public String getId_value() {
		return id_value;
	}
	public void setId_value(String id_value) {
		this.id_value = id_value;
	}
	
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getWm_acc_no() {
		return wm_acc_no;
	}
	public void setWm_acc_no(String wm_acc_no) {
		this.wm_acc_no = wm_acc_no;
	}
	public String getWm_amount() {
		return wm_amount;
	}
	public void setWm_amount(String wm_amount) {
		this.wm_amount = wm_amount;
	}
	public String getWm_mapped_ac_no() {
		return wm_mapped_ac_no;
	}
	public void setWm_mapped_ac_no(String wm_mapped_ac_no) {
		this.wm_mapped_ac_no = wm_mapped_ac_no;
	}
	public String getWm_status() {
		return wm_status;
	}
	public void setWm_status(String wm_status) {
		this.wm_status = wm_status;
	}
	public String getWm_user_id() {
		return wm_user_id;
	}
	public void setWm_user_id(String wm_user_id) {
		this.wm_user_id = wm_user_id;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
}
