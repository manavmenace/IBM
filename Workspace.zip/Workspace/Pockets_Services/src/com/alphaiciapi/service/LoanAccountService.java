package com.alphaiciapi.service;

import java.util.ArrayList;
import java.util.List;

//import org.apache.log4j.Logger;

import com.alphaiciapi.daoimpl.LoanDaoImpl;
import com.alphaiciapi.model.Loan;
import com.alphaiciapi.model.LoanReqDetails;
import com.alphaiciapi.model.LoanResCustModel;
import com.alphaiciapi.model.LoanResEmiModel;
import com.alphaiciapi.model.LoanResSumModel;
import com.alphaiciapi.model.LoanResTransModel;
import com.alphaiciapi.model.SearchCriteria;
import com.google.gson.JsonObject;

public class LoanAccountService {

	LoanDaoImpl loanDaoImpl = new LoanDaoImpl();
	
	//static final Logger logger = Logger.getLogger(LoanAccountService.class);

	public JsonObject getCustDetails(LoanReqDetails loanDetails) {
		return loanDaoImpl.getCustomerDetails(loanDetails);
	}

	public JsonObject getLoanSumDetails(LoanReqDetails loanDetails) {
		return loanDaoImpl.getLoanSummaryDetails(loanDetails);
	}

	public JsonObject getEMIDetails(LoanReqDetails loanDetails) {
		return loanDaoImpl.getEMIDetails(loanDetails);
	}

	public JsonObject getTransDetails(LoanReqDetails loanDetails) {
		return loanDaoImpl.getTransactionDetails(loanDetails);
	}

	/*public void inserLoanDetails(Loan loan) {

		try {
			loanDaoImpl.insertLoandetails(loan);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	*/
	public List<Loan> getLoanDetails(SearchCriteria searchCriteria) {

		List<Loan> loanModelList = new ArrayList<Loan>();
		try{
			loanModelList= loanDaoImpl.getLoanDetails(searchCriteria);
		}catch(Exception exception){
		}
		return loanModelList;
		
	}

}
