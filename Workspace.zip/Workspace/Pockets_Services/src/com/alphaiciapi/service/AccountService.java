package com.alphaiciapi.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;



//@Component("accountService")
public class AccountService {

	/*public List<Account> getAccounts(SearchCriteria searchCriteria) {

		List<Account> accountInfos = new ArrayList<Account>();

		Account account = new Account();

		account.setAccountNumber("5674312346789");
		account.setAccountType("acctype1");
		account.setMobileNO("mobile no1");
		account.setToken("token1");
		account.setAmount(345.89);
		account.setActivationDate(new Date());
		accountInfos.add(account);

		account = new Account();
		account.setAccountNumber("981234598765");
		account.setAccountType("acctype1");
		account.setMobileNO("mobile no1");
		account.setToken("token1");
		account.setAmount(789.89);
		account.setActivationDate(new Date());
		accountInfos.add(account);

		return accountInfos;
	}

	public List<AccountInfo> getBalanceDetails(SearchCriteria searchCriteria) {

		List<AccountInfo> accountInfoList = new ArrayList<AccountInfo>();

		AccountInfo accountInfo = new AccountInfo();

		BankDetails bankDetails = new BankDetails();
		bankDetails.setBankCode("ICICI123");
		bankDetails.setBranchLocation("ICICIGACHIBOWLY");
		bankDetails.setBranchName("GACHIBOWLYBRANCH");

		Account account = new Account();
		account.setAccountNumber("1234");
		account.setAccountType("acctype1");
		account.setMobileNO("mobile no1");
		account.setToken("token1");

		BalanceDetails balanceDetails = new BalanceDetails();
		balanceDetails.setAvailableAmout(123.78);
		balanceDetails.setFullAvailableAmout(760.78);

		accountInfo.setAccount(account);
		accountInfo.setBankDetails(bankDetails);
		accountInfo.setBalanceDetails(balanceDetails);
		accountInfoList.add(accountInfo);

		return accountInfoList;
	}

	public List<TransactinDetails> getTransactinDetails(
			SearchCriteria searchCriteria) {

		List<TransactinDetails> transactinDetailsList = new ArrayList<TransactinDetails>();
		TransactinDetails transactinDetails = new TransactinDetails();
		transactinDetails.setCurrency("INR");
		transactinDetails.setClearBalance(129.78);
		transactinDetails.setUnClearBalance(345.95);
		transactinDetailsList.add(transactinDetails);

		transactinDetails = new TransactinDetails();
		transactinDetails.setCurrency("INR");
		transactinDetails.setClearBalance(345.78);
		transactinDetails.setUnClearBalance(786.95);
		transactinDetailsList.add(transactinDetails);

		return transactinDetailsList;
	}

	public MessageStatus creditAmount(Account account) {

		return MessageStatus.SUCCESS;
	}

	public MessageStatus debidtAmount(Account account) {

		return MessageStatus.SUCCESS;
	}

	public Account getCurentBalance(CardDetails cardDetails) {

		Account account = new Account();
		
		account.setAccountNumber("55512345789");
		account.setAmount(3000.00);
		
		return account;
	}
	
	public Account getDateofActivation(CardDetails cardDetails) {

		Account account = new Account();
		
		account.setAccountNumber("55512345789");
		account.setActivationDate(new Date());
		
		return account;
	}*/

	
	
}
