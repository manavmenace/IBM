package com.alphaiciapi.service;

import java.util.List;

import com.alphaiciapi.daoimpl.CardDetailsDaoImpl;
import com.alphaiciapi.model.CardDetails;
import com.alphaiciapi.model.SearchCriteria;


public class CardDetailsService {

	
	
	
	CardDetailsDaoImpl cardDetailsDaoImpl = new CardDetailsDaoImpl();
	
	public List<CardDetails> getCardDetails(SearchCriteria searchCriteria) {

		
		List<CardDetails> cardDetailsList = null;
		
		try{
			cardDetailsList = cardDetailsDaoImpl.getCardDetails(searchCriteria);
			
		}catch(Exception exception){
			exception.printStackTrace();
		}
		return cardDetailsList;
		
	}
	
	
	
}
