package com.alphaiciapi.service;

import java.util.ArrayList;
import java.util.List;

import com.alphaiciapi.daoimpl.WalletDaoImpl;
import com.alphaiciapi.model.Wallet;
import com.alphaiciapi.model.WalletLoginUser;
import com.alphaiciapi.model.WalletLoginUserReturn;
import com.alphaiciapi.model.WalletResponse;
import com.alphaiciapi.model.WalletStmtRes;
import com.alphaiciapi.util.CommmonUtils;
import com.alphaiciapi.util.ErrorCodeConstants;
import com.alphaiciapi.util.ValidationUtil;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

public class WalletService{
	
	WalletDaoImpl walletDaoImpl = new WalletDaoImpl();
		
		public List<Object>  createWallet(String UserId,String accessId) {
			List<Object> result = null;
			try {
				result = new ArrayList<Object>();
				//result.add(walletDaoImpl.checkUser(UserId,accessId));
				result.add(CommmonUtils.getErrorInfo(ErrorCodeConstants.SUCCESS_CODE, ErrorCodeConstants.SUCCESS_DESC));
			} catch (Exception e) {
				result.add(new Wallet());
		    	result.add(CommmonUtils.getErrorInfo(ErrorCodeConstants.INTERNAL_ERROR, ErrorCodeConstants.INTERNAL_ERROR_DESC));
			}
			return result;
		 }
		
		public WalletLoginUserReturn  createNewWallet(WalletLoginUser walletLoginUser) {
			WalletLoginUserReturn result = null;
			try {
				//result = new ArrayList<Object>();
				/*result.add(walletDaoImpl.checkNewUser(walletLoginUser));*/
				result = walletDaoImpl.checkNewUser(walletLoginUser);
				//result.add(CommmonUtils.getErrorInfo(ErrorCodeConstants.SUCCESS_CODE, ErrorCodeConstants.SUCCESS_DESC));
			} catch (Exception e) {
				/*result.add(new Wallet());
		    	result.add(CommmonUtils.getErrorInfo(ErrorCodeConstants.INTERNAL_ERROR, ErrorCodeConstants.INTERNAL_ERROR_DESC));*/
			}
			return result;
		 }
		
		public Object  createNewWallet1(WalletLoginUser walletLoginUser) {
			Object obj =null;
			try {
				
				obj= walletDaoImpl.checkNewUser(walletLoginUser);
				
			} catch (Exception e) {
				
			}
			return obj;
		 }
		
		public String getWalletBalance(Wallet searchCriteria) {
			List<Object> result = null;
			JsonObject jsonObject=null;
			JsonObject jsonObject1=null;
			JsonObject jsonObject2=null;
			try {
				
				jsonObject = new JsonObject();
				
				if(ValidationUtil.isEmpty(searchCriteria.getAuth_data())){
					jsonObject.addProperty("errorCode", ErrorCodeConstants.AUTH_TOKEN_CODE);
					jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.AUTH_TOKEN_DESC);
					return jsonObject.toString();
				}
				jsonObject2 =  walletDaoImpl.getWalletBalance(searchCriteria);
				if(jsonObject2 ==null ){
					jsonObject=  new JsonObject();
					jsonObject.addProperty("errorCode", ErrorCodeConstants.RECORD_NOT_FOUNT);
					jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.RECORD_NOT_FOUNT_DESC);
			    	return jsonObject.toString();
				}
				jsonObject1 = new JsonObject();
				jsonObject1.addProperty("Code", ErrorCodeConstants.SUCCESS_CODE);
				//jsonObject1.addProperty("Message", ErrorCodeConstants.SUCCESS_DESC);
				JsonArray jarray = new JsonArray();
				jarray.add(jsonObject1);
				jarray.add(jsonObject2);
				return jarray.toString();
				//jsonObject.add(null, jsonObject1);
				//jsonObject.add(null, jsonObject2);
				
			} catch (Exception e) {
				jsonObject.addProperty("errorCode", ErrorCodeConstants.INTERNAL_ERROR);
				jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.INTERNAL_ERROR_DESC);
			}
			System.out.println("Response getCreditDetails:::::" + result);
			return jsonObject.toString();
		}
		
		
		
		public List<WalletResponse> getWalletStatementDetails(Wallet wallet) {
			
			List<WalletResponse> result = null;
			try {
				result = new ArrayList<WalletResponse>();
				if(ValidationUtil.isEmpty(wallet.getAuth_data())){
					result.add(new WalletResponse());
			    	//result.add(CommmonUtils.getErrorInfo(ErrorCodeConstants.AUTH_TOKEN_CODE, ErrorCodeConstants.AUTH_TOKEN_DESC));
			    	return result;
				}
				
				WalletStmtRes wsr = new WalletStmtRes();
				wsr = walletDaoImpl.getWalletStatement(wallet);
				result = wsr.getWalletStatement();
				
				//result.add(walletDaoImpl.getWalletStatement(wallet));
				//result.add(CommmonUtils.getErrorInfo(ErrorCodeConstants.SUCCESS_CODE, ErrorCodeConstants.SUCCESS_DESC));
			} catch (Exception e) {
				result.add(new Wallet());
		    	//result.add(CommmonUtils.getErrorInfo(ErrorCodeConstants.INTERNAL_ERROR, ErrorCodeConstants.INTERNAL_ERROR_DESC));
			}
			System.out.println("Response getWalletStatementDetails:::::::::::::" + result);
			return result;
			}
		
		
		public String creditWalletAmount(Wallet searchCriteria) {

			JsonObject jsonObject = null;
			JsonObject jsonObject1 = null;
			JsonObject jsonObject2 = null;
			JsonArray jsonObjectArray = new JsonArray();
			try {
				
				if(ValidationUtil.isEmpty(searchCriteria.getAuth_data())){
					jsonObject = new JsonObject();
					jsonObject.addProperty("errorCode", ErrorCodeConstants.AUTH_TOKEN_CODE);
					jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.AUTH_TOKEN_DESC);
					return jsonObject.toString();
				}
				
				jsonObject2 = walletDaoImpl.creditWalletAmount(searchCriteria);
				
				
				jsonObject1 = new JsonObject();
				jsonObject1.addProperty("Code", ErrorCodeConstants.SUCCESS_CODE);
				JsonArray jarray = new JsonArray();
				jarray.add(jsonObject1);
				jarray.add(jsonObject2);
				return jarray.toString();
				//jsonObject1.addProperty("Code", ErrorCodeConstants.SUCCESS_CODE);
				//jsonObject1.addProperty("Message", ErrorCodeConstants.SUCCESS_DESC);
				//jsonObjectArray.add(jsonObject1);
				//jsonObjectArray.add(jsonObject2);
				
			
			} catch (Exception e) {
				System.out.println("credit card exceptin"+e.getMessage());
				if(e.getMessage().equals("MAX_WALLET_BALANCE")){
					jsonObject = new JsonObject();
					jsonObject.addProperty("errorCode", ErrorCodeConstants.WALLET_MAX_AMOUNT);
					jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.WALLET_MAX_AMOUNT_DESC);
				
			}else if(e.getMessage().equals("NO_WALLET")){
				jsonObject = new JsonObject();
				jsonObject.addProperty("errorCode", ErrorCodeConstants.NO_WALLET);
				jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.NO_WALLET_DESC);
			
			}else{
				jsonObject = new JsonObject();
				jsonObject.addProperty("errorCode", ErrorCodeConstants.INTERNAL_ERROR);
				jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.INTERNAL_ERROR_DESC);
			   }
			}

			return jsonObject.toString();
		}
		
		public String debitWalletAmount(Wallet searchCriteria) {
			JsonObject jsonObject = null;
			JsonObject jsonObject1 = null;
			JsonObject jsonObject2 = null;
			try {
				if(ValidationUtil.isEmpty(searchCriteria.getAuth_data())){
						jsonObject = new JsonObject();
						jsonObject.addProperty("errorCode", ErrorCodeConstants.AUTH_TOKEN_CODE);
						jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.AUTH_TOKEN_DESC);
						return jsonObject.toString();
				}
					jsonObject2 = walletDaoImpl.debitWalletAmount(searchCriteria);
					jsonObject1 = new JsonObject();
					jsonObject1.addProperty("Code", ErrorCodeConstants.SUCCESS_CODE);
					//jsonObject1.addProperty("errorDescripttion", ErrorCodeConstants.SUCCESS_DESC);
					JsonArray jarray = new JsonArray();
					jarray.add(jsonObject1);
					jarray.add(jsonObject2);
					return jarray.toString();
					
			} catch (Exception e) {
				System.out.println("credit card exceptin"+e.getMessage());
				if(e.getMessage().equals("NO_BALANCE")){
						jsonObject = new JsonObject();
						jsonObject.addProperty("errorCode", ErrorCodeConstants.INSUFFICIENT_BALANCE_CODE);
						jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.INSUFFICIENT_BALANCE_DESC);
					
				}else if(e.getMessage().equals("NO_WALLET")){
					jsonObject = new JsonObject();
					jsonObject.addProperty("errorCode", ErrorCodeConstants.NO_WALLET);
					jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.NO_WALLET_DESC);
				
			}else{
					jsonObject = new JsonObject();
					jsonObject.addProperty("errorCode", ErrorCodeConstants.INTERNAL_ERROR);
					jsonObject.addProperty("errorDescripttion", ErrorCodeConstants.INTERNAL_ERROR_DESC);
				   }
			}
			return jsonObject.toString();
		}
		
		
}
