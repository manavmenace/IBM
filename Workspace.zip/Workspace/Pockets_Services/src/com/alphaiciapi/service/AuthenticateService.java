package com.alphaiciapi.service;

import com.alphaiciapi.daoimpl.AuthenticateDAO;

public class AuthenticateService {
	AuthenticateDAO authenticateDAO = new AuthenticateDAO();
	public boolean validateClient(String client_id,String token,String api_name) {
		return authenticateDAO.validateClient(client_id, token, api_name);
	}
}
