package com.alphaiciapi.dao;

import com.alphaiciapi.model.Loan;
import com.alphaiciapi.model.LoanReqDetails;
import com.alphaiciapi.model.LoanResCustModel;
import com.alphaiciapi.model.LoanResEmiModel;
import com.alphaiciapi.model.LoanResSumModel;
import com.alphaiciapi.model.LoanResTransModel;

public interface LoanDaoI {
	void insertLoandetails(Loan loan);
	
	/* LoanResCustModel getCustomerDetails(LoanReqDetails loanReqDet);
	 LoanResSumModel getLoanSummaryDetails(LoanReqDetails loanReqDet);
	 LoanResEmiModel getEMIDetails(LoanReqDetails loanReqDet);
	 LoanResTransModel getTransactionDetails(LoanReqDetails loanReqDet);
*/
}
