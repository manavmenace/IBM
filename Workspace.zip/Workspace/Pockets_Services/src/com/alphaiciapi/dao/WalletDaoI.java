package com.alphaiciapi.dao;

import java.util.List;

//import com.model.Wallet;

public interface WalletDaoI {
	 /*List<Wallet> getDebitDetails(Wallet wallet);
	 List<Wallet> getCreditDetails(Wallet wallet);
	 List<Wallet> getWalletStatement(Wallet wallet);
	 List<Wallet> getBallanceDeatils(Wallet wallet);*/
}
