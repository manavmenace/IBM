package appathon.bluemix.service;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.TimeZone;
import java.util.logging.Logger;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@Path("/icici")
public class RestCall {
	private static final Logger log = Logger.getLogger(RestCall.class.getName());

	public RestCall() throws JSONException {
		log.info("-------------Constructor------------");
		gobj.put("code", 200);
		count = 0;
	}

	JSONObject returnMessage = new JSONObject();
	JSONObject gobj = new JSONObject();
	boolean flag;
	public int count;

	// balanceinq?accountno=
	@GET
	@Path("/stockvalue")
	@Produces
	public String getMessage(@Context UriInfo uriInfo,@QueryParam("client_id") String email, @QueryParam("token") String token
			) throws JSONException {

		log.info("###---- Stock ----###");
		System.out.println("m in");
		Connection connection = null;
		Statement statement = null;
		ResultSet rs = null;
		CommonMethod comn = new CommonMethod();
		String result = "";
		String stock = "";
		String exchange = "";
		String price = "";
		DatabaseUtil dbUtil = new DatabaseUtil();
		JSONObject jobj = new JSONObject();
		JSONArray jarray = new JSONArray();

		boolean flag = false;
		boolean accflag = false;
		log.info("Validation Details " + email + " userid is " + token);
		try {
			HashSet<String> set = new HashSet<String>();
			set.add("client_id");
			set.add("token");
			String data=comn.keyvalidation(uriInfo,set);
			if(data.equalsIgnoreCase("ok"))
			{
			if (connection == null || connection.isClosed()) {
				System.out.println("Inside getMessage connection open : " + connection);
				connection = dbUtil.getConnection();
			}
			flag = validateClient(email, token, "stockvalue", connection);
			if (flag) {
				String regex = "[0-9]+";
							
							statement = connection.createStatement();
							rs = statement.executeQuery("select * from stock");
							while(rs.next()){
								stock = rs.getString("stock_code");
								exchange = rs.getString("exchange"); 
								price = rs.getString("stock_price");
								if (count == 0) {
									jarray.put(gobj);
								}
								count++;
								JSONObject jobj1 = new JSONObject();
								jobj1.put("Stock",rs.getString("stock_code"));
								jobj1.put("Exchange",rs.getString("exchange"));
								jobj1.put("Price",rs.getString("stock_price"));
								jarray.put(jobj1);
								//log.info("Beiller Detail for :" + billername + " is " + biller +", Child id is "+childid +"and state is "+ state);
							}

			}else {
				log.info("Token Verification Failed.");
				returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
				jarray.put(returnMessage);
			}
			// String out = "" + accountno + " : " + result;
			if (jarray.length() == 0) {
				jarray.put(returnMessage);
				result = jarray.toString();
			} else {
				// jarray.put(jobj);
				result = jarray.toString();
			}
		} 
			else
				{
				returnMessage.put("code",454);
				returnMessage.put("description","Invalid Parameter");
				returnMessage.put("message",data);
				jarray.put(returnMessage);
				System.out.println(jarray.toString());
				return jarray.toString();
				}
		}
		catch (SQLException e) {
				
			e.printStackTrace();
			returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
			// returnMessage = getJsonErr(400,"",
			// "Database Error. Please try after some time");
			log.info(jobj.toString() + " -- " + email);
		} catch (Exception ex) {
			ex.printStackTrace();
			returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
			// returnMessage = getJsonErr(400,"",
			// "Database Error. Please try after some time");
			log.info(jobj.toString() + " -- " + email);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result;
	}
	
	@GET
	@Path("/tradestock")
	@Produces
	public String tradestock(@Context UriInfo uriInfo,
			@QueryParam("client_id") String email, 
			@QueryParam("token") String token,
			@QueryParam("cust_id") String custid,
			@QueryParam("stockcode") String stockcode,
			@QueryParam("exchange") String exchange,
			@QueryParam("ordertype") String ordertype, 
			@QueryParam("quantity") String quantity, 
			@QueryParam("orderprice") String orderprice) throws JSONException {
		log.info("###---- trade Stock ----###");
		System.out.println("m in");
		Connection connection = null;
		Statement statement = null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		boolean rs2;
		boolean rs3;
		CommonMethod comn = new CommonMethod();
		String result = "";
		String billerName = "";
		String parentid = "";
		String childid ="";
		DatabaseUtil dbUtil = new DatabaseUtil();
		JSONObject jobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		DecimalFormat decimalFormat = new DecimalFormat("####");

		log.info("trading stock for : "+stockcode+" and exchange is : "+exchange);
		boolean flag = false;
		boolean accflag = false;
		log.info("Validation Details " + email + " userid is " + token);
		try {	
			HashSet<String> set = new HashSet<String>();
			set.add("client_id");
			set.add("token");
			set.add("cust_id");
			set.add("stockcode");
			set.add("exchange");
			set.add("ordertype");
			set.add("quantity");
			set.add("orderprice");
			String data=comn.keyvalidation(uriInfo,set);
			if(data.equalsIgnoreCase("ok"))
			{
			if (connection == null || connection.isClosed()) {
				System.out.println("Inside getMessage connection open : " + connection);
				connection = dbUtil.getConnection();
			}
			flag = validateClient(email, token, "tradestock", connection);
			if (flag) {
				String regex = "[0-9//.]+";
				if (ordertype.equalsIgnoreCase("BUY")||ordertype.equalsIgnoreCase("SELL")){
					if(quantity.matches(regex)){
						double quan = Double.parseDouble(quantity);
						if(quan>0 && quan<5001){
							if(custid.length()==8 && custid.matches(regex)){
								if(orderprice.matches(regex)){
								statement = connection.createStatement();
								System.out.println(stockcode+" ======= "+exchange);
								rs = statement.executeQuery("select stock_price from stock where stock_code=upper('"+stockcode+"') and exchange=upper('"+exchange+"')");
								if(rs.next()){
									double sp = rs.getDouble("stock_price");
									double op = decimalFormat.parse(orderprice).doubleValue();
									System.out.println(sp);
									String current_time = null;
									Date currdate = new Date();
									SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
									formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
									current_time = formatter.format(currdate);
									if(sp > op){
										rs2 = statement.execute("insert into stock_exchange values ('"+stockcode+"','"+exchange+"','"+ordertype+"','"+quantity+"','"+orderprice+"','Ordered','"+custid+"','"+current_time+"')");
										if (count == 0) {
											jarray.put(gobj);
										}
										count++;
										JSONObject jobj1 = new JSONObject();
										jobj1.put("Success","Order placed successfully");
										jarray.put(jobj1);
									}
									else{
										rs3 = statement.execute("insert into stock_exchange values ('"+stockcode+"','"+exchange+"','"+ordertype+"','"+quantity+"','"+orderprice+"','Executed','"+custid+"',sysdate)");
										double upprice = (double)(((quan/25000)*0.05)*sp)+sp;
										String w= upprice+"";
										String upp = w.substring(0, 6);
										rs2 = statement.execute("update stock set stock_price = "+upp+" where stock_code='"+stockcode+"' and exchange='"+exchange+"'");
										if (count == 0) {
											jarray.put(gobj);
										}
										count++;
										JSONObject jobj1 = new JSONObject();
										jobj1.put("Success","Order executed successfully");
										jarray.put(jobj1);
									}
								}
								else{
									returnMessage = getJsonErr(401, "incorrect value for stock code or exchnage", "Improper data entered");
									jarray.put(returnMessage);
								}
								
							}
								else{
									returnMessage = getJsonErr(401, "Must contains numbers only", "Improper data entered");
									jarray.put(returnMessage);
								}
							}
							
							else{
								returnMessage = getJsonErr(401, "custId must be 8 digit", "Improper data entered");
								jarray.put(returnMessage);
							}
						}
						else{
							returnMessage = getJsonErr(401, "Quantity cab be in between 1 to 5000", "Improper data entered");
							jarray.put(returnMessage);
						}
					}
					else{
						returnMessage = getJsonErr(401, "Quantity must be numeric", "Improper data entered");
						jarray.put(returnMessage);
					}
				}else{
					returnMessage = getJsonErr(401, "Order Type must be Buy or Sell", "Improper data entered");
					jarray.put(returnMessage);
				}
				
			} else {
				log.info("Token Verification Failed.");
				returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
				jarray.put(returnMessage);
			}
			// String out = "" + accountno + " : " + result;
			if (jarray.length() == 0) {
				jarray.put(returnMessage);
				result = jarray.toString();
			} else {
				// jarray.put(jobj);
				result = jarray.toString();
			}
		} 
			else
				{
				returnMessage.put("code",454);
				returnMessage.put("description","Invalid Parameter");
				returnMessage.put("message",data);
				jarray.put(returnMessage);
				System.out.println(jarray.toString());
				return jarray.toString();
				}
		}
			catch (SQLException e) {
				
			e.printStackTrace();
			returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
			// returnMessage = getJsonErr(400,"",
			// "Database Error. Please try after some time");
			log.info(jobj.toString() + " -- " + parentid);
		} catch (Exception ex) {
			ex.printStackTrace();
			returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
			// returnMessage = getJsonErr(400,"",
			// "Database Error. Please try after some time");
			log.info(jobj.toString() + " -- " + parentid);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (rs1 != null) {
					rs1.close();
				}

				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result;
	}
	
	@GET
	@Path("/showtrading")
	@Produces
	public String schedulePay(@Context UriInfo uriInfo,@QueryParam("client_id") String email, 
			@QueryParam("token") String token, 
			@QueryParam("cust_id") String custid, 
			@QueryParam("date") String date) throws JSONException {
		log.info("###---- Stock Trading ----###");
		System.out.println("m in");
		Connection connection = null;
		Statement statement = null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		CommonMethod comn = new CommonMethod();
		String result = "";
		String stock = "";
		String exchange = "";
		String ordertype = "";
		String quantity = "";
		String price = "";
		String confirmation = "";
		
		String state = "";
		DatabaseUtil dbUtil = new DatabaseUtil();
		JSONObject jobj = new JSONObject();
		JSONArray jarray = new JSONArray();

		
		boolean flag = false;
		boolean accflag = false;
		log.info("Validation Details " + email + " userid is " + token);
		try {
			HashSet<String> set = new HashSet<String>();
			set.add("client_id");
			set.add("token");
			set.add("cust_id");
			set.add("date");
			String data=comn.keyvalidation(uriInfo,set);
			if(data.equalsIgnoreCase("ok"))
			{
			if (connection == null || connection.isClosed()) {
				System.out.println("Inside getMessage connection open : " + connection);
				connection = dbUtil.getConnection();
			}
			flag = validateClient(email, token, "trade stock", connection);
			if (flag) {
				String regex = "[0-9]+";
				if(custid.matches(regex) && custid.length()==8){
					if(date!=""){
					System.out.println(custid);
					System.out.println(date);
					statement = connection.createStatement();
					rs = statement.executeQuery("select * from stock_exchange where cust_id='"+custid+"'");    //+"' and date like '"+date+"%'");
					while(rs.next()){
						
						stock = rs.getString("stock_code");
						exchange = rs.getString("exchange");
						ordertype = rs.getString("order_type");
						quantity = rs.getString("order_quantity");
						price = rs.getString("order_price");
						confirmation = rs.getString("confirmation");
						if (count == 0) {
							jarray.put(gobj);
							JSONObject jobj0 = new JSONObject();
							jobj0.put("Format","STOCK_CODE-EXCHANGE-ORDER_TYPE-ORDER_QUANTITY-ORDER_PRICE-CONFIRMATION");
							jarray.put(jobj0);
						}
						count++;
						JSONObject jobj1 = new JSONObject();
						jobj1.put("Value",rs.getString("stock_code")+"-"+rs.getString("exchange")+"-"+rs.getString("order_type")+"-"+rs.getString("order_quantity")+"-"+rs.getString("order_price")+"-"+ rs.getString("confirmation"));
						jarray.put(jobj1);
				}
				}
					else{
						returnMessage = getJsonErr(401, "Date cannot be empty", "Improper data entered");
						jarray.put(returnMessage);
					}
				}
				else{
					returnMessage = getJsonErr(401, "custId must be 8 digit", "Improper data entered");
					jarray.put(returnMessage);
				}
		} else {
			log.info("Token Verification Failed.");
			returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
			jarray.put(returnMessage);
		}
		// String out = "" + accountno + " : " + result;
		if (jarray.length() == 0) {
			jarray.put(returnMessage);
			result = jarray.toString();
		} else {
			// jarray.put(jobj);
			result = jarray.toString();
		}
	}
			else
			{
				returnMessage.put("code",454);
				returnMessage.put("description","Invalid Parameter");
				returnMessage.put("message",data);
				jarray.put(returnMessage);
				System.out.println(jarray.toString());
				return jarray.toString();
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
			returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
			// returnMessage = getJsonErr(400,"",
			// "Database Error. Please try after some time");
		} catch (Exception ex) {
			ex.printStackTrace();
			returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
			// returnMessage = getJsonErr(400,"",
			// "Database Error. Please try after some time");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (rs1 != null) {
					rs1.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result;
	}
	
	public JSONObject getJsonErr(int errCd, String errMsg, String errDesc) throws JSONException {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("code", errCd);

		if (errCd == 400) {
			jsonObject.put("message", "Bad request. Invalid Request parameter");
		} else if (errCd == 501) {
			jsonObject.put("message", "Processing error � One or more of internal systems gave an error while processing the request");
		} else if (errCd == 503) {
			jsonObject.put("message", "No Data Found");
		} else {
			jsonObject.put("message", errMsg);

		}
		jsonObject.put("description", errDesc);
		log.info("getJsonErr() -->" + jsonObject.toString());
		return jsonObject;
	}
	
	public boolean validateClient(String client_id, String token, String api_name, Connection connection) throws JSONException {
		// Connection connection = null;
		CommonMethod commonmethod = new CommonMethod();
		JSONObject errjobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		ResultSet rs = null;
		Statement statement = null;
		PreparedStatement pstatement = null;
		int count = 0;
		// String client_id = "";
		String result = "";
		StringWriter errors = new StringWriter();
		String query = "";
		boolean flag = false;
		String current_time = null;
		DatabaseUtil dbUtil = new DatabaseUtil();
		log.info("Inside validateClient method LOWER(client_id) is " + client_id.toLowerCase() + " token is " + token);
		try {
			System.out.println("Validate Connection Accept : " + connection);
			if (connection == null || connection.isClosed()) {
				connection = dbUtil.getConnection();
			}
			Date currdate = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
			current_time = formatter.format(currdate);
			// }
			if (!client_id.equals("")) {
				System.out.println("client");
				if (!token.equals("")) {
					// query = "select client_id,token from
					// participant_token_details where client_id='"+client_id+"'
					// and token='"+token+"' and (SELECT MINUTE(expiry_time) -
					// MINUTE('"+current_time+"') FROM SYSIBM.SYSDUMMY1) > 0";

					// timestampdiff function return diff between time
					/*
					 * 1 Microseconds 2 Seconds 4 Minutes 8 Hours 16 Days 32
					 * Weeks 64 Months 128 Quarters 256 Years
					 */
					/*query = "select client_id,token from participant_token_details where LOWER(client_id)='" + client_id.toLowerCase() + "' and token='" + token
							+ "' and (SELECT datediff(mi, p.expiry_time,'" + current_time
							+ "') FROM participant_token_details p where LOWER(p.client_id)='" + client_id.toLowerCase() + "' and p.token='" + token + "') >0";
					*/
					
					query="select client_id,token from participant_token_details "+
							"where client_id='"+client_id +"' and token = '"+token+"'";
					
					System.out.println(query);
					System.out.println("token");
					log.info("VALIDATE_____________" + query);
					statement = connection.createStatement();
					rs = statement.executeQuery(query);

					while (rs.next()) {
						System.out.println("****************************************************");
						JSONObject jobj = new JSONObject();
						jobj.put("client_id", rs.getString(1));
						jobj.put("token", rs.getString(2));
						jarray.put(jobj);
					}
					if (jarray.length() != 0) {
						flag = true;
						// update validity of token 01-03-2016
						// updateTokenValidity(client_id, token);
						setApiUsageStatus(client_id, api_name, connection);
					} else {
						returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
						jarray.put(returnMessage);
						}
					System.out.println("validate-" + flag);
					return flag;
				} else {
					log.info("Inside validateClient(..) method ---> token input is found blank");
					/*
					 * errjobj = commonmethod.getJsonStatus(400, "Bad request",
					 * "Token should not be blank"); jarray.put(errjobj);
					 * errjobj.put("ERROR", "User Id cannot be blank");
					 * jarray.put(errjobj);
					 */
					return flag;
				}
			} else {
				log.info("Inside validateClient(..) method ---> client_id id input is not set");
				/*
				 * errjobj = commonmethod.getJsonStatus(400, "Bad request",
				 * "client_id Id should not be blank"); jarray.put(errjobj);
				 * errjobj.put("ERROR", "client_id Id cannot be blank");
				 * jarray.put(errjobj);
				 */
				return flag;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
			jarray.put(returnMessage);
			e.printStackTrace(new PrintWriter(errors));
			return flag;
			/*
			 * errjobj = commonmethod.getJsonStatus(501,
			 * "Database connectivity issues or timeouts",
			 * "Please try after some time"); jarray.put(errjobj);
			 * errjobj.put("ERROR", "Database Error,Please try after some time"
			 * ); jarray.put(errjobj);
			 */
		} catch (Exception e) {
			e.printStackTrace();
			return flag;
			/*
			 * errjobj = commonmethod.getJsonStatus(402, "Error in processing",
			 * "Error while processing request"); jarray.put(errjobj);
			 */
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}

				if (statement != null) {
					statement.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			// return flag;
		}
	}
	
	public Boolean validateCustid(String custid)
	{
		String regex = "[0-9]+";
		if (custid.length() == 8)
			{
				if (custid.matches(regex))
					{
						return true;
					}
				else
					{
						return false;
					}
			}
		else
			{
				return false;
			}
	}
	
	public void setApiUsageStatus(String client_id, String api_name, Connection connection) {
		String query = "";
		// Connection connection = null;
		ResultSet rs = null;
		Statement statement = null;
		PreparedStatement pstatement = null;
		int count = 0;
		// String client_id = "";
		String result = "";
		boolean returnValue = false;
		String current_time = null;
		log.info("Inside setApiUsageStatus client_id is " + client_id + " api_name is " + api_name);
		try {
			if (connection == null || connection.isClosed()) {
				connection = new DatabaseUtil().getConnection();
				System.out.println("Inside setApiUsageStatus Passed connection not found hense instantiated new");
			}
			Date currdate = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
			current_time = formatter.format(currdate);
			query = "insert into participant_apiusage_rev(client_id,api_name,time) values(?,?,?)";
			pstatement = connection.prepareStatement(query);
			pstatement.setString(1, client_id);
			// pstatement.setString(2, userid);
			pstatement.setString(2, api_name);
			pstatement.setString(3, current_time);
			returnValue = pstatement.execute();
			connection.commit();
			log.info("Inside setApiUsageStatus Insert Status : " + returnValue);
		} catch (Exception e) {
			e.printStackTrace();
			log.warning("Exception in setApiUsageStatus : " + e.getMessage());
		} finally {
			try {
				if (pstatement != null) {
					pstatement.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		/*
		 * finally{
		 * 
		 * }
		 */
	}
}