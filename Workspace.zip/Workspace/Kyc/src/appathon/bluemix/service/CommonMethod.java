package appathon.bluemix.service;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.TimeZone;
import java.util.UUID;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.UriInfo;

import org.json.JSONException;
import org.json.JSONObject;


public class CommonMethod {
	public JSONObject getJsonStatus(int errCd, String errMsg, String errDesc) throws JSONException{
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("code", errCd);
		jsonObject.put("message", errMsg);
		jsonObject.put("description", errDesc);
		return jsonObject;
	}
	protected String keyvalidation(UriInfo uriInfo, HashSet<String> set) {
		StringBuilder sb=new StringBuilder();
		try {
			System.out.println(uriInfo.getQueryParameters());
			MultivaluedMap<String, String> params = uriInfo.getQueryParameters();
			System.out.println("**********" + set);

			System.out.println(params.keySet().containsAll(set));
			
			for(String d :set){
			if (params.keySet().containsAll(set)) {
				return "ok";
			} 
			System.out.println();
			if (!params.containsKey(d)){
				sb.append(d+"----");
			}
			}
			return "key issue for "+sb.toString();
			
		} catch (Exception e) {
			
			System.err.println(e.getMessage());
		}
		return "please Check all key it should be " + set + " only";
	}
	public String generateToken(){
		String str = (UUID.randomUUID().toString()).replace("-", "");
		System.out.println("uuid = " + str);
		String token = str.substring(1, 13);
		System.out.println("token = " + token);
		/*int randomToken=0;	
		ByteArrayOutputStream baos = null;
		DataOutputStream dos = null;
		byte[] data = null;
		String token = "";
		try{
		     //generate a 6 digit integer 
		     randomToken = (int)(Math.random()*99999)+100000;
//		     String token = String.valueOf(randomToken);
		     baos = new ByteArrayOutputStream ();
		     dos = new DataOutputStream (baos);
		     dos.writeInt (randomToken);
		     data = baos.toByteArray();
		     token = data.toString();
		     System.out.println("TOKEN:::"+token);
			}
			catch(Exception e){
				e.printStackTrace();
			}*/
		return token;
	}

	public Boolean authenticateCustidOnly(String flag,String custid,String client_id,Connection connection)
	{
		System.out.println("------------ authenticateCustidOnly --------------Account No : "+custid);
		String query="Select CUSTID from PARTICIPANT_MASTER  where LOWER(CLIENT_ID)='"+client_id.toLowerCase()+"'";
		DatabaseUtil util = new DatabaseUtil();
		String cust_ids = null ;
		Statement statement = null;
		Statement stmt1 = null;
		ResultSet rs1 = null;
		ResultSet rs = null;
		try{
			if(connection ==null || connection.isClosed() )
			{
				System.out.println("Inside authenticateCustidOnly connection open : "+connection);
				connection = util.getConnection();
			}
			statement = connection.createStatement();

			rs  = statement.executeQuery(query);
			while(rs.next()){
				cust_ids = rs.getString("CUSTID");
			}
			System.out.println("cust_ids : "+cust_ids);


			if(cust_ids.contains(custid))
			{
				System.out.println("Cust ID Successfully validated..");
				return true;
			}
			else 
			{
				System.out.println("Cust ID not validated..");
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		finally{
			try{
				if(rs != null){
					rs.close();
				}
				if(statement != null){
					statement.close();
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
	}

	public Boolean authenticateCustid(String flag,String id,String client_id,Connection connection)
	{
		Statement statement = null;
		ResultSet rs = null;
		Statement stmt1 = null;
		ResultSet rs1 = null;
		String cust_ids = null ;
		String accountno = null;
		try{
			System.out.println("------------ AuthenticateCustid --------------Accoun No : "+id);
			String query="Select CUSTID from PARTICIPANT_MASTER  where LOWER(CLIENT_ID)='"+client_id.toLowerCase()+"'";
			DatabaseUtil dbUtil = new DatabaseUtil();
			ArrayList<String> accountnos=new ArrayList<String>();
			if(connection ==null || connection.isClosed() )
			{
				connection = dbUtil.getConnection();
			}
			statement = connection.createStatement();

			rs  = statement.executeQuery(query);
			while(rs.next()){
				cust_ids = rs.getString("CUSTID");
			}
			System.out.println("cust_ids : "+cust_ids);
			if(!cust_ids.equals(""))
			{
				System.out.println("AuthenticateCustID--Cust IDs are "+cust_ids);
				String[] custArry;
				custArry=cust_ids.split("-");
				stmt1 = connection.createStatement();
				for(int i=0;i<custArry.length;i++)
				{
					System.out.println("Cust ID : "+custArry[i]);
					rs1 = stmt1.executeQuery("Select p.ACCOUNTNO,c.CARD_NUMBER,l.LOAN_ACCOUNT_NO +"
							+ "from rtl_account_master p,rtl_card_details c,rtl_loan_master l +"
							+ "where p.custid=c.custid and p.custid=l.custid and p.CUSTID ='"+custArry[i]+"'");


					while(rs1.next()){
						accountno=rs1.getString("ACCOUNTNO");
						 System.out.println("Account No in While "+accountno);
						 accountnos.add(accountno);
					}

				}
			}
			else {
				return false;
			}

			System.out.println("------------ AuthenticateCustid END--------------");

			if (accountnos.contains(id))
			{
				System.out.println("Account No Mapped to customer");
				return true;	
			}
			else{

				return false;
			}
		}
		catch(SQLException e){
			e.printStackTrace();
			return false;
		}
		catch(Exception e){
			e.printStackTrace();
			return false;
		}
		finally{
			try{
				if(rs != null){
					rs.close();
				}
				if(statement != null){
					statement.close();
				}
				if(rs1 != null){
					rs1.close();
				}
				if(stmt1 != null){
					stmt1.close();
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}

	}

	public String getAccountNo_fund(String cust_id,Connection connection) throws SQLException {
		System.out.println("-------------Get Account No--------------Cust id : "+cust_id);
		Statement statement=null;
		ResultSet rs = null;
String accountNo="";
		try{
		DatabaseUtil util = new DatabaseUtil();
		if(connection ==null || connection.isClosed() )
		{
			connection = util.getConnection();
		}
	
		statement = connection.createStatement();
		rs = statement
				.executeQuery("select accountNo from Rtl_Account_Master where custId ='"
						+ cust_id + "'");
		while (rs.next()) {
			accountNo = rs.getString("accountNo");
		}
		
		System.out.println("---Cust id : "+cust_id+" Account no"+accountNo);
	}catch(Exception e)
	{
		e.printStackTrace();
	}
		finally{
			try{
				if(rs != null){
					rs.close();
				}
				if(statement != null){
					statement.close();
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}

		return accountNo;
	}


	public HashMap<String, String> getDates(String dateInString) {
		HashMap<String, String> hm = new HashMap<String, String>();
		try{
			Date currdate = new Date();

			DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
			//		String dateInString = "2015-03-07";

			System.out.println("CURR "+formatter.format(currdate));
			Date enterddate = formatter.parse(dateInString);
			System.out.println("FORM "+formatter.format(enterddate));

			Calendar cal = Calendar.getInstance();
			cal.setTime(enterddate);  //use java.util.Date object as arguement
			// get the value of all the calendar date fields.
			int enter_year = cal.get(Calendar.YEAR);
			System.out.println("Enter Year: " +enter_year);
			int enter_month = cal.get(Calendar.MONTH);
			System.out.println("ENter Month: " +enter_month );
			int enter_day = cal.get(Calendar.DATE);
			System.out.println("Enter Day: " +enter_day );

			cal.setTime(currdate);  //use java.util.Date object as arguement
			// get the value of all the calendar date fields.
			int curr_year = cal.get(Calendar.YEAR);
			System.out.println("current Year: " +curr_year);
			int curr_year_month = cal.get(Calendar.MONTH);
			System.out.println("current Month: " + curr_year_month);
			int curr_year_day = cal.get(Calendar.DATE);
			System.out.println("current Day: " +curr_year_day );

			String start_date ="";
			String end_date = "";
			if(enter_year == curr_year){
				if((enter_month+1) <= 3){
					System.out.println("Enterd date is valid");
					start_date 	= (curr_year-1)+"-04-01";
					end_date 	= dateInString;
				}
			}
			if(enter_year == curr_year-1){
				if((enter_month+1) >= 4){
					start_date = curr_year-1+"-04-01";
					end_date = dateInString;
				}
			}


			hm.put("currYear_strat_date", start_date);
			hm.put("currYear_end_date", end_date);
			hm.put("prevYear_start_date",curr_year-2+"-04-01" );
			hm.put("prevYear_end_date",String.valueOf(curr_year-1) +"-"+String.valueOf(enter_month+1)+"-"+String.valueOf(enter_day));
			return hm;
		}
		catch(Exception e){
			e.printStackTrace();
			return hm;
		}
	}




	public JSONObject getFinancialYear(String start_date) throws JSONException{
		String[] dateArray = start_date.split("-");
		int year = Integer.parseInt(dateArray[0]);
		int month = Integer.parseInt(dateArray[1]);
		int day = Integer.parseInt(dateArray[2]);
		int startFinancialYr, endFinancialYr, prevStartFinYr, prevEndFinYr;

		//Getting Financial year of the date entered.
		if (month < 4) {
			System.out.println("Financial Year : " + (year - 1) + "-" + year);
			startFinancialYr = year - 1;
			endFinancialYr = year; 
		} else {
			System.out.println("Financial Year : " + year + "-" + (year + 1));
			startFinancialYr = year;
			endFinancialYr = year + 1;
		}

		prevStartFinYr = startFinancialYr - 1;
		prevEndFinYr = endFinancialYr - 1;

		String startFinancialYrDate = String.valueOf(startFinancialYr)+"-04-01";
		String endFinancialYrDate = String.valueOf(endFinancialYr)+"-03-31";

		String startPrevFinancialYrDate = String.valueOf(prevStartFinYr)+"-04-01";
		String endPrevFinancialYrDate = String.valueOf(prevStartFinYr)+"-03-31";

		JSONObject jsonObject = new JSONObject();
		jsonObject.put("startFinancialYrDate", startFinancialYrDate);
		jsonObject.put("endFinancialYrDate", endFinancialYrDate);
		jsonObject.put("startPrevFinancialYrDate", startPrevFinancialYrDate);
		jsonObject.put("endPrevFinancialYrDate", endPrevFinancialYrDate);
		return jsonObject;
	}

	public JSONObject getJsonErr(int errCd, String errMsg, String errDesc) throws JSONException {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("code", errCd);

		if (errCd == 400) {
			jsonObject.put("message", "Bad request. Invalid Request parameter");
		} else if (errCd == 501) {
			jsonObject
			.put("message",
					"Processing error � One or more of internal systems gave an error while processing the request");
		} else if (errCd == 503) {
			jsonObject.put("message", "No Data Found");
		} else {
			jsonObject.put("message", errMsg);

		}
		jsonObject.put("description", errDesc);
		return jsonObject;
	}

}
