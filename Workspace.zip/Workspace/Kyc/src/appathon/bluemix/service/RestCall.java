package appathon.bluemix.service;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.TimeZone;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;




@Path("/icici")
public class RestCall
	{
		private static final Logger log = Logger.getLogger(RestCall.class.getName());


		public RestCall() throws JSONException
			{
				log.info("-------------Constructor------------");
				gobj.put("code", 200);
				count = 0;
			}


		JSONObject returnMessage = new JSONObject();
		JSONObject gobj = new JSONObject();
		boolean flag;
		public int count;

//http://localhost:8080/Kyc/Kyc/icici/addKYC?client_id=sachin@gmail.com&cust_id=33335474&token=fd24a25c5cc4&KYC_type=ADDRESS_PROOF&Document_type=PAN_CARD&Document_number=BOMPP4266A&Name_on_document=sachin_pardeshi&Expirydate_on_document08-08
		// Add KYC_Details
		@GET
		@Path("/addKYC")
		@Produces
		public String addKYCDetails(@Context UriInfo uriInfo,@QueryParam("client_id")
		String email, @QueryParam("cust_id")
		String custid, @QueryParam("token")
		String token, @QueryParam("KYC_type")
		String kycTpye, @QueryParam("Document_type")
		String docType, @QueryParam("Document_number")
		String docNo, @QueryParam("Name_on_document")
		String docName, @QueryParam("Expirydate_on_document")
		String expDate) throws JSONException
			{
				String regex = "^[a-zA-Z]*$";
				Connection connection = null;
				Statement statement = null;
				ResultSet rs = null;
				CommonMethod comn = new CommonMethod();
				String dType = "";
				String kType = "";
				DatabaseUtil dbUtil = new DatabaseUtil();
				PreparedStatement pstatement = null;
				JSONObject jobj = new JSONObject();
				JSONArray jarray = new JSONArray();
				log.info("Initiate Add KYC details for:" + email + " and " + custid);
				boolean flag = false;
				boolean accflag = false;
				log.info("Validation Details " + email + " userid is " + token);
				try
					{
						HashSet<String> set = new HashSet<String>();
						set.add("client_id");
						set.add("cust_id");
						set.add("token");
						set.add("KYC_type");
						set.add("Document_type");
						set.add("Document_number");
						set.add("Name_on_document");
						set.add("Expirydate_on_document");
						String data=comn.keyvalidation(uriInfo,set);
						if(data.equalsIgnoreCase("ok"))
						{
						if (connection == null || connection.isClosed())
							{
								log.info("Inside add KYC Details connection open : " + connection);
								connection = dbUtil.getConnection();
							}
						flag = validateClient(email, token, "add_KYC", connection);
						if (flag)
							{
								if (!custid.equals(""))
									{
										if (validateCustid(custid))
											{
												accflag = comn.authenticateCustidOnly("A", custid, email, connection);
												statement = connection.createStatement();
												if (accflag)
													{
														Boolean result = false;
														log.info("inside accflag");
														result = validateDocType(kycTpye, docType, docNo);
														log.info("result" + result);
														log.info("result for validation of docType " + result);
														if (result)
															{
																if (docName.length() > 1 && docName.length() < 100 && docName.matches(regex))
																	{
																		String result1 = "success";
																		result1 = validateDate(docType, expDate);
																		log.info(result1);
																		log.info("result for expiry date validation  " + result1);
																		if (result1.equalsIgnoreCase("success"))
																			{
																				// log.info("inside
																				// big
																				// if
																				// condition
																				// ");
																				kType = kycTpye.trim().toUpperCase();
																				dType = docType.trim().toUpperCase();
																				// Select
																				// count
																				// from
																				// KYC_Master
																				int count1 = 0;
																				// log.info("near
																				// query");
																				rs = statement.executeQuery("select COUNT(*) from KYC_Master where cust_id='" + custid + "'and KYC_type='" + kType + "'and Document_type='" + dType + "'");
																				log.info("count query executed");
																				if (rs.next())
																					{
																						count1 = rs.getInt(1);
																						log.info(count1 + "");
																					}
																				log.info("count for existing KYC detail " + count1);
																				if (count1 == 0)
																					{
																						String query1 = "insert into KYC_Master(cust_id,KYC_type,Document_type,Document_no,Name_on_document,Expirydate_on_document) values(?,?,?,?,?,?)";
																						pstatement = connection.prepareStatement(query1);
																						pstatement.setString(1, custid);
																						pstatement.setString(2, kType);
																						pstatement.setString(3, dType);
																						pstatement.setString(4, docNo);
																						pstatement.setString(5, docName);
																						pstatement.setString(6, expDate);
																						log.info("insert query:" + query1);
																						log.info("KCY details inserted " + query1);
																						pstatement.execute();
																						log.info("query executed");
																						connection.commit();
																						jobj.put("code", 200);
																						jobj.put("response", "records inserted successfully");
																						jarray.put(jobj);
																					}
																				else
																					{
																						returnMessage = getJsonErr(502, "Bad request.", "Records already exist so can not insert");
																					}
																			}
																	}
																else
																	{
																		returnMessage = getJsonErr(400, "Bad request.Request parameter are not valid.", "Invalid Name ");
																	}
															}
													}
												else
													{
														returnMessage = getJsonErr(401, "User Not Authorized", "This Customer ID does not belongs to participant");
													}
											}
										else
											{
												returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Customer ID should be 8 Digits & can contain only Numbers");
											}
									}
								else
									{
										returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Customer ID  cannot be null");
									}
							}
						else
							{
								returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
								jarray.put(returnMessage);
							}
						if (jarray.length() == 0)
							{
								jarray.put(returnMessage);
							}
					}
						else
						{
							returnMessage.put("code",454);
							returnMessage.put("description","Invalid Parameter");
							returnMessage.put("message",data);
							jarray.put(returnMessage);
							System.out.println(jarray.toString());
							return jarray.toString();
						}
					}
				catch (SQLException e)
					{
						returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
						e.printStackTrace();
					}
				finally
					{
						try
							{
								if (rs != null)
									{
										rs.close();
									}
								if (statement != null)
									{
										statement.close();
									}
								if (connection != null)
									{
										connection.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				log.info("Client_id : " + email);
				log.info("Response : " + jarray.toString());
				return jarray.toString();
			}


		private String validateDate(String docType, String expDate) throws JSONException
			{
				// log.info(docType);
				log.info("inside date validation.");
				log.info("inside date validation.");
				if (docType.trim().toUpperCase().equals("PAN_CARD") || docType.trim().toUpperCase().equals("AADHAR_CARD"))
					{
						if (expDate.trim().equalsIgnoreCase("NA"))
							{
								return "success";
							}
						else
							{
								returnMessage = getJsonErr(400, "Request parameter are not valid.", "Expiry Date is invalid Parameter");
								return "unsuccess";
							}
					}
				else
					if (docType.trim().toUpperCase().equals("PASSPORT") || docType.trim().toUpperCase().equals("DRIVING_LICENCE")) { return validateEdate(expDate); }
				return "success";
			}


		private String validateEdate(String expDate) throws JSONException
			{
				// log.info("inside date 2 validation");
				log.info("inside Expiry date validation");
				Date date = null;
				String Error = "success";
				try
					{
						SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
						date = sdf.parse(expDate);
						if (!expDate.equals(sdf.format(date)))
							{
								returnMessage = getJsonErr(400, "Request parameter are not valid.", "Expiry Date  is invalid");
								Error = "Date format Exception";
							}
					}
				catch (ParseException ex)
					{
						returnMessage = getJsonErr(400, "Request parameter are not valid.", "Date format is not Valid ");
						Error = "Date format Exception";
						ex.printStackTrace();
					}
				return Error;
			}


		// kycTpye,docType,docNo
		public Boolean validateDocType(String kycTpye, String docType, String docNo) throws JSONException
			{
				log.info("inside validate doctype");
				Boolean isValid = false;
				if (kycTpye.trim().toUpperCase().equals("ID_PROOF") || kycTpye.trim().toUpperCase().equals("ADDRESS_PROOF") || kycTpye.trim().toUpperCase().equals("AGE_PROOF"))
					{ // ID Proof
						isValid = validateKycDocument(docType, docNo);
					} /*
						 * else if
						 * (kycTpye.trim().toUpperCase().equals("ADDRESS_PROOF")
						 * ) { //Address Proof
						 * 
						 * isValid = validateKycDocument(docType, docNo);
						 * 
						 * } else if
						 * (kycTpye.trim().toUpperCase().equals("AGE_PROOF")) {
						 * //Age Proof
						 * 
						 * isValid = validateKycDocument(docType, docNo); }
						 */
				else
					{
						returnMessage = getJsonErr(400, "Request parameter are not valid.", "Invalid KYC type");
					}
				return isValid;
			}


		public Boolean validateKycDocument(String docType, String docNo) throws JSONException
			{
				log.info("inside validate doucument no");
				Boolean isValid = false;
				if (docType.trim().toUpperCase().equals("PAN_CARD"))
					{
						isValid = validatePANno(docNo);
					}
				else
					if (docType.trim().toUpperCase().equals("AADHAR_CARD"))
						{
							isValid = validateAadharno(docNo);
						}
					else
						if (docType.trim().toUpperCase().equals("PASSPORT"))
							{
								isValid = validatePassportno(docNo);
							}
						else
							if (docType.trim().toUpperCase().equals("DRIVING_LICENCE"))
								{
									isValid = validateDrivingLicno(docNo);
								}
							else
								{
									returnMessage = getJsonErr(400, "Request parameter are not valid.", "Invalid Document type");
								}
				return isValid;
			}


		private Boolean validateDrivingLicno(String docNo) throws JSONException
			{
				if (docNo.length() == 15)
					{
						return true;
					}
				else
					{
						returnMessage = getJsonErr(400, "Request parameter are not valid.", "Driving Licence Document lengh is invalid");
					}
				return false;
			}


		private Boolean validatePassportno(String docNo) throws JSONException
			{
				if (docNo.length() == 8)
					{
						return true;
					}
				else
					{
						returnMessage = getJsonErr(400, "Request parameter are not valid.", "Passport Document lengh is invalid");
					}
				return false;
			}


		private Boolean validateAadharno(String docNo) throws JSONException
			{
				if (docNo.length() == 12)
					{
						Pattern pattern = Pattern.compile("[0-9]{12}");
						Matcher matcher = pattern.matcher(docNo);
						// Check if pattern matches
						if (matcher.matches())
							{
								return true;
							}
						else
							{
								returnMessage = getJsonErr(400, "Request parameter are not valid.", "Aadhar Document number is invalid");
							}
					}
				else
					{
						returnMessage = getJsonErr(400, "Request parameter are not valid.", "Aadhar Document lengh is invalid");
					}
				return false;
			}


		private Boolean validatePANno(String docNo) throws JSONException
			{
				log.info("inside validate pan no.");
				if (docNo.length() == 10)
					{
						Pattern pattern = Pattern.compile("[A-Z]{5}[0-9]{4}[A-Z]{1}");
						Matcher matcher = pattern.matcher(docNo);
						// Check if pattern matches
						if (matcher.matches())
							{
								return true;
							}
						else
							{
								returnMessage = getJsonErr(400, "Request parameter are not valid.", "PAN Document number is invalid");
							}
					}
				else
					{
						returnMessage = getJsonErr(400, "Request parameter are not valid.", "PAN Document lengh is invalid");
					}
				return false;
			}


		// Get KYC_Details
		@GET
		@Path("/getKYC")
		@Produces
		public String getKYCDetails(@Context UriInfo uriInfo,@QueryParam("client_id")
		String email, @QueryParam("cust_id")
		String custid, @QueryParam("token")
		String token) throws JSONException
			{
				Connection connection = null;
				Statement statement = null;
				ResultSet rs = null;
				CommonMethod comn = new CommonMethod();
				// String result = "";
				DatabaseUtil dbUtil = new DatabaseUtil();
				// JSONObject jobj = new JSONObject();
				JSONArray jarray = new JSONArray();
				log.info("Initiate Get KYC details for:" + email + " and " + custid);
				boolean flag = false;
				boolean accflag = false;
				log.info("Validation Details " + email + " userid is " + token);
				try
					{
						HashSet<String> set = new HashSet<String>();
						set.add("client_id");
						set.add("cust_id");
						set.add("token");
						String data=comn.keyvalidation(uriInfo,set);
						if(data.equalsIgnoreCase("ok"))
						{
							if (connection == null || connection.isClosed())
							{
								log.info("Inside account summary connection open : " + connection);
								connection = dbUtil.getConnection();
							}
						flag = validateClient(email, token, "get_KYC", connection);
						if (flag)
							{
								log.info("inside flag");
								if (validateCustid(custid))
									{
										// log.info("validatecustid");
										accflag = comn.authenticateCustidOnly("A", custid, email, connection);
										// log.info("inside accflag");
										statement = connection.createStatement();
										if (accflag)
											{
												statement = connection.createStatement();
												rs = statement.executeQuery("select KYC_type,Document_type,Document_no,Name_on_document,Expirydate_on_document from KYC_Master where cust_id =" + custid);
												log.info("query executed");
												while (rs.next())
													{
														JSONObject jtemp = new JSONObject();
														if (count == 0)
															{
																jarray.put(gobj);
															}
														count++;
														jtemp.put("KYC Type", rs.getString("KYC_type"));
														jtemp.put("Document Type", rs.getString("Document_type"));
														jtemp.put("Document Number", rs.getString("Document_no"));
														jtemp.put("Name on Document", rs.getString("Name_on_document"));
														jtemp.put("Expirydate on document", rs.getString("Expirydate_on_document"));
														jarray.put(jtemp);
													}
												if (jarray.length() == 0)
													{
														returnMessage = getJsonErr(503, "No Data found", "Document Details does not exist");
													}
											}
										else
											{
												returnMessage = getJsonErr(401, "User Not Authorized", "This Customer ID does not belongs to participant");
											}
									}
								else
									{
										returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Customer ID should be 8 Digits & can contain only Numbers");
									}
							}
						else
							{
								returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
								jarray.put(returnMessage);
							}
						if (jarray.length() == 0)
							{
								jarray.put(returnMessage);
							}
					}
						else
						{
							returnMessage.put("code",454);
							returnMessage.put("description","Invalid Parameter");
							returnMessage.put("message",data);
							jarray.put(returnMessage);
							System.out.println(jarray.toString());
							return jarray.toString();
						}
					}
				catch (SQLException e)
					{
						returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
						e.printStackTrace();
					}
				finally
					{
						try
							{
								if (rs != null)
									{
										rs.close();
									}
								if (statement != null)
									{
										statement.close();
									}
								if (connection != null)
									{
										connection.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				log.info("Client_id : " + email);
				log.info("Response : " + jarray.toString());
				log.info("Client_id=" + email + "and cust_id " + custid);
				log.info("Response : " + jarray.toString());
				return jarray.toString();
			}


		public JSONObject getJsonErr(int errCd, String errMsg, String errDesc) throws JSONException
			{
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("code", errCd);
				if (errCd == 400)
					{
						jsonObject.put("message", "Request parameter are not valid.");
					}
				else
					if (errCd == 501)
						{
							jsonObject.put("message", "Processing error � One or more of internal systems gave an error while processing the request");
						}
					else
						if (errCd == 503)
							{
								jsonObject.put("message", "No Data Found");
							}
						else
							{
								jsonObject.put("message", errMsg);
							}
				jsonObject.put("description", errDesc);
				log.info("getJsonErr() -->" + jsonObject.toString());
				return jsonObject;
			}


		public Boolean validateCustid(String custid)
			{
				log.info("inside validatecustid");
				String regex = "[0-9]+";
				if (custid.length() == 8)
					{
						// log.info("inside validate1");
						if (custid.matches(regex))
							{
								// log.info("inside validate2");
								return true;
							}
						else
							{
								return false;
							}
					}
				else
					{
						return false;
					}
			}


		/*
		 * public String generatePIN() { // generate a 4 digit integer 1000
		 * <10000 int randomPIN = (int) (Math.random() * 9000) + 1000; String
		 * mpin = String.valueOf(randomPIN); return mpin; }
		 */
		public boolean validateClient(String client_id, String token, String api_name, Connection connection) throws JSONException
			{
				// Connection connection = null;
				// CommonMethod commonmethod = new CommonMethod();
				// JSONObject errjobj = new JSONObject();
				JSONArray jarray = new JSONArray();
				ResultSet rs = null;
				Statement statement = null;
				// PreparedStatement pstatement = null;
				// int count = 0;
				// String client_id = "";
				// String result = "";
				StringWriter errors = new StringWriter();
				String query = "";
				boolean flag = false;
				String current_time = null;
				DatabaseUtil dbUtil = new DatabaseUtil();
				log.info("Inside validateClient method");
				log.info("Inside validateClient method LOWER(client_id) is " + client_id.toLowerCase() + " token is " + token);
				try
					{
						log.info("Validate Connection Accept : " + connection);
						if (connection == null || connection.isClosed())
							{
								connection = dbUtil.getConnection();
							}
						Date currdate = new Date();
						SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
						current_time = formatter.format(currdate);
						// }
						if (!client_id.equals(""))
							{
								log.info("client");
								if (!token.equals(""))
									{
										// query = "select client_id,token from
										// participant_token_details where
										// client_id='"+client_id+"'
										// and token='"+token+"' and (SELECT
										// MINUTE(expiry_time) -
										// MINUTE('"+current_time+"') FROM
										// SYSIBM.SYSDUMMY1) > 0";
										// timestampdiff function return diff
										// between time
										/*
										 * 1 Microseconds 2 Seconds 4 Minutes 8
										 * Hours 16 Days 32 Weeks 64 Months 128
										 * Quarters 256 Years
										 */
										/*
										 * query =
										 * "select client_id,token from participant_token_details where LOWER(client_id)='"
										 * + client_id.toLowerCase() +
										 * "' and token='" + token +
										 * "' and (SELECT timestampdiff (4, char(timestamp(p.expiry_time)-timestamp('"
										 * + current_time +
										 * "'))) FROM participant_token_details p, SYSIBM.SYSDUMMY1 where LOWER(p.client_id)='"
										 * + client_id.toLowerCase() +
										 * "' and p.token='" + token + "') >0";
										 */
										query = "select client_id,token from participant_token_details " + "where client_id='" + client_id + "' and token = '" + token + "'";
										log.info("token");
										log.info("VALIDATE_____________" + query);
										statement = connection.createStatement();
										rs = statement.executeQuery(query);
										while (rs.next())
											{
												log.info("****************************************************");
												JSONObject jobj = new JSONObject();
												jobj.put("client_id", rs.getString(1));
												jobj.put("token", rs.getString(2));
												jarray.put(jobj);
											}
										if (jarray.length() != 0)
											{
												flag = true;
												// update validity of token
												// 01-03-2016
												// updateTokenValidity(client_id,
												// token);
												setApiUsageStatus(client_id, api_name, connection);
												log.info("validate setApiUsage");
											}
										else
											{
												returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
												jarray.put(returnMessage);
												// new
												// SendGridExample().sendEmail(jarray.toString(),
												// client_id, token, api_name,
												// "Invalid Token");
											}
										log.info("validate-" + flag);
										return flag;
									}
								else
									{
										log.info("Inside validateClient(..) method ---> token input is found blank");
										/*
										 * errjobj =
										 * commonmethod.getJsonStatus(400,
										 * "Bad request",
										 * "Token should not be blank");
										 * jarray.put(errjobj);
										 * errjobj.put("ERROR",
										 * "User Id cannot be blank");
										 * jarray.put(errjobj);
										 */
										return flag;
									}
							}
						else
							{
								/*
								 * errjobj = commonmethod.getJsonStatus(400,
								 * "Bad request",
								 * "client_id Id should not be blank");
								 * jarray.put(errjobj); errjobj.put("ERROR",
								 * "client_id Id cannot be blank");
								 * jarray.put(errjobj);
								 */
								return flag;
							}
					}
				catch (SQLException e)
					{
						e.printStackTrace();
						returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
						jarray.put(returnMessage);
						e.printStackTrace(new PrintWriter(errors));
						// new SendGridExample().sendEmail(jarray.toString(),
						// client_id, token, api_name, errors.toString());
						return flag;
						/*
						 * errjobj = commonmethod.getJsonStatus(501,
						 * "Database connectivity issues or timeouts",
						 * "Please try after some time"); jarray.put(errjobj);
						 * errjobj.put("ERROR",
						 * "Database Error,Please try after some time" );
						 * jarray.put(errjobj);
						 */
					}
				catch (Exception e)
					{
						e.printStackTrace();
						return flag;
						/*
						 * errjobj = commonmethod.getJsonStatus(402,
						 * "Error in processing",
						 * "Error while processing request");
						 * jarray.put(errjobj);
						 */
					}
				finally
					{
						try
							{
								if (rs != null)
									{
										rs.close();
									}
								if (statement != null)
									{
										statement.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
						// return flag;
					}
			}


		public void setApiUsageStatus(String client_id, String api_name, Connection connection)
			{
				String query = "";
				// Connection connection = null;
				ResultSet rs = null;
				Statement statement = null;
				PreparedStatement pstatement = null;
				int count = 0;
				// String client_id = "";
				String result = "";
				boolean returnValue = false;
				String current_time = null;
				try
					{
						if (connection == null || connection.isClosed())
							{
								connection = new DatabaseUtil().getConnection();
								log.info("Inside setApiUsageStatus Passed connection not found hense instantiated new");
							}
						Date currdate = new Date();
						SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
						current_time = formatter.format(currdate);
						query = "insert into participant_apiusage_rev(client_id,api_name,time) values(?,?,?)";
						pstatement = connection.prepareStatement(query);
						pstatement.setString(1, client_id);
						// pstatement.setString(2, userid);
						pstatement.setString(2, api_name);
						pstatement.setString(3, current_time);
						returnValue = pstatement.execute();
						log.info("outside setApiUsageStatus");
						connection.commit();
					}
				catch (Exception e)
					{
						e.printStackTrace();
					}
				finally
					{
						try
							{
								if (pstatement != null)
									{
										pstatement.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
			}


		public JSONArray updateTokenValidity(String client_id, String token)
			{
				Connection connection = null;
				JSONArray jarray = new JSONArray();
				Statement statement = null;
				String current_time = null;
				String exp_time = null;
				try
					{
						Date currdate = new Date();
						SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
						current_time = formatter.format(currdate);
						Calendar cal = Calendar.getInstance();
						cal.add(Calendar.MINUTE, 1440);// 24 hours in minutes :
														// 60 min = 1
														// hour
						exp_time = formatter.format(cal.getTime());
						log.info("Inside updateTokenValidity---" + current_time + "***" + exp_time);
						connection = new DatabaseUtil().getConnection();
						// update token_details with token
						String query1 = "update participant_token_details set expiry_time = '" + exp_time + "' where client_id ='" + client_id + "' AND token='" + token + "'";
						statement = connection.createStatement();
						log.info("update query:" + query1);
						statement.execute(query1);
						connection.commit();
						JSONObject jobj = new JSONObject();
						jobj.put("token", token);
						jarray.put(jobj);
					}
				catch (Exception e)
					{
						e.printStackTrace();
						log.warning("Exception in  updateTokenValidity---" + e.getMessage());
					}
				return jarray;
			}
	}
