package appathon.bluemix.service;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Logger;




@Path("/icici")
public class RestCall
	{
		private static final Logger log = Logger.getLogger(RestCall.class.getName());
		JSONObject returnMessage = new JSONObject();
		JSONObject gobj = new JSONObject();
		boolean flag;
		public int count;


		public RestCall() throws JSONException
			{
				gobj.put("code", 200);
			}


		// test
		@GET
		@Path("/test")
		@Produces
		public String callHere()
			{
				log.info("M in");
				return "Ok";
			}


		// Get Customer Details
		@GET
		@Path("/getDebitDetails")
		@Produces
		public String getmyDebitCardDetails(@QueryParam("client_id")
		String email, @QueryParam("token")
		String token, @QueryParam("custid")
		String custid) throws JSONException
			{
				
				log.info("###---- Debit Details Called ----###");
				Connection connection = null;
				Statement statement = null;
				ResultSet rs = null;
				String result = "";
				JSONArray jarray = new JSONArray();
				CommonMethod comn = new CommonMethod();
				Boolean accflag = false;
				DatabaseUtil dbUtil = new DatabaseUtil();
				log.info("User cust ID :" + custid);
				String out = "";
				log.info("Validation Details " + email + " userid is " + token);
				CommonMethod comm = new CommonMethod();
				try
					{
						if (connection == null || connection.isClosed())
							{
								log.info("Inside getmyDebitCardDetails connection open : " + connection);
								connection = dbUtil.getConnection();
							}
						flag = comm.validateClient(email, token, "GetDebitCardDetails", connection);
						if (flag)
							{
								if (comm.validateCustid(custid))
									{
										log.info("cust id validated");
										// accflag =comn.authenticateCustid("A",
										// custid, email, connection);
										accflag = comn.authenticateCustidOnly("C", custid, email, connection);
										if (accflag)
											{
												log.info("GetDebitCardDetails try");
												statement = connection.createStatement();
												rs = statement.executeQuery("select accountno,custid,Debit_card_no,cvv,exp_date,Type_of_card FROM rtl_account_master where custid =" + custid + "");
												log.info("GetDebitCardDetails query---------- select accountno,custid,Debit_card_no,cvv,exp_date,Type_of_card FROM rtl_account_master where custid ='" + custid);
												while (rs.next())
													{
														log.info("inside getmyDebitCardDetails while");
														JSONObject jobj = new JSONObject();
														if (count == 0)
															{
																jarray.put(gobj);
															}
														count++;
														jobj.put("accountno", rs.getString("accountno"));
														// jobj.put("custid",
														// rs.getString("custid").toString());
														jobj.put("Debit_card_no", rs.getString("Debit_card_no"));
														jobj.put("cvv", rs.getString("cvv"));
														jobj.put("exp_date", rs.getString("exp_date"));
														jobj.put("Type_of_card", rs.getString("Type_of_card"));
														jarray.put(jobj);
													}
												if (jarray.length() == 0)
													{
														result = "card does not exist";
														returnMessage = comm.getJsonErr(503, "", result);
													}
											}
										else
											{
												returnMessage = comm.getJsonErr(401, "User Not Authorized", "This Customer ID does not belongs to participant");
												log.info(returnMessage.toString() + " -- " + custid);
											}
									}
								else
									{
										returnMessage = comm.getJsonErr(400, "Bad request. Request parameter are not provided.", "Customer ID should be 8 Digits & can contain only Numbers");
									}
							}
						else
							{
								log.info("Token Verification Failed.");
								returnMessage = comm.getJsonErr(401, "User Not Authorized", "Access Denied");
								jarray.put(returnMessage);
							}
						if (jarray.length() == 0)
							{
								out = returnMessage.toString();
							}
						else
							{
								out = jarray.toString();
							}
					}
				catch (SQLException e)
					{
						returnMessage = comm.getJsonErr(501, "", "Database Error. Please try after some time");
						log.info(returnMessage + " -- " + custid);
						e.printStackTrace();
					}
				catch (Exception ex)
					{
						try {
							returnMessage = comm.getJsonErr(501, "", "Database Error. Please try after some time");
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						log.info(returnMessage + " -- " + custid);
						ex.printStackTrace();
					}
				finally
					{
						try
							{
								if (rs != null)
									{
										rs.close();
									}
								if (statement != null)
									{
										statement.close();
									}
								if (connection != null)
									{
										connection.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				return out;
			}


		// Authorize Using debit card details
		@GET
		@Path("/authDebitDetails")
		@Produces
		public String authMyDebitCardDetails(@QueryParam("client_id")
		String email, @QueryParam("token")
		String token, @QueryParam("custid")
		String custid, @QueryParam("debit_card_no")
		String debit_card_no, @QueryParam("cvv")
		String cvv, @QueryParam("expiry_date")
		String expiry_date) throws JSONException
			{
				log.info("###---- Authenticate Debit Details ----###");
				Connection connection = null;
				Statement statement = null;
				ResultSet rs = null;
				JSONArray jarray = new JSONArray();
				CommonMethod comn = new CommonMethod();
				Boolean accflag = false;
				DatabaseUtil dbUtil = new DatabaseUtil();
				JSONObject jobj = new JSONObject();
				String regex = "[0-9]+";
				log.info("User debit_card_no :" + debit_card_no);
				String out = "";
				log.info("Validation Details userid is " + email + " token is " + token);
				CommonMethod comm = new CommonMethod();
				try
					{
						if (connection == null || connection.isClosed())
							{
								log.info("Inside authMyDebitCardDetails connection open : " + connection);
								connection = dbUtil.getConnection();
							}
						flag = comm.validateClient(email, token, "AuthDebitCard", connection);
						if (flag)
							{
								if (comm.validateCustid(custid))
									{
										System.out.println("after custid validation ");
										log.info("cust id validated");
										accflag = comn.authenticateCustidOnly("C", custid, email, connection);
										// accflag =comn.authenticateCustid("A",
										// custid, email, connection);
										if (accflag)
											{
												System.out.println("inside accflag");
												if (debit_card_no.length() == 16 && debit_card_no.matches(regex))
													{
														log.info("debit success");
														if (cvv.length() == 3 && cvv.matches(regex))
															{
																log.info("cvv success" + cvv.length());
																boolean result1 = comm.validateDate(expiry_date);
																System.out.println(result1);
																if (result1)
																	{
																		statement = connection.createStatement();
																		rs = statement.executeQuery("select COUNT(*) from rtl_account_master where custid='" + custid + "' and Debit_card_no='" + debit_card_no + "' and cvv='" + cvv + "'and exp_date='" + expiry_date + "'");
																		System.out.println("query executed");
																		int count1 = 0;
																		if (rs.next())
																			{
																				count1 = rs.getInt(1);
																				System.out.println(count1);
																			}
																		if (count1 == 1)
																			{
																				System.out.println("inside if condition ");
																				jobj.put("response", "Authentication Successful");
																				jarray.put(jobj);
																			}
																		else
																			{
																				returnMessage = comm.getJsonErr(503, "", "card does not exist");
																				jarray.put(returnMessage);
																			}
																	}
																else
																	{
																		returnMessage = comm.getJsonErr(101, " Expiry date  is invalide ", "Wrong Expiry date Entered by Participant");
																		jarray.put(returnMessage);
																	}
															}
														else
															{
																returnMessage = comm.getJsonErr(101, " CVV Number Entered is invalide ", "cvv number should be 3 digit number");
																jarray.put(returnMessage);
															}
													}
												else
													{
														returnMessage = comm.getJsonErr(101, " Debit card Number Invalide", "This Customer Debit card number should be 16 digit number");
														jarray.put(returnMessage);
													}
											}
										else
											{
												returnMessage = comn.getJsonErr(401, "User Not Authorized", "This Customer ID does not belongs to participant");
												jarray.put(returnMessage);
											}
									}
								else
									{
										returnMessage = comm.getJsonErr(400, "Bad request. Request parameter are not provided.", "Customer ID should be 8 Digits & can contain only Numbers");
										jarray.put(returnMessage);
									}
							}
						else
							{
								log.info("Token Verification Failed.");
								returnMessage = comm.getJsonErr(401, "User Not Authorized", "Access Denied");
								jarray.put(returnMessage);
							}
						if (jarray.length() == 0)
							{
								returnMessage = comm.getJsonErr(503, "", "card does not exist");
								jarray.put(returnMessage);
								out = jarray.toString();
							}
						else
							{
								out = jarray.toString();
							}
					}
				catch (SQLException e)
					{
						returnMessage = comm.getJsonErr(501, "", "Database Error. Please try after some time");
						log.info(returnMessage + " -- " + custid);
						e.printStackTrace();
					}
				catch (Exception ex)
					{
						returnMessage = comm.getJsonErr(501, "", "Database Error. Please try after some time");
						log.info(returnMessage + " -- " + custid);
						ex.printStackTrace();
					}
				finally
					{
						try
							{
								if (rs != null)
									{
										rs.close();
									}
								if (statement != null)
									{
										statement.close();
									}
								if (connection != null)
									{
										connection.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				return out;
			}


		// Add Reward points
		@GET
		@Path("/addRewardPoints")
		@Produces
		public String addRewardPoints(@QueryParam("client_id")
		String email, @QueryParam("token")
		String token, @QueryParam("custid")
		String custid, @QueryParam("reward_point")
		String reward_point) throws JSONException
			{
				log.info("###---- Inside reward point ----###");
				Connection connection = null;
				Statement statement = null;
				ResultSet rs = null;
				String getreward = "";
				JSONArray jarray = new JSONArray();
				CommonMethod comn = new CommonMethod();
				Boolean accflag = false;
				DatabaseUtil dbUtil = new DatabaseUtil();
				log.info("User custid :" + custid);
				String out = "";
				log.info("Validation Details userid is " + email + " token is " + token);
				CommonMethod comm = new CommonMethod();
				try
					{
						if (connection == null || connection.isClosed())
							{
								log.info("Inside addRewardPoints connection open : " + connection);
								connection = dbUtil.getConnection();
							}
						flag = comm.validateClient(email, token, "addRewardPoints", connection);
						if (flag)
							{
								if (comm.validateCustid(custid))
									{
										if (comm.validateRewardPoint(reward_point))
											{
												log.info("cust id validated");
												accflag = comn.authenticateCustidOnly("C", custid, email, connection);
												// accflag
												// =comn.authenticateCustid("A",
												// custid, email, connection);
												if (accflag)
													{
														log.info("addRewardPoints try");
														statement = connection.createStatement();
														rs = statement.executeQuery("select Reward_point from rtl_account_master where custid=" + custid + "");
														if (rs.next())
															{
																getreward = rs.getString("Reward_point");
																int reward = Integer.parseInt(getreward);
																log.info(reward + "");
																int new_reward = Integer.parseInt(reward_point);
																log.info(new_reward + "");
																int addition = reward + new_reward;
																log.info("add reward point --------update rtl_account_master set Reward_point=" + addition + " where custid=" + custid);
																int res = statement.executeUpdate("update rtl_account_master set Reward_point=" + addition + " where custid=" + custid + "");
																
																if (res != 0)
																	{
																		JSONObject jobj = new JSONObject();
																		jobj.put("response", "Reward Point Added Successfully");
																		jarray.put(gobj);
																		jarray.put(jobj);
																																			}
															}
														else
															{
																returnMessage = comm.getJsonErr(401, "User Not Authorized", "This Customer ID does not belongs to participant");
																log.info(returnMessage.toString() + " -- " + custid);
																jarray.put(returnMessage);
															}
													}
												else
													{
														returnMessage = comm.getJsonErr(401, "User Not Authorized", "This Customer ID does not belongs to participant");
														log.info(returnMessage.toString() + " -- " + custid);
														jarray.put(returnMessage);
													}
											}
										else
											{
												returnMessage = comm.getJsonErr(102, "Bad request. Request parameter are not provided.", "Reward point should not be 0 and length should not be more than 5 Digits & can contain only Numbers");
												jarray.put(returnMessage);
											}
									}
								else
									{
										returnMessage = comm.getJsonErr(400, "Bad request. Request parameter are not provided.", "Customer ID should be 8 Digits & can contain only Numbers");
										jarray.put(returnMessage);
									}
							}
						else
							{
								log.info("Token Verification Failed.");
								returnMessage = comm.getJsonErr(401, "User Not Authorized", "Access Denied");
								jarray.put(returnMessage);
							}
					}
				catch (SQLException e)
					{
						returnMessage = comm.getJsonErr(501, "", "Database Error. Please try after some time");
						log.info(returnMessage + " -- " + custid);
						e.printStackTrace();
						jarray.put(returnMessage);
					}
				catch (Exception ex)
					{
						returnMessage = comm.getJsonErr(501, "", "Database Error. Please try after some time");
						log.info(returnMessage + " -- " + custid);
						jarray.put(returnMessage);
						ex.printStackTrace();
					}
				finally
					{
						try
							{
								if (rs != null)
									{
										rs.close();
									}
								if (statement != null)
									{
										statement.close();
									}
								if (connection != null)
									{
										connection.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				out = jarray.toString();
				return out;
			}


		// Use Reward point for bill payment
		@GET
		@Path("/payBillViaReward")
		@Produces
		public String payBillViaDebit(@QueryParam("client_id")
		String email, @QueryParam("token")
		String token, @QueryParam("custid")
		String custid, @QueryParam("billerType")
		String billerType, @QueryParam("billerName")
		String billerName, @QueryParam("consumer_number")
		String consumer_number, @QueryParam("reward_point")
		String reward_point) throws JSONException
			{
				log.info("###---- Inside payBillViaReward point ----###");
				Connection connection = null;
				Statement statement = null;
				PreparedStatement pstmt = null;
				ResultSet rs = null;
				String acc_no = "";
				String regex = "[0-9]+";
				JSONArray jarray = new JSONArray();
				CommonMethod comn = new CommonMethod();
				Boolean accflag = false;
				DatabaseUtil dbUtil = new DatabaseUtil();
				Integer cnt = 0;
				log.info("User custid :" + custid);
				String out = "";
				log.info("Validation Details userid is " + email + " token is " + token);
				String BillerType = billerType.toUpperCase();
				String BillerName = billerName.toUpperCase();
				CommonMethod comm = new CommonMethod();
				JSONObject jobj = new JSONObject();
				try
					{
						if (connection == null || connection.isClosed())
							{
								log.info("Inside payBillViaReward connection open : " + connection);
								connection = dbUtil.getConnection();
							}
						flag = comm.validateClient(email, token, "payBillViaReward", connection);
						if (flag)
							{
								if (comm.validateCustid(custid))
									{
										if (reward_point.matches(regex) && reward_point.length() > 0)
											{
												log.info("cust id validated payBillViaReward");
												accflag = comn.authenticateCustidOnly("C", custid, email, connection);
												// accflag
												// =comn.authenticateCustid("A",
												// custid, email, connection);
												if (accflag)
													{
														try
															{
																statement = connection.createStatement();
																log.info("select count(*) from rtl_biller_master where upper(biller_type)= '" + BillerType + "' and upper(biller_name) ='" + BillerName + "'");
																rs = statement.executeQuery("select count(*) from rtl_biller_master where upper(biller_type) = '" + BillerType + "' and upper(biller_name) = '" + BillerName + "'");
																if (rs.next())
																	{
																		cnt = rs.getInt(1);
																	}
															}
														catch (SQLException e)
															{
																e.printStackTrace();
															}
														finally
															{
																rs.close();
															}
														if (cnt > 0)
															{
																Boolean result = false;
																System.out.println("inside accflag");
																result = comm.validatecunsumerNo(BillerType, consumer_number);
																System.out.println("result" + result);
																if (result)
																	{
																		log.info("payBillViaReward try");
																		rs = statement.executeQuery("select accountno,Reward_point from rtl_account_master where Reward_point>=" + reward_point + " and custid=" + custid + "");
																		if (rs.next())
																			{
																				connection.setAutoCommit(false);
																				String new_reward_point = rs.getString("Reward_point");
																				acc_no = rs.getString("accountno");
																				Integer user_reward_point = Integer.parseInt(reward_point);
																				Integer mod = Integer.parseInt(reward_point) % 3;
																				log.info("mod=" + mod);
																				
																				user_reward_point = user_reward_point - mod;
																				Integer amount = user_reward_point / 3;
																				String insertBillerTrans = "insert into biller_transaction_master (accountno,custid,amount_transfer, biller_name, biller_detail, consumer_no) values (?,?,?,?,?,?)";
																				pstmt = connection.prepareStatement(insertBillerTrans);
																				pstmt.setString(1, acc_no);
																				pstmt.setString(2, custid);
																				pstmt.setString(3, amount.toString());
																				pstmt.setString(4, billerName);
																				pstmt.setString(5, billerType);
																				pstmt.setString(6, consumer_number);
																				pstmt.execute();
																				int database_reward_point = Integer.parseInt(new_reward_point);
																				int to_be_cut = Integer.parseInt(reward_point);
																				int value = (database_reward_point - to_be_cut) + mod;
																				log.info("value" + value);
																				String new_update = "update rtl_account_master set Reward_point=" + value + " where CUSTID=" + custid + "";
																				int count = statement.executeUpdate(new_update);
																				if (count > 0)
																					{
																						connection.commit();
																						jobj.put("response", "Bill Paid successfully");
																						jarray.put(gobj);
																						jarray.put(jobj);
																					}
																			}
																		else
																			{
																				returnMessage = comm.getJsonErr(401, "Insufficient Reward Points", "This Customer  does not have sufficient Reward points");
																				log.info(returnMessage.toString() + " -- " + custid);
																				jarray.put(returnMessage);
																			}
																	}
																else
																	{
																		returnMessage = comm.getJsonErr(401, "Invalid Request", "Invalide Consumer Number length for Biller Type " + BillerType);
																		log.info(returnMessage.toString() + " -- " + custid);
																		jarray.put(returnMessage);
																	}
															}
														else
															{
																returnMessage = comm.getJsonErr(401, "Invalid Request", "Request Data does not exist in the System.");
																log.info(returnMessage.toString() + " -- " + custid);
																jarray.put(returnMessage);
															}
													}
												else
													{
														returnMessage = comm.getJsonErr(401, "User Not Authorized", "This Customer ID does not belongs to participant");
														log.info(returnMessage.toString() + " -- " + custid);
														jarray.put(returnMessage);
													}
											}
										else
											{
												returnMessage = comm.getJsonErr(102, "Bad request. Request parameter are not provided.", "Reward point should not be 0 and should contain only Numbers");
												jarray.put(returnMessage);
											}
									}
								else
									{
										returnMessage = comm.getJsonErr(400, "Bad request. Request parameter are not provided.", "Customer ID should be 8 Digits & can contain only Numbers");
										jarray.put(returnMessage);
									}
							}
						else
							{
								log.info("Token Verification Failed.");
								returnMessage = comm.getJsonErr(401, "User Not Authorized", "Access Denied");
								jarray.put(returnMessage);
							}
					}
				catch (SQLException e)
					{
						returnMessage = comm.getJsonErr(501, "", "Database Error. Please try after some time");
						log.info(returnMessage + " -- " + custid);
						e.printStackTrace();
						jarray.put(returnMessage);
					}
				catch (Exception ex)
					{
						returnMessage = comm.getJsonErr(501, "", "Database Error. Please try after some time");
						log.info(returnMessage + " -- " + custid);
						jarray.put(returnMessage);
						ex.printStackTrace();
					}
				finally
					{
						try
							{
								if (rs != null)
									{
										rs.close();
									}
								if (statement != null)
									{
										statement.close();
									}
								if (connection != null)
									{
										connection.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				out = jarray.toString();
				return out;
			}


		// Reedeem Reward Points
		@GET
		@Path("/redeemPoints")
		@Produces
		public String redeemPoints(@QueryParam("client_id")
		String email, @QueryParam("token")
		String token, @QueryParam("custid")
		String custid, @QueryParam("reward_point")
		String reward_point) throws JSONException
			{
				Connection connection = null;
				Statement statement = null;
				ResultSet rs = null;
				CommonMethod comn = new CommonMethod();
				// String result = "";
				DatabaseUtil dbUtil = new DatabaseUtil();
				JSONObject jobj = new JSONObject();
				JSONArray jarray = new JSONArray();
				CommonMethod comm = new CommonMethod();
				String regex = "[0-9]+";
				boolean flag = false;
				boolean accflag = false;
				int new_value;
				String acc_no, getRewardPoint, wallet_Bal = "";
				try
					{
						if (connection == null || connection.isClosed())
							{
								log.info("Inside account summary connection open : " + connection);
								connection = dbUtil.getConnection();
							}
						flag = comm.validateClient(email, token, "redeemPoints", connection);
						if (flag)
							{
								if (!custid.equals(""))
									{
										if (comm.validateCustid(custid))
											{
												if (reward_point.matches(regex) && reward_point.length() > 0)
													{
														accflag = comn.authenticateCustidOnly("A", custid, email, connection);
														// accflag
														// =comn.authenticateCustid("A",
														// custid, email,
														// connection);
														statement = connection.createStatement();
														if (accflag)
															{
																log.info(reward_point);
																rs = statement.executeQuery("select accountno,Reward_point,wallet_balance from rtl_account_master where Reward_point >=" + reward_point + " and custid=" + custid + "");
																if (rs.next())
																	{
																		acc_no = rs.getString("accountno");
																		getRewardPoint = rs.getString("Reward_point");
																		wallet_Bal = rs.getString("wallet_balance");
																		log.info("account no =" + acc_no + "  " + "getRewardPoint = " + getRewardPoint + "wallet_balance =" + wallet_Bal);
																		Integer mod = Integer.parseInt(reward_point) % 3;
																		int database_reward_point = Integer.parseInt(getRewardPoint);
																		int to_be_cut = Integer.parseInt(reward_point);
																		int value = (database_reward_point - to_be_cut) + mod;
																		int wallet_balance = Integer.parseInt(wallet_Bal);
																		new_value = Math.round(to_be_cut / 3);
																		int updated_wallet_bal = wallet_balance + new_value;
																		String new_update = "update rtl_account_master set Reward_point=" + value + ", wallet_balance =" + updated_wallet_bal + " where CUSTID=" + custid + "";
																		log.info("new query------------" + new_update);
																		int count = statement.executeUpdate(new_update);
																		if (count > 0)
																			{
																				jobj.put("code", 200);
																				jobj.put("response", "Point redeem successfully,Rs. " + new_value + " added to your wallet account,New  Wallet balance is Rs. " + updated_wallet_bal);
																				jarray.put(jobj);
																			}
																	}
																else
																	{
																		returnMessage = comm.getJsonErr(401, "Insufficient Reward Points", "This Customer  does not have sufficient Reward points");
																		log.info(returnMessage.toString() + " -- " + custid);
																		jarray.put(returnMessage);
																	}
															}
														else
															{
																returnMessage = comm.getJsonErr(401, "User Not Authorized", "This Customer ID does not belongs to participant");
															}
													}
												else
													{
														returnMessage = comm.getJsonErr(102, "Bad request. Request parameter are not provided.", "Reward point should not be 0 and should contain only Numbers");
														jarray.put(returnMessage);
													}
											}
										else
											{
												returnMessage = comm.getJsonErr(400, "Bad request. Request parameter are not provided.", "Customer ID should be 8 Digits & can contain only Numbers");
											}
									}
								else
									{
										returnMessage = comm.getJsonErr(400, "Bad request. Request parameter are not provided.", "Customer ID  cannot be null");
									}
							}
						else
							{
								log.info("Token Verification Failed.");
								returnMessage = comm.getJsonErr(401, "User Not Authorized", "Access Denied");
								jarray.put(returnMessage);
							}
						if (jarray.length() == 0)
							{
								jarray.put(returnMessage);
							}
					}
				catch (SQLException e)
					{
						returnMessage = comm.getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
						e.printStackTrace();
						log.info("Errorrr : " + e);
						// returnMessage =
						// getJsonErr(400,"","Database Error. Please try after
						// some time");
					}
				finally
					{
						try
							{
								if (rs != null)
									{
										rs.close();
									}
								if (statement != null)
									{
										statement.close();
									}
								if (connection != null)
									{
										connection.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				log.info("Client_id : " + email);
				log.info("Response : " + jarray.toString());
				return jarray.toString();
			}


/*		// place equity cash Order
		@GET
		@Path("/PlaceEquityCashOrder")
		@Produces
		public String PlaceEquityCashOrder(@QueryParam("client_id")
		String email, @QueryParam("token")
		String token, @QueryParam("accountno")
		String accountno)
			{
				Connection connection = null;
				Statement statement = null;
				ResultSet rs = null;
				CommonMethod comn = new CommonMethod();
				// String result = "";
				DatabaseUtil dbUtil = new DatabaseUtil();
				JSONObject jobj = new JSONObject();
				JSONArray jarray = new JSONArray();
				CommonMethod comm = new CommonMethod();
				boolean flag = false;
				String acc_no;
				try
					{
						if (connection == null || connection.isClosed())
							{
								log.info("Inside account summary connection open : " + connection);
								connection = dbUtil.getConnection();
							}
						flag = comm.validateClient(email, token, "PlaceEquityCashOrder", connection);
						if (flag)
							{
								if (!accountno.equals(""))
									{
										if (comm.validateAccountno(accountno))
											{
												System.out.println(accountno);
												System.out.println("query------------select accountno from rtl_account_master where accountno ='"+accountno+"'");
												statement = connection.createStatement();
												rs = statement.executeQuery("select accountno from rtl_account_master where accountno='"+accountno+"'");

												if (rs.next())
													{
														System.out.println("Inside While");
														acc_no = rs.getString("accountno");
														System.out.println("account no =" + acc_no);
														int int_accountno = Integer.parseInt(acc_no.substring(11));
														System.out.println("account no substring =" + int_accountno);
														
														
														 if ( int_accountno % 4 == 1 ){
															 System.out.println("You entered an 1 number.");
																jobj.put("code", 200);
																jobj.put("accountno", acc_no);
																jobj.put("Allocation in Equity", "2,64,96,181.13");
																jobj.put("Debt", "1,22,917.31");
																jobj.put("Cash/Liquid and Gold", "8,526.24");
																jobj.put("Total", "2,66,27,624.68");
																jarray.add(jobj);
													      }
													      if ( int_accountno % 4 == 2 ){
													    	  System.out.println("You entered an 2 number.");
																jobj.put("code", 200);
																jobj.put("accountno", acc_no);
																jobj.put("Allocation in Equity", "1,218.35");
																jobj.put("Debt", "0");
																jobj.put("Cash/Liquid and Gold", "855.75");
																jobj.put("Total", "2,074.10");
																jarray.add(jobj);
													      }
													      if ( int_accountno % 4 == 3 ){
													    	  System.out.println("You entered an 3 number.");
																jobj.put("code", 200);
																jobj.put("accountno", acc_no);
																jobj.put("Allocation in Equity", "526048308.48");
																jobj.put("Debt", "34741422.87");
																jobj.put("Cash/Liquid and Gold", "70872502.65");
																jobj.put("Total", "631662234");
																jarray.add(jobj);
													      }
													      else {
													    	  System.out.println("You entered an 4 number.");
													    	  jobj.put("code", 200);
																jobj.put("accountno", acc_no);
																jobj.put("Allocation in Equity", "286936081.69");
																jobj.put("Debt", "29237118.71");
																jobj.put("Cash/Liquid and Gold", "58661654.85");
																jobj.put("Total", "374834855.25");
																jarray.add(jobj);
													      }
													}
												else
													{
														returnMessage = comm.getJsonErr(503, "", "This Account No ID does not belongs to participant");
													}
											}
										else
											{
												returnMessage = comm.getJsonErr(401, "User Not Authorized", "This Account No does not belongs to participant");
											}
									}
							}
						else
							{
								returnMessage = comm.getJsonErr(400, "Bad request. Request parameter are not provided.", "Account no should be 16 Digits & can contain only Numbers");
							}
							{
								System.out.println("Token Verification Failed.");
								returnMessage = comm.getJsonErr(401, "User Not Authorized", "Access Denied");
								jarray.add(returnMessage);
							}
						if (jarray.size() == 0)
							{
								jarray.add(returnMessage);
							}
					}
				catch (SQLException e)
					{
						returnMessage = comm.getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
						e.printStackTrace();
						System.out.println("Errorrr : " + e);
						// returnMessage =
						// getJsonErr(400,"","Database Error. Please try after
						// some time");
					}
				finally
					{
						try
							{
								if (rs != null)
									{
										rs.close();
									}
								if (statement != null)
									{
										statement.close();
									}
								if (connection != null)
									{
										connection.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				System.out.println("Client_id : " + email);
				System.out.println("Response : " + jarray.toString());
				return jarray.toString();
			}*/
	}
