package appathon.service;
/*import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/corporate_banking/*")
public class BankingApplication extends Application {

}*/