package appathon.service;


import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
/*import java.sql.Time;
import java.sql.Timestamp;*/
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.logging.Logger;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


@Path("/icici")
public class RestCall {

	private static final Logger LOGGER = Logger.getLogger(RestCall.class.getName());

	JSONObject returnMessage;
	JSONObject successObj;
	public RestCall() throws JSONException{
		successObj = new JSONObject();	
		successObj.put("code", 200);
	}
	@GET
	@Path("/test")
	@Produces
	public String Test()
	{
		return "ok";
	}
	//url:/corporate_banking/icicibank/authenticate_client?client_id=sachin@gmail.com&password=sachin
	@GET
	@Path("/authenticate_client")
	@Produces
	public String authenticateClient(@Context UriInfo uriInfo,@QueryParam("client_id") String client_id,@QueryParam("password") String password) throws JSONException {
		Connection connection = null;
		CommonMethod commonmethod = new CommonMethod();
		JSONObject errjobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		ResultSet rs = null;
		ResultSet rs1 = null;
		Statement statement = null;
		int count = 0;
		//		String client_id = "";
		String result = "";
		String query1  = "";
		String query2  = "";
		String token = "";
		DatabaseUtil util = new DatabaseUtil();

		LOGGER.info("Inside authenticateClient(..) method client_id is "+client_id+" password is "+password);
		try {
			HashSet<String> set = new HashSet<String>();
			set.add("client_id");
			set.add("password");
			String data=commonmethod.keyvalidation(uriInfo, set);
			if(data.equalsIgnoreCase("OK"))
			{
			if(client_id.equalsIgnoreCase("appaccount@icici.com"))
			{
				JSONObject jobj = new JSONObject();
				jobj.put("token", "4ca4839b6db4");
				jarray.put(jobj);
				//result=jarray.toString();
			}
			else
				//				select client_id,password from participant_master where LOWER(client_id)=LOWER('dev.khp@gmail.com') and password='ICIC2877'
			{
				if(connection == null || connection.isClosed()){
					connection = util.getConnection();
					System.out.println("In API authenticateClient() Method open connection:"+connection);
				}
				if (!client_id.equals("")) {
					if(!password.equals("")){
						query1 = "select client_id,password from participant_master where LOWER(client_id)=LOWER('"+client_id+"') and password='"+password+"'";
						LOGGER.info("Inside authenticateClient(..) 1st query-"+query1);
						LOGGER.info("");
						statement = connection.createStatement();
						rs = statement.executeQuery(query1);
						if (rs.next()) {
							token = commonmethod.generateToken();
							System.out.println("TOOOOOOOKKKKENNNNN"+token);
							client_id = rs.getString("client_id");
						}

						if(!client_id.equalsIgnoreCase("")){
							query2 = "select client_id from participant_token_details where client_id='"+client_id+"'";
							LOGGER.info("query2-"+query2);
							rs1 = statement.executeQuery(query2);
							if (rs1.next()) {
								jarray = updateToken(client_id,token,connection);
							}
							else{
								jarray = insertToken(client_id,token,connection);	
							}
							setApiUsageStatus(client_id, "authenticate_client",connection);
							if(jarray.length() == 0){
								LOGGER.info("Inside authenticateClient(..) method ---> NO record Found");
								errjobj = commonmethod.getJsonStatus(503, "No Record Found", "NO Record Found");
								jarray.put(errjobj);
								errjobj.put("ERROR","NO data found in database");
								jarray.put(errjobj);
							}
						}

					}
					else{
						LOGGER.info("Inside authenticateClient(..) method ---> password input is found blank");
						errjobj = commonmethod.getJsonStatus(400, "Bad request", "Password should not be blank");
						jarray.put(errjobj);
						errjobj.put("ERROR", "User Id cannot be blank");
						jarray.put(errjobj);
					}
				}
				else{
					LOGGER.info("Inside authenticateClient(..) method ---> client_id id input is not set");
					errjobj = commonmethod.getJsonStatus(400, "Bad request", "client_id Id should not be blank");
					jarray.put(errjobj);
					errjobj.put("ERROR", "Corp Id cannot be blank");
					jarray.put(errjobj);
				}

			}
		}else
			{
			errjobj.put("code", 454);
			errjobj.put("description","User Authentication Fail");
			errjobj.put("message",data);
			jarray.put(errjobj);
			System.out.println(jarray.toString());
			return jarray.toString();
			}
		}
			
			catch (SQLException e) {
			e.printStackTrace();
			errjobj = commonmethod.getJsonStatus(501, "Database connectivity issues or timeouts", "Please try after some time");
			jarray.put(errjobj);
			errjobj.put("ERROR", "Database Error,Please try after some time");
			jarray.put(errjobj);
		}
		catch(Exception e){
			e.printStackTrace();
			errjobj = commonmethod.getJsonStatus(402, "Error in processing", "Error while processing request");
			jarray.put(errjobj);
		}
		finally{
			if(rs != null){
				try{
					rs.close();
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}
			if(rs1 != null){
				try{
					rs1.close();
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}
			if(statement != null){
				try{
					statement.close();
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}
			if(connection != null){
				try{
					connection.close();
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}

		}

		result = jarray.toString();
		return result;
	}


	//url:/corporate_banking/icicibank/invalidateToken?client_id=test@abc.com&token=test

	@GET
	@Path("/invalidateToken")
	@Produces
	public String logoutClient(@Context UriInfo uriInfo,@QueryParam("client_id") String client_id,@QueryParam("token") String token) throws JSONException {
		Connection connection = null;
		CommonMethod commonmethod = new CommonMethod();
		JSONObject errjobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		ResultSet rs = null;
		Statement statement = null;
		int count = 0;
		String result = "";
		String query  = "";
		String regex = "^[a-zA-Z0-9]*$";
		boolean flag = false;
		boolean executeFlag = false;
		LOGGER.info("Inside logoutClient(..) method client_id is "+client_id+" token is "+token);

		try {
			flag = validateClientOnly(client_id, token,"invalidateToken", connection);
			System.out.println("token flag-"+flag);
			HashMap hm = new HashMap<>();
			HashSet<String> set = new HashSet<String>();
			set.add("client_id");
			set.add("token");
			String data=commonmethod.keyvalidation(uriInfo,set);
			//String data=commonmethod.Func1(uriInfo,"client_id","token");
			if(data.equalsIgnoreCase("OK"))
			{
			if(flag){
				//				if(connection == null || connection.isClosed()){
				connection = new DatabaseUtil().getConnection();
				//				}
				if (!client_id.equals("")) {
					if(!token.equals("")){
						query = "update participant_token_details set token = '',expiry_time = '' where LOWER(client_id) =LOWER('"+client_id+"') and token ='"+token+"'";
						LOGGER.info("REMOVE____________________________________QUERY________"+query);
						statement = connection.createStatement();
						executeFlag = statement.execute(query);
						System.out.println("USER LOGOUT:"+executeFlag);
						JSONObject jobj = new JSONObject();
						jobj.put("Message", "User logout successfully");
						jarray.put(jobj);
						connection.commit();

					}
					else{
						LOGGER.info("Inside logoutClient(..) method ---> Invalid parameters");
						errjobj = commonmethod.getJsonStatus(400, "Bad request", "token should not be blank");
						jarray.put(errjobj);
					}

				}
				else{
					LOGGER.info("Inside logoutClient(..) method ---> User id input is found blank");
					errjobj = commonmethod.getJsonStatus(400, "Bad request", "client_id id should not be blank");
					jarray.put(errjobj);
					/*errjobj.put("ERROR", "User Id cannot be blank");
						jarray.put(errjobj);*/
				}
			}
			else{
				LOGGER.info("Inside logoutClient(..) method ---> ");
				errjobj = commonmethod.getJsonStatus(401, "User Not Authorized", "Access Denied");
				jarray.put(errjobj);
			}
		} 
			else
			{
				errjobj.put("code", 454);
				errjobj.put("description","User Authentication Fail");
				errjobj.put("message",data);
				jarray.put(errjobj);
				System.out.println(jarray.toString());
				return jarray.toString();
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
			errjobj = commonmethod.getJsonStatus(501, "Database connectivity issues or timeouts", "Please try after some time");
			jarray.put(errjobj);
			/*errjobj.put("ERROR", "Database Error,Please try after some time");
				jarray.put(errjobj);*/
		}
		catch(Exception e){
			e.printStackTrace();
			errjobj = commonmethod.getJsonStatus(402, "Error in processing", "Error while processing request");
			jarray.put(errjobj);
		}
		/*	finally{
			try{
				statement.close();
				connection.close();
				statement = null;
				connection = null;
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}*/
		result = jarray.toString();
		return result;
	}

	public JSONArray updateToken(String client_id,String token,Connection connection){
		JSONArray jarray = new JSONArray();
		Statement statement = null;
		String current_time = null;
		String exp_time = null;
		DatabaseUtil util = new DatabaseUtil();
		try{
			Date currdate = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
			current_time = formatter.format(currdate);

			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.MINUTE, 86400);//60 days  in minutes :  60 min = 1 hour
			//			exp_time = formatter.format(cal.getTime());
			exp_time = "2018-05-25 00:00:22";//hard coded expiry time till 5 may night 12'o clock 

			LOGGER.info("Inside updateToken---"+current_time+"***"+exp_time);
			LOGGER.info("Inside updatetoken="+token);

			if(connection == null || connection.isClosed()){
				connection = util.getConnection();
			}
			//update token_details with token
			String query1 = "update participant_token_details set token ='"+token+"' ,last_login_time = '"+current_time+"' ,expiry_time = '"+exp_time+"' where LOWER(client_id) =LOWER('"+client_id+"')";
			statement = connection.createStatement();
			System.out.println("update query:"+query1);
			statement.execute(query1);
			connection.commit();
			JSONObject jobj = new JSONObject();
			jobj.put("token", token);
			jarray.put(jobj);
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(statement != null){
					statement.close();
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		return jarray;
	}

	public JSONArray insertToken(String client_id,String token,Connection connection){
		//		Connection connection = null;
		JSONArray jarray = new JSONArray();
		PreparedStatement pstatement = null;
		String current_time = null;
		String exp_time = null;
		DatabaseUtil util = new DatabaseUtil();
		try{
			Date currdate = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
			current_time = formatter.format(currdate);

			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.MINUTE, 86400);//24 hours in minutes :  60 min = 1 hour
			//			exp_time = formatter.format(cal.getTime());
			exp_time = "2018-05-25 00:00:22";//hard coded expiry time till 5 may night 12'o clock

			if(connection == null || connection.isClosed()){
				connection = util.getConnection();
			}
			LOGGER.info("insertToken---");
			LOGGER.info("Inside insertToken="+token);
			//update token_details with token
			String query1 = "insert into participant_token_details(client_id,custid,token,last_login_time,expiry_time) values(?,?,?,?,?)";
			pstatement = connection.prepareStatement(query1);
			pstatement.setString(1,client_id);
			pstatement.setString(2, "cust01");
			pstatement.setString(3, token);
			pstatement.setString(4, current_time);
			pstatement.setString(5, exp_time);
			System.out.println("insert query:"+query1);
			pstatement.executeUpdate();
			connection.commit();
			JSONObject jobj = new JSONObject();
			jobj.put("token", token);
			jarray.put(jobj);
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				pstatement.close();
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		return jarray;
	}

	public JSONArray updateTokenValidity(String client_id,String token){
		Connection connection = null;
		JSONArray jarray = new JSONArray();
		Statement statement = null;
		String current_time = null;
		String exp_time = null;

		try{
			Date currdate = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
			current_time = formatter.format(currdate);

			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.MINUTE, 86400);//24 hours in minutes :  60 min = 1 hour
			exp_time = formatter.format(cal.getTime());

			LOGGER.info("Inside updateTokenValidity---"+current_time+"***"+exp_time);

			connection = new DatabaseUtil().getConnection();
			//update token_details with token
			String query1 = "update participant_token_details set expiry_time = '"+exp_time+"' where client_id ='"+client_id+"' AND token='"+token+"'";
			statement = connection.createStatement();
			System.out.println("update query:"+query1);
			statement.execute(query1);
			connection.commit();
			JSONObject jobj = new JSONObject();
			jobj.put("token", token);
			jarray.put(jobj);
		}
		catch(Exception e){
			e.printStackTrace();
			LOGGER.warning("Exception in  updateTokenValidity---"+e.getMessage());
		}
		return jarray;
	}


	public boolean validateClientOnly(String client_id,String token,String api_name,Connection connection) throws JSONException {
		StringWriter errors = new StringWriter();
		CommonMethod commonmethod = new CommonMethod();
		JSONObject errjobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		ResultSet rs = null;
		Statement statement = null;
		PreparedStatement pstatement = null;
		int count = 0;
		//		String client_id = "";
		String result = "";
		String query  = "";
		boolean flag = false;
		String current_time = null;
		LOGGER.info("Inside validateClientOnly(..) method client_id is "+client_id+" token is "+token);
		try {
			if(connection == null || connection.isClosed()){
				connection = new DatabaseUtil().getConnection();
			}
			Date currdate = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
			current_time = formatter.format(currdate);
			//			}
			if (!client_id.equals("")) {
				if(!token.equals("")){
					//					query = "select client_id,token from participant_token_details where client_id='"+client_id+"' and token='"+token+"' and (SELECT MINUTE(expiry_time) - MINUTE('"+current_time+"') FROM SYSIBM.SYSDUMMY1) > 0";
					//query = "select client_id,token from participant_token_details where LOWER(client_id)=LOWER('"+client_id+"') and token='"+token+"' and (SELECT timestampdiff (4, char(timestamp(p.expiry_time)-timestamp('"+current_time+"'))) FROM fnpbbmor.participant_token_details p, SYSIBM.SYSDUMMY1 where LOWER(p.client_id)=LOWER('"+client_id+"') and p.token='"+token+"') >0";
					query="select client_id,token from participant_token_details "+
							"where client_id='"+client_id +"' and token = '"+token+"' and  EXPIRY_TIME>CURRENT_TIMESTAMP";
					LOGGER.info("VALIDATE_____________"+query);
					statement = connection.createStatement();
					rs = statement.executeQuery(query);

					while (rs.next()) {
						System.out.println("****************************************************");
						JSONObject jobj = new JSONObject();
						jobj.put("client_id", rs.getString(1));
						jobj.put("token", rs.getString(2));
						jarray.put(jobj);
					}
					if(jarray.length() != 0){
						flag = true;
						//
						//						updateTokenValidity(client_id, token);
						setApiUsageStatus(client_id, api_name,connection);
					}
					else{
						//Token invalid
						System.out.println("Invalid Token");
						errjobj = commonmethod.getJsonStatus(401, "User Not Authorized", "Access Denied");
						jarray.put(errjobj);
						//new SendGridExample().sendEmail(jarray.toString(),client_id,token,api_name,"Invalid Token");//Email sending
					}
					System.out.println("validate-"+flag);
					return flag;
				}
				else{
					LOGGER.info("Inside validateClientOnly(..) method ---> token input is found blank");
					errjobj = commonmethod.getJsonStatus(400, "Bad request", "Token should not be blank");
					jarray.put(errjobj);
					errjobj.put("ERROR", "User Id cannot be blank");
					jarray.put(errjobj);
					return flag;
				}
			}
			else{
				LOGGER.info("Inside validateClientOnly(..) method ---> client_id id input is not set");
				errjobj = commonmethod.getJsonStatus(400, "Bad request", "client_id Id should not be blank");
				jarray.put(errjobj);
				errjobj.put("ERROR", "client_id Id cannot be blank");
				jarray.put(errjobj);
				return flag;
			}
		} catch (SQLException e) {
			errjobj = commonmethod.getJsonStatus(501, "Database connectivity issues or timeouts", "Please try after some time");
			jarray.put(errjobj);
			e.printStackTrace((new PrintWriter(errors)));
			System.out.println("SQL excetn catched");
			//new SendGridExample().sendEmail(jarray.toString(),client_id,token,api_name,errors.toString());
			return flag;
		}
		catch(Exception e){
			e.printStackTrace();
			errjobj = commonmethod.getJsonStatus(402, "Error in processing", "Error while processing request");
			jarray.put(errjobj);
			return flag;
		}
		finally{
			try{
				if(rs != null){
					rs.close();	
				}
				if(statement != null){
					statement.close();
				}

			}
			catch(Exception e){
				e.printStackTrace();
			}
			//			return flag;
		}
	}




	public boolean validateClient(String client_id,String token,String api_name,String queryStr,Connection connection) throws JSONException {
		//		Connection connection = null;
		StringWriter errors = new StringWriter();
		JSONArray jarray = new JSONArray();
		ResultSet rs = null;
		ResultSet rs2 = null;
		Statement statement = null;
		String query  = "";
		boolean flag = false;
		boolean mapflag = false;
		String current_time = null;
		CommonMethod commonmethod = new CommonMethod();
		JSONObject errjobj = new JSONObject();
		LOGGER.info("Inside validateClient(..) method client_id is "+client_id+" token is "+token);
		try {
			if(connection == null || connection.isClosed()){
				connection = new DatabaseUtil().getConnection();
				System.out.println("In validateClient Method open connection:"+connection);
			}
			Date currdate = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
			current_time = formatter.format(currdate);
			if (!client_id.equals("")) {
				if(!token.equals("")){
					//					query = "select client_id,token from participant_token_details where client_id='"+client_id+"' and token='"+token+"' and (SELECT MINUTE(expiry_time) - MINUTE('"+current_time+"') FROM SYSIBM.SYSDUMMY1) > 0";
					//query = "select client_id,token from fnpbbmor.participant_token_details where LOWER(client_id)=LOWER('"+client_id+"') and token='"+token+"' and (SELECT timestampdiff (4, char(timestamp(p.expiry_time)-timestamp('"+current_time+"'))) FROM fnpbbmor.participant_token_details p, SYSIBM.SYSDUMMY1 where LOWER(p.client_id)=LOWER('"+client_id+"') and p.token='"+token+"') >0";
					query="select client_id,token from participant_token_details "+
							"where client_id='"+client_id +"' and token = '"+token+"' and  EXPIRY_TIME>CURRENT_TIMESTAMP";
					LOGGER.info("VALIDATE_____________"+query);
					statement = connection.createStatement();
					rs = statement.executeQuery(query);

					while (rs.next()) {
						System.out.println("****************************************************");
						JSONObject jobj = new JSONObject();
						jobj.put("client_id", rs.getString(1));
						jobj.put("token", rs.getString(2));
						jarray.put(jobj);

						//after succesful token validation participant validation starts
						System.out.println("MYCODE QUERY::"+queryStr);
						statement = connection.createStatement();
						rs2 = statement.executeQuery(queryStr);
						if(rs2.next()){
							mapflag = true;
						}
					}
					if(jarray.length() != 0 && mapflag){
						flag = true;

						//updateTokenValidity(client_id, token);
						setApiUsageStatus(client_id, api_name,connection);
						System.out.println("mapflag---"+mapflag);
					}
					else{
						//Token invalid
						System.out.println("Invalid Token");
						errjobj = commonmethod.getJsonStatus(401, "User Not Authorized", "Access Denied");
						jarray.put(errjobj);
						//new SendGridExample().sendEmail(jarray.toString(),client_id,token,api_name,"Invalid Token");//Email sending
					}
					System.out.println("validate-"+flag);
					return flag;
				}
				else{
					LOGGER.info("Inside validateClient(..) method ---> token input is found blank");
					/*errjobj = commonmethod.getJsonStatus(400, "Bad request", "Token should not be blank");
								jarray.put(errjobj);
								errjobj.put("ERROR", "User Id cannot be blank");
								jarray.put(errjobj);*/
					return flag;
				}
			}
			else{
				LOGGER.info("Inside validateClient(..) method ---> client_id id input is not set");
				/*errjobj = commonmethod.getJsonStatus(400, "Bad request", "client_id Id should not be blank");
							jarray.put(errjobj);
							errjobj.put("ERROR", "client_id Id cannot be blank");
							jarray.put(errjobj);*/
				return flag;
			}
		} catch (SQLException e) {
//			e.printStackTrace();
			errjobj = commonmethod.getJsonStatus(501, "Database connectivity issues or timeouts", "Please try after some time");
			jarray.put(errjobj);
			e.printStackTrace((new PrintWriter(errors)));
			System.out.println("SQL excetn catched");
			//new SendGridExample().sendEmail(jarray.toString(),client_id,token,api_name,errors.toString());
			return flag;
		}
		catch(Exception e){
			e.printStackTrace();
			return flag;
			/*errjobj = commonmethod.getJsonStatus(402, "Error in processing", "Error while processing request");
						jarray.put(errjobj);*/
		}
		finally{
			try{
				if(rs != null){
					rs.close();
					rs = null;
				}
				if(rs2 != null){
					rs2.close();
					rs2 = null;
				}
				if(statement != null){
					statement.close();
					statement = null;
				}
				/*if(connection != null){
					connection.close();
					connection = null;
				}*/
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		/*finally{
		try{
			statement.close();
			rs.close();
			connection.close();
			rs = null;
			statement = null;
			connection = null;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		//			return flag;
	}*/
	}




	public void setApiUsageStatus(String client_id,String api_name,Connection connection){
		String query = ""; 

		PreparedStatement pstatement = null;
		boolean returnValue = false;
		String current_time = null;
		LOGGER.info("Inside setApiUsageStatus(..) method client_id is "+client_id+" api_name is "+api_name);
		try {
			if(connection == null || connection.isClosed() ){
				connection = new DatabaseUtil().getConnection();
			}
			System.out.println("Api usage connection"+connection);
			Date currdate = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
			current_time = formatter.format(currdate);
			query = "insert into participant_apiusage_rev(client_id,api_name,time) values(?,?,?)";
			pstatement = connection.prepareStatement(query);
			pstatement.setString(1,client_id);
			//pstatement.setString(2, userid);
			pstatement.setString(2, api_name);
			pstatement.setString(3, current_time);
			returnValue=pstatement.execute();
			connection.commit();
			LOGGER.info("Inside setApiUsageStatus(..) method insert result"+returnValue);
		}
		catch(Exception e){
			e.printStackTrace();
			LOGGER.warning("Exception in setApiUsageStatus() method"+e.getMessage());
		}
		finally{
			try{
				if(pstatement != null){
					pstatement.close();
					pstatement = null;
				}
				/*if(connection != null){
					connection.close();
					connection = null;
				}*/
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}

	}

	//url:/corporate_banking/icicibank/corp_account_summary?client_id=poonam@gmail.com&token=124&corpid=shopmall&userid=inorbit
	@GET
	@Path("/corp_account_summary")
	@Produces
	public String getCorpAccountDetail(@Context UriInfo uriInfo,@QueryParam("client_id") String client_id,@QueryParam("token") String token,@QueryParam("corpid") String corpid,@QueryParam("userid") String userid) throws JSONException {
		Connection connection = null;
		CommonMethod commonmethod = new CommonMethod();
		JSONObject errjobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		ResultSet rs = null;
		Statement statement = null;
		int count = 0;
		String result = "";
		String query  = "";
		String regex1 = "^[0-9]*$";
		String regex2 = "^[a-zA-Z0-9]*$";
		boolean flag = false;
		LOGGER.info("Inside getCorpAccountDetail(..) method corpid is "+corpid+" userid is "+userid);
		DatabaseUtil util = new DatabaseUtil();
		try {
			HashSet<String> set = new HashSet<String>();
			set.add("client_id");
			set.add("token");
			set.add("corpid");
			set.add("userid");
			String data=commonmethod.keyvalidation(uriInfo, set);
			if(data.equalsIgnoreCase("OK"))
			{
			if(connection == null || connection.isClosed()){
				connection = util.getConnection();
				System.out.println("In API getCorpAccountDetail Method open connection:"+connection);
			}
			String queryStr = "select corpid,userid from participant_master where LOWER(client_id)=LOWER('"+client_id+"') AND corpid='"+corpid+"' OR userid='"+userid+"' ";
			flag = validateClient(client_id, token,"corp_account_summary",queryStr,connection);
			System.out.println("Accout summary flag-"+flag);

			if(flag){
				if (!corpid.equals("")) {
					if(!userid.equals("")){
						if(corpid.matches(regex1)  && corpid.length()==8){
							if(userid.matches(regex2) && userid.length()>=3 && userid.length()<=20){
								//									query = "select custid,accountno,balance,status,currency from fnpbbmor.corp_account_master where custid IN (select custid from fnpbbmor.corp_user_master where corp_id='"+corpid+"' and user_id='"+userid+"')";
								query = "select accountno,balance,status,currency from corp_account_master where  corp_id='"+corpid+"' AND user_id='"+userid+"'";
								LOGGER.info("REMOVE____________________________________QUERY________"+query);
								statement = connection.createStatement();
								rs = statement.executeQuery(query);

								while (rs.next()) {
									if(count == 0){
										jarray.put(successObj);
										count++;
									}
									String bal = rs.getString("balance");
									System.out.println("acc summ balance------"+bal);
									JSONObject jobj = new JSONObject();
									jobj.put("account_no", rs.getString("accountno"));
									jobj.put("balance", bal);
									jobj.put("account_status", rs.getString("status"));
									jobj.put("currency", rs.getString("currency"));
									jarray.put(jobj);
								}
								if(jarray.length() == 0){
									LOGGER.info("Inside getCorpAccountDetail(..) method ---> NO record Found");
									errjobj = commonmethod.getJsonStatus(503, "No Record Found", "NO Record Found");
									jarray.put(errjobj);
									/*errjobj.put("ERROR","NO data found in database");
								jarray.put(errjobj);*/
								}
								count=0;

							}
							else{
								LOGGER.info("Inside getCorpAccountDetail(..) method ---> User Id should be 5 to 20 digit alphabet");
								errjobj = commonmethod.getJsonStatus(400, "Bad request", "User Id should be 5 to 20 digit alphabet");
								jarray.put(errjobj);
							}
						}
						else{
							LOGGER.info("Inside getCorpAccountDetail(..) method --->Corp Id should be fixed 8 digit numberic string");
							errjobj = commonmethod.getJsonStatus(400, "Bad request", "Corp Id should be fixed 8 digit numberic string");
							jarray.put(errjobj);
						}

					}
					else{
						LOGGER.info("Inside getCorpAccountDetail(..) method ---> User id input is found blank");
						errjobj = commonmethod.getJsonStatus(400, "Bad request", "User Id should not be blank");
						jarray.put(errjobj);
						/*errjobj.put("ERROR", "User Id cannot be blank");
					jarray.put(errjobj);*/
					}
				}
				else{
					LOGGER.info("Inside getCorpAccountDetail(..) method ---> corp id input is not set");
					errjobj = commonmethod.getJsonStatus(400, "Bad request", "Corp Id should not be blank");
					jarray.put(errjobj);
					/*errjobj.put("ERROR", "Corp Id cannot be blank");
				jarray.put(errjobj);*/
				}
			}
			else{
				LOGGER.info("Inside getCorpAccountDetail(..) method ---> ");
				errjobj = commonmethod.getJsonStatus(401, "User Not Authorized", "Access Denied");
				jarray.put(errjobj);
			}

		} 
			else
				{
				errjobj.put("code", 454);
				errjobj.put("description","User Authentication Fail");
				errjobj.put("message",data);
				jarray.put(errjobj);
				System.out.println(jarray.toString());
				return jarray.toString();
				}
		}catch (SQLException e) {
				
			errjobj = commonmethod.getJsonStatus(501, "Database connectivity issues or timeouts", "Please try after some time");
			jarray.put(errjobj);
			/*errjobj.put("ERROR", "Database Error,Please try after some time");
			jarray.put(errjobj);*/
		}
		catch(Exception e){
			e.printStackTrace();
			errjobj = commonmethod.getJsonStatus(402, "Error in processing", "Error while processing request");
			jarray.put(errjobj);
		}
		finally{
			try{
				if(rs != null){
					rs.close();
				}
				if(statement != null){
					statement.close();
				}

				if(connection != null){
					System.out.println("FINAL    CONNECTION     CLOSE STRAT"+connection);
					connection.close();
					System.out.println("FINAL    CONNECTION     CLOSE END"+connection);
					//					connection = null;
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		result = jarray.toString();
		return result;
	}


	//	select custId from corp_transaction_details where custId in(select custId from corp_user_master where corp_id='shopmall' and user_id='inorbit')
	//select tranid,transactionType,amount,currency from corp_transaction_details  where status <> 'A' AND custid='cust01'

	//	"select custid,tranid,transactionType,amount,currency,accountno from corp_transaction_details  where custid in(select custId from corp_user_master where corp_id="+corpid+" and user_id="+userid+") AND status <> 'A'";

	//url:/corporate_banking/icicibank/approval_trans_list?corpid=shopmall&userid=inorbit
	@GET
	@Path("/approval_trans_list")
	@Produces
	public String getListTransaction(@Context UriInfo uriInfo,@QueryParam("client_id") String client_id,@QueryParam("token") String token,@QueryParam("corpid") String corpid,@QueryParam("userid") String userid) throws JSONException {
		Connection connection = null;
		CommonMethod commonmethod = new CommonMethod();
		JSONObject errjobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		Statement statement = null;
		ResultSet rs = null;
		int count = 0;
		String result = "";
		String query  = "";
		String regex1 = "^[0-9]*$";
		String regex2 = "^[a-zA-Z0-9]*$";
		boolean flag = false;
		LOGGER.info("Inside getListTransaction(..) method corpid is "+corpid+" userid is "+userid);
		try {
			HashSet<String> set = new HashSet<String>();
			set.add("client_id");
			set.add("token");
			set.add("corpid");
			set.add("userid");
			String data=commonmethod.keyvalidation(uriInfo, set);
			//String data=commonmethod.Func1(uriInfo,"client_id","token","corpid","userid");
			if(data.equalsIgnoreCase("OK"))
			{
			if(connection == null || connection.isClosed()){
				connection = new DatabaseUtil().getConnection();
				System.out.println("In API getListTransaction Method open connection:"+connection);
			}
			String queryStr = "select corpid,userid from participant_master where LOWER(client_id)=LOWER('"+client_id+"') AND corpid='"+corpid+"' OR userid='"+userid+"' ";
			flag = validateClient(client_id, token,"approval_trans_list",queryStr,connection);
			if(flag){

				if (!corpid.equals("")) {
					if(!userid.equals("")){
						if(corpid.matches(regex1)  && corpid.length()==8){
							if(userid.matches(regex2) && userid.length()>=3 && userid.length()<=20){

								LOGGER.info("Inside getListTransaction(..) method regex match found");
								//				approval1		query = "select custId,tranid,transactionType,amount,currency,accountno from fnpbbmor.corp_transaction_details  where custid in(select custId from corp_user_master where corp_id='"+corpid+"'  and user_id='"+userid+"') AND status <> 'A'";
								//									query = "select approval1,last_updated_by,custId,tranid,transactionType,amount,currency,accountno,status_description from fnpbbmor.corp_transaction_details  where custid in(select custId from corp_user_master where corp_id='"+corpid+"'  and user_id='"+userid+"') order by transactiondate desc fetch first 20 rows only";
								//									query = "select approval1,last_updated_by,tranid,transactionType,amount,currency,accountno,status_description from fnpbbmor.corp_transaction_details  where corp_id='"+corpid+"'  and user_id='"+userid+"' order by transactiondate desc fetch first 20 rows only";
								query = "select approval1,last_updated_by,tranid,transactionType,amount,currency,accountno,status from corp_transaction_details  where corp_id='"+corpid+"'  and user_id='"+userid+"'";
								System.out.println("MY LIST QUERY:"+query);
								statement = connection.createStatement();
								rs = statement.executeQuery(query);
								while (rs.next()) {
									//LOGGER.info("Inside getListTransaction(..) method resultset length is "+rs.getFetchSize());
									JSONObject jobj = new JSONObject();

									if(count==0){
										jarray.put(successObj);
										count++;
									}
									//									jobj.put("cust_id", rs.getString("custid"));
									jobj.put("tran_id", rs.getString("tranid"));
									jobj.put("account_no", rs.getString("accountno"));
									jobj.put("transaction_status", rs.getString("status"));
									jobj.put("trans_type", rs.getString("transactionType"));
									jobj.put("amount", rs.getDouble("amount")+"0");
									jobj.put("currency", rs.getString("currency"));
									jobj.put("approving_authority", rs.getString("approval1"));
									jobj.put("last_updated_by", rs.getString("last_updated_by"));
									jarray.put(jobj);
								}
								if(jarray.length() == 0){
									LOGGER.info("Inside getListTransaction(..) method ---> NO record Found");
									errjobj = commonmethod.getJsonStatus(503, "No Record Found", "NO Record Found");
									jarray.put(errjobj);
									/*errjobj.put("ERROR","NO data found in database");
							jarray.put(errjobj);*/
								}
								JSONObject json = new JSONObject();
								json.put("count of transactions", String.valueOf(jarray.length()-1));
								jarray.put(json);
								count = 0;
							}
							else{
								LOGGER.info("Inside getListTransaction(..) method ---> User Id should be 5 to 20 digit alphabet");
								errjobj = commonmethod.getJsonStatus(400, "Bad request", "User Id should be 5 to 20 digit alphabet");
								jarray.put(errjobj);
							}
						}//
						else{
							LOGGER.info("Inside getListTransaction(..) method ---> Corp Id should be fixed 8 digit numberic string");
							errjobj = commonmethod.getJsonStatus(400, "Bad request", "Corp Id should be fixed 8 digit numberic string");
							jarray.put(errjobj);
						}

					}
					else{
						LOGGER.info("Inside getListTransaction(..) method ---> User id input is found blank");
						errjobj = commonmethod.getJsonStatus(400, "Bad request", "User Id should not be blank");
						jarray.put(errjobj);
						/*errjobj.put("ERROR", "User Id cannot be blank");
					jarray.put(errjobj);*/
					}
				}
				else{
					LOGGER.info("Inside getListTransaction(..) method ---> corp id input is not set");
					errjobj = commonmethod.getJsonStatus(400, "Bad request", "Corp Id should not be blank");
					jarray.put(errjobj);
					/*errjobj.put("ERROR", "Corp Id cannot be blank");
				jarray.put(errjobj);*/
				}
			}else{
				LOGGER.info("Inside getListTransaction(..) method ---> ");
				errjobj = commonmethod.getJsonStatus(401, "User Not Authorized", "Access Denied");
				jarray.put(errjobj);
			}
		}
			else
				{
				errjobj.put("code", 454);
				errjobj.put("description","User Authentication Fail");
				errjobj.put("message",data);
				jarray.put(errjobj);
				System.out.println(jarray.toString());
				return jarray.toString();
				}
		}catch (SQLException e) {
			e.printStackTrace();
			errjobj = commonmethod.getJsonStatus(501, "Database connectivity issues or timeouts", "Please try after some time");
			jarray.put(errjobj);
			/*errjobj.put("ERROR", "Database Error,Please try after some time");
			jarray.put(errjobj);*/
		}
		catch(Exception e){
			e.printStackTrace();
			errjobj = commonmethod.getJsonStatus(402, "Error in processing", "Error while processing request");
			jarray.put(errjobj);
		}
		finally{
			try{
				if(rs != null){
					rs.close();
				}
				if(statement != null){
					statement.close();
				}

				if(connection != null){
					System.out.println("FINAL    CONNECTION     CLOSE STRAT"+connection);
					connection.close();
					System.out.println("FINAL    CONNECTION     CLOSE END"+connection);
					//					connection = null;
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}


		result = jarray.toString();
		return result;
	}



	//		select rm_id,rm_name,rm_mobile from corp_Rm_details where corp_id='shopmall' and user_id='inorbit'
	//url:/corporate_banking/icicibank/show_rm_mapping?corpid=shopmall&userid=inorbit
	@GET
	@Path("/show_rm_mapping")
	@Produces
	public String getRmMap(@Context UriInfo uriInfo,@QueryParam("client_id") String client_id,@QueryParam("token") String token,@QueryParam("corpid") String corpid,@QueryParam("userid") String userid) throws JSONException {
		Connection connection = null;
		CommonMethod commonmethod = new CommonMethod();
		JSONObject errjobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		Statement statement = null;
		ResultSet rs = null;
		int count = 0;
		String result = "";
		String query  = "";
		String regex1 = "^[0-9]*$";
		//	String regex2 = "^[a-zA-Z]*$";
		boolean flag = false;
		DatabaseUtil util = new DatabaseUtil();
		LOGGER.info("Inside getRmMap(..) method corpid is "+corpid+" userid is "+userid);
		try {
			//			if(connection == null || connection.isClosed()){
			HashSet<String> set = new HashSet<String>();
			set.add("client_id");
			set.add("token");
			set.add("corpid");
			set.add("userid");
			String data=commonmethod.keyvalidation(uriInfo,set);
			//String data=commonmethod.Func1(uriInfo,"client_id","token","corpid","userid");
			if(data.equalsIgnoreCase("OK"))
			{
			if(connection == null || connection.isClosed()){
				connection = util.getConnection();
				System.out.println("In API getRmMap Method open connection:"+connection);
			}
			String queryStr = "select corpid,userid from participant_master where LOWER(client_id)=LOWER('"+client_id+"') AND corpid='"+corpid+"' OR userid='"+userid+"' ";
			flag = validateClient(client_id, token,"show_rm_mapping",queryStr,connection);
			if(flag){
				System.out.println("In API getRmMap Method open connection:"+connection);
				//			}
				if (!corpid.equals("")) {
					//				if(!userid.equals("")){
					if(corpid.matches(regex1)  && corpid.length()==8 ){
						//						query = "select rm_id,rm_name,rm_mobile,rm_email from fnpbbmor.corp_Rm_details where corp_id='"+corpid+"' and user_id='"+userid+"'";
						query = "select rm_id,rm_name,rm_mobile,rm_email from corp_Rm_details where corp_id='"+corpid+"'";
						statement = connection.createStatement();
						rs = statement.executeQuery(query);
						while (rs.next()) {
							JSONObject jobj = new JSONObject();

							if(count==0){
								jarray.put(successObj);
								count++;
							}

							jobj.put("rm_id", rs.getString("rm_id"));
							jobj.put("rm_name", rs.getString("rm_name"));
							jobj.put("rm_mobile", rs.getString("rm_mobile"));
							jobj.put("rm_email", rs.getString("rm_email"));
							jarray.put(jobj);
						}
						if(jarray.length() == 0){
							LOGGER.info("Inside getRmMap(..) method ---> NO record Found");
							errjobj = commonmethod.getJsonStatus(503, "No Record Found", "NO Record Found");
							jarray.put(errjobj);
						}
						count = 0;

					}
					else{
						LOGGER.info("Inside getRmMap(..) method ---> Corp Id should be fixed 8 digit numberic string");
						errjobj = commonmethod.getJsonStatus(400, "Bad request", "Corp Id should be fixed 8 digit numberic string");
						jarray.put(errjobj);
					}
					/*}
				else{
					LOGGER.info("Inside getRmMap(..) method ---> User id input is found blank");
					errjobj = commonmethod.getJsonStatus(400, "Bad request", "User Id should not be blank");
					jarray.put(errjobj);
				}*/
				}
				else{
					LOGGER.info("Inside getRmMap(..) method ---> corp id input is not set");
					errjobj = commonmethod.getJsonStatus(400, "Bad request", "Corp Id should not be blank");
					jarray.put(errjobj);
				}
			}
			else{
				LOGGER.info("Inside getRmMap(..) method ---> ");
				errjobj = commonmethod.getJsonStatus(401, "User Not Authorized", "Access Denied");
				jarray.put(errjobj);
			}
		} 
			else
			{
				errjobj.put("code", 454);
				errjobj.put("description","User Authentication Fail");
				errjobj.put("message",data);
				jarray.put(errjobj);
				System.out.println(jarray.toString());
				return jarray.toString();
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
			errjobj = commonmethod.getJsonStatus(501, "Database connectivity issues or timeouts", "Please try after some time");
			jarray.put(errjobj);
			/*errjobj.put("ERROR", "Database Error,Please try after some time");
				jarray.put(errjobj);*/
		}
		catch(Exception e){
			e.printStackTrace();
			errjobj = commonmethod.getJsonStatus(402, "Error in processing", "Error while processing request");
			jarray.put(errjobj);
		}
		finally{
			try{
				if(rs != null ){
					rs.close();
				}
				if(statement != null){
					statement.close();
				}
				if(connection != null){
					connection.close();
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}

		result = jarray.toString();
		return result;
	}

	//url:/corporate_banking/icicibank/corp_rm_query?corpid=shopmall&userid=infinity&rmid=rm01&query=PROBS
	@GET
	@Path("/corp_rm_query")
	@Produces
	public String getRMQueryResponse(@Context UriInfo uriInfo,@QueryParam("client_id") String client_id,@QueryParam("token") String token,@QueryParam("corpid") String corpid,@QueryParam("userid") String userid,@QueryParam("rmid") String rmid,@QueryParam("query") String rmquery) throws JSONException {
		Connection connection = null;
		boolean returnValue=false;
		PreparedStatement pstatement = null;
		ResultSet rs = null;
		JSONObject errjobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		int count = 0;
		String regex1 = "^[0-9]*$";
		String regex2 = "^[a-zA-Z]*$";
		//	String regex3 = "^[a-zA-Z0-9]*$";
		CommonMethod commonmethod = new CommonMethod();
		boolean flag = false;
		LOGGER.info("Inside getRMQueryResponse(..) method corpid is "+corpid+" userid is "+userid);
		String result = "";
		String query  = "";
		DatabaseUtil util = new DatabaseUtil();
		try {
			//			if(connection == null || connection.isClosed()){
			HashSet<String> set = new HashSet<String>();
			set.add("client_id");
			set.add("token");
			set.add("corpid");
			set.add("userid");
			set.add("rmid");
			set.add("query");
			String data=commonmethod.keyvalidation(uriInfo,set);
			//String data=commonmethod.Func1(uriInfo,"client_id","token","corpid","userid","rmid","query");
			if(data.equalsIgnoreCase("OK"))
			{
			if(connection == null || connection.isClosed()){
				connection = util.getConnection();
			}
			String queryStr = "select corpid,userid from participant_master where client_id='"+client_id+"' AND corpid='"+corpid+"'";
			flag = validateClient(client_id, token,"corp_rm_query",queryStr,connection);
			if(flag){

				//			}
				if (!corpid.equals("")) {
					//				if(!userid.equals("")){
					//					if(!rmid.equals("")){
					if(!rmquery.equals("")){
						if(corpid.matches(regex1) &&  corpid.length()==8){
							query = "insert into corp_RM_Query (corpid,rmid,rmquery,status,submit_date) values(?,?,?,?,CONVERT(date,GETDATE()))";
							pstatement = connection.prepareStatement(query);
							pstatement.setString(1,corpid);
							//								pstatement.setString(2, userid);
							pstatement.setString(2, rmid);
							pstatement.setString(3, rmquery);
							pstatement.setString(4, "1");
							returnValue=pstatement.execute();
							connection.commit();
							count++;	
						}
						else{
							LOGGER.info("Inside getRMQueryResponse(..) method --->Corp Id should be fixed 8 digit numberic string");
							errjobj = commonmethod.getJsonStatus(400, "Bad request", "Corp Id should be fixed 8 digit numberic string");
							jarray.put(errjobj);
						}

					}
					else{
						LOGGER.info("Inside getRMQueryResponse(..) method ---> RM QUERY input is found blank");
						errjobj = commonmethod.getJsonStatus(400, "Bad request", "RM QUERY should not be blank");
						jarray.put(errjobj);
					}
					/*}
					else{
						LOGGER.info("Inside getRMQueryResponse(..) method ---> RM Id should not be blank AND should be valid alphanumeric String");
						errjobj = commonmethod.getJsonStatus(400, "Bad request", "RM Id should not be blank AND should be valid alphanumeric String");
						jarray.put(errjobj);
					}*/

					/*}
				else{
					LOGGER.info("Inside getRMQueryResponse(..) method ---> User id input is found blank");
					errjobj = commonmethod.getJsonStatus(400, "Bad request", "User Id should not be blank");
					jarray.put(errjobj);
				}*/
				}

				else{
					LOGGER.info("Inside getRMQueryResponse(..) method ---> corp id input is not set");
					errjobj = commonmethod.getJsonStatus(400, "Bad request", "corp id should not be blank");
					jarray.put(errjobj);
				}

				if(count != 0){
					JSONObject jobj = new JSONObject();
					//				jobj.put("code", 200);
					jarray.put(successObj);
					jobj.put("result", "success");
					jobj.put("result", "Thank you for writing to us. Your Relationship Manager will be calling you shortly");
					LOGGER.info("Inside getRMQueryResponse(..) method ---> insertSucessFlag "+returnValue);
					jarray.put(jobj);
				}
				else{
					LOGGER.info("Inside getRMQueryResponse(..) method ---> insertSucessFlag "+returnValue);
					errjobj.put("result", "failure");
					jarray.put(errjobj);
				}
			}else{
				LOGGER.info("Inside getRMQueryResponse(..) method ---> ");
				errjobj = commonmethod.getJsonStatus(401, "User Not Authorized", "Access Denied");
				jarray.put(errjobj);
			}

		}
			else
				{
				errjobj.put("code", 454);
				errjobj.put("description","User Authentication Fail");
				errjobj.put("message",data);
				jarray.put(errjobj);
				System.out.println(jarray.toString());
				return jarray.toString();
				}
		}
		catch (SQLException e) {
				
			e.printStackTrace();
			errjobj = commonmethod.getJsonStatus(501, "Database connectivity issues or timeouts", "Please try after some time");
			jarray.put(errjobj);
			/*errjobj.put("ERROR", "Database Error,Please try after some time");
			jarray.put(errjobj);*/
		}
		catch(Exception e){
			e.printStackTrace();
			errjobj = commonmethod.getJsonStatus(402, "Error in processing", "Error while processing request");
			jarray.put(errjobj);
		}
		finally{
			try{
				if(rs != null){
					rs.close();
				}
				if(pstatement != null){
					pstatement.close();
				}
				if(connection != null){
					connection.close();
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		result = jarray.toString();
		return result;
	}

	//sql:SELECT typeoflimit,limit_sanction,limit_utilized,equvivalent_INR,current date as sysdate from corp_limit_utilization where custid='cust01' and rm_mobile='9006512345'	
	//url:/corporate_banking/icicibank/limit_utilization_summary?rmmobile=9006512345&custid=cust01
	@GET
	@Path("/limit_utilization_summary")
	@Produces
	public String getSummaryForLimitUtilization(@Context UriInfo uriInfo,@QueryParam("client_id") String client_id,@QueryParam("token") String token,@QueryParam("rmmobile") String rm_mobile,@QueryParam("cust_id") String custid,@QueryParam("date") String query_date) throws JSONException {
		Connection connection = null;
		CommonMethod commonmethod = new CommonMethod();
		JSONObject errjobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		Statement statement = null;
		ResultSet rs = null;
		boolean returnValue=false;
		int count = 0;
		String regex1 = "^[0-9]*$";
		//	String regex = "^[a-zA-Z0-9]*$";
		String result = "";
		String query  = "";
		boolean flag = false;
		boolean dateFlag = false;
		DatabaseUtil util = new DatabaseUtil();
		LOGGER.info("Inside getSummaryForLimitUtilization(..) method rm_mobile is "+rm_mobile+" custid is "+custid);
		try {
			HashMap hm = new HashMap<>();
			HashSet<String> set = new HashSet<String>();
			set.add("client_id");
			set.add("token");
			set.add("cust_id");
			set.add("date");
			String data=commonmethod.keyvalidation(uriInfo,set);
			//String data=commonmethod.Func1(uriInfo,"client_id","token","rmmobile","cust_id","date");
			if(data.equalsIgnoreCase("OK"))
			{
			if(connection == null || connection.isClosed()){
				connection = util.getConnection();
			}
			flag = validateClientOnly(client_id, token,"limit_utilization_summary",connection);
			if(flag){
				dateFlag = commonmethod.validateDate(query_date,"yyyy-MM-dd");//enterd date should be in current Financial year and less than current date
				if(!query_date.equals("") && dateFlag){
					hm = commonmethod.getDates(query_date);
					LOGGER.info("hm.get(currYear_strat_date)+hm.get(currYear_end_date)----->"+hm.get("currYear_strat_date")+hm.get("currYear_end_date"));


					if (!rm_mobile.equals("") && rm_mobile.length() == 10 && rm_mobile.matches(regex1)) {

						if(!custid.equals("") && custid.matches(regex1) && custid.length()==10){

							//query = "SELECT typeoflimit,limit_sanction,limit_utilized,query_raised_date from fnpbbmor.corp_limit_utilization where custid='"+custid+"' and rm_mobile='"+rm_mobile+"' and  (query_raised_date between '"+hm.get("currYear_strat_date")+"' and '"+hm.get("currYear_end_date")+"')";
							query = "SELECT typeoflimit_CFY,limit_sanction_CFY,limit_utilized_CFY from corp_limit_utilization where custid='"+custid+"' and rm_mobile='"+rm_mobile+"'";
							System.out.println("Limit curr year query:"+query);
							statement = connection.createStatement();
							rs = statement.executeQuery(query);
							while (rs.next()) {
								JSONObject jobj = new JSONObject();

								if(count==0){
									JSONObject yearObj = new JSONObject();
									yearObj.put("Year", "Current Financial Year Till Date "+hm.get("currYear_end_date"));
									jarray.put(successObj);
									jarray.put(yearObj);
									count++;
								}
								//									jobj.put("query_raised_date", rs.getString("query_raised_date"));
								jobj.put("type_of_limit", rs.getString("typeoflimit_CFY"));
								jobj.put("value_of_limit_sanctioned", rs.getString("limit_sanction_CFY"));
								jobj.put("value_of_limit_utilized", rs.getString("limit_utilized_CFY"));
								jarray.put(jobj);
							}

							if(jarray.length() == 0){
								LOGGER.info("Inside getSummaryForLimitUtilization(..) method ---> NO record Found");
								errjobj = commonmethod.getJsonStatus(503, "No Record Found", "NO Record Found");
								jarray.put(errjobj);
							}
							count = 0;

							//								query = "SELECT typeoflimit,limit_sanction,limit_utilized,query_raised_date from fnpbbmor.corp_limit_utilization where custid='"+custid+"' and rm_mobile='"+rm_mobile+"' and  (query_raised_date between '"+hm.get("prevYear_start_date")+"' and '"+hm.get("prevYear_end_date")+"')";
							query = "SELECT typeoflimit_PFY,limit_sanction_PFY,limit_utilized_PFY from corp_limit_utilization where custid='"+custid+"' and rm_mobile='"+rm_mobile+"'";
							System.out.println("Limit prev year query:"+query);
							statement = connection.createStatement();
							rs = statement.executeQuery(query);
							while (rs.next()) {
								JSONObject jobj = new JSONObject();

								if(count==0){
									JSONObject yearObj = new JSONObject();
									yearObj.put("Year", "Previous Financial Year Till Date 31 March 2016");
									jarray.put(successObj);
									jarray.put(yearObj);
									count++;
								}
								//									jobj.put("query_raised_date", rs.getString("query_raised_date"));
								jobj.put("type_of_limit", rs.getString("typeoflimit_PFY"));
								jobj.put("value_of_limit_sanctioned", rs.getString("limit_sanction_PFY"));
								jobj.put("value_of_limit_utilized", rs.getString("limit_utilized_PFY"));
								jarray.put(jobj);
							}

							if(jarray.length() == 0){
								LOGGER.info("Inside getSummaryForLimitUtilization(..) method ---> NO record Found");
								errjobj = commonmethod.getJsonStatus(503, "No Record Found", "NO Record Found");
								jarray.put(errjobj);
							}
							count = 0;
						}
						else{
							LOGGER.info("Inside getSummaryForLimitUtilization(..) method ---> cust id should be valid 10 digit number");
							errjobj = commonmethod.getJsonStatus(400, "Bad request", "cust id should be valid 10 digit number");
							jarray.put(errjobj);
						}

					}
					else{
						LOGGER.info("Inside getSummaryForLimitUtilization(..) method --->RM Mobile number should be valid 10 digit number");
						errjobj = commonmethod.getJsonStatus(400, "Bad request", "RM Mobile number should be valid 10 digit number");
						jarray.put(errjobj);
					}
				}
				else{
					LOGGER.info("Inside getSummaryForLimitUtilization(..) method ---> Invalid date");
					errjobj = commonmethod.getJsonStatus(400, "Bad request.", "Entered date should be in current Financial year having format YYYY-MM-DD");
					jarray.put(errjobj);

				}

			}else{
				LOGGER.info("Inside getSummaryForLimitUtilization(..) method ---> ");
				errjobj = commonmethod.getJsonStatus(401, "User Not Authorized", "Access Denied");
				jarray.put(errjobj);
			}

		} 
		else
				{
					errjobj.put("code", 454);
					errjobj.put("description","User Authentication Fail");
					errjobj.put("message",data);
					jarray.put(errjobj);
					System.out.println(jarray.toString());
					return jarray.toString();
				}
		}catch (SQLException e) {
				
			e.printStackTrace();
			//error for sql exception
			errjobj = commonmethod.getJsonStatus(501, "Database connectivity issues or timeouts", "Database Error,Please try after some time");
			jarray.put(errjobj);
		}
		catch (Exception e) {
			e.printStackTrace();
			//error for processing
			errjobj = commonmethod.getJsonStatus(500, "Processing Error", e.getMessage());
			jarray.put(errjobj);
		}
		finally{
			try{
				if(rs != null){
					rs.close();
				}
				if(statement != null){
					statement.close();
				}
				if(connection != null){
					connection.close();
				}
				count = 0;
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		result = jarray.toString();
		return result;
	}


	//url:/corporate_banking/icicibank/tol_profile?rmmobile=9006512345&custid=cust01
	@GET
	@Path("/tol_profile")
	@Produces
	public String getTolProfile(@Context UriInfo uriInfo,@QueryParam("client_id") String client_id,@QueryParam("token") String token,@QueryParam("rmmobile") String rm_mobile,@QueryParam("cust_id") String custid) throws JSONException {
		Connection connection = null;
		CommonMethod commonmethod = new CommonMethod();
		JSONObject errjobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		Statement statement = null;
		ResultSet rs = null;
		boolean returnValue=false;
		int count = 0;
		String regex1 = "^[0-9]*$";
		String regex = "^[a-zA-Z0-9]*$";
		String result = "";
		String query  = "";
		boolean flag = false;
		//select custid,total_trade_transactions,total_eligible_transactions,total_tol_transactions,total_nontol_transactions,current date as sysdate from corp_tol_profile where rm_mobile ='9006512345' and custid ='cust01'
		LOGGER.info("Inside getTolProfile(..) method rm_mobile is "+rm_mobile+" custid is "+custid);

		try {
			HashSet<String> set = new HashSet<String>();
			set.add("client_id");
			set.add("token");
			set.add("rmmobile");
			set.add("cust_id");
			
			String data=commonmethod.keyvalidation(uriInfo,set);
			if(data.equalsIgnoreCase("OK"))
			{
			if(connection == null || connection.isClosed()){
				connection = new DatabaseUtil().getConnection();
			}
			flag = validateClientOnly(client_id, token,"tol_profile",connection);
			if(flag){
				if (!rm_mobile.equals("") && rm_mobile.length() == 10 &&  rm_mobile.matches(regex1)) {

					if(!custid.equals("") && custid.matches(regex1) && custid.length()==10){
						query = "select custid,ucc,total_trade_transactions,total_eligible_transactions,total_tol_transactions,total_nontol_transactions,CONVERT(date,GETDATE()) as sysdate from corp_tol_profile where rm_mobile = '"+rm_mobile+"' and custid ='"+custid+"'";
						statement = connection.createStatement();
						LOGGER.info("quer---REMOVE-------------------y=--------------------------"+query);
						rs = statement.executeQuery(query);
						while (rs.next()) {
							JSONObject jobj = new JSONObject();

							if(count==0){
								jarray.put(successObj);
								count++;
							}

							jobj.put("cust_id", rs.getString("custid"));
							jobj.put("ucc", rs.getString("ucc"));
							jobj.put("total_trade_transactions", rs.getString("total_trade_transactions"));
							jobj.put("total_eligible_transactions", rs.getString("total_eligible_transactions"));
							jobj.put("total_tol_transactions", rs.getString("total_tol_transactions"));
							jobj.put("total_nontol_transactions", rs.getString("total_nontol_transactions"));
							jarray.put(jobj);
						}

						if(jarray.length() == 0){
							LOGGER.info("Inside getTolProfile(..) method ---> NO record Found");
							errjobj = commonmethod.getJsonStatus(503, "No Record Found", "NO Record Found");
							jarray.put(errjobj);
						}
						count = 0;
					}
					else{
						//error for custid  blank
						LOGGER.info("Inside getTolProfile(..) method ---> cust id should be valid 10 digit number");
						errjobj = commonmethod.getJsonStatus(400, "Bad request.", "cust id should be valid 10 digit number");
						jarray.put(errjobj);
					}

				}
				else{
					//error for mobile no is not a valid number
					LOGGER.info("Inside getTolProfile(..) method ---> RM Mobile number should be valid 10 digit number");
					errjobj = commonmethod.getJsonStatus(400, "Bad request.", "RM Mobile number should be valid 10 digit number");
					jarray.put(errjobj);
				}

			}else{
				LOGGER.info("Inside getTolProfile(..) method ---> ");
				errjobj = commonmethod.getJsonStatus(401, "User Not Authorized", "Access Denied");
				jarray.put(errjobj);
			}
		}
			else
			{
				errjobj.put("code", 454);
				errjobj.put("description","User Authentication Fail");
				errjobj.put("message",data);
				jarray.put(errjobj);
				System.out.println(jarray.toString());
				return jarray.toString();
			}
		}catch (SQLException e) {
			e.printStackTrace();
			//error for sql exception
			errjobj = commonmethod.getJsonStatus(501, "Database connectivity issues or timeouts", "Database Error,Please try after some time");
			jarray.put(errjobj);
		}
		catch(Exception e){
			e.printStackTrace();
			errjobj = commonmethod.getJsonStatus(402, "Error in processing", "Error while processing request");
			jarray.put(errjobj);
		}
		finally{
			try{
				if(rs != null){
					rs.close();
				}
				if(statement != null){
					statement.close();
				}
				if(connection != null){
					connection.close();
				}
				count = 0;
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}		result = jarray.toString();
		return result;
	}


	//url:/corporate_banking/icicibank/corp_import_summary_customerlevel?rmmobile=9006512345&custid=cust01&startdate_FY=2016-01-27
	@GET
	@Path("/corp_import_summary_customerlevel")
	@Produces
	public String getCorpImportSummary(@Context UriInfo uriInfo,@QueryParam("client_id") String client_id,@QueryParam("token") String token,@QueryParam("rmmobile") String rm_mobile,@QueryParam("cust_id") String custid,@QueryParam("startdate_FY") String start_FYdate) throws JSONException {
		Connection connection = null;
		CommonMethod commonmethod = new CommonMethod();
		JSONObject errjobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		Statement statement = null;
		ResultSet rs = null;
		boolean returnValue=false;
		boolean flag = false;

		/*String start_date = "2015"+"-"+"04"+"-"+"01";
		String end_date =  "2016"+"-"+"03"+"-"+"31";*/



		int count = 0;
		String regex1 = "^[0-9]*$";
		//		String regex = "^[a-zA-Z0-9]*$";
		//select custid,total_trade_transactions,total_eligible_transactions,total_tol_transactions,total_nontol_transactions,current date as sysdate from corp_tol_profile where rm_mobile ='9006512345' and custid ='cust01'
		LOGGER.info("Inside getCorpImportSummary(..) method rm_mobile is "+rm_mobile+" custid is "+custid+"start_FYdate-"+start_FYdate);
		String result = "";
		String query  = "";
		boolean dateFlag = false;
		Set s = null;
		Iterator it = null;
		Map.Entry me = null;

		try {
			HashMap hm = new HashMap();
			HashSet<String> set = new HashSet<String>();
			set.add("client_id");
			set.add("token");
			set.add("rmmobile");
			set.add("cust_id");
			set.add("startdate_FY");
			String data=commonmethod.keyvalidation(uriInfo,set);
			//String data=commonmethod.Func1(uriInfo,"client_id","token","rmmobile","cust_id","startdate_FY");
			if(data.equalsIgnoreCase("OK"))
			{
			if(connection == null || connection.isClosed()){
				connection = new DatabaseUtil().getConnection();
			}
			flag = validateClientOnly(client_id, token,"corp_import_summary_customerlevel",connection);
			if(flag){
				dateFlag = commonmethod.validateDate(start_FYdate,"yyyy-MM-dd");//enterd date should be in current Financial year
				if(!start_FYdate.equals("") && dateFlag){
				//	hm = commonmethod.getDates(start_FYdate);
					LOGGER.info("hm.get(currYear_strat_date)+hm.get(currYear_end_date)----->"+hm.get("currYear_strat_date")+hm.get("currYear_end_date"));

					if (!rm_mobile.equals("") && rm_mobile.length() == 10 &&  rm_mobile.matches(regex1)) {

						if(!custid.equals("") && custid.matches(regex1) && custid.length()==10){
							//								String query1 = "select custid,type_of_transaction as Transaction_Type, sum(value_of_transaction) as Transaction_Total, count(value_of_transaction) as Transaction_Count from fnpbbmor.corp_import_summary where rm_mobile = '"+rm_mobile+"' and custid ='"+custid+"'  and (transaction_date between '"+hm.get("currYear_strat_date")+"' and '"+hm.get("currYear_end_date")+"') group by custid, ucc, type_of_transaction";
							String query1 = "select custid,type_of_transaction_CFY as Transaction_Type, value_of_transaction_CFY as Transaction_Total, count_of_transaction_CFY as Transaction_Count from corp_import_summary where rm_mobile = '"+rm_mobile+"' and custid ='"+custid+"'";
							statement = connection.createStatement();
							LOGGER.info("CustId Import summary cuur year query-------"+query1);
							rs = statement.executeQuery(query1);
							while (rs.next()) {
								JSONObject jobj = new JSONObject();
								if(count==0){
									JSONObject yearObj = new JSONObject();
									//yearObj.put("Year", "Current Financial Year Till Date "+hm.get("currYear_end_date"));
									yearObj.put("Year", "Current Financial Year Till Date "+start_FYdate);
									jarray.put(successObj);
									jarray.put(yearObj);
									count++;
								}
								jobj.put("cust_id", rs.getString("custid"));
								jobj.put("Transaction_Type", rs.getString("Transaction_Type"));
								jobj.put("Transaction_Agg_Value(in equivalent $)", rs.getString("Transaction_Total"));
								jobj.put("Transaction_Count", rs.getString("Transaction_Count"));
								//							jobj.put("count_of_bill_of_entry", rs.getString("count_of_billOfEntry"));
								jarray.put(jobj);
							}

							if(jarray.length() == 0){
								LOGGER.info("Inside getCorpImportSummary(..) method ---> NO record Found");
								errjobj = commonmethod.getJsonStatus(503, "No Record Found", "NO Record Found");
								jarray.put(errjobj);
							}
							count=0;
							int prevFinYr_EndDt = Integer.parseInt(start_FYdate.split("-")[0])-1;
							String prevFinYr_EndDtStr = String.valueOf(prevFinYr_EndDt)+"-"+start_FYdate.split("-")[1]+"-"+start_FYdate.split("-")[2];
							LOGGER.info("prevFinYr_EndDt: "+prevFinYr_EndDt+" prevFinYr_EndDtStr: "+prevFinYr_EndDtStr);
							//								String query2 = "select custid, type_of_transaction as Transaction_Type,sum(value_of_transaction) as Transaction_Total, count(value_of_transaction) as Transaction_Count from fnpbbmor.corp_import_summary where rm_mobile = '"+rm_mobile+"' and custid ='"+custid+"'  and (transaction_date between '"+hm.get("prevYear_start_date")+"' and '"+hm.get("prevYear_end_date")+"') group by custid, ucc, type_of_transaction";
							String query2 = "select custid, type_of_transaction_PFY as Transaction_Type,value_of_transaction_PFY as Transaction_Total, count_of_transaction_PFY as Transaction_Count from corp_import_summary where rm_mobile = '"+rm_mobile+"' and custid ='"+custid+"'";
							//							String query2 = "select custid, type_of_transaction as Transaction_Type,sum(value_of_transaction) as Transaction_Total, count(value_of_transaction) as Transaction_Count from fnpbbmor.corp_import_summary where rm_mobile = '"+rm_mobile+"' and custid ='"+custid+"'  and transaction_date = '"+hm.get("prevYear_end_date")+"' group by custid, ucc, type_of_transaction";
							statement = connection.createStatement();
							LOGGER.info("CustId Import Summary Prev Year Query--"+query2);
							rs = statement.executeQuery(query2);
							while (rs.next()) {
								JSONObject jobj = new JSONObject();

								if(count==0){
									JSONObject yearObj = new JSONObject();
									//yearObj.put("Year", "Previous Financial Year Till Date "+hm.get("prevYear_end_date"));
									yearObj.put("Year", "Previous Financial Year Till Date "+prevFinYr_EndDtStr);
									jarray.put(successObj);
									jarray.put(yearObj);
									count++;
								}
								jobj.put("cust_id", rs.getString("custid"));
								jobj.put("Transaction_Type", rs.getString("Transaction_Type"));
								jobj.put("Transaction_Agg_Value(in equivalent $)", rs.getString("Transaction_Total"));
								jobj.put("Transaction_Count", rs.getString("Transaction_Count"));							//							jobj.put("count_of_bill_of_entry", rs.getString("count_of_billOfEntry"));
								jarray.put(jobj);
							}

							if(jarray.length() == 0){
								LOGGER.info("Inside getCorpImportSummary(..) method ---> NO record Found");
								errjobj = commonmethod.getJsonStatus(503, "No Record Found", "NO Record Found");
								jarray.put(errjobj);
							}
							count =0;
							//								String query3 = "select custid,type_of_transaction as Transaction_Type, sum(value_of_transaction) as Transaction_Total, count(value_of_transaction) as Transaction_Count from fnpbbmor.corp_import_summary where rm_mobile = '"+rm_mobile+"' and custid ='"+custid+"' and supported_by_billOfEntry = 'N' group by custid, ucc, type_of_transaction";
							String query3 = "select count_supported_by_billOfEntry as Transaction_Count from corp_import_summary where rm_mobile = '"+rm_mobile+"'";
							statement = connection.createStatement();
							LOGGER.info("CustId Import Summary Bill_Of_Entry Checking query---"+query3);
							rs = statement.executeQuery(query3);
							if (rs.next()) {
								if(count==0){
									JSONObject summaryObj = new JSONObject();
									summaryObj.put("Summary", "Transactions Not supported By Bill_Of_Entry");
									jarray.put(summaryObj);
									count++;
								}
								JSONObject jobj = new JSONObject();
								//									jobj.put("custid", rs.getString("custid"));
								//									jobj.put("Transaction_Type", rs.getString("Transaction_Type"));
								//									jobj.put("Transaction_Agg_Value(in equivalent $)", rs.getString("Transaction_Total"));
								jobj.put("Transaction_Count", rs.getString("Transaction_Count"));
								//							jobj.put("count_of_bill_of_entry", rs.getString("count_of_billOfEntry"));
								jarray.put(jobj);
							}

							if(jarray.length() == 0){
								LOGGER.info("Inside getCorpImportSummary(..) method ---> NO record Found");
								errjobj = commonmethod.getJsonStatus(503, "No Record Found", "NO Record Found");
								jarray.put(errjobj);
							}
							count=0;

						}
						else{
							//error for custid  blank
							LOGGER.info("Inside getCorpImportSummary(..) method ---> cust id should be valid 10 digit number");
							errjobj = commonmethod.getJsonStatus(400, "Bad request.", "cust id should be valid 10 digit number");
							jarray.put(errjobj);
						}

					}
					else{
						//error for mobile no is not a valid number
						LOGGER.info("Inside getCorpImportSummary(..) method ---> RM Mobile number should be valid 10 digit number");
						errjobj = commonmethod.getJsonStatus(400, "Bad request.", "RM Mobile number should be valid 10 digit number");
						jarray.put(errjobj);
					}
				}else{
					LOGGER.info("Inside getCorpImportSummary(..) method ---> Invalid date");
					errjobj = commonmethod.getJsonStatus(400, "Bad request.", "Entered date should be in current Financial year having format YYYY-MM-DD");
					jarray.put(errjobj);

				}
			}
			else{
				LOGGER.info("Inside getCorpImportSummary(..) method ---> ");
				errjobj = commonmethod.getJsonStatus(401, "User Not Authorized", "Access Denied");
				jarray.put(errjobj);
			}
		}
			else
			{
				errjobj.put("code", 454);
				errjobj.put("description","User Authentication Fail");
				errjobj.put("message",data);
				jarray.put(errjobj);
				System.out.println(jarray.toString());
				return jarray.toString();
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
			//error for sql exception
			errjobj = commonmethod.getJsonStatus(501, "Database connectivity issues or timeouts", "Database Error,Please try after some time");
			jarray.put(errjobj);
		}
		catch(Exception e){
			e.printStackTrace();
			errjobj = commonmethod.getJsonStatus(402, "Error in processing", "Error while processing request");
			jarray.put(errjobj);
		}
		finally{
			try{
				if(rs != null){
					rs.close();
				}
				if(statement != null){
					statement.close();
				}
				if(connection != null){
					connection.close();
				}
				count = 0;
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		result = jarray.toString();
		return result;

	}

	//	url:/corporate_banking/icicibank/corp_import_summary_ucclevel?rmmobile=9006512345&ucc=1234&startdate_FY=2016-01-27
	@GET
	@Path("/corp_import_summary_ucclevel")
	@Produces
	public String getCorpImportSummaryAtUCCLevel(@Context UriInfo uriInfo,@QueryParam("client_id") String client_id,@QueryParam("token") String token,@QueryParam("rmmobile") String rm_mobile,@QueryParam("ucc") String ucc,@QueryParam("startdate_FY") String start_FYdate) throws JSONException {
		Connection connection = null;
		CommonMethod commonmethod = new CommonMethod();
		JSONObject errjobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		Statement statement = null;
		ResultSet rs = null;
		boolean returnValue=false;
		int count = 0;
		String regex1 = "^[0-9]*$";
		//		String regex = "^[a-zA-Z0-9]*$";
		String result = "";
		String query  = "";
		boolean flag = false;
		boolean dateFlag = false;
		//select custid,total_trade_transactions,total_eligible_transactions,total_tol_transactions,total_nontol_transactions,current date as sysdate from corp_tol_profile where rm_mobile ='9006512345' and custid ='cust01'
		LOGGER.info("Inside getCorpImportSummaryAtUCCLevel(..) method rm_mobile is "+rm_mobile+" ucc is "+ucc+"start_FYdate-"+start_FYdate);

		try {
			HashMap hm = new HashMap();
			HashSet<String> set = new HashSet<String>();
			set.add("client_id");
			set.add("token");
			set.add("rmmobile");
			set.add("ucc");
			set.add("startdate_FY");
			String data=commonmethod.keyvalidation(uriInfo,set);
			//String data=commonmethod.Func1(uriInfo,"client_id","token","rmmobile","ucc","startdate_FY");
			if(data.equalsIgnoreCase("OK"))
			{
			if(connection == null || connection.isClosed()){
				connection = new DatabaseUtil().getConnection();
			}
			flag = validateClientOnly(client_id, token,"corp_import_summary_ucclevel",connection);
			if(flag){
				//			if(connection == null || connection.isClosed()){
				dateFlag = commonmethod.validateDate(start_FYdate,"yyyy-MM-dd");//enterd date should be in current Financial year
				if(!start_FYdate.equals("") && dateFlag){
					//hm = commonmethod.getDates(start_FYdate);
					LOGGER.info("hm.get(currYear_strat_date)+hm.get(currYear_end_date)----->"+hm.get("currYear_strat_date")+hm.get("currYear_end_date"));

					if (!rm_mobile.equals("") && rm_mobile.length() == 10 &&  rm_mobile.matches(regex1)) {

						if(!ucc.equals("") && ucc.matches(regex1) && ucc.length()>=3 && ucc.length()<=15){
							String query1 ="select custid,ucc,type_of_transaction_CFY as Transaction_Type, value_of_transaction_CFY as Transaction_Total, count_of_transaction_CFY as Transaction_Count from corp_import_summary where rm_mobile = '"+rm_mobile+"' and ucc ='"+ucc+"'";
							//								String query1 ="select custid,ucc,type_of_transaction as Transaction_Type, sum(value_of_transaction) as Transaction_Total, count(value_of_transaction) as Transaction_Count from fnpbbmor.corp_import_summary where rm_mobile = '"+rm_mobile+"' and ucc ='"+ucc+"'  and (transaction_date between '"+hm.get("currYear_strat_date")+"' and '"+hm.get("currYear_end_date")+"') group by custid, ucc, type_of_transaction";
							statement = connection.createStatement();
							LOGGER.info("UCC import summary current year query"+query1);
							rs = statement.executeQuery(query1);
							while (rs.next()) {
								JSONObject jobj = new JSONObject();

								if(count==0){
									JSONObject yearObj = new JSONObject();
									//yearObj.put("Year", "Current Financial Year Till Date "+hm.get("currYear_end_date"));
									yearObj.put("Year", "Current Financial Year Till Date "+start_FYdate );
									jarray.put(successObj);
									jarray.put(yearObj);
									count++;
								}

								jobj.put("cust_id", rs.getString("custid"));
								jobj.put("ucc", rs.getString("ucc"));
								jobj.put("Transaction_Type", rs.getString("Transaction_Type"));
								jobj.put("Transaction_Agg_Value(in equivalent $)", rs.getString("Transaction_Total"));
								jobj.put("Transaction_Count", rs.getString("Transaction_Count"));
								//							jobj.put("count_of_bill_of_entry", rs.getString("count_of_billOfEntry"));
								jarray.put(jobj);
							}

							if(jarray.length() == 0){
								LOGGER.info("Inside getCorpImportSummaryAtUCCLevel(..) method ---> NO record Found");
								errjobj = commonmethod.getJsonStatus(503, "No Record Found", "NO Record Found");
								jarray.put(errjobj);
							}
							count=0;
							
							int prevFinYr_EndDt = Integer.parseInt(start_FYdate.split("-")[0])-1;
							String prevFinYr_EndDtStr = String.valueOf(prevFinYr_EndDt)+"-"+start_FYdate.split("-")[1]+"-"+start_FYdate.split("-")[2];
							LOGGER.info("prevFinYr_EndDt: "+prevFinYr_EndDt+" prevFinYr_EndDtStr: "+prevFinYr_EndDtStr);
							
							//			String query2 = "select custid, type_of_transaction_PFY as Transaction_Type,value_of_transaction_PFY as Transaction_Total, count_of_transaction_PFY as Transaction_Count from fnpbbmor.corp_import_summary where rm_mobile = '"+rm_mobile+"' and custid ='"+custid+"'";

							String query2 = "select custid,ucc,type_of_transaction_PFY as Transaction_Type, value_of_transaction_PFY as Transaction_Total, count_of_transaction_PFY as Transaction_Count from corp_import_summary where rm_mobile = '"+rm_mobile+"' and ucc ='"+ucc+"'";
							//							String query2 = "select custid,ucc,type_of_transaction as Transaction_Type, sum(value_of_transaction) as Transaction_Total, count(value_of_transaction) as Transaction_Count from fnpbbmor.corp_import_summary where rm_mobile = '"+rm_mobile+"' and ucc ='"+ucc+"'  and transaction_date ='"+hm.get("prevYear_end_date")+"' group by custid, ucc, type_of_transaction";
							statement = connection.createStatement();
							LOGGER.info("UCC import summary prev year query-"+query2);
							rs = statement.executeQuery(query2);
							while (rs.next()) {
								JSONObject jobj = new JSONObject();

								if(count==0){
									JSONObject yearObj = new JSONObject();
									//yearObj.put("Year", "Previous Financial Year Till Date "+hm.get("prevYear_end_date"));
									yearObj.put("Year", "Previous Financial Year Till Date "+prevFinYr_EndDtStr);
									jarray.put(successObj);
									jarray.put(yearObj);
									count++;
								}

								jobj.put("cust_id", rs.getString("custid"));
								jobj.put("ucc", rs.getString("ucc"));
								jobj.put("Transaction_Type", rs.getString("Transaction_Type"));
								jobj.put("Transaction_Agg_Value(in equivalent $)", rs.getString("Transaction_Total"));
								jobj.put("Transaction_Count", rs.getString("Transaction_Count"));
								//							jobj.put("count_of_bill_of_entry", rs.getString("count_of_billOfEntry"));
								jarray.put(jobj);
							}

							count=0;
							if(jarray.length() == 0){
								LOGGER.info("Inside getCorpImportSummaryAtUCCLevel(..) method ---> NO record Found");
								errjobj = commonmethod.getJsonStatus(503, "No Record Found", "NO Record Found");
								jarray.put(errjobj);
							}
							count =0;
							//								String query3 = "select count_supported_by_billOfEntry as Transaction_Count from fnpbbmor.corp_import_summary where rm_mobile = '"+rm_mobile+"'";
							String query3 = "select count_supported_by_billOfEntry as Transaction_Count from corp_import_summary where rm_mobile = '"+rm_mobile+"' and ucc ='"+ucc+"'";
							//								String query3 = "select custid,ucc,type_of_transaction as Transaction_Type ,sum(value_of_transaction) as Transaction_Total, count(value_of_transaction) as Transaction_Count from fnpbbmor.corp_import_summary where rm_mobile = '"+rm_mobile+"' and ucc ='"+ucc+"' and supported_by_billOfEntry = 'N' group by custid, ucc, type_of_transaction";
							statement = connection.createStatement();
							LOGGER.info("UCC import summary bill Of Entry-"+query3);
							rs = statement.executeQuery(query3);
							if (rs.next()) {
								if(count==0){
									JSONObject summaryObj = new JSONObject();
									summaryObj.put("Summary", "Transactions Not supported By Bill_Of_Entry");
									jarray.put(summaryObj);
									count++;
								}
								JSONObject jobj = new JSONObject();
								//							jobj.put("cust_id", rs.getString("custid"));
								//							jobj.put("ucc", rs.getString("ucc"));
								//									jobj.put("Transaction_Type", rs.getString("Transaction_Type"));
								//									jobj.put("Transaction_Agg_Value(in equivalent $)", rs.getString("Transaction_Total"));
								jobj.put("Transaction_Count", rs.getString("Transaction_Count"));
								//							jobj.put("count_of_bill_of_entry", rs.getString("count_of_billOfEntry"));
								jarray.put(jobj);
							}

							if(jarray.length() == 0){
								LOGGER.info("Inside getCorpImportSummary(..) method ---> NO record Found");
								errjobj = commonmethod.getJsonStatus(503, "No Record Found", "NO Record Found");
								jarray.put(errjobj);
							}
							count=0;
						}
						else{
							//error for custid  blank
							LOGGER.info("Inside getCorpImportSummaryAtUCCLevel(..) method ---> ucc should be valid 3 to 15 digit number");
							errjobj = commonmethod.getJsonStatus(400, "Bad request.", "ucc should be valid 3 to 15 digit number");
							jarray.put(errjobj);
						}

					}
					else{
						//error for mobile no is not a valid number
						LOGGER.info("Inside getCorpImportSummaryAtUCCLevel(..) method ---> RM Mobile number should be valid 10 digit number");
						errjobj = commonmethod.getJsonStatus(400, "Bad request.", "RM Mobile number should be valid 10 digit number");
						jarray.put(errjobj);
					}
				}
				else{
					LOGGER.info("Inside getCorpImportSummaryAtUCCLevel(..) method ---> Invalid date");
					errjobj = commonmethod.getJsonStatus(400, "Bad request.", "Entered date should be in current Financial year having format YYYY-MM-DD");
					jarray.put(errjobj);
				}
			}
			else{
				LOGGER.info("Inside getCorpImportSummary(..) method ---> ");
				errjobj = commonmethod.getJsonStatus(401, "User Not Authorized", "Access Denied");
				jarray.put(errjobj);
			}
		}else
		{
			errjobj.put("code", 454);
			errjobj.put("description","User Authentication Fail");
			errjobj.put("message",data);
			jarray.put(errjobj);
			System.out.println(jarray.toString());
			return jarray.toString();
		}
	} catch (SQLException e) {
			e.printStackTrace();
			//error for sql exception
			errjobj = commonmethod.getJsonStatus(501, "Database connectivity issues or timeouts", "Database Error,Please try after some time");
			jarray.put(errjobj);
		}
		catch(Exception e){
			e.printStackTrace();
			errjobj = commonmethod.getJsonStatus(402, "Error in processing", "Error while processing request");
			jarray.put(errjobj);
		}
		finally{
			try{
				if(rs != null){
					rs.close();
				}
				if(statement != null){
					statement.close();
				}
				if(connection != null){
					connection.close();
				}
				count = 0;
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}

		result = jarray.toString();
		return result;

	}
	//	url: /corporate_banking/icicibank/corp_export_summary_custid?rmmobile=9006512345&custid=cust01&startdate_FY=2016-01-28
	@GET
	@Path("/corp_export_summary_custid")
	@Produces
	public String getCorpExportSummaryByCustId(
			@Context UriInfo uriInfo,@QueryParam("client_id") String client_id,
			@QueryParam("token") String token,
			@QueryParam("rmmobile") String rm_mobile,
			@QueryParam("cust_id") String custid,
			@QueryParam("startdate_FY") String start_date
			) throws JSONException {
		Connection connection = null;
		Statement statement = null;
		ResultSet rs = null;
		JSONObject errjobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		CommonMethod commonmethod = new CommonMethod();
		//		String regex = "[0-9]";		
		String regex1 = "^[0-9]*$";
		int count = 0;
		String result = "";
		String query  = "";
		boolean flag = false;
		boolean dateFlag = false;
		try {
			
			//String data=commonmethod.Func1(uriInfo,"client_id","token","rmmobile","custid","startdate_FY");
			HashSet<String> set = new HashSet<String>();
			set.add("client_id");
			set.add("token");
			set.add("rmmobile");
			set.add("cust_id");
			set.add("startdate_FY");
			String data=commonmethod.keyvalidation(uriInfo, set);
			if(data.equalsIgnoreCase("OK"))
			{
			if(connection == null || connection.isClosed()){
				connection = new DatabaseUtil().getConnection();
			}
			flag = validateClientOnly(client_id, token,"corp_export_summary_custid",connection);

			if(flag){
				dateFlag = commonmethod.validateDate(start_date,"yyyy-MM-dd");//enterd date should be in current Financial year
				if(!start_date.equals("") && dateFlag){
					if (!rm_mobile.equals("") && rm_mobile.length() == 10 && rm_mobile.matches(regex1) ) {
						if(!custid.equals("") && custid.matches(regex1) && custid.length()==10){							
							JSONObject finYrJson = commonmethod.getFinancialYear(start_date);
							LOGGER.info("finYrJson: "+finYrJson.toString());
							//								String query1 = "select custid, type_of_transaction as Transaction_Type,sum(value_of_transaction) as Transaction_Total,"
							//										+ " count(value_of_transaction) as Transaction_Count"
							//										+ " from fnpbbmor.corp_export_summary where rm_mobile = '"+rm_mobile+"' and custid ='"+custid+"'"
							//										+" and transaction_date between '"+finYrJson.get("startFinancialYrDate")+"' and '"+start_date+"'"
							//										+" group by custid, type_of_transaction";

							String query1 = "select custid, type_of_transaction_cfy as Transaction_Type,value_of_transaction_CFY as Transaction_Total,"
									+ " count_transaction_CFY as Transaction_Count"
									+ " from corp_export_summary where rm_mobile = '"+rm_mobile+"' and custid ='"+custid+"'"
									;


							LOGGER.info("CustId Export Summary Curr year query: "+query1);
							statement = connection.createStatement();							
							rs = statement.executeQuery(query1);
							while (rs.next()) {
								JSONObject jsonObject = new JSONObject();

								if(count==0){
									JSONObject yearObj = new JSONObject();
									yearObj.put("Year", "Current Financial Year Till Date "+start_date);
									jarray.put(successObj);
									jarray.put(yearObj);
									count++;
									/*jarray.put(successObj);
										count++;*/
								}
								jsonObject.put("cust_id", rs.getString("custid"));
								jsonObject.put("Transaction_Type", rs.getString("Transaction_Type"));
								jsonObject.put("Transaction_Agg_Value(in equivalent $)", rs.getString("Transaction_Total"));
								jsonObject.put("Transaction_Count", rs.getString("Transaction_Count"));

								//									jsonObject.put("financial_year", "C");
								jarray.put(jsonObject);
							}
							if(jarray.length() == 0){
								LOGGER.info("NO record Found");
								errjobj = commonmethod.getJsonStatus(503, "No Record Found", "NO Record Found");
								jarray.put(errjobj);
							}
							count = 0;

							int prevFinYr_EndDt = Integer.parseInt(start_date.split("-")[0])-1;
							String prevFinYr_EndDtStr = String.valueOf(prevFinYr_EndDt)+"-"+start_date.split("-")[1]+"-"+start_date.split("-")[2];
							LOGGER.info("prevFinYr_EndDt: "+prevFinYr_EndDt+" prevFinYr_EndDtStr: "+prevFinYr_EndDtStr);							
							//								String query2 = "select custid,type_of_transaction as Transaction_Type, sum(value_of_transaction) as Transaction_Total,"
							//										+ " count(value_of_transaction) as Transaction_Count"
							//										+ " from fnpbbmor.corp_export_summary where rm_mobile = '"+rm_mobile+"' and custid ='"+custid+"'"
							//										+" and transaction_date between '"+finYrJson.get("startPrevFinancialYrDate")+"' and '"+prevFinYr_EndDtStr+"'"
							//										+" group by custid,type_of_transaction";

							String query2 = "select custid,type_of_transaction_PFY as Transaction_Type, value_of_transaction_PFY as Transaction_Total,"
									+ " count_transaction_PFY as Transaction_Count"
									+ " from corp_export_summary where rm_mobile = '"+rm_mobile+"' and custid ='"+custid+"'";

							LOGGER.info("CustId Exprt Summary prev Year Query: "+query2);							
							rs = statement.executeQuery(query2);
							while (rs.next()) {
								JSONObject jsonObject = new JSONObject();								
								if(count==0){
									JSONObject yearObj = new JSONObject();
									yearObj.put("Year", "Previous Financial Year Till Date "+prevFinYr_EndDtStr);
									jarray.put(successObj);
									jarray.put(yearObj);
									count++;
									/*jarray.put(successObj);
										count++;*/
								}
								jsonObject.put("cust_id", rs.getString("custid"));
								jsonObject.put("Transaction_Type", rs.getString("Transaction_Type"));
								jsonObject.put("Transaction_Agg_Value(in equivalent $)", rs.getString("Transaction_Total"));
								jsonObject.put("Transaction_Count", rs.getString("Transaction_Count"));

								//									jsonObject.put("financial_year", "P");
								jarray.put(jsonObject);
							}

							if(jarray.length() == 0){
								LOGGER.info("NO record Found");
								errjobj = commonmethod.getJsonStatus(503, "No Record Found", "NO Record Found");
								jarray.put(errjobj);
							}
							count=0;

							String query3 = "select count_no_supported_by_EDF_Softex as Transaction_Count"
									+ " from corp_export_summary where rm_mobile = '"+rm_mobile+"' and custid ='"+custid+"'";

							LOGGER.info("CustId Exprt Summary not supported by edf_softex Query: "+query3);							
							rs = statement.executeQuery(query3);
							if (rs.next()) {
								JSONObject jsonObject = new JSONObject();								
								if(count==0){
									JSONObject summaryObj = new JSONObject();
									summaryObj.put("Summary", "Transactions NOT supported By GR or EDF or SOFTEX");
									jarray.put(summaryObj);
									count++;
								}
								//									jsonObject.put("custid", rs.getString("custid"));
								//									jsonObject.put("Transaction_Type", rs.getString("Transaction_Type"));
								//									jsonObject.put("Transaction_Agg_Value(in equivalent $)", rs.getString("Transaction_Total"));
								jsonObject.put("Transaction_Count", rs.getString("Transaction_Count"));
								jarray.put(jsonObject);
							}

							if(jarray.length() == 0){
								LOGGER.info("NO record Found");
								errjobj = commonmethod.getJsonStatus(503, "No Record Found", "NO Record Found");
								jarray.put(errjobj);
							}
							count=0;

							//								String query4 = "select custid,type_of_transaction as Transaction_Type ,sum(value_of_transaction) as Transaction_Total,"
							//										+ " count(value_of_transaction) as Transaction_Count ,Status_Of_Bill" 
							//										+ " from fnpbbmor.corp_export_summary where rm_mobile = '"+rm_mobile+"' and custid ='"+custid+"'"
							//										+" group by custid,type_of_transaction,Status_Of_Bill";
							//								LOGGER.info("CustId Exprt Status Of Bill Query: "+query4);							

							String query4 = "select Status_L,Status_P,Status_R,Status_C"
									+ " from corp_export_summary where rm_mobile = '"+rm_mobile+"' and custid ='"+custid+"'";
							LOGGER.info("CustId Exprt Status Of Bill Query: "+query4);							
							rs = statement.executeQuery(query4);
							while (rs.next()) {
								JSONObject jsonObject = new JSONObject();								
								if(count==0){
									JSONObject summaryObj = new JSONObject();
									summaryObj.put("Summary", "Status Of Bill");
									jarray.put(summaryObj);
									count++;
								}
								//								jobj.put("custid", rs.getString("custid"));
								jsonObject.put("Lodged", rs.getString("Status_L"));
								jsonObject.put("Partly_Realized", rs.getString("Status_P"));
								jsonObject.put("Realized", rs.getString("Status_R"));
								jsonObject.put("Closed", rs.getString("Status_C"));	
								jarray.put(jsonObject);
							}

							if(jarray.length() == 0){
								LOGGER.info("NO record Found");
								errjobj = commonmethod.getJsonStatus(503, "No Record Found", "NO Record Found");
								jarray.put(errjobj);
							}
							count = 0;

						}
						else{
							//error for custid  blank
							errjobj = commonmethod.getJsonStatus(400, "Bad request.", "custid should be valid 10 digit number");
							jarray.put(errjobj);
						}

					}
					else{
						//error for rm_mobile blank entry
						errjobj = commonmethod.getJsonStatus(400, "Bad request.", "RM Mobile number should be valid 10 digit number");
						jarray.put(errjobj);
					}
				}else{
					LOGGER.info("Inside getCorpExportSummaryByCustId(..) method ---> Invalid date");
					errjobj = commonmethod.getJsonStatus(400, "Bad request.", "Entered date should be in current Financial year having format YYYY-MM-DD");
					jarray.put(errjobj);

				}
			}else{
				LOGGER.info("Inside getCorpExportSummaryByCustId(..) method ---> ");
				errjobj = commonmethod.getJsonStatus(401, "User Not Authorized", "Access Denied");
				jarray.put(errjobj);
			}
		}
			else
			{
				errjobj.put("code", 454);
				errjobj.put("description","User Authentication Fail");
				errjobj.put("message",data);
				jarray.put(errjobj);
				System.out.println(jarray.toString());
				return jarray.toString();
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
			//error for sql exception
			errjobj = commonmethod.getJsonStatus(501, "Database connectivity issues or timeouts", "Database Error,Please try after some time");
			jarray.put(errjobj);
		}
		catch(Exception e){
			e.printStackTrace();
			errjobj = commonmethod.getJsonStatus(402, "Error in processing", "Error while processing request");
			jarray.put(errjobj);
		}
		finally{
			try{
				if(rs != null){
					rs.close();
				}
				if(statement != null){
					statement.close();
				}
				if(connection != null){
					connection.close();
				}
				count = 0;
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		result = jarray.toString();
		return result;
	}

	//	url:/corporate_banking/icicibank/corp_export_summary_ucc?rmmobile=9006512345&ucc=1234&startdate_FY=2016-01-28
	@GET
	@Path("/corp_export_summary_ucc")
	@Produces
	public String getCorpExportSummaryByUCC(@Context UriInfo uriInfo,
			@QueryParam("client_id") String client_id,
			@QueryParam("token") String token,
			@QueryParam("rmmobile") String rm_mobile,
			@QueryParam("ucc") String ucc,
			@QueryParam("startdate_FY") String start_date
			) throws JSONException {
		Connection connection = null;
		Statement statement = null;
		ResultSet rs = null;
		JSONObject errjobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		CommonMethod commonmethod = new CommonMethod();
		String regex = "[0-9]{10}";	
		String regex1 = "^[0-9]*$";
		String result = "";
		String query  = "";
		boolean dateFlag = false;
		int count = 0;
		boolean flag = false;
		try {
			HashSet<String> set = new HashSet<String>();
			set.add("client_id");
			set.add("token");
			set.add("rmmobile");
			set.add("ucc");
			set.add("startdate_FY");
			//String data=commonmethod.Func1(uriInfo,"client_id","token","rmmobile","ucc","startdate_FY");
			String data=commonmethod.keyvalidation(uriInfo, set);
			
			if(data.equalsIgnoreCase("OK"))
			{
			if(connection == null || connection.isClosed()){
				connection = new DatabaseUtil().getConnection();
			}
			flag = validateClientOnly(client_id, token,"corp_export_summary_ucc",connection);
			if(flag){
				dateFlag = commonmethod.validateDate(start_date,"yyyy-MM-dd");//enterd date should be in current Financial year
				if(!start_date.equals("") && dateFlag){
					if (!rm_mobile.equals("") && rm_mobile.length() == 10 && rm_mobile.matches(regex) ) {
						if(!ucc.equals("") && ucc.matches(regex1) && ucc.length() >=3 && ucc.length()<=15){							
							JSONObject finYrJson = commonmethod.getFinancialYear(start_date);
							LOGGER.info("finYrJson: "+finYrJson.toString());

							//								String query1 = "select ucc,type_of_transaction as Transaction_Type, sum(value_of_transaction) as Transaction_Total,"
							//										+ " count(value_of_transaction) as Transaction_Count"
							//										+ " from fnpbbmor.corp_export_summary where rm_mobile = '"+rm_mobile+"' and ucc ='"+ucc+"'"
							//										+" and transaction_date between '"+finYrJson.get("startFinancialYrDate")+"' and '"+start_date+"'"
							//										+" group by ucc, type_of_transaction";

							String query1 = "select ucc,type_of_transaction_CFY as Transaction_Type, value_of_transaction_CFY as Transaction_Total,"
									+ "  count_transaction_CFY as Transaction_Count"
									+ " from corp_export_summary where rm_mobile = '"+rm_mobile+"' and ucc ='"+ucc+"'"
									;
							LOGGER.info("Ucc Export Summary Curr Year Query: "+query1) ;
							statement = connection.createStatement();							
							rs = statement.executeQuery(query1);
							while (rs.next()) {
								JSONObject jsonObject = new JSONObject();

								if(count==0){
									JSONObject yearObj = new JSONObject();
									yearObj.put("Year", "Current Financial Year Till Date "+start_date);
									jarray.put(successObj);
									jarray.put(yearObj);
									count++;
									/*jarray.put(successObj);
										count++;*/
								}

								jsonObject.put("ucc", rs.getString("ucc"));
								jsonObject.put("Transaction_Type", rs.getString("Transaction_Type"));
								jsonObject.put("Transaction_Agg_Value(in equivalent $)", rs.getString("Transaction_Total"));
								jsonObject.put("Transaction_Count", rs.getString("Transaction_Count"));
								//									jsonObject.put("financial_year", "C");
								jarray.put(jsonObject);
							}
							if(jarray.length() == 0){
								LOGGER.info("NO record Found");
								errjobj = commonmethod.getJsonStatus(503, "No Record Found", "NO Record Found");
								jarray.put(errjobj);
							}
							count = 0;

							int prevFinYr_EndDt = Integer.parseInt(start_date.split("-")[0])-1;
							String prevFinYr_EndDtStr = String.valueOf(prevFinYr_EndDt)+"-"+start_date.split("-")[1]+"-"+start_date.split("-")[2];
							LOGGER.info("prevFinYr_EndDt: "+prevFinYr_EndDt+" prevFinYr_EndDtStr: "+prevFinYr_EndDtStr);
							String query2 = "select ucc,type_of_transaction_PFY as Transaction_Type, value_of_transaction_PFY as Transaction_Total,"
									+ "  count_transaction_PFY as Transaction_Count"
									+ " from corp_export_summary where rm_mobile = '"+rm_mobile+"' and ucc ='"+ucc+"'"
									;
							LOGGER.info("UCC export summary Prev year query: "+query2);							
							rs = statement.executeQuery(query2);
							while (rs.next()) {
								JSONObject jsonObject = new JSONObject();

								if(count==0){
									JSONObject yearObj = new JSONObject();
									yearObj.put("Year", "Previous Financial Year Till Date "+prevFinYr_EndDtStr);
									jarray.put(successObj);
									jarray.put(yearObj);
									count++;
								}
								jsonObject.put("ucc", rs.getString("ucc"));
								jsonObject.put("Transaction_Type", rs.getString("Transaction_Type"));
								jsonObject.put("Transaction_Agg_Value(in equivalent $)", rs.getString("Transaction_Total"));
								jsonObject.put("Transaction_Count", rs.getString("Transaction_Count"));
								//									jsonObject.put("financial_year", "P");
								jarray.put(jsonObject);
							}

							if(jarray.length() == 0){
								LOGGER.info("NO record Found");
								errjobj = commonmethod.getJsonStatus(503, "No Record Found", "NO Record Found");
								jarray.put(errjobj);
							}
							count = 0;

							String query3 = "select count_no_supported_by_EDF_Softex as Transaction_Count"
									+ " from corp_export_summary where rm_mobile = '"+rm_mobile+"' and ucc ='"+ucc+"'"
									;
							LOGGER.info("UCC export summary Prev year NOT SUPPORTED BY edf softex entry query: "+query3);							
							rs = statement.executeQuery(query3);
							while (rs.next()) {
								JSONObject jsonObject = new JSONObject();

								if(count==0){
									JSONObject summaryObj = new JSONObject();
									summaryObj.put("Summary", "Transactions NOT supported By GR or EDF or SOFTEX");
									jarray.put(summaryObj);
									count++;
								}
								//									jsonObject.put("ucc", rs.getString("ucc"));
								//									jsonObject.put("Transaction_Type", rs.getString("Transaction_Type"));
								//									jsonObject.put("Transaction_Agg_Value(in equivalent $)", rs.getString("Transaction_Total"));
								jsonObject.put("Transaction_Count", rs.getString("Transaction_Count"));
								//									jsonObject.put("financial_year", "P");
								jarray.put(jsonObject);
							}

							if(jarray.length() == 0){
								LOGGER.info("NO record Found");
								errjobj = commonmethod.getJsonStatus(503, "No Record Found", "NO Record Found");
								jarray.put(errjobj);
							}
							count = 0;

							String query4 = "select Status_L,Status_P,Status_R,Status_C  "
									+ " from corp_export_summary where rm_mobile = '"+rm_mobile+"' and ucc ='"+ucc+"'";
							LOGGER.info("UCC export summary Status of Bill query: "+query4);							
							rs = statement.executeQuery(query4);
							while (rs.next()) {
								JSONObject jsonObject = new JSONObject();

								if(count==0){
									JSONObject summaryObj = new JSONObject();
									summaryObj.put("Summary", "Status Of Bill");
									jarray.put(summaryObj);
									count++;
								}
								jsonObject.put("Lodged", rs.getString("Status_L"));
								jsonObject.put("Partly_Realized", rs.getString("Status_P"));
								jsonObject.put("Realized", rs.getString("Status_R"));
								jsonObject.put("Closed", rs.getString("Status_C"));
								//									jsonObject.put("financial_year", "P");
								jarray.put(jsonObject);
							}

							if(jarray.length() == 0){
								LOGGER.info("NO record Found");
								errjobj = commonmethod.getJsonStatus(503, "No Record Found", "NO Record Found");
								jarray.put(errjobj);
							}
							count = 0;

						}
						else{
							//error for ucc  blank
							errjobj = commonmethod.getJsonStatus(400, "Bad request.", "ucc should be valid 3 to 15 digit number");
							jarray.put(errjobj);
						}
					}
					else{
						//error for mobile no is not a valid number
						errjobj = commonmethod.getJsonStatus(400, "Bad request.", "RM Mobile number should be valid 10 digit number");
						jarray.put(errjobj);
					}
				}

				else{
					LOGGER.info("Inside getCorpExportSummaryByUCC(..) method ---> Invalid date");
					errjobj = commonmethod.getJsonStatus(400, "Bad request.", "Entered date should be in current Financial year having format YYYY-MM-DD");
					jarray.put(errjobj);

				}
			}
			else{
				LOGGER.info("Inside getCorpExportSummaryByUCC(..) method ---> ");
				errjobj = commonmethod.getJsonStatus(401, "User Not Authorized", "Access Denied");
				jarray.put(errjobj);
			}


		} else
			{	
			errjobj.put("code", 454);
			errjobj.put("description","User Authentication Fail");
			errjobj.put("message",data);
			jarray.put(errjobj);
			System.out.println(jarray.toString());
			return jarray.toString();
			}
		}catch (SQLException e) {
			e.printStackTrace();
			//error for sql exception
			errjobj = commonmethod.getJsonStatus(501, "Database connectivity issues or timeouts", "Database Error,Please try after some time");
			jarray.put(errjobj);
		}
		catch(Exception e){
			e.printStackTrace();
			errjobj = commonmethod.getJsonStatus(402, "Error in processing", "Error while processing request");
			jarray.put(errjobj);
		}
		finally{
			try{
				if(rs != null){
					rs.close();
				}
				if(statement != null){
					statement.close();
				}
				if(connection != null){
					connection.close();
				}
				count = 0;
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}	
		result = jarray.toString();
		return result;
	}


	//url: /corporate_banking/icicibank/crop_approve_transaction?corpid=shopmall12&userid=inorbit&custid=10000001&tranid=1&action=A
	/*@GET
	@Path("/corp_approve_transaction")
	@Produces
	public String getcorpAprove(
			@QueryParam("client_id") String client_id,
			@QueryParam("token") String token,
			@QueryParam("corpid") String corpid,
			@QueryParam("custid") String custid,
			@QueryParam("userid") String userid,
			@QueryParam("tranid") String tranid,
			@QueryParam("action") String action) {

		LOGGER.info("###---- Corp Approve Transaction ----###");
		CommonMethod commonmethod = new CommonMethod();
		Connection connection;
		ResultSet rs = null;
		ResultSet rs1 = null;
		JSONObject jobj = new JSONObject();
		JSONObject errjobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		String status = "";
		String approve1 = "";
		String approve2 = "";
		int statusflag = 0;
		String result="";
		boolean flag = false;
		String regex1 = "^[a-zA-Z0-9]*$";
		String regex2 = "^[0-9]*$";
		String regex3 = "^[a-zA-Z]*$";
		String from_account_no;
		String to_account_no;
		int accountbalance_flag;
		double amount ;
		String query1;
		flag = validateClient(client_id, token);
		if(flag){
			try{
				//check enterd tranid is present in database
				String tranid_check_query = "select tranid from corp_transaction_details where tranid="+tranid;
				ResultSet rs0 = selectionQuery(tranid_check_query);
				connection = DatabaseUtil.getConnection();
				if(!corpid.equals("") && corpid.matches(regex1) && corpid.length()==8)
				{
					if(!userid.equals("") && userid.matches(regex3) && userid.length()>=3 && userid.length()<=20){//user id validation need to check
						if(!custid.equals("") && custid.matches(regex2) && custid.length()==10){
							if(!tranid.equals("") && tranid.matches(regex2))
							{
								if(rs0.next()){
								if(action.trim().equalsIgnoreCase("A") || action.trim().equalsIgnoreCase("R"))
								{
									LOGGER.info("get Status for tranid : " + tranid);
									Statement statement = connection.createStatement();
									query1 = "select amount, status,from_accountno,To_accountno from fnpbbmor.corp_transaction_details where tranid="+tranid+" AND custid in  (select custid from fnpbbmor.corp_user_master where corp_id='"+corpid+"' and user_id='"+userid+"' and custid = '"+custid+"')";
									System.out.println("First query in getCorpApprove::"+query1);
									rs = statement.executeQuery(query1);
									if (rs.next()) {
										status = rs.getString("status").trim();
										from_account_no = rs.getString("from_accountno");
										to_account_no = rs.getString("To_accountno");	
										amount = rs.getDouble("amount");

										LOGGER.info("Status fron transaction table : " + status);
										LOGGER.info("get approver's for corp id : " + corpid);
										rs1 = statement.executeQuery("select user_approver1,user_approver2 from fnpbbmor.corp_workflow_master where lower(corp_id)='"+ corpid + "'");

										if (rs1.next()) {
											LOGGER.info("in if");
											LOGGER.info("in if Approve 1 : "
													+ rs1.getString("user_approver1"));

											approve1 = rs1.getString("user_approver1").trim();

											approve2 = rs1.getString("user_approver2").trim();
											LOGGER.info("Approvers fron worlflow table : " + approve1
													+ " - " + approve2);

											if (status.equals("0") && custid.equalsIgnoreCase(approve1)) {
												if (action.equalsIgnoreCase("A")) {
													statusflag = updateTranStatus(tranid, "1","Pending");
												} else if (action.equalsIgnoreCase("R")) {
													statusflag = updateTranStatus(tranid, "3","Rejected");
												}
											} else if (status.equals("1")
													&& custid.equalsIgnoreCase(approve2)) {
												if (action.equalsIgnoreCase("A")) {
													statusflag = updateTranStatus(tranid, "2","Approved");
													accountbalance_flag = updateBalStatus(from_account_no,to_account_no,amount);
												} else if (action.equalsIgnoreCase("R")) {
													statusflag = updateTranStatus(tranid, "4","Rejected");
												}
											} else if (status.equals("3") || status.equals("4")) {
												returnMessage = commonmethod.getJsonErr(400,
														"Bad request. If request parameter are not provided.",
														"Transaction already Rejected");
												LOGGER.info(returnMessage.toString() + " -- " +action);
											}
											//jobj.put("error", "Transaction already Rejected");                    }
											LOGGER.info("Update Status " + statusflag);

										} //if ends for second approver tables resultset
									} //if for first resultset ends
									else{
										//No Record Found for given corp and user
										errjobj = commonmethod.getJsonStatus(503, "No Record Found", "NO Record Found");
										jarray.put(errjobj);
										LOGGER.info("Inside getCorpApprove() method----"+"No record found for first resultset");
									}

								}//if ends for action checking
								else{
									//invalid action
									errjobj = commonmethod.getJsonStatus(400, "Bad request", "Action should not be blank,It should be either A Or R");
									jarray.put(errjobj);
									LOGGER.info("Inside getCorpApprove() method----"+"Improper Action enterd");
								}
								}//if ends for tranid presence in database
								else{
									LOGGER.info("Inside getCorpApprove(..) method ---> ");
									errjobj = commonmethod.getJsonStatus(400, "Bad request","enterd tranid is not present in database");
									jarray.put(errjobj);
								}

							}//if ends for tranid checking
							else{
								//invalid tranid
								errjobj = commonmethod.getJsonStatus(400, "Bad request", "tranid should be valid number And it should not be blank");
								jarray.put(errjobj);
								LOGGER.info("Inside getCorpApprove() method----"+"tranid invalid found");

							}

						}//if ends for custid checking
						else{
							//invalid custid
							errjobj = commonmethod.getJsonStatus(400, "Bad request", "custid should be valid 8 digit number And it should not be blank");
							jarray.put(errjobj);
							LOGGER.info("Inside getCorpApprove() method----"+"custid invalid found");
						}
					}//if ends for userid checking
					else{
						//invalid userid
						errjobj = commonmethod.getJsonStatus(400, "Bad request", "userid should not be blank & it should be valid alphanumeric 5 to 20 length string");
						jarray.put(errjobj);
						LOGGER.info("Inside getCorpApprove() method----"+"userid invalid found");
					}
				}//if ends for corpid
				else{
					//invalid corpid
					errjobj = commonmethod.getJsonStatus(400, "Bad request", "userid should not be blank & it should be valid alphanumeric 5 to 20 length string");
					jarray.put(errjobj);
					LOGGER.info("Inside getCorpApprove() method----"+"userid invalid found");
				}


				if (statusflag == 1) {
					jobj.put("code", 200);
					jobj.put("approvalstatus", "success");
				} else {
					jobj.put("code", 200);
					jobj.put("approvalstatus", "failure or already approved");

				}
				LOGGER.info("Response : " + jobj.toString());
				if(jobj.length()==0)
				{
					result=returnMessage.toString();
				}
				else{
					result=jobj.toString();
				}
			}
			catch (SQLException e) {
				e.printStackTrace();
			} 
		}
		else{
			LOGGER.info("Inside getCorpExportSummaryByUCC(..) method ---> ");
			errjobj = commonmethod.getJsonStatus(401, "User Not Authorized", "Access Denied");
			jarray.put(errjobj);
		}
		return result;
	}

	 */
	public String checkvalidation(String corpid,String userid,String tranid,Connection connection){
		String regex1 = "^[0-9]*$";
		String regex2 = "^[0-9]*$";
		String regex3 = "^[a-zA-Z0-9]*$";
		String result = "";
		ResultSet rs0 = null;
		JSONObject errjobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		CommonMethod commonmethod = new CommonMethod();
		try{
			if(!tranid.equals("") && tranid.matches("^[a-zA-Z0-9]*$")){
				//check enterd tranid is present in database
				String tranid_check_query = "select tranid from corp_transaction_details where tranid='"+tranid+"'";
				System.out.println("TRANID CHK QUERY******"+tranid_check_query);
				rs0 = selectionQuery(tranid_check_query,connection);
				if(rs0.next()){
					if(!corpid.equals("") && corpid.matches(regex1) && corpid.length()==8){
						if(!userid.equals("") && userid.matches(regex3) && userid.length()>=3 && userid.length()<=20){
							result = "success";
						}//if user id check
						else{
							//userid should not be blank
							errjobj = commonmethod.getJsonStatus(400, "Bad request", "UserId should not be blank,It should be either 5 to 10 length alphabet String ");
							jarray.put(errjobj);
							result = jarray.toString();
							LOGGER.info("Inside checkvalidation() method----"+"Improper Userid entered");
						}
					}//if corp id check
					else{
						//corp id should not be blank
						errjobj = commonmethod.getJsonStatus(400, "Bad request", "CorpID should not be blank,It should be either Fixed 10 digith alphanumeric string ");
						result = jarray.toString();
						LOGGER.info("Inside checkvalidation() method----"+"Improper Corpid entered");
					}
				}//if tranid presnece
				else{
					// tranid doesnot present in Database
					//No Record Found
					errjobj = commonmethod.getJsonStatus(503, "No Record Found", "Invalid TranId");
					jarray.put(errjobj);
					result = jarray.toString();
					LOGGER.info("Inside checkvalidation() method----"+"invalid tranid entered which doesnt present in DB");
				}
			}//if tranid valid
			else{
				//tranid should not be blank
				errjobj = commonmethod.getJsonStatus(400, "Bad request", "Tranid should not be blank,It should be string valid with respect to transaction");
				jarray.put(errjobj);
				result = jarray.toString();
				LOGGER.info("Inside checkvalidation() method----"+"Improper tranid entered");
			}
		}//try
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
			if(rs0 != null){
				rs0.close();
			}
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		return result;
	}


	//url: /corporate_banking/icicibank/crop_approve_transaction?corpid=shopmall12&userid=inorbit&custid=10000001&tranid=1&action=A
	@GET
	@Path("/corp_approve_transaction")
	@Produces
	public String getcorpAprove(
			@Context UriInfo uriInfo,@QueryParam("client_id") String client_id,
			@QueryParam("token") String token,
			@QueryParam("corpid") String corpid,
			@QueryParam("cust_id") String custid,
			@QueryParam("userid") String userid,
			@QueryParam("tranid") String tranid,
			@QueryParam("action") String action) throws JSONException {

		LOGGER.info("###---- Corp Approve Transaction ----###");
		CommonMethod commonmethod = new CommonMethod();
		Connection connection = null;
		ResultSet rs = null;
		JSONObject errjobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		String status = "";
		int statusflag = 0;
		String result="";
		boolean flag = false;
		String from_account_no = "";
		int accountbalance_flag;
		double amount = 0; 
		String query1;
		String validationFlag ="";
		Statement statement = null;
		String queryStr = "select corpid,userid from participant_master where LOWER(client_id)=LOWER('"+client_id+"') AND corpid='"+corpid+"' OR userid='"+userid+"' ";

		try{
			
			//String data=commonmethod.Func1(uriInfo,"client_id","token","corpid","cust_id","userid","tranid","action");
			HashSet<String> set = new HashSet<String>();
			set.add("client_id");
			set.add("token");
			set.add("corpid");
			set.add("cust_id");
			set.add("userid");
			set.add("tranid");
			set.add("action");
			
			String data=commonmethod.keyvalidation(uriInfo, set);
			if(data.equalsIgnoreCase("OK"))
			{
			if(connection == null || connection.isClosed()){
				connection = new DatabaseUtil().getConnection();
			}
			flag = validateClient(client_id, token,"corp_approve_transaction",queryStr,connection);
			if(flag){
				validationFlag = checkvalidation(corpid,userid,tranid,connection);
				LOGGER.info("ValidatonFlag for approve txn-----------"+validationFlag);
				if(validationFlag.equalsIgnoreCase("success")){
					//get amount,accounts,status for tran
					query1 = "select amount, status,accountno from corp_transaction_details where tranid='"+tranid+"' AND corp_id='"+corpid+"' and user_id='"+userid+"'";
					System.out.println("First query in getCorpApprove::"+query1);
					statement = connection.createStatement();
					rs = statement.executeQuery(query1);
					if (rs.next()) {
						status = rs.getString("status").trim();
						from_account_no = rs.getString("accountno");
						//							to_account_no = rs.getString("To_accountno");	
						amount = rs.getDouble("amount");
						if (status.equalsIgnoreCase("Pending for approval")){
							//								if (action.equalsIgnoreCase("A")) {
							statusflag = updateTranStatus(tranid,"Approved",connection);
							System.out.println(statusflag);
							accountbalance_flag = updateBalStatus(from_account_no,"111111111111",amount,connection);
							System.out.println(accountbalance_flag);
							LOGGER.info("statusflag -"+statusflag+"--accountbalance_flag-"+accountbalance_flag);
							if(statusflag == 1 && accountbalance_flag == 1){
								jarray.put(successObj);
								JSONObject obj = new JSONObject();
								obj.put("success", "Transaction Approved");
								jarray.put(obj);
								result = jarray.toString();
								LOGGER.info("Approved log=="+result);
							}
							else{
								JSONObject obj = new JSONObject();
								obj.put("Failure", "Transaction approved but account updation failed");
								jarray.put(obj);
								result = jarray.toString();	
							}

							//								}
							/*else if (action.equalsIgnoreCase("R")) {
									statusflag = updateTranStatus(tranid, "4","Rejected");
									jarray.put(successObj);
									JSONObject obj = new JSONObject();
									obj.put("Failure", "Transaction Rejected");
									jarray.put(obj);
									result = jarray.toString();
								}*/
						}
						if (status.equalsIgnoreCase("Rejected")) {
							returnMessage = commonmethod.getJsonErr(400,
									"Bad request. If request parameter are not provided.",
									"Transaction already Rejected");
							LOGGER.info(returnMessage.toString() + " -- " +action);
							jarray.put(returnMessage);
							result = jarray.toString();
						}
						if (status.equalsIgnoreCase("Approved")) {
							returnMessage = commonmethod.getJsonErr(400,
									"Bad request. If request parameter are not provided.",
									"Transaction already Approved");
							LOGGER.info(returnMessage.toString() + " -- " +action);
							jarray.put(returnMessage);
							result = jarray.toString();
						}

					}

					else{
						errjobj = commonmethod.getJsonStatus(503, "No Record Found", "NO Record Found");
						jarray.put(errjobj);
						LOGGER.info("Inside getCorpApprove() method----"+"No record found for first resultset");
						result = jarray.toString();
					}

				}
				else{
					if(!validationFlag.equalsIgnoreCase("")){
						result = validationFlag;
					}
				}

			}
			else{
				LOGGER.info("Inside getCorpExportSummaryByUCC(..) method ---> ");
				errjobj = commonmethod.getJsonStatus(401, "User Not Authorized", "Access Denied");
				jarray.put(errjobj);
				result = jarray.toString();
			}
		}
			else
			{	
			errjobj.put("code", 454);
			errjobj.put("description","User Authentication Fail");
			errjobj.put("message",data);
			jarray.put(errjobj);
			System.out.println(jarray.toString());
			return jarray.toString();
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally{
			try{
				if(rs != null){
					rs.close();
				}
				if(statement != null){
					statement.close();
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		return result;
	}




	int updateTranStatus(String tranid, String status,Connection connection) {
		Statement stmt = null;
		int updateflag = 0;
		try {
			if(connection == null || connection.isClosed()){
				connection = new DatabaseUtil().getConnection();
			}
			stmt = connection.createStatement();
			updateflag = stmt
					.executeUpdate("Update corp_transaction_details set status='"
							+ status +  "' where tranid='" + tranid+"'");

			connection.commit();
			//			connection.close();
		} catch (SQLException s) {
			s.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		finally{
			try{
				if(stmt != null){
					stmt.close();
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}

		return updateflag;
	}

	int updateBalStatus(String from_account_no,String to_account_no,double amount,Connection connection){
		int updateflag = 0;
		ResultSet rs = null;
		double from_acc_balance=0;
		double to_acc_balance=0;
		//update corp_account_master set balance=balance+amount where accountno='to_account_no'
		//		update corp_account_master set balance= balance-amount where accountno='from_account_number'
		//	
		try {
			if(connection == null || connection.isClosed()){
				connection = new DatabaseUtil().getConnection();
			}
			String query1 = "select balance from corp_account_master where accountno="+from_account_no;
			String query2 = "select balance from corp_account_master where accountno="+to_account_no;
			rs = selectionQuery(query1,connection);
			while(rs.next()){
				from_acc_balance = rs.getDouble("balance");
			}
			double updated_from_acc_balance = from_acc_balance-amount;
			rs = selectionQuery(query2,connection);
			while(rs.next()){
				to_acc_balance = rs.getDouble("balance");
			}
			double updated_to_acc_balance = to_acc_balance+amount;

			String query4 = "update corp_account_master set balance="+updated_from_acc_balance+" where accountno='"+from_account_no+"'";
			int fromAccUpFlag = updateQuery(query4,connection);
			LOGGER.info("Updated Balance  for from account*************  "+fromAccUpFlag);
			String query5 = "update corp_account_master set balance="+updated_to_acc_balance+" where accountno='"+to_account_no+"'";
			int toAccUpFlag = updateQuery(query5,connection);
			LOGGER.info("Updated BAlance for to account***********"+toAccUpFlag);

			if(fromAccUpFlag != 0 && toAccUpFlag !=0){
				LOGGER.info("Updated BAlance Succesful***********");
				return 1;
			}
			else{
				LOGGER.info("Updated BAlance FAilure***********");
				return 0;
			}
		} catch (SQLException s) {
			s.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		finally{
			try{
				if(rs != null){
					rs.close();
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		return 0;
	}

	int updateQuery(String query,Connection connection){
		Statement stmt = null;
		int updateflag = 0;
		try{
			if(connection == null || connection.isClosed()){
				connection = new DatabaseUtil().getConnection();
			}
			stmt = connection.createStatement();
			updateflag = stmt.executeUpdate(query);
			connection.commit();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				if(stmt != null){
					stmt.close();
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}

		return updateflag;
	}

	ResultSet selectionQuery(String query,Connection connection){
		Statement stmt = null;
		ResultSet rs = null;
		try{
			if(connection == null || connection.isClosed()){
				connection = new DatabaseUtil().getConnection();
			}
			stmt = connection.createStatement();
			rs = stmt.executeQuery(query);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				/*if(rs != null){
					rs.close();
				}
				if(stmt != null){
					stmt.close();
				}*/
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		return rs;
	}

	/*	//url:/corporate_banking/icicibank/corp_import_summary?rmmobile=9006512345&custid=cust01&start_date=2016-01-21
	@GET
	@Path("/corp_import_summary")
	@Produces
	public String getCorpImportSummary(@QueryParam("rmmobile") String rm_mobile,@QueryParam("custid") String custid,@QueryParam("startdate_FY") String start_FYdate) {
		boolean returnValue=false;
		Statement statement = null;
		ResultSet rs = null;
		JSONObject errjobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		CommonMethod commonmethod = new CommonMethod();
		int count = 0;
		String regex = "^[a-zA-Z0-9]*$";
		//		select * from corp_import_summary where custid='cust01' AND  supported_by_billofentry='Y' AND (transaction_date BETWEEN '2015-04-01' AND '2016-03-31')
		LOGGER.info("Inside getCorpImportSummary(..) method rm_mobile is '"+rm_mobile+"' custid is '"+custid+"'");
		String result = "";
		String query  = "";
		int no_Of_transactions = 0;
		double sum_of_transactions = 0;
		String start_date = "2015"+"-"+"04"+"-"+"01";
		String end_date =  "2016"+"-"+"03"+"-"+"31";
		int LC_count = 0;
		int BG_count = 0;
		int LOC_count = 0;
		double LC_total =0;
		double LOC_total =0;
		double BG_total =0;
		int no_Of_txn = 0;
		String ucc = "";
		String cust = "";
		ArrayList<String> al = new ArrayList<String>();
		try {
			if(connection == null || connection.isClosed()){
				connection = DatabaseUtil.getConnection();
			}
			query = "select * from corp_import_summary where custid='"+custid+"' AND  supported_by_billofentry='Y' AND rm_mobile = '9006512345' AND (transaction_date BETWEEN '"+start_date+"' AND '"+end_date+"')";
			statement = connection.createStatement();
			LOGGER.info("quer---REMOVE-------------------y=--------------------------"+query);
			rs = statement.executeQuery(query);
			while (rs.next()) {
				String type_of_transaction = rs.getString("type_of_transaction");
				al.put(type_of_transaction);


				if(type_of_transaction.equalsIgnoreCase("LC")){
					LC_count = LC_count+1;
					double value_of_transaction = rs.getInt("value_of_transaction");
					LC_total = LC_total+value_of_transaction;
				}
				else if(type_of_transaction.equalsIgnoreCase("BG")){
					BG_count = BG_count+1;
					double value_of_transaction = rs.getInt("value_of_transaction");
					BG_total = BG_total+value_of_transaction;
				}
				else if(type_of_transaction.equalsIgnoreCase("LOC")){
					LOC_count = LOC_count+1;
					double value_of_transaction = rs.getInt("value_of_transaction");
					LOC_total = LOC_total+value_of_transaction;
				}

				ucc = rs.getString("ucc");
				cust = rs.getString("custid");
				no_Of_txn++;
			}

			for(int i=0;i<al.length();i++)
			{
				JSONObject jobj = new JSONObject();
				jobj.put("custid",cust);
				jobj.put("ucc", ucc);
				jobj.put("type_of_transaction", "LC");
				jobj.put("No_Of_Transactions_for_Previous_YTD", String.valueOf(LC_count));
				jobj.put("total_Value_Of_Transactions_for_Previous_YTD", String.valueOf(LC_total));
				jobj.put("type_of_transaction", "BG");
				jobj.put("No_Of_Transactions_for_Previous_YTD", String.valueOf(BG_count));
				jobj.put("total_Value_Of_Transactions_for_Previous_YTD", String.valueOf(BG_total));
				jobj.put("type_of_transaction", "LOC");
				jobj.put("No_Of_Transactions_for_Previous_YTD", String.valueOf(LOC_count));
				jobj.put("total_Value_Of_Transactions_for_Previous_YTD", String.valueOf(LOC_total));
				jobj.put("No_Of_Transsaction_Not_supportedBy_BillOfEntry", String.valueOf(no_Of_txn));

				jarray.put(jobj);
				LOGGER.info("quer---jarray-------------------y=--------------------------"+jarray.toString());
			}

			LOGGER.info("quer---jarray-------------------y=--------------------------"+jarray.toString());

		} catch (SQLException e) {
			e.printStackTrace();
			//error for sql exception


			errjobj = commonmethod.getJsonStatus(501, "Database connectivity issues or timeouts", "Database Error,Please try after some time");
			jarray.put(errjobj);
		}
		catch(Exception e){
			e.printStackTrace();
			errjobj = commonmethod.getJsonStatus(402, "Error in processing", "Error while processing request");
			jarray.put(errjobj);
		}
		finally{
			try{
				statement.close();
				rs.close();
				connection.close();
				rs = null;
				statement = null;
				connection = null;
				count = 0;
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		result = jarray.toString();
		return result;
	}

	 */
	/*select custid, sum(value_of_transaction) as ONE, count(value_of_transaction) as TWO, type_of_transaction from corp_import_summary where rm_mobile = '9006512345' and custid ='cust01'
            and (transaction_date between '2015-04-01' and '2016-03-31') group by custid, ucc, type_of_transaction
	 */


	/*@GET
		@Path("/balanceinq")
		@Produces
		public String getMessage(@QueryParam("accountno") String accountno) {
			Connection connection;
			Statement statement;
			ResultSet rs = null;

			String result = "";
			JSONObject jobj = new JSONObject();

			log.info("Initiate Balance Inquiry for Account No. :" + accountno);

			String regex = "[0-9]+";
			if (!accountno.equals("")) {
				if (accountno.length() == 4) {
					if (accountno.matches(regex)) {

						connection = DemoDBConnection.getConnection();

						try {
							statement = connection.createStatement();
							rs = statement
									.executeQuery("select balance from fnpbbmor.Rtl_Account_Master where accountNo="
											+ accountno);

							if (rs.next()) {
								result = result + rs.getString("balance");
								jobj.put("Account No.", accountno);
								jobj.put("Balance", rs.getString("balance"));
								log.info("Balance for Account No. :" + accountno
										+ " is " + result);

							} else {
								jobj.put("Error", "Account Number does not exist");
								log.info(result + " -- " + accountno);

							}
						} catch (SQLException e) {
							e.printStackTrace();
							jobj.put("Error",
									"Database Error. Please try after some time");
							log.info(jobj.toString() + " -- " + accountno);
						} finally {
							try {
								connection.close();
								rs.close();
								rs = null;
							} catch (SQLException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					} else {
						jobj.put("Error",
								"Account Number should contain only Numbers");
						log.info(jobj.toString() + " -- " + accountno);
					}

				} else {
					jobj.put("Error", "Account Number should be 4 digits");
					log.info(jobj.toString() + " -- " + accountno);
				}
			} else {
				jobj.put("Error", "Account Number cannot be Empty");
				log.info(jobj.toString() + " -- " + accountno);
			}
			// String out = "" + accountno + " : " + result;

			return jobj.toString();
		}
	 */




}


//select custid, sum(value_of_transaction) as ONE, count(value_of_transaction) as TWO, type_of_transaction from corp_import_summary where rm_mobile = '9006512345' and custid ='cust01'
//and (transaction_date between '2015-04-01' and '2016-03-31') group by custid, ucc, type_of_transaction








