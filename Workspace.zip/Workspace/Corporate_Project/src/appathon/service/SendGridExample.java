package appathon.service;
// SendGridExample.java
/*import com.sendgrid.*;
//pwd:icici@pp
public class SendGridExample {
	public void sendEmail(String ErrorMsg,String participant,String token,String api_name,String stackTraceMsg){
		SendGrid sendgrid = new SendGrid("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");
		String subject = participant+" : "+token+" : "+"-->"+api_name+" : "+ErrorMsg;
		
				SendGrid.Email email = new SendGrid.Email();
		email.addTo("iciciapp@gmail.com");
		email.setFrom("iciciapp@gmail.com");
		email.setSubject(subject);
		email.setText(stackTraceMsg);

		try {
			SendGrid.Response response = sendgrid.send(email);
			System.out.println(response.getMessage());
			System.out.println("SendEmail Method END");
		}
		catch (SendGridException e) {
			System.err.println(e);
		}
	}
}
*/