package appathon.bluemix.service;

import java.io.StringWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.TimeZone;
import java.util.logging.Logger;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@Path("/icici")
public class RestCall {

	private static final Logger LOGGER = Logger.getLogger(RestCall.class.getName());

	JSONObject returnMessage;
	JSONObject successObj;

	public RestCall() throws JSONException {
		successObj = new JSONObject();
		successObj.put("code", 200);
	}

	public boolean validateClient(String client_id, String token, String api_name, Connection connection)
			throws JSONException {
		StringWriter errors = new StringWriter();
		CommonMethod commonmethod = new CommonMethod();
		JSONObject errjobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		ResultSet rs = null;
		Statement statement = null;
		String query = "";
		boolean flag = false;
		String current_time = null;
		System.out.println("Inside validateClient(..) method client_id is " + client_id + " token is " + token);
		try {
			if (connection == null || connection.isClosed()) {
				connection = new DatabaseUtil().getConnection();
			}
			Date currdate = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
			current_time = formatter.format(currdate);
			// }
			if (!client_id.equals("")) {
				if (!token.equals("")) {
					// query = "select client_id,token from
					// participant_token_details where client_id='"+client_id+"'
					// and token='"+token+"' and (SELECT MINUTE(expiry_time) -
					// MINUTE('"+current_time+"') FROM SYSIBM.SYSDUMMY1) > 0";
					query = "select client_id,token from participant_token_details where client_id='" + client_id
							+ "' and token = '" + token + "'";
					System.out.println("VALIDATE_____________" + query);
					statement = connection.createStatement();
					rs = statement.executeQuery(query);

					while (rs.next()) {
						JSONObject jobj = new JSONObject();
						jobj.put("client_id", rs.getString(1));
						jobj.put("token", rs.getString(2));
						jarray.put(jobj);
					}
					if (jarray.length() != 0) {
						flag = true;
						setApiUsageStatus(client_id, api_name, connection);
					} else {
						errjobj = commonmethod.getJsonStatus(401, "User Not Authorized", "Access Denied");
						jarray.put(errjobj);
					}
					System.out.println("validate-" + flag);
					return flag;
				} else {
					System.out.println("Inside validateClient(..) method ---> token input is found blank");
					/*
					 * errjobj = commonmethod.getJsonStatus(400, "Bad request",
					 * "Token should not be blank"); jarray.put(errjobj);
					 * errjobj.put("ERROR", "User Id cannot be blank");
					 * jarray.put(errjobj);
					 */
					return flag;
				}
			} else {
				System.out.println("Inside validateClient(..) method ---> client_id id input is not set");
				/*
				 * errjobj = commonmethod.getJsonStatus(400, "Bad request",
				 * "client_id Id should not be blank"); jarray.put(errjobj);
				 * errjobj.put("ERROR", "client_id Id cannot be blank");
				 * jarray.put(errjobj);
				 */
				return flag;
			}
		} catch (SQLException e) {
			errjobj = commonmethod.getJsonStatus(501, "Database connectivity issues or timeouts",
					"Please try after some time");
			jarray.put(errjobj);
			e.printStackTrace();
			// System.out.println("SQL excetn catched");
			return flag;
		} catch (Exception e) {
			e.printStackTrace();
			return flag;
			/*
			 * errjobj = commonmethod.getJsonStatus(402, "Error in processing",
			 * "Error while processing request"); jarray.put(errjobj);
			 */
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (statement != null) {
					statement.close();
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
			// return flag;
		}
	}

	public void setApiUsageStatus(String client_id, String api_name, Connection connection) {
		String query = "";
		PreparedStatement pstatement = null;
		boolean returnValue = false;
		String current_time = null;
		System.out
				.println("Inside setApiUsageStatus(..) method client_id is " + client_id + " api_name is " + api_name);
		try {
			if (connection == null || connection.isClosed()) {
				connection = new DatabaseUtil().getConnection();
			}
			Date currdate = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
			current_time = formatter.format(currdate);
			query = "insert into participant_apiusage_rev(client_id,api_name,time) values(?,?,?)";
			pstatement = connection.prepareStatement(query);
			pstatement.setString(1, client_id);
			// pstatement.setString(2, userid);
			pstatement.setString(2, api_name);
			pstatement.setString(3, current_time);
			returnValue = pstatement.execute();
			connection.commit();
			System.out.println("Inside setApiUsageStatus(..) method insert result" + returnValue);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.warning("Exception in setApiUsageStatus() method" + e.getMessage());
		} finally {
			try {
				if (pstatement != null) {
					pstatement.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	@GET
	@Path("/ok")
	@Produces
	public String gmf() {
		return "Ok";
	}

	// http://localhost:8080/Security/Security/icici/get_mf_details?client_id=sachin@gmail.com&token=fd24a25c5cc4&mf_scheme_id=MF0001
	// http://securities.mybluemix.net/banking/icici_securities/get_mf_details?client_id=test@abc.com&token=f5316a5e35a4&mf_scheme_id=10001
	// url:/banking/icici_securities/get_mf_details?client_id=test@email.com&token=&custid=55501501
	@GET
	@Path("/get_mf_details")
	@Produces
	public String getMFDetails(@Context UriInfo uriInfo, @QueryParam("client_id") String client_id,
			@QueryParam("token") String token, @QueryParam("mf_scheme_id") String mf_scheme_id) throws JSONException {
		Connection connection = null;
		CommonMethod commonmethod = new CommonMethod();
		JSONObject errjobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		ResultSet rs = null;
		// ResultSet rs1 = null;
		Statement statement = null;
		int count = 0;
		// String client_id = "";
		String result = "";
		String query1 = "";
		// String query2 = "";
		String regex = "^[a-zA-Z0-9]*$";
		boolean flag = false;
		System.out.println("Inside getMFDetails(..) method mf_scheme_id is " + mf_scheme_id);
		try {
			HashSet<String> set = new HashSet<String>();
			set.add("client_id");
			set.add("token");
			set.add("mf_scheme_id");
			String data = commonmethod.keyvalidation(uriInfo, set);
			if (data.equalsIgnoreCase("ok")) {
				if (connection == null || connection.isClosed()) {
					connection = new DatabaseUtil().getConnection();
				}
				flag = validateClient(client_id, token, "get_mf_details", connection);
				if (flag) {
					if (!mf_scheme_id.equals("")
							/* && mf_scheme_id.matches(regex) */ && mf_scheme_id.length() == 6) {
						System.out.println(
								"select scheme_id,custid,mf_scheme_name,last_nav,last_nav_date,cut_off_time,rating,i_sec_research_view,fund_mgr_name,fund_type,AUM,exit_load from Mutual_Fund_Master where scheme_id ='"
										+ mf_scheme_id + "'");
						query1 = "select scheme_id,custid,mf_scheme_name,last_nav,last_nav_date,cut_off_time,rating,i_sec_research_view,fund_mgr_name,fund_type,AUM,exit_load from Mutual_Fund_Master where scheme_id ='"
								+ mf_scheme_id + "'";
						statement = connection.createStatement();
						rs = statement.executeQuery(query1);
						while (rs.next()) {
							if (count == 0) {
								jarray.put(successObj);
								count++;
							}
							JSONObject jobj = new JSONObject();
							// jobj.put("custid", rs.getString("custid"));
							jobj.put("mf_scheme_id", rs.getString("scheme_id"));
							jobj.put("mf_scheme_name", rs.getString("mf_scheme_name"));
							jobj.put("last_nav", rs.getString("last_nav"));
							jobj.put("last_nav_date", rs.getString("last_nav_date"));
							jobj.put("cut_off_time", rs.getString("cut_off_time"));
							jobj.put("rating", rs.getString("rating"));
							jobj.put("i_sec_research_view", rs.getString("i_sec_research_view"));
							jobj.put("fund_mgr_name", rs.getString("fund_mgr_name"));
							jobj.put("fund_type", rs.getString("fund_type"));
							jobj.put("AUM", rs.getString("AUM"));
							jobj.put("exit_load", rs.getString("exit_load"));
							jarray.put(jobj);
						}
						count = 0;
						if (jarray.length() == 0) {
							System.out.println("Inside getMFDetails(..) method ---> NO record Found");
							errjobj = commonmethod.getJsonStatus(503, "No Record Found", "NO Record Found");
							jarray.put(errjobj);
						}
					} else {
						// custid checkin
						System.out.println(
								"Inside getMFDetails(..) method ---> Scheme Id should be fixed 8 digit number and it should not be blank");
						errjobj = commonmethod.getJsonStatus(400, "Bad request",
								"SchemeId should be fixed 5 digit number and it should not be blank");
						jarray.put(errjobj);
					}
				} else {
					// authoriztion failed
					System.out.println("Inside getMFDetails(..) method ---> ");
					errjobj = commonmethod.getJsonStatus(401, "User Not Authorized", "Access Denied");
					jarray.put(errjobj);
				}
			} else {
				returnMessage.put("code", 454);
				returnMessage.put("description", "Invalid Parameter");
				returnMessage.put("message", data);
				jarray.put(returnMessage);
				System.out.println(jarray.toString());
				return jarray.toString();
			}
		} catch (SQLException e) {
			e.printStackTrace();
			errjobj = commonmethod.getJsonStatus(501, "Database connectivity issues or timeouts",
					"Please try after some time");
			jarray.put(errjobj);
			/*
			 * errjobj.put("ERROR",
			 * "Database Error,Please try after some time");
			 * jarray.put(errjobj);
			 */
		} catch (Exception e) {
			e.printStackTrace();
			errjobj = commonmethod.getJsonStatus(402, "Error in processing", "Error while processing request");
			jarray.put(errjobj);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		/*
		 * finally{ try{
		 * 
		 * rs.close(); statement.close(); connection.close(); rs = null;
		 * statement = null; connection = null; } catch(Exception e){
		 * e.printStackTrace(); } }
		 */ result = jarray.toString();
		return result;
	}

	@GET
	@Path("/viewportfolio")
	@Produces
	public String viewCurrencyPairs(@Context UriInfo uriInfo, @QueryParam("client_id") String client_id,
			@QueryParam("token") String token, @QueryParam("custid") String custid) throws JSONException {
		String returnValue = "";
		String regex1 = "^[0-9]*$";
		JSONObject jobj = new JSONObject();
		JSONObject errjobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		CommonMethod dao = new CommonMethod();
		// SecuritirsDAO dao = new SecuritirsDAO();
		Connection connection = null;
		try {
			HashSet<String> set = new HashSet<String>();
			set.add("client_id");
			set.add("token");
			set.add("custid");
			String data = dao.keyvalidation(uriInfo, set);
			if (data.equalsIgnoreCase("ok")) {
				if (connection == null || connection.isClosed()) {
					connection = new DatabaseUtil().getConnection();
				}
				if (client_id.equals("") || token.equals("") || custid.equals("")) {
					dao.getJsonStatus(400, "Bad request.", "Please enter all required values.");
				} else {
					boolean isClientValidated = validateClient(client_id, token, "viewportfolio", connection);
					if (isClientValidated) {
						if (!(custid.equalsIgnoreCase("")) && custid.matches(regex1) && custid.length() == 8) {
							JSONArray jsonArray = getPortfolio(custid, connection);
							if (jsonArray.length() > 1) {
								returnValue = jsonArray.toString();
							} else {
								returnValue = dao.getJsonStatus1(402, "No records available.", "No Records available");
							}

						} else {
							System.out.println(
									"Inside viewCurrencyPairs(..) method ---> cust id should be valid 8 digit number");
							errjobj = dao.getJsonStatus(400, "Bad request", "cust id should be valid 8 digit number");
							jarray.put(errjobj);
						}
					} else {
						System.out.println("User Not Authorized");
						returnValue = dao.getJsonStatus1(401, "User Not Authorized", "Access Denied");
					}
				}
			} else {
				returnMessage.put("code", 454);
				returnMessage.put("description", "Invalid Parameter");
				returnMessage.put("message", data);
				jarray.put(returnMessage);
				System.out.println(jarray.toString());
				return jarray.toString();
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			returnValue = dao.getJsonStatus1(501, "Database connectivity issue or Timeouts.",
					"Database Error. Please try after some time.");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			returnValue = dao.getJsonStatus1(402, "Error in processing.", "Currency Pairs value couldn't be fetched.");
		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return returnValue;
	}

	// http://retail_banking.mybluemix.net/banking/icicibank_treasury/dealMis?email=test@abc.com&token=f5316a5e35a4&dealno=1021698567&fromDate=2016-01-13&toDate=2016-02-02
	@GET
	@Path("/placemforder")
	@Produces
	public String getplaceOrder(@Context UriInfo uriInfo, @QueryParam("client_id") String client_id,
			@QueryParam("token") String token, @QueryParam("cust_id") String cust_id,
			@QueryParam("MF_scheme_name") String MF_scheme_name,
			@QueryParam("transaction_type") String transaction_type, @QueryParam("folio") String folio,
			@QueryParam("joint_holder") String joint_holder, @QueryParam("nominee_flag") String nominee_flag,
			@QueryParam("nominee_name") String nominee_name, @QueryParam("nominee_relation") String nominee_relation,
			@QueryParam("nominee_dob") String nominee_dob, @QueryParam("investment_amount") String investment_amount,
			@QueryParam("payment_source") String payment_source, @QueryParam("is_agent") String is_agent,
			@QueryParam("euin") String euin, @QueryParam("declaration") String declaration,
			@QueryParam("units") String units) throws JSONException {
		Connection connection = null;
		boolean flag = false;
		String returnValue = "";
		// String query="";
		// String mfdetails="";
		JSONObject errjobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		// boolean paramValidationFlag = false;
		// SecuritirsDAO dao = new SecuritirsDAO();
		CommonMethod commonmethod = new CommonMethod();
		System.out.println("###------------ Place Order MF ------------###");
		try {
			HashSet<String> set = new HashSet<String>();
			set.add("client_id");
			set.add("token");
			set.add("cust_id");
			set.add("MF_scheme_name");
			set.add("transaction_type");
			set.add("folio");
			set.add("joint_holder");
			set.add("nominee_flag");
			set.add("nominee_name");
			set.add("nominee_relation");
			set.add("nominee_dob");
			set.add("investment_amount");
			set.add("payment_source");
			set.add("is_agent");
			set.add("euin");
			set.add("declaration");
			set.add("units");

			String data = commonmethod.keyvalidation(uriInfo, set);
			if (data.equalsIgnoreCase("ok")) {
				if (connection == null || connection.isClosed()) {
					connection = new DatabaseUtil().getConnection();
				}
				flag = validateClient(client_id, token, "placemforder", connection);
				String regex = "[0-9]+";
				if (flag) {
					if (MF_scheme_name != "") {
						if (transaction_type != "") {
							if (folio != "") {
								if (units != "" && units.matches(regex)) {
									System.out.println("CUSSSSTTTID:" + cust_id);
									// paramValidationFlag =
									// checkvalidation(MF_scheme_name, cust_id,
									// transaction_type, folio,
									// joint_holder,nominee_flag,nominee_relation,nominee_dob,investment_amount,payment_source,is_agent,euin,declaration,units)
									// ;
									returnValue = placeOrder(connection, cust_id, MF_scheme_name, transaction_type,
											folio, joint_holder, nominee_flag, nominee_name, nominee_relation,
											nominee_dob, investment_amount, payment_source, is_agent, euin, declaration,
											units, client_id);
									System.out.println("return Value : " + returnValue);
								} else {
									returnValue = commonmethod.getJsonStatus1(402, "Improper data inserted",
											"Units can't be null");
								}
							} else {
								returnValue = commonmethod.getJsonStatus1(402, "Improper data inserted",
										"Folio can't be null");
							}
						} else {
							returnValue = commonmethod.getJsonStatus1(402, "Improper data inserted",
									"Transaction type can't be null");
						}
					} else {
						returnValue = commonmethod.getJsonStatus1(402, "Improper data inserted",
								"Scheme name can't be null");
					}
				} else {
					System.out.println("Inside getplaceOrder(..) method ---> ");
					errjobj = commonmethod.getJsonStatus(401, "User Not Authorized", "Access Denied");
					jarray.put(errjobj);
				}

			} else {
				returnMessage.put("code", 454);
				returnMessage.put("description", "Invalid Parameter");
				returnMessage.put("message", data);
				jarray.put(returnMessage);
				System.out.println(jarray.toString());
				return jarray.toString();
			}
		} catch (SQLException e) {

			returnValue = commonmethod.getJsonStatus1(501, "Database connectivity issue or Timeouts.",
					"Database Error. Please try after some time.");
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (Exception e) {
			returnValue = commonmethod.getJsonStatus1(402, "Error in processing.",
					"MIS of Deal could not be fetched successfully.");
			e.printStackTrace();
			System.out.println(e.getMessage());
		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		return returnValue;
	}

	public JSONArray getPortfolio_old(String custid) throws SQLException, JSONException {
		JSONArray jsonArray = new JSONArray();
		JSONObject gobj = new JSONObject();
		gobj.put("code", 200);
		Connection connection = new DatabaseUtil().getConnection();
		Statement statement = connection.createStatement();// CUST_ID: 11111111
		String queryString = "select mf_scheme_name,category,sub_category,amount,average_cost_price,tran_date,value_to_nav,sum(unit) as Avg_Unit from MF_Transaction_Details where custid = '"
				+ custid + "' group by scheme_id";
		System.out.println("YYYYYYYYYYYYY" + queryString);
		ResultSet resultSet = statement.executeQuery(queryString);

		// String curr_pair = "", rate_for_buy = "", rate_for_sell = "",
		// deal_type = "";
		jsonArray.put(gobj);
		while (resultSet.next()) {
			/*
			 * curr_pair = resultSet.getString("curr_pair"); rate_for_buy =
			 * resultSet.getString("rate_for_buy"); rate_for_sell =
			 * resultSet.getString("rate_for_sell"); deal_type =
			 * resultSet.getString("deal_type");
			 */
			System.out.println("Quer sucess On p");
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("scheme_name", resultSet.getString("mf_scheme_name"));
			jsonObject.put("category", resultSet.getString("category"));
			jsonObject.put("sub_category", resultSet.getString("sub_category"));
			jsonObject.put("value_cost", resultSet.getString("amount"));

			jsonObject.put("average_cost", resultSet.getString("average_cost_price"));
			jsonObject.put("date_of_purchase", resultSet.getString("tran_date"));
			jsonObject.put("value_to_nav", resultSet.getString("value_to_nav"));
			double value = resultSet.getDouble("Avg_Unit") * 100;
			jsonObject.put("unit_held", String.valueOf(value));

			jsonObject.put("realised(profit/loss)", "Profit");
			jsonObject.put("realised(profit/loss)_percentage", "10%");
			jsonObject.put("research_view", "Buy");
			jsonArray.put(jsonObject);
		}
		return jsonArray;
	}

	// amar

	public JSONArray getPortfolio(String custid, Connection connection) throws SQLException, JSONException {
		JSONArray jsonArray = new JSONArray();
		String scheme_id = "";
		JSONObject gobj = new JSONObject();
		gobj.put("code", 200);
		Statement statement = null;

		ResultSet resultSet = null;
		ResultSet resultSet2 = null;
		try {
			if (connection == null || connection.isClosed()) {
				connection = new DatabaseUtil().getConnection();
			}
			statement = connection.createStatement();// CUST_ID: 11111111
			String queryString = "select scheme_id,sum(cast(unit as int)) as Avg_Unit from MF_Transaction_Details where custid='"
					+ custid + "' group by scheme_id";
			System.out.println("YYYYYYYYYYYYY" + queryString);
			resultSet = statement.executeQuery(queryString);

			// String curr_pair = "", rate_for_buy = "", rate_for_sell = "",
			// deal_type = "";
			jsonArray.put(gobj);
			while (resultSet.next()) {
				System.out.println("Quer sucess On p");

				JSONObject jsonObject = new JSONObject();
				scheme_id = resultSet.getString("scheme_id");
				jsonObject.put("scheme_id", scheme_id);
				double value = resultSet.getDouble("Avg_Unit") * 100;
				jsonObject.put("Avg_Unit", String.valueOf(value));

				String queryString2 = "select mf_scheme_name,category,sub_category,amount,average_cost_price,tran_date,value_to_nav from MF_Transaction_Details where custid = '"
						+ custid + "' AND scheme_id ='" + scheme_id + "'";
				System.out.println("Quer sucess On p2" + queryString2);

				resultSet2 = statement.executeQuery(queryString2);

				if (resultSet2.next()) {
					jsonObject.put("scheme_name", resultSet2.getString("mf_scheme_name"));
					jsonObject.put("category", resultSet2.getString("category"));
					jsonObject.put("sub_category", resultSet2.getString("sub_category"));
					jsonObject.put("value_cost", resultSet2.getString("amount"));

					jsonObject.put("average_cost", resultSet2.getString("average_cost_price"));
					jsonObject.put("date_of_purchase", resultSet2.getString("tran_date"));
					jsonObject.put("value_to_nav", resultSet2.getString("value_to_nav"));

					jsonObject.put("realised(profit/loss)", "Profit");
					jsonObject.put("realised(profit/loss)_percentage", "10%");
					jsonObject.put("research_view", "Buy");
					jsonArray.put(jsonObject);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (resultSet2 != null) {
					resultSet2.close();
				}
				if (statement != null) {
					statement.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return jsonArray;
	}

	public String placeOrder(Connection connection, String cust_id, String MF_scheme_name, String transaction_type,
			String folio, String joint_holder, String nominee_flag, String nominee_name, String nominee_relation,
			String nominee_dob, String investment_amount, String payment_source, String is_agent, String euin,
			String declaration, String units, String client_id) throws SQLException {
		System.out.println("---------- In side Place order method ---------");
		ResultSet rs = null;
		ResultSet rs2 = null;
		Statement statement = null;
		try {
			if (connection == null || connection.isClosed()) {
				connection = new DatabaseUtil().getConnection();

			}
			connection.setAutoCommit(false);
			String accountno = getAccountNo(cust_id, connection);

			if (accountno.equals("")) {
				CommonMethod commonmethod = new CommonMethod();
				JSONObject errjobj = new JSONObject();

				errjobj = commonmethod.getJsonStatus(401, "Customer ID doesnot Exists", "Invalid Data");
				return errjobj.toString();

			} else {

				Date date = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				sdf.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
				String sysdate = sdf.format(date);
				// String trandtl=getTransactionDtl();

				String query = "Select max(tranid) from MF_Transaction_Details";

				statement = connection.createStatement();
				rs = statement.executeQuery(query);

				int maxTranId = 0;
				while (rs.next()) {
					maxTranId = rs.getInt(1);
				}

				String q2 = "select * from mutual_fund_master where mf_scheme_name like '%e" + MF_scheme_name + "%'";

				rs2 = statement.executeQuery(q2);

				String schemid = "";
				while (rs2.next()) {
					schemid = rs.getString(1);
				}

				System.out.println("Max Transaction ID : " + maxTranId);
				JSONObject gobj = new JSONObject();
				JSONArray jarray = new JSONArray();
				gobj.put("code", 200);
				jarray.put(gobj);
				Boolean insertflag = statement.execute(
						"insert into MF_Transaction_Details (custid,scheme_id,mf_scheme_name,tran_type,tran_date,fund_name,amount,unit,selection_folio,selection_joint_holder,nominee_name,"
								+ "payment_source,EUIN,category,sub_category,average_cost_price,value_to_nav,units_held) values('"
								+ cust_id + "','" + schemid + "','" + MF_scheme_name + "','" + transaction_type + "','"
								+ sysdate + "','ICICI Prudential Mutual Fund','" + investment_amount + "','" + units
								+ "','" + folio + "','" + joint_holder + "','" + nominee_name + "'," + "'"
								+ payment_source + "','" + euin + "','Equity','Mid Cap','12.69','',1500.12)");

				JSONObject jsonObject = new JSONObject();
				jsonObject.put("message", "SUCCESS");
				jsonObject.put("date_of_transaction", sysdate);
				jsonObject.put("transaction_id", maxTranId);
				jsonObject.put("transaction_type", transaction_type);

				jsonObject.put("mf_scheme_name", MF_scheme_name);
				jsonObject.put("fund_name", "ICICI Prudential Mutual Fund");
				jsonObject.put("last_nav", "1.23"); // ----
				jsonObject.put("last_nav_date", "2016-02-01");
				jsonObject.put("div-reinvestment", "N");
				jsonObject.put("amount", investment_amount);
				jsonObject.put("premium_amount", "1000");
				jsonObject.put("unit", units);
				jsonObject.put("status", "Executed");
				jsonObject.put("tax_saving", "Tax Receipt");
				jsonObject.put("channel", "Web / SYS");

				connection.commit();

				String tranStatus = fundTransfer(accountno, client_id);
				System.out.println("Prudential tranStatus" + tranStatus);

				if (tranStatus.contains("Insufficient")) {
					System.out.println("Prudential insuffienct if");

					connection.rollback();
					connection = null;
					return tranStatus;

				} else if (tranStatus.contains("SUCCESS")) {
					System.out.println("Prudential success if");

					connection.commit();
					connection = null;
					return jsonObject.toString();

				} else {
					System.out.println("Prudential error if");

					connection.rollback();
					connection = null;
					return tranStatus;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (rs2 != null) {
					rs2.close();
				}
				if (statement != null) {
					statement.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	// url:/corporate_banking/icicibank/invalidateToken?client_id=test@abc.com&token=test

	public String checkvalidation(String MF_scheme_name, String cust_id, String transaction_type, String folio,
			String joint_holder, String nominee_flag, String nominee_relation, String nominee_dob,
			String investment_amount, String payment_source, String is_agent, String euin, String declaration,
			String units) {
		String regex1 = "^[a-zA-Z0-9]*$";
		String regex2 = "^[0-9]*$";
		String regex3 = "^[a-zA-Z]*$";
		String result = "";
		JSONObject errjobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		CommonMethod commonmethod = new CommonMethod();
		try {
			// if(MF_scheme_name.equalsIgnoreCase("") &&
			// cust_id.equalsIgnoreCase("") && )
		} // try
		catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/*
	 * public String fundTransfer(String accountno) {
	 * 
	 * System.out.println("---------- Fund Transfer -----------"+accountno);
	 * 
	 * String email="test@abc.com"; String token="f5316a5e35a4"; String
	 * srcAccount=accountno; String destAccount="5555666677779999"; String
	 * amt="5000"; String payeeDesc="icici"; String payeeId="1"; String
	 * type_of_transaction="purchase product";
	 * 
	 * 
	 * GenericClass genericClass = new GenericClass(); String returnMessage =
	 * ""; JSONArray jarr=new JSONArray(); ArrayList<String> type_tran=new
	 * ArrayList<String>(); // jarr.add(gobj);
	 * System.out.println("Validation Details " + email + " userid is " +
	 * token);
	 * 
	 * type_tran.add("pmr"); type_tran.add("dth");
	 * type_tran.add("school fee payment"); type_tran.add("Movie Ticket");
	 * type_tran.add("electricity"); type_tran.add("restaurant ticket");
	 * type_tran.add("Fuel"); type_tran.add("groceries");
	 * type_tran.add("home loan emi"); type_tran.add("insurance payment");
	 * type_tran.add("car insurance"); type_tran.add("mf payments");
	 * type_tran.add("purchase product"); Boolean flag = true;
	 * 
	 * if (flag) { try {
	 * 
	 * if (srcAccount.equals("") || destAccount.equals("") || amt.equals("") ||
	 * payeeDesc.equals("") || payeeId.equals("") ||
	 * type_of_transaction.equals("")) { returnMessage = genericClass
	 * .getJsonErr(400, "Bad request.", "Please enter all required values."); }
	 * else if (!NumberUtils.isNumber(amt) || Double.parseDouble(amt) <= 0) {
	 * returnMessage = genericClass.getJsonErr(400, "Bad request.",
	 * "Invalid Amount."); } else
	 * if(!type_tran.contains(type_of_transaction.toLowerCase())) {
	 * 
	 * returnMessage = genericClass.getJsonErr(400, "Bad request.",
	 * "Type of Transaction should be from list");
	 * 
	 * }
	 * 
	 * 
	 * else { // Validate if source account exists boolean srcAccountExists =
	 * genericClass .chkIfAccountExists(srcAccount); if (srcAccountExists) { //
	 * Validate if Payee is listed in Payee list based on // Customer ID. String
	 * srcCustId = genericClass.getCustId(srcAccount); String payeenamedb =
	 * genericClass .chkIfPayeeExists(destAccount, srcCustId);
	 * 
	 * if (!payeenamedb.equalsIgnoreCase("")) { // Check if enough balance is
	 * available in source // account to transfer. double srcBalance =
	 * genericClass .getBalance(srcAccount); boolean balanceAvailable =
	 * (srcBalance < Double .parseDouble(amt)) ? false : true;
	 * 
	 * if (balanceAvailable) { // Fetch details to enter in Transaction & //
	 * Account details table. String destCustId = genericClass
	 * .getCustId(destAccount);
	 * 
	 * Date todaysDate = new Date(); String todaysDate_SQLFormatted =
	 * genericClass .getSQLDate(todaysDate); System.out
	 * .println("---------- todaysDate_SQLFormatted -------" +
	 * todaysDate_SQLFormatted); // Make Transaction entries //Source
	 * transaction entry String tranid = genericClass
	 * .addTransactionDtl(srcCustId, Double.parseDouble(amt), "0",
	 * todaysDate_SQLFormatted, srcAccount, destAccount, srcAccount,
	 * "Dr.",srcBalance,type_of_transaction); String destAccTran_ReturnVal =
	 * genericClass .addTransactionDtl(destCustId, Double.parseDouble(amt), "0",
	 * todaysDate_SQLFormatted, srcAccount, destAccount, destAccount,
	 * "Cr.",srcBalance,type_of_transaction);
	 * 
	 * // Make Account Balance Updates double newSrcBalance = srcBalance -
	 * Double.parseDouble(amt); int srcBalanceUpdateResult = genericClass
	 * .updateBalance(srcAccount, newSrcBalance);
	 * 
	 * double destBalance = genericClass .getBalance(destAccount); double
	 * newDestBalance = destBalance + Double.parseDouble(amt); int
	 * destBalanceUpdateResult = genericClass .updateBalance(destAccount,
	 * newDestBalance);
	 * 
	 * System.out.println("tranid: " + tranid + " destAccTran_ReturnVal: " +
	 * destAccTran_ReturnVal + " srcBalanceUpdateResult: " +
	 * srcBalanceUpdateResult + " destBalanceUpdateResult: " +
	 * destBalanceUpdateResult);
	 * 
	 * JSONObject js=new JSONObject(); js.put("transaction_amount", amt+".00");
	 * js.put("status", "SUCCESS"); js.put("destination_accountno",
	 * destAccount); js.put("payee_name", payeenamedb); js.put("payee_id", "1");
	 * js.put("transaction_date", todaysDate_SQLFormatted);
	 * js.put("referance_no", tranid); jarr.add(js); returnMessage =
	 * jarr.toString(); } else { returnMessage = genericClass.getJsonErr(402,
	 * "Error in processing.", "Insufficient Balance"); } } else { returnMessage
	 * = genericClass.getJsonErr(402, "Error in processing.",
	 * "Destination Account doesn't exist."); } } else { returnMessage =
	 * genericClass.getJsonErr(402, "Error in processing.",
	 * "Source account doesn't exist."); }
	 * 
	 * } } catch (SQLException e) { returnMessage = genericClass.getJsonErr(402,
	 * "Error in processing.", "Fund Transfer failed."); e.printStackTrace();
	 * System.out.println(e.getMessage()); } catch (Exception e) { returnMessage
	 * = genericClass.getJsonErr(402, "Error in processing.",
	 * "Fund Transfer failed."); e.printStackTrace();
	 * System.out.println(e.getMessage()); } } else {
	 * System.out.println("Token Verification Failed."); returnMessage =
	 * genericClass.getJsonErr(401, "User Not Authorized", "Access Denied");
	 * 
	 * } System.out.println("returnMessage: " + returnMessage); return
	 * returnMessage; }
	 * 
	 */

	public String fundTransfer(String srcAccount, String client_id) throws JSONException {

		CommonMethod comn = new CommonMethod();
		Boolean accflag = false;
		GenericClass genericClass = new GenericClass();
		String returnMessage = "";
		JSONArray jarr = new JSONArray();
		Connection connection = null;
		//
		try {
			DatabaseUtil util = new DatabaseUtil();
			if (connection == null || connection.isClosed()) {
				connection = util.getConnection();
				System.out.println("Inside fundTransfer connection open -->: " + connection);
			}
			if (!comn.authenticateCustid("A", srcAccount, client_id, connection)) {

				returnMessage = genericClass.getJsonErr(401, "User Not Authorized",
						"This Account Number does not belongs to participant");
				System.out.println(returnMessage.toString() + " -- " + srcAccount);

			} else {
				// Validate if source account exists
				boolean srcAccountExists = genericClass.chkIfAccountExists(srcAccount, connection);
				if (srcAccountExists) {
					// Validate if Payee is listed in Payee list based on
					// Customer ID.
					String srcCustId = genericClass.getCustId(srcAccount, connection);
					String payeenamedb = genericClass.chkIfPayeeExists("5555666677770002", srcCustId, connection);

					if (!payeenamedb.equalsIgnoreCase("")) {
						// Check if enough balance is available in source
						// account to transfer.
						double srcBalance = genericClass.getBalance(srcAccount, connection);
						boolean balanceAvailable = (srcBalance < Double.parseDouble("5000")) ? false : true;

						if (balanceAvailable) {
							// Fetch details to enter in Transaction &
							// Account details table.
							String destCustId = genericClass.getCustId("5555666677770002", connection);

							Date todaysDate = new Date();
							String todaysDate_SQLFormatted = genericClass.getSQLDate(todaysDate);
							System.out.println("---------- todaysDate_SQLFormatted -------" + todaysDate_SQLFormatted);
							// Make Transaction entries
							// Source transaction entry
							String tranid = genericClass.addTransactionDtl(srcCustId, Double.parseDouble("5000"), "0",
									todaysDate_SQLFormatted, srcAccount, "5555666677770002", srcAccount, "Dr.",
									srcBalance, "purchase product", connection);
							String destAccTran_ReturnVal = genericClass.addTransactionDtl(destCustId,
									Double.parseDouble("5000"), "0", todaysDate_SQLFormatted, srcAccount,
									"5555666677770002", "5555666677770002", "Cr.", srcBalance, "purchase product",
									connection);

							// Make Account Balance Updates
							double newSrcBalance = srcBalance - Double.parseDouble("5000");
							int srcBalanceUpdateResult = genericClass.updateBalance(srcAccount, newSrcBalance,
									connection);

							double destBalance = genericClass.getBalance("5555666677770002", connection);
							double newDestBalance = destBalance + Double.parseDouble("5000");
							int destBalanceUpdateResult = genericClass.updateBalance("5555666677770002", newDestBalance,
									connection);

							System.out.println("tranid: " + tranid + " destAccTran_ReturnVal: " + destAccTran_ReturnVal
									+ " srcBalanceUpdateResult: " + srcBalanceUpdateResult
									+ " destBalanceUpdateResult: " + destBalanceUpdateResult);

							JSONObject js = new JSONObject();
							js.put("transaction_amount", "5000.00");
							js.put("status", "SUCCESS");
							js.put("destination_accountno", "5555666677770002");
							js.put("payee_name", payeenamedb);
							js.put("payee_id", 1);
							js.put("transaction_date", todaysDate_SQLFormatted);
							js.put("referance_no", tranid);
							jarr.put(js);
							returnMessage = jarr.toString();
						} else {
							returnMessage = genericClass.getJsonErr(402, "Error in processing.",
									"Insufficient Balance");
						}
					} else {
						returnMessage = genericClass.getJsonErr(402, "Error in processing.",
								"Destination Account doesn't exist.");
					}
				} else {
					returnMessage = genericClass.getJsonErr(402, "Error in processing.",
							"Source account doesn't exist.");
				}

			}
		} catch (SQLException e) {
			returnMessage = genericClass.getJsonErr(402, "Error in processing.", "Fund Transfer failed.");
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (Exception e) {
			returnMessage = genericClass.getJsonErr(402, "Error in processing.",
					"Fund Transfer failed. Please check URL parameters.");
			e.printStackTrace();
			System.out.println(e.getMessage());
		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		System.out.println("returnMessage: " + returnMessage);
		return returnMessage;
	}

	public String getAccountNo(String cust_id, Connection connection) throws SQLException {
		System.out.println("-------------Get Account No--------------Cust id : " + cust_id);
		ResultSet rs = null;
		Statement statement = null;
		if (connection == null || connection.isClosed()) {
			connection = new DatabaseUtil().getConnection();
		}

		String accountNo = "";
		statement = connection.createStatement();
		rs = statement.executeQuery("select accountNo from Rtl_Account_Master where custId ='" + cust_id + "'");
		while (rs.next()) {
			accountNo = rs.getString("accountNo");
		}
		System.out.println("---Cust id : " + cust_id + " Account no" + accountNo);
		statement.close();
		return accountNo;
	}

	// place equity cash Order
	@GET
	@Path("/NetworthWithAssetAllocation")
	@Produces
	public String NetworthWithAssetAllocation(@Context UriInfo uriInfo, @QueryParam("client_id") String email,
			@QueryParam("token") String token, @QueryParam("accountno") String accountno) throws JSONException {
		Connection connection = null;
		Statement statement = null;
		ResultSet rs = null;
		CommonMethod comn = new CommonMethod();
		// String result = "";
		DatabaseUtil dbUtil = new DatabaseUtil();
		JSONObject jobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		CommonMethod comm = new CommonMethod();
		boolean flag = false;
		String acc_no;
		try {
			HashSet<String> set = new HashSet<String>();
			set.add("client_id");
			set.add("token");
			set.add("accountno");
			String data = comn.keyvalidation(uriInfo, set);
			if (data.equalsIgnoreCase("ok")) {
				if (connection == null || connection.isClosed()) {
					System.out.println("Inside account summary connection open : " + connection);
					connection = dbUtil.getConnection();
				}
				flag = validateClient(email, token, "PlaceEquityCashOrder", connection);
				if (flag) {
					if (!accountno.equals("")) {
						if (validateAccountno(accountno)) {
							System.out.println(accountno);
							System.out.println(
									"query------------select accountno from rtl_account_master where accountno ='"
											+ accountno + "'");
							statement = connection.createStatement();
							rs = statement.executeQuery(
									"select accountno from rtl_account_master where accountno='" + accountno + "'");

							if (rs.next()) {
								System.out.println("Inside While");
								acc_no = rs.getString("accountno");
								System.out.println("account no =" + acc_no);
								int int_accountno = Integer.parseInt(acc_no.substring(11));
								System.out.println("account no substring =" + int_accountno);

								if (int_accountno % 4 == 1) {
									System.out.println("You entered an 1 number.");
									jobj.put("code", 200);

									jobj.put("accountno", acc_no);
									jobj.put("Allocation in Equity", "2,64,96,181.13");
									jobj.put("Allocation in  Debt", "1,22,917.31");
									jobj.put("Allocation in  Cash or Liquid and Gold", "8,526.24");
									jobj.put("Allocation Total", "2,66,27,624.68");

									jobj.put("Allocation Equity in %", "99.51");
									jobj.put("Allocation Debt in %", "0.46");
									jobj.put("Allocation Cash or Liquid and Gold in in %", "0.03");
									jobj.put("Allocation Total in %", "100");
									jarray.put(jobj);
								}
								if (int_accountno % 4 == 2) {
									System.out.println("You entered an 2 number.");
									jobj.put("code", 200);
									jobj.put("accountno", acc_no);
									jobj.put("Allocation in Equity", "1218.35");
									jobj.put("Allocation in  Debt", "0");
									jobj.put("Allocation in  Cash or Liquid and Gold", "855.75");
									jobj.put("Allocation Total", "2074.1");

									jobj.put("Allocation Equity in %", "58.74");
									jobj.put("Allocation Debt in %", "0");
									jobj.put("Allocation Cash or Liquid and Gold in in %", "41.26");
									jobj.put("Allocation Total in %", "100");
									jarray.put(jobj);
								}
								if (int_accountno % 4 == 3) {
									System.out.println("You entered an 3 number.");
									jobj.put("code", 200);
									jobj.put("accountno", acc_no);
									jobj.put("Allocation in Equity", "526048308.48");
									jobj.put("Allocation in  Debt", "34741422.87");
									jobj.put("Allocation in  Cash or Liquid and Gold", "70872502.65");
									jobj.put("Allocation Total", "631662234");

									jobj.put("Allocation Equity in %", "83.28");
									jobj.put("Allocation Debt in %", "5.5");
									jobj.put("Allocation Cash or Liquid and Gold in in %", "11.22");
									jobj.put("Allocation Total in %", "100");
									jarray.put(jobj);
								} else {
									System.out.println("You entered an 4 number.");
									jobj.put("code", 200);
									jobj.put("accountno", acc_no);
									jobj.put("Allocation in Equity", "286936081.69");
									jobj.put("Allocation in  Debt", "29237118.71");
									jobj.put("Allocation in  Cash or Liquid and Gold", "58661654.85");
									jobj.put("Allocation Total", "374834855.25");

									jobj.put("Allocation Equity in %", "76.55");
									jobj.put("Allocation Debt in %", "7.8");
									jobj.put("Allocation Cash or Liquid and Gold in in %", "15.65");
									jobj.put("Allocation Total in %", "100");
									jarray.put(jobj);
								}
							} else {
								returnMessage = comm.getJsonErr(503, "",
										"This Account No ID does not belongs to participant");
							}
						} else {
							returnMessage = comm.getJsonErr(401, "User Not Authorized",
									"This Account No does not belongs to participant");
						}
					}
				} else {
					returnMessage = comm.getJsonErr(400, "Bad request. Request parameter are not provided.",
							"Account no should be 16 Digits & can contain only Numbers");
				}

				/*
				 * { System.out.println("Token Verification Failed.");
				 * returnMessage = comm.getJsonErr(401, "User Not Authorized",
				 * "Access Denied"); jarray.put(returnMessage); }
				 */
				if (jarray.length() == 0) {
					jarray.put(returnMessage);
				}
			} else {
				returnMessage.put("code", 454);
				returnMessage.put("description", "Invalid Parameter");
				returnMessage.put("message", data);
				jarray.put(returnMessage);
				System.out.println(jarray.toString());
				return jarray.toString();
			}
		} catch (SQLException e) {
			returnMessage = comm.getJsonErr(501,
					"Processing error � One or more of internal systems gave an error while processing the request",
					"Database Error. Please try after some time");
			e.printStackTrace();
			System.out.println("Errorrr : " + e);
			// returnMessage =
			// getJsonErr(400,"","Database Error. Please try after
			// some time");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		System.out.println("Client_id : " + email);
		System.out.println("Response : " + jarray.toString());
		return jarray.toString();
	}

	public Boolean validateAccountno(String accountno) {
		System.out.println("inside custid validation");
		String regex = "[0-9]+";
		if (accountno.length() == 16) {
			if (accountno.matches(regex)) {
				System.out.println("inside regex matching ");
				return true;
			} else {
				return false;
			}
		} else {
			System.out.println("inside else condition");
			return false;
		}
	}

}

/*
 * public boolean validateClient(String client_id,String token) { Connection
 * connection = null; CommonMethod commonmethod = new CommonMethod(); JSONObject
 * errjobj = new JSONObject(); JSONArray jarray = new JSONArray(); ResultSet rs
 * = null; Statement statement = null; PreparedStatement pstatement = null; int
 * count = 0; // String client_id = ""; String result = ""; String query = "";
 * boolean flag = false; String current_time = null;
 * System.out.println("Inside validateClient(..) method client_id is "
 * +client_id+" token is "+token); try { // if(connection == null ||
 * connection.isClosed()){ connection = DatabaseUtil.getConnection(); Date
 * currdate = new Date(); SimpleDateFormat formatter = new
 * SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
 * formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata")); current_time =
 * formatter.format(currdate); // } if (!client_id.equals("")) {
 * if(!token.equals("")){ // query =
 * "select client_id,token from participant_token_details where client_id='"
 * +client_id+"' and token='"
 * +token+"' and (SELECT MINUTE(expiry_time) - MINUTE('"
 * +current_time+"') FROM SYSIBM.SYSDUMMY1) > 0"; query =
 * "select client_id,token from participant_token_details where client_id='"
 * +client_id+"' and token='"
 * +token+"' and (SELECT timestampdiff (4, char(timestamp(p.expiry_time)-timestamp('"
 * +current_time+"'))) FROM participant_token_details p, SYSIBM.SYSDUMMY1 where p.client_id='"
 * +client_id+"' and p.token='"+token+"') >0";
 * 
 * System.out.println("VALIDATE_____________"+query); statement =
 * connection.createStatement(); rs = statement.executeQuery(query);
 * 
 * while (rs.next()) {
 * System.out.println("****************************************************");
 * JSONObject jobj = new JSONObject(); jobj.put("client_id", rs.getString(1));
 * jobj.put("token", rs.getString(2)); jarray.put(jobj); } if(jarray.length() !=
 * 0){ flag = true; } System.out.println("validate-"+flag); return flag; } else{
 * System.out.
 * println("Inside validateClient(..) method ---> token input is found blank");
 * errjobj = commonmethod.getJsonStatus(400, "Bad request",
 * "Token should not be blank"); jarray.put(errjobj); errjobj.put("ERROR",
 * "User Id cannot be blank"); jarray.put(errjobj); return flag; } } else{
 * System.out.
 * println("Inside validateClient(..) method ---> client_id id input is not set"
 * ); errjobj = commonmethod.getJsonStatus(400, "Bad request",
 * "client_id Id should not be blank"); jarray.put(errjobj);
 * errjobj.put("ERROR", "client_id Id cannot be blank"); jarray.put(errjobj);
 * return flag; } } catch (SQLException e) { e.printStackTrace(); return flag;
 * errjobj = commonmethod.getJsonStatus(501,
 * "Database connectivity issues or timeouts", "Please try after some time");
 * jarray.put(errjobj); errjobj.put("ERROR",
 * "Database Error,Please try after some time"); jarray.put(errjobj); }
 * catch(Exception e){ e.printStackTrace(); return flag; errjobj =
 * commonmethod.getJsonStatus(402, "Error in processing",
 * "Error while processing request"); jarray.put(errjobj); } finally{ try{
 * statement.close(); rs.close(); connection.close(); rs = null; statement =
 * null; connection = null; } catch(Exception e){ e.printStackTrace(); } //
 * return flag; } } }
 * 
 * 
 * //amar
 * 
 * public JSONArray getPortfolio(String custid,Connection connection) throws
 * SQLException{ JSONArray jsonArray = new JSONArray(); String scheme_id = "";
 * JSONObject gobj = new JSONObject(); gobj.put("code", 200); Statement
 * statement = null;
 * 
 * ResultSet resultSet = null; ResultSet resultSet2 = null; try{ if(connection
 * == null || connection.isClosed()){ connection = new
 * DatabaseUtil().getConnection(); } statement =
 * connection.createStatement();//CUST_ID: 11111111 String queryString =
 * "select scheme_id,sum(unit) as Avg_Unit from MF_Transaction_Details where custid = '"
 * +custid+"' group by scheme_id";
 * System.out.println("YYYYYYYYYYYYY"+queryString); resultSet =
 * statement.executeQuery(queryString);
 * 
 * // String curr_pair = "", rate_for_buy = "", rate_for_sell = "", deal_type =
 * ""; jsonArray.put(gobj); while(resultSet.next()){
 * System.out.println("Quer sucess On p");
 * 
 * JSONObject jsonObject = new JSONObject(); scheme_id =
 * resultSet.getString("scheme_id"); jsonObject.put("scheme_id",scheme_id);
 * double value = resultSet.getDouble("Avg_Unit")*100;
 * jsonObject.put("Avg_Unit",String.valueOf(value) );
 * 
 * 
 * 
 * String queryString2 =
 * "select mf_scheme_name,category,sub_category,amount,average_cost_price,tran_date,value_to_nav from MF_Transaction_Details where custid = '"
 * +custid+"' AND scheme_id ='"+scheme_id+"'";
 * System.out.println("Quer sucess On p2"+queryString2);
 * 
 * resultSet2 = statement.executeQuery(queryString2);
 * 
 * if(resultSet2.next()){ jsonObject.put("scheme_name",
 * resultSet2.getString("mf_scheme_name")); jsonObject.put("category",
 * resultSet2.getString("category")); jsonObject.put("sub_category",
 * resultSet2.getString("sub_category")); jsonObject.put("value_cost",
 * resultSet2.getString("amount"));
 * 
 * jsonObject.put("average_cost", resultSet2.getString("average_cost_price"));
 * jsonObject.put("date_of_purchase", resultSet2.getString("tran_date"));
 * jsonObject.put("value_to_nav", resultSet2.getString("value_to_nav"));
 * 
 * jsonObject.put("realised(profit/loss)", "Profit");
 * jsonObject.put("realised(profit/loss)_percentage", "10%");
 * jsonObject.put("research_view", "Buy"); jsonArray.put(jsonObject); } } }
 * catch(Exception e){ e.printStackTrace(); } finally{ try{ if(resultSet !=
 * null){ resultSet.close(); } if(resultSet2 != null){ resultSet2.close(); }
 * if(statement != null){ statement.close(); } } catch(Exception e){
 * e.printStackTrace(); } } return jsonArray; }
 * 
 * 
 */
