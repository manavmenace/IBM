package appathon.bluemix.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import java.util.logging.Logger;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@Path("/icici")
public class UpiMain {
	private static final Logger logger = Logger.getLogger(UpiMain.class.getName());

	public UpiMain() throws JSONException {
		logger.info("-------------Constructor------------");
		gobj.put("code", 200);
		count = 0;
	}

	JSONObject returnMessage = new JSONObject();
	UpiDAO dao = new UpiDAO();
	JSONObject gobj = new JSONObject();
	boolean flag;
	public int count;

	// Method used to create new Virtual Payment Address(VPA)
	@GET
	@Path("/createVPA")
	@Produces
	public String createVPA(@QueryParam("client_id") String clientId, @QueryParam("token") String token,
			@QueryParam("accountno") String accountNo, @QueryParam("vpa") String vpa) throws JSONException {
		logger.info("Started Create VPA for account no :" + accountNo);
		DatabaseUtil dbUtil = new DatabaseUtil();
		Connection connection = null;
		Statement statement = null;
		ResultSet rs = null;
		JSONObject jObj = new JSONObject();
		JSONArray jArray = new JSONArray();
		String result = "";
		Boolean isValid = false;
		String response = "";
		String apiName = "createVPA";
		try {
			if (connection == null || connection.isClosed()) {
				connection = dbUtil.getConnection();
			}
			// validate client
			if (validateClient(clientId, token, apiName, connection)) {
				if (accountNo != null && !accountNo.isEmpty()) {
					vpa = vpa.toLowerCase();
					// validate AccountNo and VPA
					isValid = validateDetails(clientId, accountNo, vpa);
					if (isValid) {
						// map VPA to Account Number
						response = dao.mapVPAToAccount(accountNo, vpa);
						if (response.equals("success")) {
							jArray.put(gobj);
							jObj.put("response", "VPA " + vpa + " mapped successfully for account no " + accountNo);
							jArray.put(jObj);
						}
					}
				} else {
					returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.",
							"Customer ID cannot be null");
				}
			} else {
				logger.info("Token Verification Failed.");
				returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			returnMessage = getJsonErr(501,
					"Processing error � One or more of internal systems gave an error while processing the request",
					"Database Error. Please try after some time");
		} catch (Exception ex) {
			ex.printStackTrace();
			returnMessage = getJsonErr(501,
					"Processing error � One or more of internal systems gave an error while processing the request",
					"Database Error. Please try after some time");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (jArray.length() == 0) {
			jArray.put(returnMessage);
			result = jArray.toString();
		} else {
			result = jArray.toString();
		}
		logger.info("Response in createVPA" + result);
		return result;
	}

	// Method used to transfer fund using UPI from VPA to VPA
	@GET
	@Path("/upiFundTransferVToV")
	@Produces
	public String upiFundTransferVToV(@QueryParam("client_id") String clientId, @QueryParam("token") String token,
			@QueryParam("payerCustId") String payerCustId, @QueryParam("payerVPA") String payerVPA,
			@QueryParam("payeeVPA") String payeeVPA, @QueryParam("amount") String amount,
			@QueryParam("remarks") String remarks) throws JSONException {
		logger.info("Started Fund Transfer using UPI from payer VPA: " + payerVPA + " to payee VPA: " + payeeVPA);
		DatabaseUtil dbUtil = new DatabaseUtil();
		Connection connection = null;
		Statement statement = null;
		ResultSet rs = null;
		JSONObject jObj = new JSONObject();
		JSONArray jArray = new JSONArray();
		String response = "";
		Boolean isValidCustId = false;
		String apiName = "upiFundTransferVToV";
		try {
			if (connection == null || connection.isClosed()) {
				connection = dbUtil.getConnection();
			}
			// validate client
			if (validateClient(clientId, token, apiName, connection)) {
				if (payerCustId != null && !payerCustId.isEmpty()) {
					// authenticate custId
					isValidCustId = authenticateCustId(payerCustId, clientId, connection);
					if (isValidCustId) {
						payerVPA = payerVPA.toLowerCase();
						payeeVPA = payeeVPA.toLowerCase();
						// validate payer and payee VPAs
						if (validateVPAs(payerVPA, payeeVPA, payerCustId, clientId, apiName)) {
							if (amount != null && !amount.isEmpty() && amount.matches("^[0-9]+(\\.[0-9]{1,2})?$")) {
								// get cust ids and account numbers
								String payeeCustId = dao.getCustIdByVpa(payeeVPA, clientId, connection);
								String payerAccount = dao.getAccNoByCustId(payerCustId, connection);
								String payeeAccount = dao.getAccNoByCustId(payeeCustId, connection);
								String payeeName = dao.getPayeeName(payeeAccount, payerCustId);
								// check if there is sufficient balance in payer
								// account to transfer amount
								Double payerBalance = dao.getBalance(payerAccount, connection);
								Boolean balanceAvailable = (payerBalance < Double.parseDouble(amount)) ? false : true;
								if (balanceAvailable) {
									Date todaysDate = new Date();
									String todaysDate_SQLFormatted = getSQLDate(todaysDate);
									/*
									 * System.out.println(
									 * "---------- todaysDate_SQLFormatted -------"
									 * + todaysDate_SQLFormatted);
									 */
									// save transaction details in database and
									// get transaction Id
									String tranId = dao.addTransactionDtl(payerCustId, Double.parseDouble(amount), "0",
											todaysDate_SQLFormatted, payerAccount, payeeAccount, payerAccount, "Dr.",
											payerBalance, "UPI to UPI Transfer", remarks, connection);
									String payeeAccTran_ReturnVal = dao.addTransactionDtl(payeeCustId,
											Double.parseDouble(amount), "0", todaysDate_SQLFormatted, payerAccount,
											payeeAccount, payeeAccount, "Cr.", payerBalance, "UPI to UPI Transfer",
											remarks, connection);
									// Make Account Balance Updates
									Double newSrcBalance = payerBalance - Double.parseDouble(amount);
									Integer payerBalanceUpdateResult = dao.updateBalance(payerAccount, newSrcBalance,
											connection);
									Double destBalance = dao.getBalance(payeeAccount, connection);
									Double newDestBalance = destBalance + Double.parseDouble(amount);
									Integer payeeBalanceUpdateResult = dao.updateBalance(payeeAccount, newDestBalance,
											connection);
									logger.info(
											"tranid: " + tranId + " payeeAccTran_ReturnVal: " + payeeAccTran_ReturnVal
													+ " payerBalanceUpdateResult: " + payerBalanceUpdateResult
													+ " payeeBalanceUpdateResult: " + payeeBalanceUpdateResult);
									jArray.put(gobj);
									jObj.put("payee_VPA", payeeVPA);
									jObj.put("transaction_date", todaysDate_SQLFormatted);
									jObj.put("transaction_id", tranId);
									jObj.put("transaction_amount", amount);
									jObj.put("payee_name", payeeName);
									jObj.put("status", "SUCCESS");
									jArray.put(jObj);
								} else {
									returnMessage = getJsonErr(402, "Error in processing.", "Insufficient Balance");
								}
							} else {
								returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.",
										"Invalid Amount entered.");
							}
						}
					} else {
						returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.",
								"Customer ID invalid. It should be 8 Digits & can contain only Numbers");
					}
				} else {
					returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.",
							"Customer ID cannot be null");
				}
			} else {
				logger.info("Token Verification Failed.");
				returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			returnMessage = getJsonErr(501,
					"Processing error � One or more of internal systems gave an error while processing the request",
					"Database Error. Please try after some time");
		} catch (Exception ex) {
			ex.printStackTrace();
			returnMessage = getJsonErr(501,
					"Processing error � One or more of internal systems gave an error while processing the request",
					"Database Error. Please try after some time");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (jArray.length() == 0) {
			jArray.put(returnMessage);
			response = jArray.toString();
		} else {
			response = jArray.toString();
		}
		logger.info("Response in upiFundTransferVToV" + response);
		return response;
	}

	// Method used to transfer fund using UPI from VPA to Account Number
	@GET
	@Path("/upiFundTransferVToA")
	@Produces
	public String upiFundTransferVToA(@QueryParam("client_id") String clientId, @QueryParam("token") String token,
			@QueryParam("payerCustId") String payerCustId, @QueryParam("payerVPA") String payerVPA,
			@QueryParam("payeeAccount") String payeeAccount, @QueryParam("amount") String amount,
			@QueryParam("remarks") String remarks) {
		logger.info(
				"Started Fund Transfer using UPI from payer VPA: " + payerVPA + " to payee Account: " + payeeAccount);
		DatabaseUtil util = new DatabaseUtil();
		Connection connection = null;
		JSONObject jObj = new JSONObject();
		JSONArray jArray = new JSONArray();
		String response = "";
		String apiName = "upiFundTransferVToA";
		try {
			if (connection == null || connection.isClosed()) {
				connection = util.getConnection();
			}
			// validate client
			flag = validateClient(clientId, token, apiName, connection);
			if (flag) {
				// get payer account number
				String payerAccount = dao.getAccNoByCustId(payerCustId, connection);
				// validate details
				if (payerVPA.equals("") || payeeAccount.equals("") || amount.equals("")) {
					returnMessage = getJsonErr(400, "Bad request.", "Please enter all required values.");
				} else if (!validateVPAs(payerVPA, "", payerCustId, clientId, "VPA_To_Account")) {
					// error messages inside validate method.
				} else if (Double.parseDouble(amount) <= 0) {
					returnMessage = getJsonErr(400, "Bad request.", "Invalid Amount.");
				} else if (!dao.validateAccountNo(payerAccount, clientId)) {
					returnMessage = getJsonErr(401, "User Not Authorized",
							"This Account Number does not belongs to participant");
				} else {
					// validate if Payee is listed in Payee list based on
					// Customer ID.
					String payeeName = dao.getPayeeName(payeeAccount, payerCustId);
					if (!payeeName.equalsIgnoreCase("")) {
						// check if enough balance is available in source
						// account to transfer.
						Double payerBalance = dao.getBalance(payerAccount, connection);
						Boolean balanceAvailable = (payerBalance < Double.parseDouble(amount)) ? false : true;
						if (balanceAvailable) {
							// fetch details to enter in Transaction & Account
							// details table.
							String destCustId = dao.getCustIdByAccNo(payeeAccount, connection);
							Date todaysDate = new Date();
							String todaysDate_SQLFormatted = getSQLDate(todaysDate);
							/*
							 * System.out.
							 * println("---------- todaysDate_SQLFormatted -------"
							 * + todaysDate_SQLFormatted);
							 */
							// Make Transaction entries
							String tranId = dao.addTransactionDtl(payerCustId, Double.parseDouble(amount), "0",
									todaysDate_SQLFormatted, payerAccount, payeeAccount, payerAccount, "Dr.",
									payerBalance, "UPI to Account Transfer", remarks, connection);
							String payeeAccTran_ReturnVal = dao.addTransactionDtl(destCustId,
									Double.parseDouble(amount), "0", todaysDate_SQLFormatted, payerAccount,
									payeeAccount, payeeAccount, "Cr.", payerBalance, "UPI to Account Transfer", remarks,
									connection);
							// Make Account Balance Updates
							Double newPayerBalance = payerBalance - Double.parseDouble(amount);
							Integer payerBalanceUpdateResult = dao.updateBalance(payerAccount, newPayerBalance,
									connection);
							Double payeeBalance = dao.getBalance(payeeAccount, connection);
							Double newPayeeBalance = payeeBalance + Double.parseDouble(amount);
							Integer payeeBalanceUpdateResult = dao.updateBalance(payeeAccount, newPayeeBalance,
									connection);
							logger.info("tranid: " + tranId + " payeeAccTran_ReturnVal: " + payeeAccTran_ReturnVal
									+ " payerBalanceUpdateResult: " + payerBalanceUpdateResult
									+ " payeeBalanceUpdateResult: " + payeeBalanceUpdateResult);
							jArray.put(gobj);
							/*
							 * jObj.put("payee_VPA", payeeVPA);
							 * jObj.put("transaction_date",
							 * todaysDate_SQLFormatted);
							 * jObj.put("transaction_id", tranId);
							 * jObj.put("transaction_amount", amount + ".00");
							 * jObj.put("payee_name", payeenamedb);
							 * jObj.put("status", "SUCCESS"); jArray.add(jObj);
							 */
							jObj.put("payeeAccount", payeeAccount);
							jObj.put("transaction_date", todaysDate_SQLFormatted);
							jObj.put("transaction_id", tranId);
							jObj.put("transaction_amount", amount);
							jObj.put("payee_name", payeeName);
							jObj.put("status", "SUCCESS");
							jArray.put(jObj);
						} else {
							returnMessage = getJsonErr(402, "Error in processing.", "Insufficient Balance");
						}
					} else {
						returnMessage = getJsonErr(402, "Error in processing.",
								"Account Number " + payeeAccount + " does not exist in your Payee List.");
					}
				}
			} else {
				logger.info("Token Verification Failed.");
				returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
			}
		} catch (SQLException e) {
			try {
				returnMessage = getJsonErr(402, "Error in processing.", "Fund Transfer failed.");
			} catch (JSONException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
			logger.info(e.getMessage());
		} catch (Exception e) {
			try {
				returnMessage = getJsonErr(402, "Error in processing.",
						"Fund Transfer failed. Please check URL parameters.");
			} catch (JSONException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
			logger.info(e.getMessage());
		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (jArray.length() == 0) {
			jArray.put(returnMessage);
			response = jArray.toString();
		} else {
			response = jArray.toString();
		}
		logger.info("Response in upiFundTransferVToA" + response);
		return response;
	}

	// Method used to validate Client Id and Token
	public Boolean validateClient(String client_id, String token, String apiName, Connection connection) {
		logger.info(
				"Inside validateClient method LOWER(client_id) is " + client_id.toLowerCase() + " token is " + token);
		DatabaseUtil dbUtil = new DatabaseUtil();
		ResultSet rs = null;
		Statement statement = null;
		JSONArray jarray = new JSONArray();
		String query = "";
		Boolean flag = false;
		try {
			logger.info("Validate Connection Accept : " + connection);
			if (connection == null || connection.isClosed()) {
				connection = dbUtil.getConnection();
			}
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
			if (!client_id.equals("")) {
				if (!token.equals("")) {
					query = "select client_id, token from participant_token_details " + "where LOWER(client_id)='"
							+ client_id.toLowerCase() + "' and token ='" + token
							+ "'  and  EXPIRY_TIME > CURRENT_TIMESTAMP"; // For
																			// DB2
					logger.info("VALIDATE_____________" + query);
					statement = connection.createStatement();
					rs = statement.executeQuery(query);
					while (rs.next()) {
						logger.info("****************************************************");
						JSONObject jobj = new JSONObject();
						/*
						 * logger.info("client_id from DB::" + rs.getString(1));
						 * logger.info("token from DB::" + rs.getString(2));
						 */
						jobj.put("client_id", rs.getString(1));
						jobj.put("token", rs.getString(2));
						jarray.put(jobj);
					}
					if (jarray.length() != 0)

					{
						flag = true;
						setApiUsageStatus(client_id, apiName, connection); // Set
																			// API
																			// usage
					} else {
						returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
						jarray.put(returnMessage);
					}
					return flag;
				} else {
					logger.info("Inside validateClient(..) method ---> token input is found blank");
					return flag;
				}
			} else {
				logger.info("Inside validateClient(..) method ---> client_id id input is not set");
				return flag;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				returnMessage = getJsonErr(501,
						"Processing error � One or more of internal systems gave an error while processing the request",
						"Database Error. Please try after some time");
			} catch (JSONException e1) {
				e1.printStackTrace();
			}
			return flag;
		} catch (Exception e) {
			e.printStackTrace();
			return flag;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (statement != null) {
					statement.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public Boolean authenticateCustId(String custId, String client_id, Connection connection) {
		logger.info("------------ authenticateCustId--------------Cust Id : " + custId);
		String query = "Select CUSTID from PARTICIPANT_MASTER  where LOWER(CLIENT_ID)='" + client_id.toLowerCase()
				+ "'"; // For DB2
		/*
		 * String
		 * query="Select CUSTID from PARTICIPANT_MASTER  where LOWER(CLIENT_ID)='"
		 * + client_id.toLowerCase()+"'";
		 */ // For SQL
		DatabaseUtil util = new DatabaseUtil();
		String cust_ids = null;
		Statement statement = null;
		ResultSet rs = null;
		try {
			if (connection == null || connection.isClosed()) {
				connection = util.getConnection();
			}
			statement = connection.createStatement();
			rs = statement.executeQuery(query);
			while (rs.next()) {
				cust_ids = rs.getString("CUSTID");
			}
			logger.info("cust_ids : " + cust_ids);
			if (cust_ids.contains(custId)) {
				logger.info("Cust ID Successfully validated..");
				return true;
			} else {
				logger.info("Cust ID not validated..");
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (statement != null) {
					statement.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public Boolean validateDetails(String clientId, String accountNo, String vpa) throws JSONException {
		JSONArray jArray = new JSONArray();
		Boolean isValidDetails = false;
		// Account No
		if (accountNo != null && !accountNo.isEmpty()) {
			if (dao.validateAccountNo(accountNo, clientId)) {
				isValidDetails = true;
				logger.info("Account No validated successfully.");
			} else {
				try {
					returnMessage = getJsonErr(401, "User Not Authorized",
							"This Account Number does not belongs to participant");
				} catch (JSONException e) {
					e.printStackTrace();
				}
				jArray.put(returnMessage);
				logger.info(returnMessage.toString() + " -- " + accountNo);
				isValidDetails = false;
				return isValidDetails;
			}
		} else {
			logger.info("Account No cannot be blank!");
			try {
				returnMessage = getJsonErr(400, "Bad request. Invalid Request parameter",
						"Account Number cannot be blank");
			} catch (JSONException e) {
				e.printStackTrace();
			}
			jArray.put(returnMessage);
			isValidDetails = false;
			return isValidDetails;
		}
		// VPA
		if (vpa != null && !vpa.isEmpty()) {
			if ((vpa.endsWith("@icicibank") && vpa.length() > 10) || 
					(vpa.endsWith("@abcbank") && vpa.length() > 8 )) {
				int cnt = 0;
				for (int i = 0; i < vpa.length(); i++) {
					if (vpa.charAt(i) == '@') {
						cnt++;
					}
				}
				String vpaArr[] = vpa.split("@");
				String vpaBank = vpaArr[1].equals("icicibank") ? "ICICI" : "ABC";
				String validVpa = "";
				
				if (vpaArr[0].matches("^[a-zA-Z0-9]+.[a-zA-Z0-9]+$") && cnt == 1) {
					
					if (dao.isValidBankAccountMapping(vpaBank, accountNo)) {
						if (!dao.isVpaAlreadyExists(clientId, vpa)) {
							isValidDetails = true;
							logger.info("VPA validated successfully.");
						} else {
							logger.info("Same VPA already exists for user " + clientId);
							returnMessage = getJsonErr(400, "Bad request. Invalid Request parameter",
									"Same VPA already exists for user " + clientId);
							jArray.put(returnMessage);
							isValidDetails = false;
							return isValidDetails;
						}
					} else {
						logger.info("Invalid VPA " + vpa);
						
						validVpa = vpaArr[1].equals("icicibank") ? "example@abcbank" : "example@icicibank";
						
						returnMessage = getJsonErr(400, "Bad request. Invalid Request parameter",
								"Invalid VPA " + vpa + ".It should be in the format " + validVpa);
						jArray.put(returnMessage);
						isValidDetails = false;
						return isValidDetails;
					}
				} else {
					logger.info("Invalid VPA!" + vpa);
					try {
						returnMessage = getJsonErr(400, "Bad request. Invalid Request parameter",
								"Invalid VPA " + vpa + ". Only alphanumeric and dot(.) is allowed as name.");
					} catch (JSONException e) {
						e.printStackTrace();
					}
					jArray.put(returnMessage);
					isValidDetails = false;
					return isValidDetails;
				}
			} else {
				logger.info("Invalid VPA!" + vpa);
				try {
					returnMessage = getJsonErr(400, "Bad request. Invalid Request parameter",
							"Invalid VPA " + vpa + 
							". It should be in the format example@icicibank or example@abcbank");
					
				} catch (JSONException e) {
					e.printStackTrace();
				}
				jArray.put(returnMessage);
				isValidDetails = false;
				return isValidDetails;
			}
		} else {
			logger.info("VPA cannot be blank!");
			returnMessage = getJsonErr(400, "Bad request. Invalid Request parameter", "VPA cannot be blank");
			jArray.put(returnMessage);
			isValidDetails = false;
			return isValidDetails;
		}
		return isValidDetails;
	}

	public Boolean validateVPAs(String payerVPA, String payeeVPA, String custId, String clientId, String apiName)
			throws JSONException {
		JSONArray jArray = new JSONArray();
		Boolean isValidDetails = false;
		// Payer VPA

		if (payerVPA != null && !payerVPA.isEmpty()) {
			if (dao.isVpaMappedToCustid(payerVPA, custId)) {
				logger.info("Payer VPA validated successfully..");
				isValidDetails = true;
			} else {
				logger.info("VPA not mapped to the cust id " + custId);
				returnMessage = getJsonErr(400, "Bad request. Invalid Request parameter",
						"VPA not mapped to the cust id " + custId);
				jArray.put(returnMessage);
				isValidDetails = false;
				return isValidDetails;
			}
		} else {
			logger.info("Payer VPA cannot be blank!");
			returnMessage = getJsonErr(400, "Bad request. Invalid Request parameter", "Payer VPA cannot be blank");
			jArray.put(returnMessage);
			isValidDetails = false;
			return isValidDetails;
		}
		// Payee VPA
		if (apiName.equals("upiFundTransferVToV")) {
			if (payeeVPA != null && !payeeVPA.isEmpty() && !payeeVPA.equalsIgnoreCase(payerVPA)) {
				if (dao.validatePayeeVpa(payeeVPA, custId, clientId)) {
					logger.info("Payee VPA validated successfully..");
					isValidDetails = true;
				} else {
					logger.info("Invalid Payee VPA " + payeeVPA);
					returnMessage = getJsonErr(400, "Bad request. Invalid Request parameter",
							"Invalid Payee VPA " + payeeVPA);
					jArray.put(returnMessage);
					isValidDetails = false;
					return isValidDetails;
				}
			} else {
				logger.info("Payee VPA cannot be blank!");
				returnMessage = getJsonErr(400, "Bad request. Invalid Request parameter",
						"Payee VPA cannot be blank or same as payer VPA");
				jArray.put(returnMessage);
				isValidDetails = false;
				return isValidDetails;
			}
		}
		return isValidDetails;
	}

	// Method used to set API Usage Status
	public void setApiUsageStatus(String client_id, String apiName, Connection connection) {
		logger.info("Inside setApiUsageStatus");
		String query = "";
		String current_time = null;
		PreparedStatement pstatement = null;
		try {
			if (connection == null || connection.isClosed()) {
				connection = new DatabaseUtil().getConnection();
			}
			Date currdate = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
			current_time = formatter.format(currdate);
			query = "insert into participant_apiusage_rev(client_id,api_name,time) values(?,?,?)";
			pstatement = connection.prepareStatement(query);
			pstatement.setString(1, client_id);
			pstatement.setString(2, apiName);
			pstatement.setString(3, current_time);
			pstatement.execute();
			connection.commit();
		} catch (Exception e) {
			e.printStackTrace();
			logger.warning("Exception in setApiUsageStatus : " + e.getMessage());
		} finally {
			try {
				if (pstatement != null) {
					pstatement.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	// Method used to get Json Error
	public JSONObject getJsonErr(int errCd, String errMsg, String errDesc) throws JSONException {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("code", errCd);
		if (errCd == 400) {
			jsonObject.put("message", "Bad request. Invalid Request parameter");
		} else if (errCd == 501) {
			jsonObject.put("message",
					"Processing error � One or more of internal systems gave an error while processing the request");
		} else if (errCd == 503) {
			jsonObject.put("message", "No Data Found");
		} else {
			jsonObject.put("message", errMsg);
		}
		jsonObject.put("description", errDesc);
		logger.info("getJsonErr() -->" + jsonObject.toString());
		return jsonObject;
	}

	public String getSQLDate(Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		sdf.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
		String SQLFormattedDate = sdf.format(date);
		return SQLFormattedDate;
	}
}
