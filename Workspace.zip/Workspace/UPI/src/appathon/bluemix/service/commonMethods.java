package appathon.bluemix.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.sun.org.apache.bcel.internal.generic.NEW;

public class commonMethods
	{

		private static final Logger logger = Logger.getLogger(UpiMain.class.getName());

		public commonMethods() throws JSONException
		{
			System.out.println("-------------Constructor------------");
			gobj.put("code", 200);
			count = 0;
		}

		JSONObject returnMessage = new JSONObject();
		UpiDAO dao=new UpiDAO();
		JSONObject gobj = new JSONObject();
		boolean flag;
		public int count;

		// Method used to validate Client Id and Token
		public Boolean validateClient(String client_id, String token, String apiName, Connection connection) throws JSONException
		{
			System.out.println("Inside validateClient method LOWER(client_id) is " + client_id.toLowerCase() + " token is " + token);
			DatabaseUtil dbUtil = new DatabaseUtil();
			ResultSet rs = null;
			Statement statement = null;
			JSONArray jArray = new JSONArray();
			String query = "";
			Boolean flag = false;
			try
			{
				System.out.println("Validate Connection Accept : " + connection);
				if (connection == null || connection.isClosed())
				{
					connection = dbUtil.getConnection();
				}
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
				if (!client_id.equals(""))
				{
					if (!token.equals(""))
					{
						// query =
						// "select client_id, token from participant_token_details "
						// + "where LOWER(client_id)='" +
						// client_id.toLowerCase() + "' and token ='" + token +
						// "'  and  EXPIRY_TIME > CURRENT_TIMESTAMP"; // For DB2
						query = "select email, token from participant_token_details " + "where LOWER(email)='" + client_id.toLowerCase() + "' and token ='" + token + "'";
						System.out.println("VALIDATE_____________" + query);
						statement = connection.createStatement();
						rs = statement.executeQuery(query);
						while (rs.next())
						{
							System.out.println("****************************************************");
							JSONObject jobj = new JSONObject();
							/*
							 * System.out.println("client_id from DB::" +
							 * rs.getString(1));
							 * System.out.println("token from DB::" +
							 * rs.getString(2));
							 */
							jobj.put("client_id", rs.getString(1));
							jobj.put("token", rs.getString(2));
							jArray.put(jobj);
						}
						if (jArray.length() != 0)
						{
							flag = true;
							setApiUsageStatus(client_id, apiName, connection); // Set
																				// API
																				// usage
						} else
						{
							returnMessage = getJsonErr("601");
							jArray.put(returnMessage);
						}
						return flag;
					} else
					{
						System.out.println("Inside validateClient(..) method ---> token input is found blank");
						return flag;
					}
				} else
				{
					System.out.println("Inside validateClient(..) method ---> client_id id input is not set");
					return flag;
				}
			} catch (SQLException e)
			{
				e.printStackTrace();
				returnMessage = getJsonErr("603");
				return flag;
			} catch (Exception e)
			{
				e.printStackTrace();
				return flag;
			} finally
			{
				try
				{
					if (rs != null)
					{
						rs.close();
					}
					if (statement != null)
					{
						statement.close();
					}
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		}

		public Boolean authenticateCustId(String custId, String client_id, Connection connection)
		{
			System.out.println("------------ authenticateCustId--------------Cust Id : " + custId);
			String query = "Select CUSTID from rtl_account_details where LOWER(EMAIL)='" + client_id.toLowerCase() + "'"; // For
																																// DB2
			/*
			 * String query=
			 * "Select CUSTID from PARTICIPANT_MASTER  where LOWER(CLIENT_ID)='"
			 * + client_id.toLowerCase()+"'";
			 */// For SQL
			DatabaseUtil util = new DatabaseUtil();
			String cust_ids = null;
			Statement statement = null;
			ResultSet rs = null;
			try
			{
				if (connection == null || connection.isClosed())
				{
					connection = util.getConnection();
				}
				statement = connection.createStatement();
				rs = statement.executeQuery(query);
				while (rs.next())
				{
					cust_ids = rs.getString("CUSTID");
				}
				System.out.println("cust_ids : " + cust_ids);
				if (cust_ids.contains(custId))
				{
					System.out.println("Cust ID Successfully validated..");
					return true;
				} else
				{
					System.out.println("Cust ID not validated..");
					return false;
				}
			} catch (SQLException e)
			{
				e.printStackTrace();
				return false;
			} finally
			{
				try
				{
					if (rs != null)
					{
						rs.close();
					}
					if (statement != null)
					{
						statement.close();
					}
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		}

		public Boolean validateDetails(String clientId, String accountNo, String vpa) throws JSONException
		{
			JSONArray jArray = new JSONArray();
			Boolean isValidDetails = false;
			// Account No
			if (accountNo != null && !accountNo.isEmpty())
			{
				if (dao.validateAccountNo(accountNo, clientId))
				{
					isValidDetails = true;
					System.out.println("Account No validated successfully.");
				} else
				{
					returnMessage = getJsonErr("224");
					jArray.put(returnMessage);
					System.out.println(returnMessage.toString() + " -- " + accountNo);
					return false;
				}
			} else
			{
				System.out.println("Account No cannot be blank!");
				returnMessage = getJsonErr("223");
				jArray.put(returnMessage);
				return false;
			}
			// VPA
			if (vpa != null && !vpa.isEmpty())
			{
				if (vpa.length() > 10 && vpa.endsWith("@icicibank"))
				{
					int cnt = 0;
					for (int i = 0; i < vpa.length(); i++)
					{
						if (vpa.charAt(i) == '@')
						{
							cnt++;
						}
					}
					String vpaArr[] = vpa.split("@");
					if (vpaArr[0].matches("^[a-zA-Z0-9]+.[a-zA-Z0-9]+$") && cnt == 1)
					{
						if (!dao.isVpaAlreadyExists(clientId, vpa))
						{
							isValidDetails = true;
							System.out.println("VPA validated successfully.");
						} else
						{
							System.out.println("Same VPA already exists for user " + clientId);
							returnMessage = getJsonErr("219");
							jArray.put(returnMessage);
							return false;
						}
					} else
					{
						System.out.println("Invalid VPA!" + vpa);
						returnMessage = getJsonErr("221");
						jArray.put(returnMessage);
						return false;
					}
				} else
				{
					System.out.println("Invalid VPA!" + vpa);
					returnMessage = getJsonErr("220");
					jArray.put(returnMessage);
					return false;
				}
			} else
			{
				System.out.println("VPA cannot be blank!");
				returnMessage = getJsonErr("222");
				jArray.put(returnMessage);
				return false;
			}
			return isValidDetails;
		}

		public Boolean validateVPAs(String payerVPA, String payeeVPA, String custId, String clientId, String apiName) throws JSONException
		{
			JSONArray jArray = new JSONArray();
			Boolean isValidDetails = false;
			// Payer VPA

			if (payerVPA != null && !payerVPA.isEmpty())
			{
				if (dao.isVpaMappedToCustid(payerVPA, custId))
				{
					System.out.println("Payer VPA validated successfully..");
					isValidDetails = true;
				} else
				{
					System.out.println("VPA not mapped to the cust id " + custId);
					returnMessage = getJsonErr("225");
					jArray.put(returnMessage);
					isValidDetails = false;
					return isValidDetails;
				}
			} else
			{
				System.out.println("Payer VPA cannot be blank!");
				returnMessage = getJsonErr("226");
				jArray.put(returnMessage);
				isValidDetails = false;
				return isValidDetails;
			}
			// Payee VPA
			if (apiName.equals("upiFundTransferVToV"))
			{
				if (payeeVPA != null && !payeeVPA.isEmpty() && !payeeVPA.equalsIgnoreCase(payerVPA))
				{
					if (dao.validatePayeeVpa(payeeVPA, custId, clientId))
					{
						System.out.println("Payee VPA validated successfully..");
						isValidDetails = true;
					} else
					{
						System.out.println("Invalid Payee VPA " + payeeVPA);
						returnMessage = getJsonErr("227");
						jArray.put(returnMessage);
						isValidDetails = false;
						return isValidDetails;
					}
				} else
				{
					System.out.println("Payee VPA cannot be blank!");
					returnMessage = getJsonErr("228");
					jArray.put(returnMessage);
					isValidDetails = false;
					return isValidDetails;
				}
			}
			return isValidDetails;
		}

		// Method used to set API Usage Status
		public void setApiUsageStatus(String client_id, String apiName, Connection connection)
		{
			System.out.println("Inside setApiUsageStatus");
			String query = "";
			String current_time = null;
			PreparedStatement pstatement = null;
			try
			{
				if (connection == null || connection.isClosed())
				{
					connection = new DatabaseUtil().getConnection();
				}
				Date currdate = new Date();
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
				current_time = formatter.format(currdate);
				query = "insert into participant_apiusage_rev(client_id,api_name,time) values(?,?,?)";
				pstatement = connection.prepareStatement(query);
				pstatement.setString(1, client_id);
				pstatement.setString(2, apiName);
				pstatement.setString(3, current_time);
				pstatement.execute();
				connection.commit();
			} catch (Exception e)
			{
				e.printStackTrace();
				logger.warning("Exception in setApiUsageStatus : " + e.getMessage());
			} finally
			{
				try
				{
					if (pstatement != null)
					{
						pstatement.close();
					}
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		}

		// Method used to get Json Error
		public JSONObject getJsonErr(String code) throws JSONException
		{
			JSONObject jsonObject = new JSONObject();

			String query = "";
			String description = null;
			String message = null;
			PreparedStatement pstatement = null;
			Connection connection = null;
			ResultSet rs = null;
			try
			{
				if (connection == null || connection.isClosed())
				{
					connection = new DatabaseUtil().getConnection();
				}
				query = "select DESCRIPTION_MSG,MESSAGE_MSG from error_details where code=?";
				pstatement = connection.prepareStatement(query);
				pstatement.setString(1, code);
				rs = pstatement.executeQuery();
				do
				{
					if (!rs.next())
					{
						jsonObject.put("Description", "Database Error");
						jsonObject.put("message", "Processing error � One or more of internal systems gave an error while processing the request");
					} else
					{
						description = rs.getString(1);
						message = rs.getString(2);
						jsonObject.put("description", description);
						jsonObject.put("message", message);
					}

				} while (rs.next());

				connection.commit();
			} catch (Exception e)
			{
				e.printStackTrace();
				logger.warning("Exception in getJsonErr : " + e.getMessage());
			} finally
			{
				try
				{
					if (pstatement != null)
					{
						pstatement.close();
					}
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
			jsonObject.put("code", code);
			System.out.println("getJsonErr() -->" + jsonObject.toString());
			return jsonObject;
		}

		public String getSQLDate(Date date)
		{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			sdf.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
			String SQLFormattedDate = sdf.format(date);
			return SQLFormattedDate;
		}
	}
