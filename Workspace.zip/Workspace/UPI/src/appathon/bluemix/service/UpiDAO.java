package appathon.bluemix.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Logger;

public class UpiDAO {

	private static final Logger logger = Logger.getLogger(UpiDAO.class.getName());

	public Boolean validateAccountNo(String accountNo, String clientId) {

		Statement statement = null;
		ResultSet rs = null;
		Statement stmt1 = null;
		ResultSet rs1 = null;
		Connection connection = null;

		String custIds = null;
		String accountno = null;
		String queryAccNo = null;

		try {

			logger.info("------------ validateAccountNo --------------Accoun No : " + accountNo);

			String queryCustId = "Select CUSTID from PARTICIPANT_MASTER  where LOWER(CLIENT_ID)='"
					+ clientId.toLowerCase() + "'";
			DatabaseUtil dbUtil = new DatabaseUtil();
			ArrayList<String> accountNos = new ArrayList<String>();
			if (connection == null || connection.isClosed()) {
				connection = dbUtil.getConnection();
			}
			statement = connection.createStatement();

			rs = statement.executeQuery(queryCustId);
			while (rs.next()) {
				custIds = rs.getString("CUSTID");
			}
			logger.info("custIds : " + custIds);
			System.out.println("custIds : " + custIds);

			if (custIds != null && !custIds.equals("")) {

				String[] custArray;
				custArray = custIds.split("-");
				stmt1 = connection.createStatement();
				for (int i = 0; i < custArray.length; i++) {

					queryAccNo = "Select acc.ACCOUNTNO from rtl_account_master acc " + "where acc.CUSTID ='"
							+ custArray[i] + "'";

					rs1 = stmt1.executeQuery(queryAccNo);

					while (rs1.next()) {
						accountno = rs1.getString("ACCOUNTNO");
						accountNos.add(accountno);
					}

				}
			} else {
				return false;
			}

			logger.info("------------ validateAccountNo END--------------");

			if (accountNos.contains(accountNo)) {
				System.out.println("Account No Mapped to customer");
				return true;
			} else {

				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (rs1 != null) {
					rs1.close();
				}
				if (stmt1 != null) {
					stmt1.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public Boolean isVpaAlreadyExists(String clientId, String vpa) {

		Connection connection = null;
		Statement statement = null;
		ResultSet rs = null;
		DatabaseUtil util = new DatabaseUtil();

		Boolean isExist = false;
		String custIds = "";
		Integer cnt = 0;

		try {

			custIds = getCustIdForClient(clientId);
			String[] custArr = custIds.split("-");

			if (connection == null || connection.isClosed()) {
				connection = util.getConnection();
			}

			statement = connection.createStatement();

			for (int i = 0; i < custArr.length; i++) {

				rs = statement.executeQuery("select count(*) from RTL_ACCOUNT_MASTER where CUSTID = "
						+ custArr[i] + " AND VPA = '" + vpa + "'");

				if (rs.next()) {

					cnt = rs.getInt(1);
				}

				if (cnt > 0) {

					logger.info("VPA already exists for custID : " + custArr[i]);
					isExist = true;
					break;
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return isExist;
	}

	public String getCustIdForClient(String clientId) {

		Connection connection = null;
		Statement statement = null;
		ResultSet rs = null;
		DatabaseUtil util = new DatabaseUtil();

		String custId = "";

		String query = "select CUSTID from PARTICIPANT_MASTER where client_id = '" + clientId + "'";

		try {

			if (connection == null || connection.isClosed()) {
				connection = util.getConnection();
			}
			connection = util.getConnection();

			statement = connection.createStatement();
			rs = statement.executeQuery(query);

			if (rs.next()) {
				custId = rs.getString("CUSTID");
			}

			logger.info("CUSTID: " + custId);

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return custId;
	}

	public String mapVPAToAccount(String accountNo, String vpa) {

		Connection connection = null;
		Statement statement = null;
		DatabaseUtil util = new DatabaseUtil();

		String result = "";
		String query = "UPDATE RTL_ACCOUNT_MASTER SET VPA = '" + vpa + "' where ACCOUNTNO = " + accountNo; // For
																													// DB2

		try {

			if (connection == null || connection.isClosed()) {
				connection = util.getConnection();
			}

			statement = connection.createStatement();
			Integer records = statement.executeUpdate(query);

			if (records >= 1) {
				result = "success";
				logger.info("VPA mapped successfully");

			} else {
				result = "Some error occured while adding Credit Card details!";
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return result;

	}

	public Boolean isVpaMappedToCustid(String vpa, String custId) {

		Connection connection = null;
		Statement statement = null;
		ResultSet rs = null;
		DatabaseUtil util = new DatabaseUtil();

		String query = "";
		Integer cnt = 0;
		Boolean isValid = false;

		try {

			if (connection == null || connection.isClosed()) {
				connection = util.getConnection();
			}

			statement = connection.createStatement();
			query = "select count(*) from RTL_ACCOUNT_MASTER where CUSTID = " + custId + " AND VPA = '" + vpa
					+ "'";

			rs = statement.executeQuery(query);

			if (rs.next()) {
				cnt = rs.getInt(1);
			}

			if (cnt > 0) {
				isValid = true;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return isValid;
	}

	public Boolean validatePayeeVpa(String vpa, String custId, String clientId) {

		Connection connection = null;
		Statement statement = null;
		ResultSet rs = null;
		DatabaseUtil util = new DatabaseUtil();

		Boolean isExist = false;
		String custIds = "";
		Integer cnt = 0;

		try {

			custIds = getCustIdForClient(clientId);
			String[] custArr = custIds.split("-");

			if (connection == null || connection.isClosed()) {
				System.out.println("Inside validatePayeeVpa connection open : " + connection);
				connection = util.getConnection();
			}

			statement = connection.createStatement();

			for (int i = 0; i < custArr.length; i++) {

				if (custArr[i] != custId) {

					rs = statement.executeQuery("select count(*) from RTL_ACCOUNT_MASTER where CUSTID = "
							+ custArr[i] + " AND LOWER(VPA) = '" + vpa + "'");
				}

				if (rs.next()) {

					cnt = rs.getInt(1);
					System.out.println("----"+cnt);
				}

				if (cnt > 0) {

					isExist = true;
					break;
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return isExist;
	}

	public Double getBalance(String accountNo, Connection connection) throws SQLException {

		DatabaseUtil util = new DatabaseUtil();
		Statement statement = null;
		ResultSet rs = null;

		Double balance = 0.0D;

		try {

			if (connection == null || connection.isClosed()) {
				System.out.println("Inside getBalance connection open : " + connection);
				connection = util.getConnection();
			}

			statement = connection.createStatement();
			rs = statement.executeQuery(
					"select balance from Rtl_Account_Master where accountno ='" + accountNo + "'");

			while (rs.next()) {
				balance = rs.getDouble(1);
			}
			connection = null;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (rs != null) {
					rs.close();
				}

				if (statement != null) {
					statement.close();
				}

			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		return balance;
	}

	public String getCustIdByVpa(String vpa, String clientId, Connection connection) {

		Statement statement = null;
		ResultSet rs = null;
		DatabaseUtil util = new DatabaseUtil();

		String custIds = "";
		String cust_Id = "";
		Integer cnt = 0;

		try {

			custIds = getCustIdForClient(clientId);
			String[] custArr = custIds.split("-");

			if (connection == null || connection.isClosed()) {
				System.out.println("Inside getCustIdByVpa connection open : " + connection);
				connection = util.getConnection();
			}

			statement = connection.createStatement();

			for (int i = 0; i < custArr.length; i++) {

				rs = statement.executeQuery("select count(*) from RTL_ACCOUNT_MASTER where CUSTID = "+ custArr[i] + " AND LOWER(VPA) = '" + vpa + "'");

				if (rs.next()) {
					cnt = rs.getInt(1);
				}

				if (cnt > 0) {
					cust_Id = custArr[i];
					break;
				} else {
					cust_Id = "";
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return cust_Id;
	}

	public String getAccNoByCustId(String custId, Connection connection) {

		Statement statement = null;
		ResultSet rs = null;
		DatabaseUtil util = new DatabaseUtil();
		connection = null;

		String accNo = "";
		String query = "";

		try {

			if (connection == null || connection.isClosed()) {
				System.out.println("Inside getAccNoByCustId connection open : " + connection);
				connection = util.getConnection();
			}

			statement = connection.createStatement();

			query = "select accountno from RTL_ACCOUNT_MASTER where CUSTID = '" + custId + "'";
			rs = statement.executeQuery(query);

			if (rs.next()) {
				accNo = rs.getString(1);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return accNo;
	}

	public Integer updateBalance(String accountNo, Double amount, Connection connection) throws SQLException {

		DatabaseUtil util = new DatabaseUtil();
		PreparedStatement ps = null;
		if (connection == null || connection.isClosed()) {

			System.out.println("Inside updateBalance connection open : " + connection);
			connection = util.getConnection();
		}

		int returnValue = 0;
		ps = connection
				.prepareStatement("update Rtl_Account_Master set balance = ? where " + " accountNo = ?");

		ps.setString(1, amount+"");
		ps.setString(2, accountNo);

		returnValue = ps.executeUpdate();
		connection.commit();

		if (ps != null) {
			ps.close();
		}

		return returnValue;
	}

	public synchronized String addTransactionDtl(String custId, double amount, String status, String transactionDate,
			String fromAccount, String toAccount, String c_accountNo, String credit_debit_flag, Double srcBalance,
			String type_of_transaction, String remark, Connection connection) throws SQLException {

		Statement st = null;
		ResultSet rs = null;
		PreparedStatement ps = null;
		DatabaseUtil util = new DatabaseUtil();

		if (connection == null || connection.isClosed()) {
			System.out.println("Inside addTransactionDtl connection open : " + connection);
			connection = util.getConnection();
		}

		String query = "Select max(tranid) from Rtl_Transaction_Details";
		Double closingBal;

		if (credit_debit_flag.contains("D")) {
			closingBal = srcBalance - amount;
		} else {
			Double closingdestbal = getBalance(toAccount, connection);
			closingBal = closingdestbal + amount;
		}

		st = connection.createStatement();
		rs = st.executeQuery(query);
		int maxTranId = 0;

		while (rs.next()) {
			maxTranId = rs.getInt(1);
		}

		maxTranId++;

		ps = connection.prepareStatement("insert into Rtl_Transaction_Details("
				+ "custId,amount,status,transactionDate,fromAccount,toAccount,c_accountNo,credit_debit_flag,tranid,Closing_balance,transactiontype, REMARK)"
				+ " values(?,?,?,?,?,?,?,?,?,?,?,?)");

		ps.setString(1, custId);
		ps.setString(2, amount+"");
		ps.setString(3, status);
		ps.setString(4, transactionDate);
		ps.setString(5, fromAccount);
		ps.setString(6, toAccount);
		ps.setString(7, c_accountNo);
		ps.setString(8, credit_debit_flag);
		ps.setInt(9, maxTranId);
		ps.setString(10, closingBal + "");
		ps.setString(11, type_of_transaction);
		ps.setString(12, remark);

		ps.execute();
		connection.commit();

		if (rs != null) {
			rs.close();
		}
		if (st != null) {
			st.close();
		}
		if (ps != null) {
			ps.close();
		}

		return maxTranId + "";
	}

	public String getCustIdByAccNo(String accountNo, Connection connection) throws SQLException {

		DatabaseUtil util = new DatabaseUtil();
		Statement statement = null;
		ResultSet rs = null;

		String custId = "";

		try {

			if (connection == null || connection.isClosed()) {
				System.out.println("Inside getCustId connection open : " + connection);
				connection = util.getConnection();
			}

			statement = connection.createStatement();
			rs = statement.executeQuery(
					"select custId from Rtl_Account_Master where accountNo ='" + accountNo + "'");

			while (rs.next()) {
				custId = rs.getString(1);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {

				if (rs != null) {
					rs.close();
				}

				if (statement != null) {
					statement.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		return custId;
	}
	
	public String getPayeeName(String AccountNo, String custId) throws SQLException{
		DatabaseUtil util = new DatabaseUtil();
		Statement statement = null;
		ResultSet rs = null;
		Connection connection = null;
		String payeename = "";
		
		try {
			
			if(connection ==null || connection.isClosed()) {
				logger.info("Inside getPayeeName connection open : "+connection);
				connection = util.getConnection();
			}
	
			statement = connection.createStatement();
			rs = statement.executeQuery("SELECT PAYEENAME FROM Rtl_Payee_Details where payeeaccountno ='"+ AccountNo
					+"' and c_custId = '"+custId+"'");
			while (rs.next()) {
				payeename = rs.getString("payeename");
				System.out.println("Payeename:"+payeename);
			}
			
			// connection.close();	
			if(rs != null){
				rs.close();
			}
			
			if(statement != null){
				statement.close();
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return payeename;
	}

	public boolean isValidBankAccountMapping(String vpaBank, String accountNo) {
		
		DatabaseUtil util = new DatabaseUtil();
		Statement statement = null;
		ResultSet rs = null;
		Connection connection = null;
		String bankName = "";
		Boolean isValid = false;
		
		try {
			
			if(connection ==null || connection.isClosed()) {
				logger.info("Inside isValidBankAccountMapping connection open : "+connection);
				connection = util.getConnection();
			}
	
			statement = connection.createStatement();
			rs = statement.executeQuery("SELECT BANK_NAME FROM RTL_ACCOUNT_MASTER where ACCOUNTNO ='"+ accountNo+"'");
			while (rs.next()) {
				bankName = rs.getString("BANK_NAME");
			}
			
			// connection.close();	
			if(rs != null){
				rs.close();
			}
			
			if(statement != null){
				statement.close();
			}
			
			if (bankName.equalsIgnoreCase(vpaBank)) {
				isValid = true;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return isValid;
	}

}
