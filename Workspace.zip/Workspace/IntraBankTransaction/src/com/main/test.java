package com.main;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class test {

	public static void main(String[] args) {
		int a=10;
		int b=a;
		if(b==a)		
		System.out.println('a'  +  'b');
		
		else
			System.out.println("ullu");
	}


}
