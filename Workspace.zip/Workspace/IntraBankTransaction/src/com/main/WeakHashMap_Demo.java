package com.main;

import java.util.Set;
import java.util.TreeSet;

public class WeakHashMap_Demo {
	Set s =new TreeSet();
	s.add("a");
	
	
	
	
}