package appathon.service;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.TimeZone;
import java.util.UUID;
import java.util.logging.Logger;

import org.json.JSONException;
import org.json.JSONObject;






public class CommonMethod
	{
		private static final Logger log = Logger.getLogger(CommonMethod.class.getName());


		public JSONObject getJsonStatus(int errCd, String errMsg, String errDesc) throws JSONException
			{
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("code", errCd);
				jsonObject.put("message", errMsg);
				jsonObject.put("description", errDesc);
				return jsonObject;
			}


		public String generateToken()
			{
				String str = (UUID.randomUUID().toString()).replace("-", "");
				log.info("uuid = " + str);
				String token = str.substring(1, 13);
				log.info("token = " + token);
				return token;
			}


		public Boolean authenticateCustidOnly(String flag, String custid, String client_id, Connection connection)
			{
				log.info("------------ authenticateCustidOnly --------------Account No : " + custid);
				log.info("/*/*" + "Select CUSTID from PARTICIPANT_MASTER  where LOWER(CLIENT_ID)=" + client_id.toLowerCase() + "");
				String query = "Select CUSTID from PARTICIPANT_MASTER  where LOWER(CLIENT_ID)='" + client_id.toLowerCase() + "'";
				DatabaseUtil util = new DatabaseUtil();
				String cust_ids = null;
				Statement statement = null;
				Statement stmt1 = null;
				ResultSet rs1 = null;
				ResultSet rs = null;
				try
					{
						if (connection == null || connection.isClosed())
							{
								log.info("Inside authenticateCustidOnly connection open : " + connection);
								connection = util.getConnection();
							}
						statement = connection.createStatement();
						rs = statement.executeQuery(query);
						while (rs.next())
							{
								cust_ids = rs.getString("CUSTID");
							}
						log.info("cust_ids : " + cust_ids);
						if (cust_ids.contains(custid))
							{
								log.info("Cust ID Successfully validated..");
								return true;
							}
						else
							{
								log.info("Cust ID not validated..");
								return false;
							}
					}
				catch (SQLException e)
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
						return false;
					}
				finally
					{
						try
							{
								if (rs != null)
									{
										rs.close();
									}
								if (statement != null)
									{
										statement.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
			}


		public Boolean authenticateCustid(String flag, String id, String client_id, Connection connection)
			{
				Statement statement = null;
				ResultSet rs = null;
				Statement stmt1 = null;
				ResultSet rs1 = null;
				String cust_ids = null;
				String accountno = null;
				try
					{
						log.info("------------ AuthenticateCustid --------------Accoun No : " + id);
						String query = "Select CUSTID from PARTICIPANT_MASTER  where LOWER(CLIENT_ID)='" + client_id.toLowerCase() + "'";
						DatabaseUtil dbUtil = new DatabaseUtil();
						ArrayList<String> accountnos = new ArrayList<String>();
						if (connection == null || connection.isClosed())
							{
								connection = dbUtil.getConnection();
							}
						statement = connection.createStatement();
						rs = statement.executeQuery(query);
						while (rs.next())
							{
								cust_ids = rs.getString("CUSTID");
							}
						log.info("cust_ids : " + cust_ids);
						if (!cust_ids.equals(""))
							{
								log.info("AuthenticateCustID--Cust IDs are " + cust_ids);
								String[] custArry;
								custArry = cust_ids.split("-");
								String loan;
								String card;
								stmt1 = connection.createStatement();
								for (int i = 0; i < custArry.length; i++)
									{
										log.info("Cust ID : " + custArry[i]);
										log.info("***********Select p.ACCOUNTNO,p.DEBIT_CARD_NO,l.LOAN_ACCOUNT_NO from rtl_account_master p,rtl_loan_master l where  p.custid=l.custid and p.CUSTID =" + custArry[i] + "");
										System.out.println("***********Select p.ACCOUNTNO,p.DEBIT_CARD_NO,l.LOAN_ACCOUNT_NO from rtl_account_master p,rtl_loan_master l where  p.custid=l.custid and p.CUSTID =" + custArry[i] + "");
										
										rs1 = stmt1.executeQuery("Select p.ACCOUNTNO,p.DEBIT_CARD_NO,l.LOAN_ACCOUNT_NO from rtl_account_master p,rtl_loan_master l where  p.custid=l.custid and p.CUSTID =" + custArry[i] + "");
										while (rs1.next())
											{
												accountno = rs1.getString("ACCOUNTNO");
												log.info("Account No in While " + accountno);
												accountnos.add(accountno);
											}
									}
							}
						else
							{
								return false;
							}
						log.info("------------ AuthenticateCustid END--------------");
						if (accountnos.contains(id))
							{
								log.info("Account No Mapped to customer");
								return true;
							}
						else
							{
								return false;
							}
					}
				catch (SQLException e)
					{
						e.printStackTrace();
						return false;
					}
				catch (Exception e)
					{
						e.printStackTrace();
						return false;
					}
				finally
					{
						try
							{
								if (rs != null)
									{
										rs.close();
									}
								if (statement != null)
									{
										statement.close();
									}
								if (rs1 != null)
									{
										rs1.close();
									}
								if (stmt1 != null)
									{
										stmt1.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
			}


		public String getAccountNo_fund(String cust_id, Connection connection) throws SQLException
			{
				log.info("-------------Get Account No--------------Cust id : " + cust_id);
				Statement statement = null;
				ResultSet rs = null;
				String accountNo = "";
				try
					{
						DatabaseUtil util = new DatabaseUtil();
						if (connection == null || connection.isClosed())
							{
								connection = util.getConnection();
							}
						statement = connection.createStatement();
						rs = statement.executeQuery("select accountNo from Rtl_Account_Master where custId ='" + cust_id + "'");
						while (rs.next())
							{
								accountNo = rs.getString("accountNo");
							}
						log.info("---Cust id : " + cust_id + " Account no" + accountNo);
					}
				catch (Exception e)
					{
						e.printStackTrace();
					}
				finally
					{
						try
							{
								if (rs != null)
									{
										rs.close();
									}
								if (statement != null)
									{
										statement.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				return accountNo;
			}


		public HashMap getDates(String dateInString)
			{
				// TODO Auto-generated method stub
				HashMap hm = new HashMap<String, String>();
				try
					{
						Date currdate = new Date();
						DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
						formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
						// String dateInString = "2015-03-07";
						log.info("CURR " + formatter.format(currdate));
						Date enterddate = formatter.parse(dateInString);
						log.info("FORM " + formatter.format(enterddate));
						Calendar cal = Calendar.getInstance();
						cal.setTime(enterddate); // use java.util.Date object as
													// arguement
						// get the value of all the calendar date fields.
						int enter_year = cal.get(Calendar.YEAR);
						log.info("Enter Year: " + enter_year);
						int enter_month = cal.get(Calendar.MONTH);
						log.info("ENter Month: " + enter_month);
						int enter_day = cal.get(Calendar.DATE);
						log.info("Enter Day: " + enter_day);
						cal.setTime(currdate); // use java.util.Date object as
												// arguement
						// get the value of all the calendar date fields.
						int curr_year = cal.get(Calendar.YEAR);
						log.info("current Year: " + curr_year);
						int curr_year_month = cal.get(Calendar.MONTH);
						log.info("current Month: " + curr_year_month);
						int curr_year_day = cal.get(Calendar.DATE);
						log.info("current Day: " + curr_year_day);
						String start_date = "";
						String end_date = "";
						if (enter_year == curr_year)
							{
								if ((enter_month + 1) <= 3)
									{
										log.info("Enterd date is valid");
										start_date = (curr_year - 1) + "-04-01";
										end_date = dateInString;
									}
							}
						if (enter_year == curr_year - 1)
							{
								if ((enter_month + 1) >= 4)
									{
										start_date = curr_year - 1 + "-04-01";
										end_date = dateInString;
									}
							}
						hm.put("currYear_strat_date", start_date);
						hm.put("currYear_end_date", end_date);
						hm.put("prevYear_start_date", curr_year - 2 + "-04-01");
						hm.put("prevYear_end_date", String.valueOf(curr_year - 1) + "-" + String.valueOf(enter_month + 1) + "-" + String.valueOf(enter_day));
						return hm;
					}
				catch (Exception e)
					{
						e.printStackTrace();
						return hm;
					}
			}


		public JSONObject getFinancialYear(String start_date) throws JSONException
			{
				String[] dateArray = start_date.split("-");
				int year = Integer.parseInt(dateArray[0]);
				int month = Integer.parseInt(dateArray[1]);
				int day = Integer.parseInt(dateArray[2]);
				int startFinancialYr, endFinancialYr, prevStartFinYr, prevEndFinYr;
				// Getting Financial year of the date entered.
				if (month < 4)
					{
						log.info("Financial Year : " + (year - 1) + "-" + year);
						startFinancialYr = year - 1;
						endFinancialYr = year;
					}
				else
					{
						log.info("Financial Year : " + year + "-" + (year + 1));
						startFinancialYr = year;
						endFinancialYr = year + 1;
					}
				prevStartFinYr = startFinancialYr - 1;
				prevEndFinYr = endFinancialYr - 1;
				String startFinancialYrDate = String.valueOf(startFinancialYr) + "-04-01";
				String endFinancialYrDate = String.valueOf(endFinancialYr) + "-03-31";
				String startPrevFinancialYrDate = String.valueOf(prevStartFinYr) + "-04-01";
				String endPrevFinancialYrDate = String.valueOf(prevStartFinYr) + "-03-31";
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("startFinancialYrDate", startFinancialYrDate);
				jsonObject.put("endFinancialYrDate", endFinancialYrDate);
				jsonObject.put("startPrevFinancialYrDate", startPrevFinancialYrDate);
				jsonObject.put("endPrevFinancialYrDate", endPrevFinancialYrDate);
				return jsonObject;
			}


		public JSONObject getJsonErr(int errCd, String errMsg, String errDesc) throws JSONException
			{
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("code", errCd);
				if (errCd == 400)
					{
						jsonObject.put("message", "Bad request. Invalid Request parameter");
					}
				else
					if (errCd == 501)
						{
							jsonObject.put("message", "Processing error � One or more of internal systems gave an error while processing the request");
						}
					else
						if (errCd == 503)
							{
								jsonObject.put("message", "No Data Found");
							}
						else
							{
								jsonObject.put("message", errMsg);
							}
				jsonObject.put("description", errDesc);
				return jsonObject;
			}
	}
