/*package appathon.service;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.math.BigInteger;

import javax.ws.rs.core.Application;





@ApplicationPath("/banking/*")
public class BankingApplication extends Application
	{
		
		public void rtl_payee_accountNoGenerator() throws UnsupportedEncodingException, FileNotFoundException,IOException
			{
				BigInteger accno = new BigInteger("4444777755550001");
				BigInteger add4 = new BigInteger("4");
				Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("rtl_payee_details.txt"), "utf-8"));
				try
					{
						for (int i = 0; i <= 1000; i++)
							{
								BigInteger accno1 = new BigInteger("+1");
								BigInteger accno2 = new BigInteger("+2");
								BigInteger accno3 = new BigInteger("+3");
								BigInteger accno4 = new BigInteger("-1");
								BigInteger accno5 = new BigInteger("+1");
								BigInteger accno6 = new BigInteger("+2");
								BigInteger accno7 = new BigInteger("-2");
								BigInteger accno8 = new BigInteger("-1");
								BigInteger accno9 = new BigInteger("+1");
								BigInteger accno10 = new BigInteger("-3");
								BigInteger accno11 = new BigInteger("-2");
								BigInteger accno12 = new BigInteger("-1");
								
								writer.write(accno.add(accno1) + "" + "\n");
								writer.write(accno.add(accno2) + "" + "\n");
								writer.write(accno.add(accno3) + "" + "\n");
								writer.write(accno.add(accno1).add(accno4) + "" + "\n");
								writer.write(accno.add(accno1).add(accno5) + "" + "\n");
								writer.write(accno.add(accno1).add(accno6) + "" + "\n");
								writer.write(accno.add(accno2).add(accno7) + "" + "\n");
								writer.write(accno.add(accno2).add(accno8) + "" + "\n");
								writer.write(accno.add(accno2).add(accno9) + "" + "\n");
								writer.write(accno.add(accno3).add(accno10) + "" + "\n");
								writer.write(accno.add(accno3).add(accno11) + "" + "\n");
								writer.write(accno.add(accno3).add(accno12) + "" + "\n");
							
								System.out.println(accno.add(accno1));
								System.out.println(accno.add(accno2));
								System.out.println(accno.add(accno3));
								System.out.println(accno.add(accno1).add(accno4));
								System.out.println(accno.add(accno1).add(accno5));
								System.out.println(accno.add(accno1).add(accno6));
								System.out.println(accno.add(accno2).add(accno7));
								System.out.println(accno.add(accno2).add(accno8));
								System.out.println(accno.add(accno2).add(accno9));
								System.out.println(accno.add(accno3).add(accno10));
								System.out.println(accno.add(accno3).add(accno11));
								System.out.println(accno.add(accno3).add(accno12));
								accno = accno.add(add4);
							}
						writer.flush();
						writer.close();
					}
				catch (Exception e)
					{
						e.printStackTrace();
					}
			
				
			}
		
		
		public static void main(String[] args) throws UnsupportedEncodingException, FileNotFoundException, IOException 
			{
				BankingApplication s=new BankingApplication();
				s.rtl_payee_accountNoGenerator();
				
			}
	}
*/