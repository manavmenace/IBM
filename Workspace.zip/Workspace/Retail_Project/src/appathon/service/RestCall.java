package appathon.service;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import java.util.logging.Logger;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
//import org.apache.commons.lang.math.NumberUtils;

import org.apache.commons.lang3.math.NumberUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;




@Path("/icici")
public class RestCall
	{
		private static final Logger log = Logger.getLogger(RestCall.class.getName());

		public RestCall() throws JSONException
			{
				log.info("-------------Constructor------------");
				gobj.put("code", 200);
				count = 0;
			}

		JSONObject returnMessage = new JSONObject();
		JSONObject gobj = new JSONObject();
		boolean flag;
		public int count;

		@GET
		@Path("/test")
		@Produces
		public String tm()
		{
			return "Ok dude";
		}
		

		// balanceinq?accountno=
		@GET
		@Path("/balanceenquiry")
		@Produces
		public String getMessage(
				@QueryParam("client_id")String email, 
				@QueryParam("token")String token, 
				@QueryParam("accountno")String accountno
				) throws JSONException
			{
				log.info("###---- Balance Inquiry ----###");
				log.info("m in");
				Connection connection = null;
				Statement statement = null;
				ResultSet rs = null;
				CommonMethod comn = new CommonMethod();
				String result = "";
				DatabaseUtil dbUtil = new DatabaseUtil();
				JSONObject jobj = new JSONObject();
				JSONArray jarray = new JSONArray();
				log.info("Initiate Balance Inquiry for Account No. :" + accountno);
				boolean flag = false;
				boolean accflag = false;
				log.info("Validation Details " + email + " userid is " + token);
				try
					{
						if (connection == null || connection.isClosed())
							{
								log.info("Inside getMessage connection open : " + connection);
								connection = dbUtil.getConnection();
							}
						flag = validateClient(email, token, "balanceenquiry", connection);
						if (flag)
							{
								String regex = "[0-9]+";
								if (!accountno.equals(""))
									{
										if (accountno.length() == 16)
											{
												if (accountno.matches(regex))
													{
														accflag = comn.authenticateCustid("A", accountno, email, connection);
														if (accflag)
															{
																DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
																Date date = new Date();
																log.info(dateFormat.format(date)); // 2014/08/06
																// 15:59:48
																Date today = new Date();
																// displaying
																// this date on
																// IST timezone
																DateFormat df = new SimpleDateFormat("dd-MM-yy HH:mm:SS z");
																df.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
																String IST = df.format(today);
																log.info("Date in Indian Timezone (IST) : " + IST);
																statement = connection.createStatement();
																rs = statement.executeQuery("select balance,accountType from Rtl_Account_Master where accountNo=" + accountno);
																if (rs.next())
																	{
																		result = rs.getString("balance");
																		if (count == 0)
																			{
																				jarray.put(gobj);
																			}
																		count++;
																		jobj.put("accountno", accountno);
																		jobj.put("balancetime", IST);
																		jobj.put("accounttype", rs.getString("accountType"));
																		jobj.put("balance", Double.parseDouble(rs.getString("balance")) + "0");
																		jarray.put(jobj);
																		log.info("Balance for Account No. :" + accountno + " is " + result);
																	}
																else
																	{
																		returnMessage = getJsonErr(503, "No Data found", "Account Number does not exist");
																		log.info(result + " -- " + accountno);
																	}
															}
														else
															{
																returnMessage = getJsonErr(401, "User Not Authorized", "This Account Number does not belongs to participant");
																log.info(returnMessage.toString() + " -- " + accountno);
															}
													}
												else
													{
														returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Account Number should contain only Numbers");
														log.info(returnMessage.toString() + " -- " + accountno);
													}
											}
										else
											{
												returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Account Number should be 16 digits");
												log.info(returnMessage.toString() + " -- " + accountno);
											}
									}
								else
									{
										returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Account Number cannot be Empty");
										log.info(returnMessage.toString() + " -- " + accountno);
									}
							}
						else
							{
								log.info("Token Verification Failed.");
								returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
								jarray.put(returnMessage);
							}
						// String out = "" + accountno + " : " + result;
						if (jarray.length() == 0)
							{
								jarray.put(returnMessage);
								result = jarray.toString();
							}
						else
							{
								// jarray.put(jobj);
								result = jarray.toString();
							}
					}
				catch (SQLException e)
					{
						e.printStackTrace();
						returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
						log.info(jobj.toString() + " -- " + accountno);
					}
				catch (Exception ex)
					{
						ex.printStackTrace();
						returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
						log.info(jobj.toString() + " -- " + accountno);
					}
				finally
					{
						try
							{
								if (rs != null)
									{
										rs.close();
									}
								if (statement != null)
									{
										statement.close();
									}
								if (connection != null)
									{
										connection.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				return result;
			}


		public JSONObject getJsonErr(int errCd, String errMsg, String errDesc) throws JSONException
			{
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("code", errCd);
				if (errCd == 400)
					{
						jsonObject.put("message", "Bad request. Invalid Request parameter");
					}
				else
					if (errCd == 501)
						{
							jsonObject.put("message", "Processing error � One or more of internal systems gave an error while processing the request");
						}
					else
						if (errCd == 503)
							{
								jsonObject.put("message", "No Data Found");
							}
						else
							{
								jsonObject.put("message", errMsg);
							}
				jsonObject.put("description", errDesc);
				log.info("getJsonErr() -->" + jsonObject.toString());
				return jsonObject;
			}


		// account_summary?custid=&accountno=&mobileno=
		@GET
		@Path("/account_summary")
		@Produces
		public String getaccount_detail(@QueryParam("client_id")
		String email, @QueryParam("token")
		String token, @QueryParam("custid")
		String custid, @QueryParam("accountno")
		String accountno) throws JSONException
			{
				log.info("###---- Account Details ----###");
				Connection connection = null;
				Statement statement = null;
				JSONArray jarray = new JSONArray();
				String regex = "[0-9]+";
				ResultSet rs = null;
				CommonMethod comn = new CommonMethod();
				Boolean accflag = false;
				log.info("Initiate account Inquiry for Cust Id or Account No. :" + custid + " -- " + accountno);
				log.info("Validation Details " + email + " userid is " + token);
				DatabaseUtil util = new DatabaseUtil();
				try
					{
						if (connection == null || connection.isClosed())
							{
								log.info("Inside account summary connection open : " + connection);
								connection = util.getConnection();
							}
						flag = validateClient(email, token, "account_summary", connection);
						if (flag)
							{
								if (!custid.equals("") || !accountno.equals(""))
									{
										log.info("in try");
										statement = connection.createStatement();
										// On the bases of cust ID
										if (!custid.trim().equals(""))
											{
												if (validateCustid(custid))
													{
														accflag = comn.authenticateCustidOnly("A", custid, email, connection);
														if (accflag)
															{
																log.info("select a.accountno,a.accounttype,a.balance,c.prod_type,c.prod_category,c.prod_desc,c.sub_prod_type,c.MOBILE,c.custid from Rtl_Account_Master a ,rtl_customer_master c where  c.custid=a.custid and c.custid=" + custid + "");
																rs = statement.executeQuery("select a.accountno,a.accounttype,a.balance,c.prod_type,c.prod_category,c.prod_desc,c.sub_prod_type,c.MOBILE,c.custid,a.wallet_balance,a.WALLET_ID,vpa, reward_point from Rtl_Account_Master a ,rtl_customer_master c where  c.custid=a.custid and c.custid=" + custid + "");
																while (rs.next())
																	{
																		JSONObject jtemp = new JSONObject();
																		log.info("in while of Account Summary : ");
																		if (count == 0)
																			{
																				jarray.put(gobj);
																			}
																		count++;
																		// if
																		// (!custid.equals(""))
																		// {
																		jtemp.put("custid", rs.getString("custid"));
																		// }
																		jtemp.put("accountno", rs.getString("accountno"));
																		jtemp.put("accounttype", rs.getString("accounttype"));
																		jtemp.put("balance", rs.getDouble("balance") + "0");
																		jtemp.put("account_status", "Active");
																		jtemp.put("mobileno", rs.getString("MOBILE"));
																		jtemp.put("product_type", rs.getString("prod_type"));
																		jtemp.put("product_category", rs.getString("prod_category"));
																		jtemp.put("sub_product_type", rs.getString("sub_prod_type"));
																		jtemp.put("product_desc", rs.getString("prod_desc"));
																		jtemp.put("wallet_id", rs.getString("WALLET_ID"));
																		jtemp.put("wallet_balance", rs.getString("wallet_balance"));
																		jtemp.put("vpa", rs.getString("vpa"));
																		jtemp.put("reward_point", rs.getString("reward_point"));
																		jarray.put(jtemp);
																	}
																if (jarray.length() == 0)
																	{
																		returnMessage = getJsonErr(503, "No Data found", "Account Details does not exist");
																	}
															}
														else
															{
																returnMessage = getJsonErr(401, "User Not Authorized", "This Customer ID does not belongs to participant");
																log.info(returnMessage.toString() + " -- " + accountno);
															}
													}
												else
													{
														returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Customer ID should be 8 Digits & can contain only Numbers");
													}
												// On the bases of Account No
											}
										else
											/*if (custid.equals("") && !accountno.equals(""))*/
											if (!accountno.trim().equals(""))
												{
													log.info("inside account no validation");
													if (accountno.length() == 16)
														{
															if (accountno.matches(regex))
																{
																	log.info("matches account no ");
																	accflag = comn.authenticateCustid("A", accountno, email, connection);
																	log.info("inside  account no accflag "+accflag);
																	if (accflag)
																		{
																			rs = statement.executeQuery("select accountno,accounttype,balance,prod_type,prod_category,prod_desc,sub_prod_type,MOBILE,c.custid,a.wallet_balance,a.WALLET_ID,a.vpa,reward_point from Rtl_Account_Master a ,rtl_customer_master c where  c.custid=a.custid and a.accountno='" + accountno + "'");
																			while (rs.next())
																				{
																					JSONObject jtemp = new JSONObject();
																					log.info("in while of Account Summary : ");
																					if (count == 0)
																						{
																							jarray.put(gobj);
																						}
																					count++;
																					// if
																					// (!custid.equals(""))
																					// {
																					jtemp.put("custid", rs.getString("custid"));
																					// }
																					jtemp.put("accountno", rs.getString("accountno"));
																					jtemp.put("accounttype", rs.getString("accounttype"));
																					jtemp.put("balance", rs.getDouble("balance") + "0");
																					jtemp.put("account_status", "Active");
																					jtemp.put("mobileno", rs.getString("MOBILE"));
																					jtemp.put("product_type", rs.getString("prod_type"));
																					jtemp.put("product_category", rs.getString("prod_category"));
																					jtemp.put("sub_product_type", rs.getString("sub_prod_type"));
																					jtemp.put("product_desc", rs.getString("prod_desc"));
																					jtemp.put("wallet_id", rs.getString("WALLET_ID"));
																					jtemp.put("wallet_balance", rs.getString("wallet_balance"));
																					jtemp.put("vpa", rs.getString("vpa"));
																					jtemp.put("reward_point", rs.getString("reward_point"));
																					jarray.put(jtemp);
																				}
																			if (jarray.length() == 0)
																				{
																					returnMessage = getJsonErr(503, "No Data found", "Account Details does not exist");
																				}
																		}
																	else
																		{
																			returnMessage = getJsonErr(401, "User Not Authorized", "This Account Number does not belongs to participant");
																			log.info(returnMessage.toString() + " -- " + accountno);
																		}
																}
															else
																{
																	returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Account Number should contain only Numbers");
																}
														}
													else
														{
															returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Account Number should be 16 digits");
															log.info(returnMessage.toString() + " -- " + accountno);
														}
												}
											else
												{
													returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Inavalid Input");
												}
									}
								else
									{
										returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Customer ID or Account Number cannot be null");
									}
							}
						else
							{
								log.info("Token Verification Failed.");
								returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
								jarray.put(returnMessage);
							}
						//}
						/*else{
							returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", " Account Number should be 16 digit and numbers only");
						}*/
						if (jarray.length() == 0)
							{
								jarray.put(returnMessage);
							}
					}
				catch (SQLException e)
					{
						returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
						e.printStackTrace();
						log.info("Errorrr : " + e);
						// returnMessage =
						// getJsonErr(400,"","Database Error. Please try after
						// some time");
					}
				finally
					{
						try
							{
								if (rs != null)
									{
										rs.close();
									}
								if (statement != null)
									{
										statement.close();
									}
								if (connection != null)
									{
										connection.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				log.info("Client_id : " + email);
				log.info("Response : " + jarray.toString());
				return jarray.toString();
			}


		public Boolean validateCustid(String custid)
			{
				String regex = "[0-9]+";
				if (custid.length() == 8)
					{
						if (custid.matches(regex))
							{
								return true;
							}
						else
							{
								return false;
							}
					}
				else
					{
						return false;
					}
			}


		public String generatePIN()
			{
				// generate a 4 digit integer 1000 <10000
				int randomPIN = (int) (Math.random() * 9000) + 1000;
				String mpin = String.valueOf(randomPIN);
				return mpin;
			}
		// recenttransaction?accountno=1001


		@GET
		@Path("/recenttransaction")
		@Produces
		public String gettransation(@QueryParam("client_id")
		String email, @QueryParam("token")
		String token, @QueryParam("accountno")
		String accountno) throws JSONException
			{
				log.info("###---- Transaction Recent ----###");
				Connection connection = null;
				Statement statement = null;
				JSONArray jarray = new JSONArray();
				ResultSet rs = null;
				String result = "";
				CommonMethod comn = new CommonMethod();
				Boolean accflag = false;
				String regex = "[0-9]+";
				log.info("Validation Details " + email + " userid is " + token);
				DatabaseUtil util = new DatabaseUtil();
				try
					{
						if (connection == null || connection.isClosed())
							{
								connection = util.getConnection();
								log.info("Inside recenttransaction connection open : " + connection);
							}
						flag = validateClient(email, token, "recenttransaction", connection);
						if (flag)
							{
								if (!accountno.equals(""))
									{
										if (accountno.length() == 16)
											{
												if (accountno.matches(regex))
													{
														accflag = comn.authenticateCustid("A", accountno, email, connection);
														if (accflag)
															{
																connection = util.getConnection();
																statement = connection.createStatement();
																//rs = statement.executeQuery("SELECT t.c_accountno,a.balance,t.transactionType,t.amount,t.transactionDate,t.remark,t.credit_debit_flag,t.Closing_balance FROM Rtl_Transaction_Details t, rtl_account_master a where t.c_accountNo ='" + accountno + "' and t.c_accountno = a.accountno order by t.transactionDate desc fetch first 5 rows only");
																rs = statement.executeQuery("SELECT top 5 t.c_accountno,a.balance,t.transactionType,t.amount,t.transactionDate,t.remark,t.credit_debit_flag,t.Closing_balance FROM Rtl_Transaction_Details t, rtl_account_master a where t.c_accountNo ='" + accountno + "' and t.c_accountno = a.accountno order by t.transactionDate desc");
																while (rs.next())
																	{
																		JSONObject jtemp = new JSONObject();
																		log.info("Amount " + rs.getString("amount"));
																		if (count == 0)
																			{
																				jarray.put(gobj);
																			}
																		count++;
																		String remark = "";
																		if (rs.getString("remark") == null)
																			{
																				remark = "-";
																			}
																		else
																			{
																				remark = rs.getString("remark");
																			}
																		log.info("Transaction Date from Database : " + rs.getString("transactionDate"));
																		jtemp.put("accountno", rs.getString("c_accountno"));
																		jtemp.put("closing_balance", rs.getString("Closing_balance") + "0");
																		jtemp.put("transactiondate", rs.getString("transactionDate"));
																		jtemp.put("remark", remark);
																		jtemp.put("credit_debit_flag", rs.getString("credit_debit_flag"));
																		jtemp.put("transaction_amount", rs.getString("amount") + "0");
																		jarray.put(jtemp);
																	}
																if (jarray.length() == 0)
																	{
																		returnMessage = getJsonErr(503, "", "No transaction found for Account. Please perform Fund Transfer to view transaction");
																		log.info(returnMessage.toString() + " -- " + accountno);
																		jarray.put(returnMessage);
																	}
															}
														else
															{
																returnMessage = getJsonErr(401, "User Not Authorized", "This Account Number does not belongs to participant");
																log.info(returnMessage.toString() + " -- " + accountno);
																jarray.put(returnMessage);
															}
													}
												else
													{
														returnMessage = getJsonErr(400, "", "Account Number should contain only Numbers");
														// returnMessage =
														// getJsonErr(400,"",
														// "Account Number
														// should contain only
														// Numbers");
														log.info(returnMessage.toString() + " -- " + accountno);
														jarray.put(returnMessage);
													}
											}
										else
											{
												returnMessage = getJsonErr(400, "", "Account Number should be 16 digits");
												// returnMessage =
												// getJsonErr(400,"","Account
												// Number should be 4
												// digits");
												log.info(returnMessage.toString() + " -- " + accountno);
												jarray.put(returnMessage);
											}
									}
								else
									{
										returnMessage = getJsonErr(400, "", "Account Number cannot be Empty");
										// returnMessage =
										// getJsonErr(400,"","Account Number
										// cannot be Empty");
										log.info(returnMessage.toString() + " -- " + accountno);
										jarray.put(returnMessage);
									}
							}
						else
							{
								log.info("Token Verification Failed.");
								returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
								jarray.put(returnMessage);
							}
						result = jarray.toString();
					}
				catch (SQLException e)
					{
						returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
						e.printStackTrace();
					}
				catch (Exception ex)
					{
						returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
						ex.printStackTrace();
					}
				finally
					{
						try
							{
								if (rs != null)
									{
										rs.close();
									}
								if (statement != null)
									{
										statement.close();
									}
								if (connection != null)
									{
										connection.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				return result;
			}


		// ndaystransaction?accountno=1001&days=2
		@GET
		@Path("/ndaystransaction")
		@Produces
		public String getndaystransaction(@QueryParam("client_id")
		String email, @QueryParam("token")
		String token, @QueryParam("accountno")
		String accountno, @QueryParam("days")
		String ndays) throws JSONException
			{
				log.info("###---- Transaction N-Days ----###");
				Connection connection = null;
				Statement statement = null;
				ResultSet rs = null;
				String currentDate = "";
				DateFormat dateFormat = null;
				CommonMethod comn = new CommonMethod();
				Boolean accflag = false;
				DatabaseUtil util = new DatabaseUtil();
				Date date = null;
				JSONObject jobj = new JSONObject();
				JSONArray jarray = new JSONArray();
				String result = "";
				String regex = "[0-9]+";
				String previousDate = "";
				log.info("Validation Details " + email + " userid is " + token);
				try
					{
						if (connection == null || connection.isClosed())
							{
								log.info("Inside account summary connection open : " + connection);
								connection = util.getConnection();
							}
						flag = validateClient(email, token, "ndaystransaction", connection);
						if (flag)
							{
								if (!accountno.equals(""))
									{
										if (accountno.length() == 16)
											{
												if (accountno.matches(regex))
													{
														if (!ndays.equals("")&&ndays.length()<=3)
															{
																if (ndays.matches(regex))
																	{
																		accflag = comn.authenticateCustid("A", accountno, email, connection);
																		if (accflag)
																			{
																				dateFormat = new SimpleDateFormat("yyyy-MM-dd");
																				date = new Date();
																				Date today = new Date();
																				DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
																				df.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
																				String IST = df.format(today);
																				log.info("Date in Indian Timezone (IST) : " + IST);
																				currentDate = IST;
																				log.info("Current Date -- " + currentDate);
																				previousDate = minusDate(Integer.parseInt(ndays));
																				log.info("Previous Date -- " + previousDate);
																				connection = util.getConnection();
																				statement = connection.createStatement();
																			/*	rs = statement.executeQuery("SELECT top 15 t.c_accountno,a.balance,t.transactionType,t.amount,t.transactionDate,t.remark,t.credit_debit_flag,t.closing_balance FROM Rtl_Transaction_Details t, rtl_account_master a where t.c_accountNo ='" + accountno + "' AND t.c_accountno=a.accountno and (t.transactionDate BETWEEN '"
																						+ previousDate + "' AND date('" + currentDate + "') + 1 DAYS) order by t.transactionDate desc");*/
																				
																				//DB2
																				/*rs = statement.executeQuery("SELECT top 15 t.c_accountno,a.balance,t.transactionType,t.amount,t.transactionDate,t.remark,t.credit_debit_flag,t.closing_balance FROM Rtl_Transaction_Details t, rtl_account_master a where t.c_accountNo ='" + accountno + "' AND t.c_accountno=a.accountno and (t.transactionDate BETWEEN '"
																						+ previousDate + "' AND DATEADD(MONTH,1,CONVERT(DATE,GETDATE())) order by t.transactionDate desc");*/
																				
																				//SQL
																				//String nDayTranjsaction="SELECT top 15 t.c_accountno,a.balance,t.transactionType,t.amount,t.transactionDate,t.remark,t.credit_debit_flag,t.closing_balance FROM Rtl_Transaction_Details t, rtl_account_master a where t.c_accountNo ='" + accountno + "' AND t.c_accountno=a.accountno and t.transactionDate BETWEEN '"+ previousDate + "' AND '" + currentDate + "' order by t.transactionDate desc";
																				String nDayTranjsaction="SELECT top 15 t.c_accountno,a.balance,t.transactionType,t.amount,t.transactionDate,t.remark,t.credit_debit_flag,t.closing_balance FROM Rtl_Transaction_Details t, rtl_account_master a where t.c_accountNo ='" + accountno + "' AND t.c_accountno=a.accountno and t.transactionDate BETWEEN '"+ previousDate + "' AND DATEADD(Day, 1, '" + currentDate + "')  order by t.transactionDate desc";
																				
																				System.out.println(nDayTranjsaction);
																				
																				rs = statement.executeQuery(nDayTranjsaction);
																				
																				while (rs.next())
																					{
																						log.info("Amount " + rs.getString("amount"));
																						JSONObject jtemp = new JSONObject();
																						if (count == 0)
																							{
																								jarray.put(gobj);
																							}
																						count++;
																						String remark = "";
																						if (rs.getString("remark") == null)
																							{
																								remark = "-";
																							}
																						else
																							{
																								remark = rs.getString("remark");
																							}
																						jtemp.put("accountno", rs.getString("c_accountno"));
																						jtemp.put("closing_balance", rs.getString("closing_balance"));
																						jtemp.put("transactiondate", rs.getString("transactionDate"));
																						jtemp.put("remark", remark);
																						jtemp.put("credit_debit_flag", rs.getString("credit_debit_flag"));
																						jtemp.put("transaction_amount", rs.getString("amount"));
																						jarray.put(jtemp);
																					}
																				if (jarray.length() == 0)
																					{
																						returnMessage = getJsonErr(503, "", "No transaction found for Account. Please perform Fund Transfer to view transaction " + accountno);
																						log.info(jobj.toString() + " -- " + accountno);
																					}
																			}
																		else
																			{
																				returnMessage = getJsonErr(401, "User Not Authorized", "This Account Number does not belongs to participant");
																				log.info(returnMessage.toString() + " -- " + accountno);
																			}
																	}
																else
																	{
																		returnMessage = getJsonErr(400, "", "Number of Days should be number only");
																	}
															}
														else
															{
																returnMessage = getJsonErr(400, "", "Number of days cannot be Empty");
															}
													}
												else
													{
														returnMessage = getJsonErr(400, "", "Account Number should contain only Numbers");
														log.info(returnMessage + " -- " + accountno);
													}
											}
										else
											{
												returnMessage = getJsonErr(400, "", "Account Number should be 16 digits");
												log.info(returnMessage + " -- " + accountno);
											}
									}
								else
									{
										returnMessage = getJsonErr(400, "", "Account Number cannot be Empty");
										log.info(returnMessage + " -- " + accountno);
									}
							}
						else
							{
								log.info("Token Verification Failed.");
								returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
								jarray.put(returnMessage);
							}
						if (jarray.length() == 0)
							{
								jarray.put(returnMessage);
							}
						result = jarray.toString();
					}
				catch (SQLException e)
					{
						returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
						e.printStackTrace();
					}
				catch (Exception ex)
					{
						returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
						ex.printStackTrace();
					}
				finally
					{
						try
							{
								if (rs != null)
									{
										rs.close();
									}
								if (statement != null)
									{
										statement.close();
									}
								if (connection != null)
									{
										connection.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				return result;
			}


		public String datevalidator(String fromdate, String todate)
			{
				String Error = "success";
				try
					{
						Date date = new Date();
						// displaying this date on IST timezone
						DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
						df.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
						String sysdate = df.format(date);
						log.info("Date in Indian Timezone (IST) : " + sysdate);
						SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
						Date fdate = sdf.parse(fromdate);
						Date tdate = sdf.parse(todate);
						log.info(sdf.format(fdate));
						log.info(sdf.format(tdate));
						if (fdate.after(tdate))
							{
								Error = "From date cannot be greated then todate";
								log.info("From date cannot be greated then todate");
							}
						if (fdate.before(tdate))
							{
								log.info("To date cannot be greater then todays date");
							}
						if (fdate.equals(tdate))
							{
								log.info("Date1 is equal Date2");
							}
					}
				catch (ParseException ex)
					{
						Error = "Date format Exception";
						ex.printStackTrace();
					}
				catch (Exception e)
					{
						e.printStackTrace();
					}
				return Error;
			}


		// transactioninterval?accountno=1001&fromdate=2016-01-01&todate=2016-01-20
		@GET
		@Path("/transactioninterval")
		@Produces
		public String gettransationinterval(@QueryParam("client_id")
		String email, @QueryParam("token")
		String token, @QueryParam("accountno")
		String accountno, @QueryParam("fromdate")
		String fromdate, @QueryParam("todate")
		String todate) throws JSONException
			{
				log.info("###---- Transaction Interval ----###");
				CommonMethod comn = new CommonMethod();
				Boolean accflag = false;
				Connection connection = null;
				Statement statement = null;
				JSONObject jobj = new JSONObject();
				JSONArray jarray = new JSONArray();
				String result = "";
				String regex = "[0-9]+";
				ResultSet rs = null;
				log.info("Validation Details " + email + " userid is " + token);
				DatabaseUtil util = new DatabaseUtil();
				try
					{
						if (connection == null || connection.isClosed())
							{
								log.info("Inside transactioninterval connection open : " + connection);
								connection = util.getConnection();
							}
						flag = validateClient(email, token, "transactioninterval", connection);
						if (flag)
							{
								if (!accountno.equals(""))
									{
										if (accountno.length() == 16)
											{
												if (accountno.matches(regex))
													{
														if (!fromdate.equals(""))
															{
																if (!todate.equals(""))
																	{
																		accflag = comn.authenticateCustid("A", accountno, email, connection);
																		if (accflag)
																			{
																				String isdatecorrect = datevalidator(fromdate, todate);
																				if (isdatecorrect.equalsIgnoreCase("success"))
																					{
																						connection = util.getConnection();
																						statement = connection.createStatement();
																						/*rs = statement.executeQuery("SELECT t.c_accountno,a.balance,t.transactionType,t.amount,t.transactionDate,t.remark,t.credit_debit_flag,t.closing_balance FROM Rtl_Transaction_Details t, rtl_account_master a where t.c_accountNo ='" + accountno + "' AND t.c_accountno=a.accountno and (t.transactionDate BETWEEN '"
																								+ fromdate + "' AND DATE('" + todate + "') + 1 DAYS) order by t.transactionDate desc fetch first 15 rows only");*/
																						//db2
																						//String transactionInterval="SELECT top 15 t.c_accountno,a.balance,t.transactionType,t.amount,t.transactionDate,t.remark,t.credit_debit_flag,t.closing_balance FROM Rtl_Transaction_Details t, rtl_account_master a where t.c_accountNo ='" + accountno + "' AND t.c_accountno=a.accountno and (t.transactionDate BETWEEN '"
																						//+ fromdate + "' AND  DATEADD(MONTH,1,CONVERT(DATE,GETDATE())) order by t.transactionDate desc "
																						String transactionInterval="SELECT top 15 t.c_accountno,a.balance,t.transactionType,t.amount,t.transactionDate,t.remark,t.credit_debit_flag,t.closing_balance FROM Rtl_Transaction_Details t, rtl_account_master a where t.c_accountNo ='" + accountno + "' AND t.c_accountno=a.accountno and (t.transactionDate BETWEEN '"
																								+ fromdate + "' AND DATEADD(Day, 1, '"+todate+"')  ) order by t.transactionDate desc ";
																						System.out.println(transactionInterval);
																						rs = statement.executeQuery(transactionInterval);
																						while (rs.next())
																							{
																								log.info("----------- Inside While -----------");
																								JSONObject jtemp = new JSONObject();
																								if (count == 0)
																									{
																										jarray.put(gobj);
																									}
																								count++;
																								String remark = "";
																								if (rs.getString("remark") == null)
																									{
																										remark = "-";
																									}
																								else
																									{
																										remark = rs.getString("remark");
																									}
																								jtemp.put("accountno", rs.getString("c_accountno"));
																								jtemp.put("closing_balance", rs.getString("closing_balance"));
																								jtemp.put("transactiondate", rs.getString("transactionDate"));
																								jtemp.put("remark", remark);
																								jtemp.put("credit_debit_flag", rs.getString("credit_debit_flag"));
																								jtemp.put("transaction_amount", rs.getString("amount"));
																								log.info("Amount----------- " + rs.getString("amount"));
																								jarray.put(jtemp);
																							}
																						if (jarray.length() == 0)
																							{
																								returnMessage = getJsonErr(503, "", "No transaction found for Account. Please perform Fund Transfer to view transaction  " + accountno);
																								log.info(jobj.toString() + " -- " + accountno);
																								jarray.put(returnMessage);
																							}
																					}
																				else
																					{
																						returnMessage = getJsonErr(400, "", isdatecorrect);
																						log.info(accountno + " -- " + returnMessage);
																					}
																			}
																		else
																			{
																				returnMessage = getJsonErr(401, "User Not Authorized", "This Account Number does not belongs to participant");
																				log.info(returnMessage.toString() + " -- " + accountno);
																			}
																	}
																else
																	{
																		returnMessage = getJsonErr(400, "", "To Date cannot be Empty");
																	}
															}
														else
															{
																returnMessage = getJsonErr(400, "", "From Date cannot be Empty");
															}
													}
												else
													{
														returnMessage = getJsonErr(400, "", "Account Number should contain only Numbers");
														log.info(jobj.toString() + " -- " + accountno);
													}
											}
										else
											{
												returnMessage = getJsonErr(400, "", "Account Number should be 16 digits");
												log.info(jobj.toString() + " -- " + accountno);
											}
									}
								else
									{
										returnMessage = getJsonErr(400, "", "Account Number cannot be Empty");
										log.info(jobj.toString() + " -- " + accountno);
									}
							}
						else
							{
								log.info("Token Verification Failed.");
								returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
								jarray.put(returnMessage);
							}
						if (jarray.length() == 0)
							{
								jarray.put(returnMessage);
							}
						result = jarray.toString();
					}
				catch (SQLException e)
					{
						returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
						e.printStackTrace();
					}
				catch (Exception ex)
					{
						returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
						ex.printStackTrace();
					}
				finally
					{
						try
							{
								if (rs != null)
									{
										rs.close();
									}
								if (statement != null)
									{
										statement.close();
									}
								if (connection != null)
									{
										connection.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				return result;
			}


		public String minusDate(int n)
			{
				GregorianCalendar cal = new GregorianCalendar();
				String currentDate = "";
				DateFormat dateFormat = null;
				Date date = null;
				String previousDate = null;
				try
					{
						dateFormat = new SimpleDateFormat("yyyy-MM-dd");
						date = new Date();
						currentDate = dateFormat.format(date);
						log.info("Today date" + currentDate);
						Date currDate = dateFormat.parse(currentDate);
						cal.setTime(currDate);
						log.info("Calendar.DATE:" + Calendar.DATE);
						cal.add(Calendar.DATE, -n);
						previousDate = dateFormat.format(cal.getTime());
						log.info("previous Date =" + previousDate);
					}
				catch (Exception e)
					{
						e.printStackTrace();
					}
				return previousDate;
			}


		@GET
		@Path("/listpayee")
		@Produces
		public String getpayeelist(@QueryParam("client_id")
		String email, @QueryParam("token")
		String token, @QueryParam("custid")
		String custid) throws JSONException
			{
				log.info("###---- List Payee ----###");
				Connection connection = null;
				Statement statement = null;
				ResultSet rs = null;
				String result = "";
				JSONArray jarray = new JSONArray();
				CommonMethod comn = new CommonMethod();
				Boolean accflag = false;
				DatabaseUtil dbUtil = new DatabaseUtil();
				log.info("Payee cust ID :" + custid);
				String out = "";
				log.info("Validation Details " + email + " userid is " + token);
				try
					{
						if (connection == null || connection.isClosed())
							{
								log.info("Inside getpayeelist connection open : " + connection);
								connection = dbUtil.getConnection();
							}
						flag = validateClient(email, token, "listpayee", connection);
						if (flag)
							{
								if 	(validateCustid(custid))
									{
										accflag = comn.authenticateCustidOnly("C", custid, email, connection);
										if (accflag)
											{
												log.info("LIst Payee try");
												statement = connection.createStatement();
												log.info("select payeeid,payeeAccountno,payeename,sname,creationdate from rtl_payee_details where c_custid =" + custid + "");
												rs = statement.executeQuery("select payeeid,payeeAccountno,payeename,sname,creationdate from rtl_payee_details where c_custid =" + custid + "");
												while (rs.next())
													{
														log.info("LIst Payee while");
														JSONObject jobj = new JSONObject();
														if (count == 0)
															{
																jarray.put(gobj);
															}
														count++;
														jobj.put("custid", custid);
														jobj.put("payeeid", rs.getString("payeeid"));
														jobj.put("payeeaccountno", rs.getString("payeeAccountno"));
														jobj.put("payeename", rs.getString("payeename"));
														jobj.put("shortname", rs.getString("sname"));
														jobj.put("creationdate", rs.getString("creationdate"));
														jarray.put(jobj);
													}
												if (jarray.length() == 0)
													{
														result = "Payee does not exist";
														returnMessage = getJsonErr(503, "", result);
													}
											}
										else
											{
												returnMessage = getJsonErr(401, "User Not Authorized", "This Customer ID does not belongs to participant");
												log.info(returnMessage.toString() + " -- " + custid);
											}
									}
								else
									{
										returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Customer ID should be 8 Digits & can contain only Numbers");
									}
							}
						else
							{
								log.info("Token Verification Failed.");
								returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
								jarray.put(returnMessage);
							}
						/*
						 * try { log.info(" Close try " + mobileno);
						 * 
						 * rs.close(); connection.close();
						 * 
						 * } catch (SQLException e) { e.printStackTrace(); }
						 *//*
							 * finally { try { //rs.close(); rs = null;
							 * connection.close(); connection = null; } catch
							 * (Exception e) { e.printStackTrace(); } }
							 */
						if (jarray.length() == 0)
							{
								out = returnMessage.toString();
							}
						else
							{
								out = jarray.toString();
							}
					}
				catch (SQLException e)
					{
						returnMessage = getJsonErr(501, "", "Database Error. Please try after some time");
						log.info(returnMessage + " -- " + custid);
						e.printStackTrace();
					}
				catch (Exception ex)
					{
						returnMessage = getJsonErr(501, "", "Database Error. Please try after some time");
						log.info(returnMessage + " -- " + custid);
						ex.printStackTrace();
					}
				finally
					{
						try
							{
								if (rs != null)
									{
										rs.close();
									}
								if (statement != null)
									{
										statement.close();
									}
								if (connection != null)
									{
										connection.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				return out;
			}


		// fundTransfer?srcAccount=1001&destAccount=1004&amt=500&memo=dump&payeeDesc=payeedesc&payeeId=1&payeeType=dump&paymentType=FT
		// icici_hackathon_practice.mybluemix.net/banking/icicibank/fundTransfer?srcAccount=1001&destAccount=1004&amt=500&memo=abc&payeeDesc=payeeDesc&payeeId=1&payeeType=payeeType&paymentType=FT
		@GET
		@Path("/fundTransfer")
		@Produces
		public String fundTransfer(@QueryParam("client_id")
		String email, @QueryParam("token")
		String token, @QueryParam("srcAccount")
		String srcAccount, @QueryParam("destAccount")
		String destAccount, @QueryParam("amt")
		String amt, @QueryParam("payeeDesc")
		String payeeDesc, @QueryParam("payeeId")
		String payeeId, @QueryParam("type_of_transaction")
		String type_of_transaction) throws JSONException
			{
				CommonMethod comn = new CommonMethod();
				GenericClass genericClass = new GenericClass();
				String returnMessage = "";
				JSONArray jarr = new JSONArray();
				ArrayList<String> type_tran = new ArrayList<String>();
				jarr.put(gobj);
				log.info("Validation Details " + email + " userid is " + token);
				type_tran.add("pmr");
				type_tran.add("dth");
				type_tran.add("school fee payment");
				type_tran.add("movie ticket");
				type_tran.add("electricity");
				type_tran.add("restaurant ticket");
				type_tran.add("fuel");
				type_tran.add("groceries");
				type_tran.add("home loan emi");
				type_tran.add("insurance payment");
				type_tran.add("car insurance");
				type_tran.add("mf payments");
				type_tran.add("direct-to-home payments");
				type_tran.add("mutual fund payments");
				type_tran.add("purchase product");
				Connection connection = null;
				//
				try
					{
						DatabaseUtil util = new DatabaseUtil();
						if (connection == null || connection.isClosed())
							{
								connection = util.getConnection();
								log.info("Inside fundTransfer connection open -->: " + connection);
							}
						flag = validateClient(email, token, "fundTransfer", connection);
						if (flag)
							{
								if (srcAccount.equals("") || destAccount.equals("") || amt.equals("") || type_of_transaction.equals(""))
									{
										returnMessage = genericClass.getJsonErr(400, "Bad request.", "Please enter all required values.");
									}
								else
									if (!NumberUtils.isNumber(amt) || Double.parseDouble(amt) <= 0)
										{
											returnMessage = genericClass.getJsonErr(400, "Bad request.", "Invalid Amount.");
										}
									else
										if (!type_tran.contains(type_of_transaction.toLowerCase()))
											{
												returnMessage = genericClass.getJsonErr(400, "Bad request.", "Type of Transaction should be from list");
											}
										// else if(!comn.authenticateCustid("A",
										// srcAccount,email))
										else
											if (!comn.authenticateCustid("A", srcAccount, email, connection))
												{
													returnMessage = genericClass.getJsonErr(401, "User Not Authorized", "This Account Number does not belongs to participant");
													log.info(returnMessage.toString() + " -- " + srcAccount);
												}
											else
												{
													// Validate if source
													// account exists
													boolean srcAccountExists = genericClass.chkIfAccountExists(srcAccount, connection);
													if (srcAccountExists)
														{
															// Validate if Payee
															// is listed in
															// Payee list based
															// on
															// Customer ID.
															String srcCustId = genericClass.getCustId(srcAccount, connection);
															String payeenamedb = genericClass.chkIfPayeeExists(destAccount, srcCustId, connection);
															if (!payeenamedb.equalsIgnoreCase(""))
																{
																	// Check if
																	// enough
																	// balance
																	// is
																	// available
																	// in source
																	// account
																	// to
																	// transfer.
																	double srcBalance = genericClass.getBalance(srcAccount, connection);
																	boolean balanceAvailable = (srcBalance < Double.parseDouble(amt)) ? false : true;
																	if (balanceAvailable)
																		{
																			// Fetch
																			// details
																			// to
																			// enter
																			// in
																			// Transaction
																			// &
																			// Account
																			// details
																			// table.
																			String destCustId = genericClass.getCustId(destAccount, connection);
																			Date todaysDate = new Date();
																			String todaysDate_SQLFormatted = genericClass.getSQLDate(todaysDate);
																			log.info("---------- todaysDate_SQLFormatted -------" + todaysDate_SQLFormatted);
																			// Make
																			// Transaction
																			// entries
																			// Source
																			// transaction
																			// entry
																			String tranid = genericClass.addTransactionDtl(srcCustId, Double.parseDouble(amt), "0", todaysDate_SQLFormatted, srcAccount, destAccount, srcAccount, "Dr.", srcBalance, type_of_transaction, connection);
																			String destAccTran_ReturnVal = genericClass.addTransactionDtl(destCustId, Double.parseDouble(amt), "0", todaysDate_SQLFormatted, srcAccount, destAccount, destAccount, "Cr.", srcBalance, type_of_transaction, connection);
																			// Make
																			// Account
																			// Balance
																			// Updates
																			double newSrcBalance = srcBalance - Double.parseDouble(amt);
																			
																			int srcBalanceUpdateResult = genericClass.updateBalance(srcAccount, newSrcBalance, connection);
																			
																			double destBalance = genericClass.getBalance(destAccount, connection);
																			
																			double newDestBalance = destBalance + Double.parseDouble(amt);
																			int destBalanceUpdateResult = genericClass.updateBalance(destAccount, newDestBalance, connection);
																			log.info("tranid: " + tranid + " destAccTran_ReturnVal: " + destAccTran_ReturnVal + " srcBalanceUpdateResult: " + srcBalanceUpdateResult + " destBalanceUpdateResult: " + destBalanceUpdateResult);
																			JSONObject js = new JSONObject();
																			js.put("transaction_amount", amt + ".00");
																			js.put("status", "SUCCESS");
																			js.put("destination_accountno", destAccount);
																			js.put("payee_name", payeenamedb);
																			js.put("payee_id", payeeId);
																			js.put("transaction_date", todaysDate_SQLFormatted);
																			js.put("referance_no", tranid);
																			jarr.put(js);
																			returnMessage = jarr.toString();
																		}
																	else
																		{
																			returnMessage = genericClass.getJsonErr(402, "Error in processing.", "Insufficient Balance");
																		}
																}
															else
																{
																	returnMessage = genericClass.getJsonErr(402, "Error in processing.", "Destination Account doesn't exist.");
																}
														}
													else
														{
															returnMessage = genericClass.getJsonErr(402, "Error in processing.", "Source account doesn't exist.");
														}
												}
							}
						else
							{
								log.info("Token Verification Failed.");
								returnMessage = genericClass.getJsonErr(401, "User Not Authorized", "Access Denied");
							}
					}
				catch (SQLException e)
					{
						returnMessage = genericClass.getJsonErr(402, "Error in processing.", "Fund Transfer failed.");
						e.printStackTrace();
						log.info(e.getMessage());
					}
				catch (Exception e)
					{
						returnMessage = genericClass.getJsonErr(402, "Error in processing.", "Fund Transfer failed. Please check URL parameters.");
						e.printStackTrace();
						log.info(e.getMessage());
					}
				finally
					{
						try
							{
								if (connection != null)
									{
										connection.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				log.info("returnMessage: " + returnMessage);
				return returnMessage;
			}


		// /behaviour_score?accountno=1001
		@GET
		@Path("/behaviour_score")
		@Produces
		public String getbehaviour_score(@QueryParam("client_id")
		String email, @QueryParam("token")
		String token, @QueryParam("accountno")
		String accountno) throws JSONException
			{
				log.info("###---- Behaviour Score ----###");
				Statement statement = null;
				Connection connection = null;
				// connection = DatabaseUtil.getConnection();
				ResultSet rs = null;
				DatabaseUtil util = new DatabaseUtil();
				JSONObject jobj = new JSONObject();
				JSONArray jarray = new JSONArray();
				String regex = "[0-9]+";
				String result = "";
				boolean accflag=false;
				CommonMethod comn=new CommonMethod();
				log.info("Validation Details " + email + " userid is " + token);
				try
					{
						if (connection == null || connection.isClosed())
							{
								log.info("Inside behaviour_score connection open : " + connection);
								connection = util.getConnection();
							}
						flag = validateClient(email, token, "behaviour_score", connection);
						if (flag)
							{
								if (!accountno.equals(""))
									{
										if (accountno.length() == 16)
											{
												if (accountno.matches(regex))
													{
													accflag = comn.authenticateCustid("A", accountno, email, connection);
													if(accflag){
														statement = connection.createStatement();
														rs = statement.executeQuery("SELECT score from Rtl_Customer_Master u,Rtl_Account_Master a where a.accountno=" + accountno + " and a.custid=u.custid ");
														while (rs.next())
															{
																result = rs.getString("score");
																int s = Integer.parseInt(result);
																/*
																 * if(s<=30) {
																 * jobj.put(
																 * "Score",
																 * "High Risk");
																 * } else
																 * if(s<=70 &&
																 * s>30)
																 * {jobj.put(
																 * "Score",
																 * "Medium Risk"
																 * );} else
																 * if(s<=100 &&
																 * s>70)
																 * {jobj.put(
																 * "Score",
																 * "Low Risk");}
																 */
																if (count == 0)
																	{
																		jarray.put(gobj);
																	}
																count++;
																jobj.put("score", s);
																jarray.put(jobj);
															}
														/*
														 * finally { try {
														 * connection.close();
														 * connection = null;
														 * rs.close(); rs =
														 * null; } catch
														 * (Exception e) {
														 * e.printStackTrace();
														 * } }
														 */
														}
													else{
														returnMessage = getJsonErr(401, "User Not Authorized", "This Account Number does not belongs to participant");
														log.info(returnMessage.toString() + " -- " + accountno);
														
													}
													}
												else
													{
														// returnMessage =
														// getJsonErr(400,"",
														// "Account Number
														// should contain only
														// Numbers");
														returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Account Number should contain only Numbers");
														log.info(returnMessage.toString() + " -- " + accountno);
													}
													
											}
										else
											{
												// returnMessage =
												// getJsonErr(400,"","Account
												// Number should be 4
												// digits");
												returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Account Number should be 16 digits");
												log.info(returnMessage.toString() + " -- " + accountno);
											}
												
									}
								else
									{
										// returnMessage =
										// getJsonErr(400,"","Account Number
										// cannot be Empty");
										returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Account Number cannot be Empty");
										log.info(returnMessage.toString() + " -- " + accountno);
									}
							}
						else
							{
								log.info("Token Verification Failed.");
								returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
							}
					}
				catch (SQLException e)
					{
						e.printStackTrace();
					}
				finally
					{
						try
							{
								if (rs != null)
									{
										rs.close();
									}
								if (statement != null)
									{
										statement.close();
									}
								if (connection != null)
									{
										connection.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				if (jarray.length() == 0)
					{
						jarray.put(returnMessage);
					}
				return jarray.toString();
			}


		// BranchAtmLocator?locate=
		// http://retailbanking.mybluemix.net/banking/icicibank/BranchAtmLocator?client_id=test@abc.com&token=f5316a5e35a4&locate=ATM&lat=72.9376984&long=19.1445007
		@GET
		@Path("/BranchAtmLocator")
		@Produces
		public String getBranchLocation(@QueryParam("client_id")
		String email, @QueryParam("token")
		String token, @QueryParam("locate")
		String locate, @QueryParam("lat")
		String lat, @QueryParam("long")
		String longg) throws JSONException
			{
				log.info("###---- Branch Atm Locator ----###");
				Connection connection = null;
				Statement statement = null;
				ResultSet rs = null;
				JSONArray jarray = new JSONArray();
				String result = "";
				String locateflag = "";
				DatabaseUtil util = new DatabaseUtil();
				log.info("Get Branch & Atm location : " + locate);
				log.info("Validation Details " + email + " userid is " + token);
				try
					{
						if (connection == null || connection.isClosed())
							{
								connection = util.getConnection();
							}
						flag = validateClient(email, token, "BranchAtmLocator", connection);
						if (flag)
							{
								if (locate.trim().equalsIgnoreCase("BRANCH"))
									{
										locateflag = "B";
									}
								else
									if (locate.trim().equalsIgnoreCase("ATM"))
										{
											locateflag = "A";
										}
								log.info("Locate Flag : " + locateflag);
								if (!locateflag.equalsIgnoreCase(""))
									{
										statement = connection.createStatement();
										/*
										 * rs = statement .executeQuery(
										 * "select phoneno,Branch_Atm_Flag,BRANCHNAME,IFSC_CODE,CITY,STATE,putRESS,PINCODE,LATITUDE,LONGITUDE from fnpbbmor.rtl_branch_master where branch_Atm_flag='"
										 * + locateflag + "' and LATITUDE='"
										 * +lat+"' and LONGITUDE='" +longg+"'");
										 */
										log.info("select phoneno,Branch_Atm_Flag,BRANCHNAME,IFSC_CODE,CITY,STATE,ADDRESS,PINCODE,LATITUDE,LONGITUDE from rtl_branch_master where branch_Atm_flag='" + locateflag + "'");
										rs = statement.executeQuery("select phoneno,Branch_Atm_Flag,BRANCHNAME,IFSC_CODE,CITY,STATE,ADDRESS,PINCODE,LATITUDE,LONGITUDE from rtl_branch_master where branch_Atm_flag='" + locateflag + "'");
										while (rs.next())
											{
												JSONObject jobj = new JSONObject();
												log.info("Inside While");
												if (rs.getString("Branch_Atm_Flag").equalsIgnoreCase("B"))
													{
														log.info("Inside While" + rs.getString("latitude"));
														if (count == 0)
															{
																jarray.put(gobj);
															}
														count++;
														jobj.put("Type", "Branch");
														jobj.put("pincode", rs.getString("pincode"));
														jobj.put("latitude", rs.getString("latitude"));
														jobj.put("longitude", rs.getString("longitude"));
														jobj.put("flag", rs.getString("branch_atm_flag"));
														jobj.put("branchname", rs.getString("BRANCHNAME"));
														jobj.put("IFSC_CODE", rs.getString("IFSC_CODE"));
														jobj.put("city", rs.getString("city"));
														jobj.put("state", rs.getString("STATE"));
														jobj.put("phoneno", rs.getString("phoneno"));
														jobj.put("address", rs.getString("address"));
														jarray.put(jobj);
													}
												if (rs.getString("Branch_Atm_Flag").equalsIgnoreCase("A"))
													{
														log.info("Inside While" + rs.getString("longitude"));
														if (count == 0)
															{
																jarray.put(gobj);
															}
														count++;
														jobj.put("Type", "ATM");
														jobj.put("pincode", rs.getString("pincode"));
														jobj.put("latitude", rs.getString("latitude"));
														jobj.put("longitude", rs.getString("longitude"));
														jobj.put("flag", rs.getString("branch_atm_flag"));
														jobj.put("branchname", rs.getString("BRANCHNAME"));
														jobj.put("IFSC_CODE", rs.getString("IFSC_CODE"));
														jobj.put("city", rs.getString("city"));
														jobj.put("state", rs.getString("STATE"));
														jobj.put("phoneno", rs.getString("phoneno"));
														jobj.put("address", rs.getString("address"));
													}
												jarray.put(jobj);
											}
										if (jarray.length() == 0)
											{
												returnMessage = getJsonErr(503, "No Data found", "Invalid Input");
											}
									}
								else
									{
										log.info("Invalid Locate Value");
										returnMessage = getJsonErr(400, "Bad request. Request parameter are not provided.", "Invalid data. Locate value can be Branch or ATM only");
									}
							}
						else
							{
								log.info("Token Verification Failed.");
								returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
								jarray.put(returnMessage);
							}
						// String out = "" + accountno + " : " + result;
						if (jarray.length() == 0)
							{
								jarray.put(returnMessage);
								result = jarray.toString();
							}
						else
							{
								result = jarray.toString();
							}
					}
				catch (SQLException e)
					{
						e.printStackTrace();
						returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
						log.info(jarray.toString() + " -- " + locate);
					}
				catch (Exception ex)
					{
						ex.printStackTrace();
						returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
						log.info(jarray.toString() + " -- " + locate);
					}
				finally
					{
						try
							{
								if (statement != null)
									{
										statement.close();
									}
								if (rs != null)
									{
										rs.close();
									}
								if (connection != null)
									{
										connection.close();
									}
							}
						catch (SQLException e)
							{
								e.printStackTrace();
							}
					}
				return result;
			}


		public boolean validateClient(String client_id, String token, String api_name, Connection connection) throws JSONException
			{
				// Connection connection = null;
				JSONArray jarray = new JSONArray();
				ResultSet rs = null;
				Statement statement = null;
				// String client_id = "";
				StringWriter errors = new StringWriter();
				String query = "";
				boolean flag = false;
				String current_time = null;
				DatabaseUtil dbUtil = new DatabaseUtil();
				log.info("Inside validateClient method LOWER(client_id) is " + client_id.toLowerCase() + " token is " + token);
				try
					{
						log.info("Validate Connection Accept : " + connection);
						if (connection == null || connection.isClosed())
							{
								connection = dbUtil.getConnection();
							}
						Date currdate = new Date();
						SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
						current_time = formatter.format(currdate);
						// }
						if (!client_id.equals(""))
							{
								log.info("client");
								if (!token.equals(""))
									{
										// query = "select client_id,token from
										// participant_token_details where
										// client_id='"+client_id+"'
										// and token='"+token+"' and (SELECT
										// MINUTE(expiry_time) -
										// MINUTE('"+current_time+"') FROM
										// SYSIBM.SYSDUMMY1) > 0";
										// timestampdiff function return diff
										// between time
										/*
										 * 1 Microseconds 2 Seconds 4 Minutes 8
										 * Hours 16 Days 32 Weeks 64 Months 128
										 * Quarters 256 Years
										 */
										/*
										 * query =
										 * "select client_id,token from fnpbbmor.participant_token_details where LOWER(client_id)='"
										 * + client_id.toLowerCase() +
										 * "' and token='" + token +
										 * "' and (SELECT timestampdiff (4, char(timestamp(p.expiry_time)-timestamp('"
										 * + current_time +
										 * "'))) FROM fnpbbmor.participant_token_details p, SYSIBM.SYSDUMMY1 where LOWER(p.client_id)='"
										 * + client_id.toLowerCase() +
										 * "' and p.token='" + token + "') >0";
										 */
										query = "select client_id,token from participant_token_details " + "where client_id='" + client_id + "' and token = '" + token + "' and  EXPIRY_TIME>CURRENT_TIMESTAMP";
										log.info("token");
										log.info("VALIDATE_____________" + query);
										statement = connection.createStatement();
										rs = statement.executeQuery(query);
										while (rs.next())
											{
												log.info("****************************************************");
												JSONObject jobj = new JSONObject();
												jobj.put("client_id", rs.getString(1));
												jobj.put("token", rs.getString(2));
												jarray.put(jobj);
											}
										if (jarray.length() != 0)
											{
												flag = true;
												// update validity of token
												// 01-03-2016
												// updateTokenValidity(client_id,
												// token);
												setApiUsageStatus(client_id, api_name, connection);
											}
										else
											{
												returnMessage = getJsonErr(401, "User Not Authorized", "Access Denied");
												jarray.put(returnMessage);
												//new SendGridExample().sendEmail(jarray.toString(), client_id, token, api_name, "Invalid Token");
											}
										log.info("validate-" + flag);
										return flag;
									}
								else
									{
										log.info("Inside validateClient(..) method ---> token input is found blank");
										/*
										 * errjobj =
										 * commonmethod.getJsonStatus(400,
										 * "Bad request",
										 * "Token should not be blank");
										 * jarray.put(errjobj);
										 * errjobj.put("ERROR",
										 * "User Id cannot be blank");
										 * jarray.put(errjobj);
										 */
										return flag;
									}
							}
						else
							{
								log.info("Inside validateClient(..) method ---> client_id id input is not set");
								/*
								 * errjobj = commonmethod.getJsonStatus(400,
								 * "Bad request",
								 * "client_id Id should not be blank");
								 * jarray.put(errjobj); errjobj.put("ERROR",
								 * "client_id Id cannot be blank");
								 * jarray.put(errjobj);
								 */
								return flag;
							}
					}
				catch (SQLException e)
					{
						e.printStackTrace();
						returnMessage = getJsonErr(501, "Processing error � One or more of internal systems gave an error while processing the request", "Database Error. Please try after some time");
						jarray.put(returnMessage);
						e.printStackTrace(new PrintWriter(errors));
						//new SendGridExample().sendEmail(jarray.toString(), client_id, token, api_name, errors.toString());
						return flag;
						/*
						 * errjobj = commonmethod.getJsonStatus(501,
						 * "Database connectivity issues or timeouts",
						 * "Please try after some time"); jarray.put(errjobj);
						 * errjobj.put("ERROR",
						 * "Database Error,Please try after some time" );
						 * jarray.put(errjobj);
						 */
					}
				catch (Exception e)
					{
						e.printStackTrace();
						return flag;
						/*
						 * errjobj = commonmethod.getJsonStatus(402,
						 * "Error in processing",
						 * "Error while processing request");
						 * jarray.put(errjobj);
						 */
					}
				finally
					{
						try
							{
								if (rs != null)
									{
										rs.close();
									}
								if (statement != null)
									{
										statement.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
						// return flag;
					}
			}


		public void setApiUsageStatus(String client_id, String api_name, Connection connection)
			{
				String query = "";
				// Connection connection = null;
				PreparedStatement pstatement = null;
				// String client_id = "";
				boolean returnValue = false;
				String current_time = null;
				log.info("Inside setApiUsageStatus client_id is " + client_id + " api_name is " + api_name);
				try
					{
						if (connection == null || connection.isClosed())
							{
								connection = new DatabaseUtil().getConnection();
								log.info("Inside setApiUsageStatus Passed connection not found hense instantiated new");
							}
						Date currdate = new Date();
						SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
						current_time = formatter.format(currdate);
						query = "insert into participant_apiusage_rev(client_id,api_name,time) values(?,?,?)";
						pstatement = connection.prepareStatement(query);
						pstatement.setString(1, client_id);
						// pstatement.setString(2, userid);
						pstatement.setString(2, api_name);
						pstatement.setString(3, current_time);
						returnValue = pstatement.execute();
						connection.commit();
						log.info("Inside setApiUsageStatus Insert Status : " + returnValue);
					}
				catch (Exception e)
					{
						e.printStackTrace();
						log.warning("Exception in setApiUsageStatus : " + e.getMessage());
					}
				finally
					{
						try
							{
								if (pstatement != null)
									{
										pstatement.close();
									}
							}
						catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				/*
				 * finally{
				 * 
				 * }
				 */
			}


		public JSONArray updateTokenValidity(String client_id, String token)
			{
				Connection connection = null;
				JSONArray jarray = new JSONArray();
				Statement statement = null;
				String current_time = null;
				String exp_time = null;
				try
					{
						Date currdate = new Date();
						SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
						current_time = formatter.format(currdate);
						Calendar cal = Calendar.getInstance();
						cal.add(Calendar.MINUTE, 1440);// 24 hours in minutes :
														// 60 min = 1
														// hour
						exp_time = formatter.format(cal.getTime());
						log.info("Inside updateTokenValidity---" + current_time + "***" + exp_time);
						connection = new DatabaseUtil().getConnection();
						// update token_details with token
						String query1 = "update participant_token_details set expiry_time = '" + exp_time + "' where client_id ='" + client_id + "' AND token='" + token + "'";
						statement = connection.createStatement();
						log.info("update query:" + query1);
						statement.execute(query1);
						connection.commit();
						JSONObject jobj = new JSONObject();
						jobj.put("token", token);
						jarray.put(jobj);
					}
				catch (Exception e)
					{
						e.printStackTrace();
						log.warning("Exception in  updateTokenValidity---" + e.getMessage());
					}
				return jarray;
			}


		@GET
		@Path("/participantmapping")
		@Produces
		public String getParticipantMapping(@QueryParam("client_id")
		String client_id)
			{
				log.info("###-------- Participant Mapping --------###");
				String returnValue = "";
				Statement stmt1 = null;
				ResultSet rs1 = null;
				Statement stmt3 = null;
				ResultSet rs3 = null;
				ResultSet rs = null;
				String treasury = null;
				String userid = "";
				// SecuritirsDAO dao=new SecuritirsDAO();
				JSONArray jarry = new JSONArray();
				String currencypair = "";
				Connection connection = null;
				Statement statement = null;
				try
					{
						log.info("Inside Participant Mapping :" + client_id);
						String query = "Select CUSTID from PARTICIPANT_MASTER  where LOWER(CLIENT_ID)='" + client_id.toLowerCase() + "'";
						DatabaseUtil util = new DatabaseUtil();
						if (connection == null || connection.isClosed())
							{
								connection = new DatabaseUtil().getConnection();
								System.out.println("Inside participantmapping");
							}
						statement = connection.createStatement();
						String cust_ids = null;
						String schemeID = null;
						String bankName = null;
						String accountno = null;
						rs = statement.executeQuery(query);
						if (rs.next())
							{
								cust_ids = rs.getString("CUSTID");
							}
						else
							{
								// returnValue = dao.getJsonStatus(402, "Bad
								// Request", "Inavlid Participant ID or
								// Participant ID not present in Database");
								jarry.put(returnValue);
							}
						log.info("-------- Cust IDs " + cust_ids);
						String[] custArry;
						if (!cust_ids.equals(""))
							{
								custArry = cust_ids.split("-");
								String loan;
								String card;
								stmt1 = connection.createStatement();
								for (int i = 0; i < custArry.length; i++)
									{
										System.out.println("Cust ID : " + custArry[i]);
										// rs1 = stmt1.executeQuery("Select
										// m.scheme_id,p.ACCOUNTNO,c.CARD_NUMBER,l.LOAN_ACCOUNT_NO
										// from treasury.rtl_account_master
										// p,treasury.rtl_card_details
										// c,treasury.rtl_loan_master
										// l,treasury.mutual_fund_master m where
										// p.custid=c.custid and
										// p.custid=l.custid and
										// m.custid=c.custid and p.CUSTID
										// ='"+custArry[i]+"'");
										rs1 = stmt1.executeQuery("Select m.scheme_id,p.ACCOUNTNO,p.debit_card_no,l.LOAN_ACCOUNT_NO, p.BANK_NAME from rtl_account_master p,rtl_loan_master l,mutual_fund_master m where p.custid=l.custid and p.custid=m.custid and p.CUSTID =" + custArry[i] + "");
										while (rs1.next())
											{
												card = rs1.getString("debit_card_no");
												loan = rs1.getString("LOAN_ACCOUNT_NO");
												accountno = rs1.getString("accountno");
												schemeID = rs1.getString("scheme_id");
												bankName = rs1.getString("BANK_NAME");
												System.out.println("Scheme ID : " + schemeID);
												JSONObject jobj = new JSONObject();
												jobj.put("cust_id", custArry[i]);
												jobj.put("bank_name", bankName);
												jobj.put("account_no", accountno);
												jobj.put("loan account_no", loan);
												jobj.put("debit card no", card);
												jobj.put("securities_scheme_id", schemeID);
												jarry.put(jobj);
											}
										System.out.println("--------- Treasury -----------");
										treasury = "select CUST_ID,USER_ID,CURR_PAIR from tre_currency_master where cust_id='" + custArry[i] + "'";
										stmt3 = connection.createStatement();
										rs3 = stmt3.executeQuery(treasury);
										int j = 0;
										currencypair="";
										while (rs3.next())
											{
												System.out.println("treasury _ Query::" + treasury);
												userid = rs3.getString("USER_ID");
												currencypair = currencypair + rs3.getString("CURR_PAIR") + ",";
												System.out.println("CurrencyPair --- " + j + " : " + currencypair);
												j++;
											}
										JSONObject jobj = new JSONObject();
										jobj.put("treasury_cust_id", custArry[i]);
										jobj.put("treasury_userid", userid);
										jobj.put("treasury_currency_pair", currencypair.substring(0, currencypair.length() - 1));
										jarry.put(jobj);
										System.out.println("--------- Treasury ------End-----");
									}
								String corp_query = "Select corpid,userid,typeofcustomer,mobile,city from PARTICIPANT_MASTER  where CLIENT_ID='" + client_id + "'";
								ResultSet rs2 = stmt1.executeQuery(corp_query);
								while (rs2.next())
									{
										JSONObject jobj = new JSONObject();
										System.out.println("Myquery::" + corp_query);
										jobj.put("corpid", rs2.getString("corpid"));
										jobj.put("userid", rs2.getString("userid"));
										jobj.put("custid", rs2.getString("typeofcustomer"));
										jobj.put("rmmobile", rs2.getString("mobile"));
										jobj.put("ucc", rs2.getString("city"));
										jarry.put(jobj);
										System.out.println("corp_data---" + jarry.toString());
									}
								// log.info("Account Nos :
								// "+accountno.toString());
							}
					}
				catch (SQLException e)
					{
						log.info(e.getMessage());
						e.printStackTrace();
						// returnValue = dao.getJsonStatus(501, "Database
						// connectivity issue or Timeouts.", "Database Error.
						// Please try after some time.");
						jarry.put(returnValue);
					}
				catch (Exception e)
					{
						log.info(e.getMessage());
						e.printStackTrace();
						// returnValue = dao.getJsonStatus(402, "Error in
						// processing.", "Errorr...");
						jarry.put(returnValue);
					}
				log.info("###-------- Participant Mapping End--------###");
				return jarry.toString();
			}
		/*
		 * public boolean validateClient(String email, String token) {
		 * Connection connection = null; JSONArray jarray = new JSONArray();
		 * ResultSet rs = null; Statement statement = null; String query = "";
		 * boolean flag = false; String current_time = null; log.info(
		 * "Inside validateClient(..) method emailid is " + email + " token is "
		 * + token); try { // if(connection == null || connection.isClosed()){
		 * connection = DatabaseUtil.getConnection(); Date currdate = new
		 * Date(); SimpleDateFormat formatter = new SimpleDateFormat(
		 * "yyyy-MM-dd HH:mm:ss" );
		 * formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
		 * current_time = formatter.format(currdate); // } if
		 * (!email.equals("")) { if (!token.equals("")) { // query = //
		 * "select emailid,token from participant_token_details where emailid='"
		 * +email+"' and token='"+token+
		 * "' and (SELECT MINUTE(expiry_time) - MINUTE('"+current_time+
		 * "') FROM SYSIBM.SYSDUMMY1) > 0"; query =
		 * "select client_id,token from fnpbbmor.participant_token_details where client_id='"
		 * + email + "' and token='" + token +
		 * "' and (SELECT timestampdiff (4, char(timestamp(p.expiry_time)-timestamp('"
		 * + current_time +
		 * "'))) FROM fnpbbmor.participant_token_details p, SYSIBM.SYSDUMMY1 where p.client_id='"
		 * + email + "' and p.token='" + token + "') >0";
		 * 
		 * log.info("VALIDATE_____________" + query); statement =
		 * connection.createStatement(); rs = statement.executeQuery(query);
		 * 
		 * while (rs.next()) { System.out
		 * .println("****************************************************");
		 * JSONObject jobj = new JSONObject(); jobj.put("emailid",
		 * rs.getString(1)); jobj.put("token", rs.getString(2));
		 * jarray.put(jobj); } if (jarray.length() != 0) { flag = true; }
		 * log.info("validate-" + flag); return flag; } else { log.info(
		 * "Inside validateClient(..) method ---> token input is found blank");
		 * 
		 * return flag; } } else {
		 * 
		 * return flag; } } catch (SQLException e) { e.printStackTrace(); return
		 * flag;
		 * 
		 * } catch (Exception e) { e.printStackTrace(); return flag;
		 * 
		 * } /* finally { try { statement.close(); rs.close();
		 * connection.close(); rs = null; statement = null; connection = null; }
		 * catch (Exception e) { e.printStackTrace(); } return flag; }
		 */
		// }*/
	}
