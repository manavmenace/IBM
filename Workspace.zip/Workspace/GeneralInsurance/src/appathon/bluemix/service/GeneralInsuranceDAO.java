package appathon.bluemix.service;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class GeneralInsuranceDAO {
	private static final Logger LOGGER = Logger
			.getLogger(GeneralInsuranceDAO.class.getName());
	public DatabaseUtil dbUtil = new DatabaseUtil();

	public Double getPremiumAmt(String manufacturer, String model,
			Connection connection) throws SQLException {
		if (connection == null || connection.isClosed()) {
			System.out.println("Inside connection open : " + connection);
			connection = dbUtil.getConnection();
		}
		Statement statement = connection.createStatement();
		String queryString = "SELECT premium FROM GI_QUOTE_MASTER where lower(manufacture) = '"
				+ manufacturer.toLowerCase()
				+ "' and lower(model) = '"
				+ model.toLowerCase() + "'";
		ResultSet resultSet = statement.executeQuery(queryString);
		Double amt = 0.0;
		while (resultSet.next()) {
			amt = resultSet.getDouble("premium");
		}
	
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (statement != null) {
					statement.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		
		return amt;
	}

	public void saveQuickQuotes(String custName, String mobileNo,
			String emailId, String manufacturer, String model,
			Double premium_amt, String address, String rto, String regDt,
			Double ex_showroom_price, Double idv, Connection connection)
			throws SQLException {
		System.out.println("Inside Save Quick Quotes : " + custName);
		Statement statement = null;
		try {
			if (connection == null || connection.isClosed()) {
				System.out.println("Inside connection open : " + connection);
				connection = dbUtil.getConnection();
			}
			statement = connection.createStatement();
			statement
					.execute("insert into GI_QUOTE_DTLS (cust_name, mobile_no, email_id, manufacture, model, premium, address, rto, regDt, ex_showroom_price, idv) values ('"
							+ custName
							+ "','"
							+ mobileNo
							+ "','"
							+ emailId
							+ "','"
							+ manufacturer
							+ "','"
							+ model
							+ "','"
							+ premium_amt
							+ "','"
							+ address
							+ "','"
							+ rto
							+ "','"
							+ regDt
							+ "','"
							+ ex_showroom_price
							+ "','"
							+ idv + "')");
			connection.commit();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception el) {
			el.printStackTrace();
		}
		finally{
			try {
			
				if (statement != null) {
					statement.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public JSONArray getQuickQuotes(String mobile_no, String email_id,
			Connection connection) throws SQLException, JSONException {

		if (connection == null || connection.isClosed()) {
			System.out.println("Inside connection open : " + connection);
			connection = dbUtil.getConnection();
		}
		Statement statement = connection.createStatement();
		String queryString = "SELECT * FROM GI_QUOTE_DTLS where mobile_no = '"
				+ mobile_no
				+ "' or lower(email_id) = '"
				+ email_id.toLowerCase() + "'";
		ResultSet resultSet = statement.executeQuery(queryString);
		JSONArray jsonArray = new JSONArray();
		while (resultSet.next()) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("cust_name", resultSet.getString("cust_name"));
			jsonObject.put("mobile_no", resultSet.getString("mobile_no"));
			jsonObject.put("email_id", resultSet.getString("email_id"));
			jsonObject.put("manufacture", resultSet.getString("manufacture"));
			jsonObject.put("model", resultSet.getString("model"));
			jsonObject.put("premium", resultSet.getDouble("PREMIUM"));
			jsonObject.put("address", resultSet.getString("address"));
			jsonObject.put("rto", resultSet.getString("rto"));
			jsonObject.put("regDt", (resultSet.getDate("regDt")).toString());
			jsonObject.put("ex_showroom_price",
					resultSet.getString("ex_showroom_price"));
			jsonObject.put("idv", resultSet.getDouble("idv"));
			jsonArray.put(jsonObject);
		}
		try {
			if (resultSet != null) {
				resultSet.close();
			}
			if (statement != null) {
				statement.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return jsonArray;
		
	}

	public JSONArray getRenewalNotice(String mobileNo, String emailId,
			Connection connection) throws SQLException, JSONException {
		if (connection == null || connection.isClosed()) {
			System.out.println("Inside connection open : " + connection);
			connection = dbUtil.getConnection();
		}
		String queryString = "select top 1 mobile_no, email_id, vehicle_tp, policy_no, engine_no, chasis_no, manufacturer, model, rto, cust_name, cust_name, policy_st_date, policy_end_date, new_policy_no, idv, basic_premium, serv_tax, tot_premium_amt from GI_RENEWAL_DATA where mobile_no = '"
				+ mobileNo
				+ "' or lower(email_id) = '"
				+ emailId.toLowerCase()
				+ "'";
		JSONArray jsonArray = new JSONArray();
		Statement statement = connection.createStatement();
		ResultSet resultSet = statement.executeQuery(queryString);
		JSONObject js = new JSONObject();
		js.put("code", 200);
		jsonArray.put(js);
		while (resultSet.next()) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("mobile_no", resultSet.getString("mobile_no"));
			jsonObject.put("email_id", resultSet.getString("email_id"));
			jsonObject.put("vehicle_tp", resultSet.getString("vehicle_tp"));
			jsonObject.put("policy_no", resultSet.getString("policy_no"));
			jsonObject.put("engine_no", resultSet.getString("engine_no"));
			jsonObject.put("chasis_no", resultSet.getString("chasis_no"));
			jsonObject.put("manufacturer", resultSet.getString("manufacturer"));
			jsonObject.put("model", resultSet.getString("model"));
			jsonObject.put("rto", resultSet.getString("rto"));
			jsonObject.put("cust_name", resultSet.getString("cust_name"));
			jsonObject.put("policy_st_date",
					resultSet.getString("policy_st_date"));
			jsonObject.put("policy_end_date",
					resultSet.getString("policy_end_date"));
			jsonObject.put("new_policy_no",
					resultSet.getString("new_policy_no"));
			jsonObject.put("idv", resultSet.getString("idv"));
			jsonObject.put("basic_premium",
					resultSet.getString("basic_premium") + "0");
			jsonObject.put("serv_tax", resultSet.getString("serv_tax"));
			jsonObject.put("tot_premium_amt",
					resultSet.getString("tot_premium_amt"));

			jsonArray.put(jsonObject);
		}
		return jsonArray;
	}

	public JSONArray getCustomerDtls(String mobile_no, String email_id,
			Connection connection) throws SQLException, JSONException {
		if (connection == null || connection.isClosed()) {
			System.out.println("Inside connection open : " + connection);
			connection = dbUtil.getConnection();
		}
		Statement statement = null;
		ResultSet resultSet1 = null;
		ResultSet resultSet2 = null;
		JSONArray jsonArray = new JSONArray();
		JSONObject js = new JSONObject();
		js.put("code", 200);
		jsonArray.put(js);

		try {
			statement = connection.createStatement();
			String queryString = "select top 1 * from GI_CUSTOMER_POLICY cp  where cp.Mobile_No = '"
					+ mobile_no
					+ "' or lower(cp.Email_ID) = '"
					+ (email_id.toLowerCase()) + "'";
			ResultSet resultSet = statement.executeQuery(queryString);
			while (resultSet.next()) {
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("insured_name",
						resultSet.getString("insured_name"));
				jsonObject.put("dob", resultSet.getString("dob"));
				jsonObject.put("resident_add",
						resultSet.getString("resident_add"));
				jsonObject.put("state", resultSet.getString("state"));
				jsonObject.put("pincode", resultSet.getString("pincode"));
				jsonObject.put("product", resultSet.getString("product"));

				// jsonObject.put("policyno", resultSet.getString("policyno"));
				jsonObject.put("policy_start_date",
						resultSet.getString("policy_start_date"));
				jsonObject.put("policy_end_date",
						resultSet.getString("policy_end_date"));
				jsonObject.put("total_premium_amt",
						resultSet.getString("total_premium_amt") + "0");
				jsonObject.put("mobile_no", mobile_no);
				jsonObject.put("email_id", email_id);
				jsonArray.put(jsonObject);
			}

			String queryString1 = "select top 1 * from GI_CLAIM cp  where cp.Mobile_No = '"
					+ mobile_no
					+ "' or lower(cp.Email_ID) = '"
					+ (email_id.toLowerCase()) + "'";
			resultSet1 = statement.executeQuery(queryString1);
			while (resultSet1.next()) {
				JSONObject jsonObject1 = new JSONObject();
				jsonObject1.put("claim_no", resultSet1.getString("claim_no"));
				jsonObject1.put("reg_dt", resultSet1.getString("reg_dt"));
				jsonObject1.put("claim_status",
						resultSet1.getString("claim_status"));
				jsonObject1.put("lastchanged_status_dt",
						resultSet1.getString("lastchanged_status_dt"));
				jsonArray.put(jsonObject1);
			}
			String queryString2 = "select top 1 * from GI_SERVICE cp  where cp.Mobile_No = '"
					+ mobile_no
					+ "' or lower(cp.Email_ID) = '"
					+ (email_id.toLowerCase()) + "'";
			resultSet2 = statement.executeQuery(queryString2);
			while (resultSet2.next()) {
				JSONObject jsonObject2 = new JSONObject();
				jsonObject2.put("service_req_no",
						resultSet2.getString("service_req_no"));
				jsonObject2.put("incident_type",
						resultSet2.getString("incident_type"));
				jsonObject2.put("incident_raised_dt",
						resultSet2.getString("incident_raised_dt"));
				jsonObject2.put("incident_status", "Open");
				jsonArray.put(jsonObject2);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (resultSet1 != null) {
					resultSet1.close();
				}
				if (resultSet2 != null) {
					resultSet2.close();
				}
				if (statement != null) {
					statement.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return jsonArray;
	}

	public boolean validateClient(String client_id, String token,
			String api_name, Connection connection) {
		// CommonMethod commonmethod = new CommonMethod();
		JSONObject errjobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		ResultSet rs = null;
		Statement statement = null;
		PreparedStatement pstatement = null;
		int count = 0;
		// String client_id = "";
		String result = "";
		String query = "";
		boolean flag = false;
		String current_time = null;
		LOGGER.info("Inside validateClient(..) method client_id is "
				+ client_id + " token is " + token);
		try {
			// if(connection == null || connection.isClosed()){
			if (connection == null || connection.isClosed()) {
				System.out.println("Inside connection open : " + connection);
				connection = dbUtil.getConnection();
			}
			Date currdate = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat(
					"yyyy-MM-dd HH:mm:ss");
			formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
			current_time = formatter.format(currdate);
			// }
			if (!client_id.equals("")) {
				if (!token.equals("")) {
					// query =
					// "select client_id,token from participant_token_details where client_id='"+client_id+"' and token='"+token+"' and (SELECT MINUTE(expiry_time) - MINUTE('"+current_time+"') FROM SYSIBM.SYSDUMMY1) > 0";
					
					
					/*query = "select client_id,token from fnpbbmor.participant_token_details where LOWER(client_id)='"
							+ client_id.toLowerCase()
							+ "' and token='"
							+ token
							+ "' and (SELECT timestampdiff (4, char(timestamp(p.expiry_time)-timestamp('"
							+ current_time
							+ "'))) FROM fnpbbmor.participant_token_details p, SYSIBM.SYSDUMMY1 where LOWER(p.client_id)='"
							+ client_id.toLowerCase()
							+ "' and p.token='"
							+ token + "') >0";*/
					query = "select client_id,token from participant_token_details " + "where client_id='" + client_id + "' and token = '" + token + "'";
					LOGGER.info("VALIDATE_____________" + query);
					statement = connection.createStatement();
					rs = statement.executeQuery(query);

					while (rs.next()) {
						System.out.println("Inside while Validate Method");
						JSONObject jobj = new JSONObject();
						jobj.put("client_id", rs.getString(1));
						jobj.put("token", rs.getString(2));
						jarray.put(jobj);
					}
					if (jarray.length() != 0) {
						flag = true;
						//
						// updateTokenValidity(client_id, token);
						setApiUsageStatus(client_id, api_name, connection);
					}
					System.out.println("validate-" + flag);
					return flag;
				} else {
					LOGGER.info("Inside validateClient(..) method ---> token input is found blank");
					/*
					 * errjobj = commonmethod.getJsonStatus(400, "Bad request",
					 * "Token should not be blank"); jarray.add(errjobj);
					 * errjobj.put("ERROR", "User Id cannot be blank");
					 * jarray.add(errjobj);
					 */
					return flag;
				}
			} else {
				LOGGER.info("Inside validateClient(..) method ---> client_id id input is not set");
				/*
				 * errjobj = commonmethod.getJsonStatus(400, "Bad request",
				 * "client_id Id should not be blank"); jarray.add(errjobj);
				 * errjobj.put("ERROR", "client_id Id cannot be blank");
				 * jarray.add(errjobj);
				 */
				return flag;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return flag;
			/*
			 * errjobj = commonmethod.getJsonStatus(501,
			 * "Database connectivity issues or timeouts",
			 * "Please try after some time"); jarray.add(errjobj);
			 * errjobj.put("ERROR",
			 * "Database Error,Please try after some time");
			 * jarray.add(errjobj);
			 */
		} catch (Exception e) {
			e.printStackTrace();
			return flag;
			/*
			 * errjobj = commonmethod.getJsonStatus(402, "Error in processing",
			 * "Error while processing request"); jarray.add(errjobj);
			 */
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (statement != null) {
					statement.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void setApiUsageStatus(String client_id, String api_name,
			Connection connection) {
		String query = "";
		ResultSet rs = null;
		Statement statement = null;
		PreparedStatement pstatement = null;
		int count = 0;
		// String client_id = "";
		String result = "";
		boolean returnValue = false;
		String current_time = null;
		LOGGER.info("Inside setApiUsageStatus(..) method client_id is "
				+ client_id + " api_name is " + api_name);
		try {
			if (connection == null || connection.isClosed()) {
				System.out.println("Inside connection open : " + connection);
				connection = dbUtil.getConnection();
			}
			Date currdate = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat(
					"yyyy-MM-dd HH:mm:ss");
			formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
			current_time = formatter.format(currdate);
			query = "insert into participant_apiusage_rev(client_id,api_name,time) values(?,?,?)";
			pstatement = connection.prepareStatement(query);
			pstatement.setString(1, client_id);
			// pstatement.setString(2, userid);
			pstatement.setString(2, api_name);
			pstatement.setString(3, current_time);
			returnValue = pstatement.execute();
			connection.commit();
			LOGGER.info("Inside setApiUsageStatus(..) method insert result"
					+ returnValue);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.warning("Exception in setApiUsageStatus() method"
					+ e.getMessage());
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (statement != null) {
					statement.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

	}
}
