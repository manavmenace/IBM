package appathon.bluemix.service;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.TimeZone;
import java.util.UUID;

import org.json.JSONException;
import org.json.JSONObject;



public class CommonClass {
	public JSONObject getJsonStatus(int errCd, String errMsg, String errDesc) throws JSONException{
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("code", errCd);
		jsonObject.put("message", errMsg);
		jsonObject.put("description", errDesc);
		return jsonObject;
	}
	
	public String getJsonStatus1(int errCd, String errMsg, String errDesc) throws JSONException{
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("code", errCd);
		jsonObject.put("message", errMsg);
		jsonObject.put("description", errDesc);
		return jsonObject+"";
	}
	
	public String generateToken(){
		String str = (UUID.randomUUID().toString()).replace("-", "");
		System.out.println("uuid = " + str);
		if(str.contains("%")){
			str = str.replace("%", "");
		}
		String token = str.substring(1, 13);
		System.out.println("token = " + token);
		/*int randomToken=0;	
		ByteArrayOutputStream baos = null;
		DataOutputStream dos = null;
		byte[] data = null;
		String token = "";
		try{
		     //generate a 6 digit integer 
		     randomToken = (int)(Math.random()*99999)+100000;
//		     String token = String.valueOf(randomToken);
		     baos = new ByteArrayOutputStream ();
		     dos = new DataOutputStream (baos);
		     dos.writeInt (randomToken);
		     data = baos.toByteArray();
		     token = data.toString();
		     System.out.println("TOKEN:::"+token);
			}
			catch(Exception e){
				e.printStackTrace();
			}*/
		     return token;
	}
	
	public boolean validateDate(String dateInString){
		boolean flag = false;
		boolean compare_currdateFlag = false;
		Date currdate = new Date();
		try{
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
		//		String dateInString = "2015-03-07";

		System.out.println("CURR "+formatter.format(currdate));
		Date enterddate = formatter.parse(dateInString);
		System.out.println("FORM "+formatter.format(enterddate));
		
		compare_currdateFlag = compareDatesByDateMethods(formatter, enterddate, currdate);
		if(compare_currdateFlag){
		
		Calendar cal = Calendar.getInstance();
		cal.setTime(enterddate);  //use java.util.Date object as arguement
		// get the value of all the calendar date fields.
		int enter_year = cal.get(Calendar.YEAR);
		System.out.println("Enter Year: " +enter_year);
		int enter_month = cal.get(Calendar.MONTH);
		System.out.println("ENter Month: " +enter_month );
		int enter_day = cal.get(Calendar.DATE);
		System.out.println("Enter Day: " +enter_day );

		cal.setTime(currdate);  //use java.util.Date object as arguement
		// get the value of all the calendar date fields.
		int curr_year = cal.get(Calendar.YEAR);
		System.out.println("current Year: " +curr_year);
		int curr_year_month = cal.get(Calendar.MONTH);
		System.out.println("current Month: " + curr_year_month);
		int curr_year_day = cal.get(Calendar.DATE);
		System.out.println("current Day: " +curr_year_day );

		String start_date ="";
		String end_date = "";
		if(enter_year == curr_year){
			if((enter_month+1) <= 3){
				flag = true;
				System.out.println("Enterd date is valid");
				return flag;
			}
			{
				System.out.println("Invalid Date");
				return flag;
			}
		}
		if(enter_year == curr_year-1){
			if((enter_month+1) >= 4){
			flag = true;	
			return flag;
			}
			else{
				System.out.println("Invalid Date");
				return flag;
			}
		}
		}
		else{
			return false;
		}
		}
		catch(Exception e){
			e.printStackTrace();
			return flag;
		}
		return flag;
	}
	
	public HashMap getDates(String dateInString) {
		// TODO Auto-generated method stub
		HashMap hm = new HashMap<String, String>();
		try{
			Date currdate = new Date();

			DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
			//		String dateInString = "2015-03-07";

			System.out.println("CURR "+formatter.format(currdate));
			Date enterddate = formatter.parse(dateInString);
			System.out.println("FORM "+formatter.format(enterddate));

			Calendar cal = Calendar.getInstance();
			cal.setTime(enterddate);  //use java.util.Date object as arguement
			// get the value of all the calendar date fields.
			int enter_year = cal.get(Calendar.YEAR);
			System.out.println("Enter Year: " +enter_year);
			int enter_month = cal.get(Calendar.MONTH);
			System.out.println("ENter Month: " +enter_month );
			int enter_day = cal.get(Calendar.DATE);
			System.out.println("Enter Day: " +enter_day );

			cal.setTime(currdate);  //use java.util.Date object as arguement
			// get the value of all the calendar date fields.
			int curr_year = cal.get(Calendar.YEAR);
			System.out.println("current Year: " +curr_year);
			int curr_year_month = cal.get(Calendar.MONTH);
			System.out.println("current Month: " + curr_year_month);
			int curr_year_day = cal.get(Calendar.DATE);
			System.out.println("current Day: " +curr_year_day );

			String start_date ="";
			String end_date = "";
			if(enter_year == curr_year){
				if((enter_month+1) <= 3){
					System.out.println("Enterd date is valid");
					start_date 	= (curr_year-1)+"-04-01";
					end_date 	= dateInString;
				}
				{
					System.out.println("Invalid Date");
				}
			}
			if(enter_year == curr_year-1){
				if((enter_month+1) >= 4){
					start_date = curr_year-1+"-04-01";
					end_date = dateInString;
				}
				else{
					System.out.println("Invalid Date");
				}
			}


			hm.put("currYear_strat_date", start_date);
			hm.put("currYear_end_date", end_date);
			hm.put("prevYear_start_date",curr_year-2+"-04-01" );
			hm.put("prevYear_end_date",String.valueOf(curr_year-1) +"-"+String.valueOf(enter_month+1)+"-"+String.valueOf(enter_day+1));
			return hm;
		}
		catch(Exception e){
			e.printStackTrace();
			return hm;
		}
	}

	public  boolean compareDatesByDateMethods(DateFormat df, Date enterd_date, Date current_date) {
        //how to check if two dates are equals in java
                if (enterd_date.after(current_date)) {
            System.out.println(df.format(enterd_date) + " comes after " + df.format(current_date));
            return false;
                }
                else{
                	return true;
                }
                
        
    }

	
	
	
	public JSONObject getFinancialYear(String start_date) throws JSONException{
		String[] dateArray = start_date.split("-");
		int year = Integer.parseInt(dateArray[0]);
	    int month = Integer.parseInt(dateArray[1]);
	    int day = Integer.parseInt(dateArray[2]);
	    int startFinancialYr, endFinancialYr, prevStartFinYr, prevEndFinYr;
	    
		//Getting Financial year of the date entered.
	    if (month < 4) {
	        System.out.println("Financial Year : " + (year - 1) + "-" + year);
	        startFinancialYr = year - 1;
	        endFinancialYr = year; 
	    } else {
	        System.out.println("Financial Year : " + year + "-" + (year + 1));
	        startFinancialYr = year;
	        endFinancialYr = year + 1;
	    }
	    
	    prevStartFinYr = startFinancialYr - 1;
	    prevEndFinYr = endFinancialYr - 1;
		
	    String startFinancialYrDate = String.valueOf(startFinancialYr)+"-04-01";
	    String endFinancialYrDate = String.valueOf(endFinancialYr)+"-03-31";
	    
	    String startPrevFinancialYrDate = String.valueOf(prevStartFinYr)+"-04-01";
	    String endPrevFinancialYrDate = String.valueOf(prevStartFinYr)+"-03-31";
	    
	    JSONObject jsonObject = new JSONObject();
	    jsonObject.put("startFinancialYrDate", startFinancialYrDate);
	    jsonObject.put("endFinancialYrDate", endFinancialYrDate);
	    jsonObject.put("startPrevFinancialYrDate", startPrevFinancialYrDate);
	    jsonObject.put("endPrevFinancialYrDate", endPrevFinancialYrDate);
	    return jsonObject;
	}

	public String getJsonErr(int errCd, String errMsg, String errDesc) throws JSONException {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("code", errCd);

        if (errCd == 400) {
            jsonObject.put("message", "Bad request. Invalid Request parameter");
        } else if (errCd == 501) {
            jsonObject
                    .put("message",
                            "Processing error � One or more of internal systems gave an error while processing the request");
        } else if (errCd == 503) {
            jsonObject.put("message", "No Data Found");
        } else {
            jsonObject.put("message", errMsg);

        }
        jsonObject.put("description", errDesc);
        return jsonObject.toString();
    }

//Previous approv txn code
/*	public String getcorpAprove(
			@QueryParam("email") String email,
			@QueryParam("token") String token,
			@QueryParam("corpid") String corpid,
			@QueryParam("custid") String custid,
			@QueryParam("tranid") String tranid,
			@QueryParam("action") String action) {

		LOGGER.info("###---- Corp Approve Transaction ----###");
		CommonMethod commonmethod = new CommonMethod();
		Connection connection;
		ResultSet rs = null;
		ResultSet rs1 = null;
		JSONObject jobj = new JSONObject();
		String status = "";
		String approve1 = "";
		String approve2 = "";
		int statusflag = 0;
		String result="";
		boolean flag = false;
		String regex1 = "^[a-zA-Z0-9]*$";
		String regex2 = "^[0-9]*$";
		flag = validateClient(email, token);
		if(flag){
			connection = DatabaseUtil.getConnection();
			if(!corpid.equals("") && corpid.matches(regex1) && corpid.length()==10)
			{
				if(!custid.equals("") && custid.matches(regex2) && custid.length()==8){
					if(!tranid.equals("") && tranid.matches(regex2))
					{
						if(action.trim().equalsIgnoreCase("A") || action.trim().equalsIgnoreCase("R"))
						{
							try {
								LOGGER.info("get Status for tranid : " + tranid);
								Statement statement = connection.createStatement();
								rs = statement
										.executeQuery("select status from user09768.corp_transaction_details where tranid="
												+ tranid);
								if (rs.next()) {
									status = rs.getString("status").trim();

									LOGGER.info("Status fron transaction table : " + status);
									LOGGER.info("get approver's for corp id : " + corpid);
									rs1 = statement
											.executeQuery("select user_approver1,user_approver2 from user09768.corp_workflow_master where lower(corp_id)='"
													+ corpid + "'");

									if (rs1.next()) {
										LOGGER.info("in if");
										LOGGER.info("in if Approve 1 : "
												+ rs1.getString("user_approver1"));

										approve1 = rs1.getString("user_approver1").trim();

										approve2 = rs1.getString("user_approver2").trim();
										LOGGER.info("Approvers fron worlflow table : " + approve1
												+ " - " + approve2);

										if (status.equals("0") && custid.equalsIgnoreCase(approve1)) {
											if (action.equalsIgnoreCase("A")) {
												statusflag = updateTranStatus(tranid, "1","Pending");
											} else if (action.equalsIgnoreCase("R")) {
												statusflag = updateTranStatus(tranid, "3","Rejected");
											}
										} else if (status.equals("1")
												&& custid.equalsIgnoreCase(approve2)) {
											if (action.equalsIgnoreCase("A")) {
												statusflag = updateTranStatus(tranid, "2","Approved");
												//account master balance update from to account
											} else if (action.equalsIgnoreCase("R")) {
												statusflag = updateTranStatus(tranid, "4","Rejected");
											}
										} else if (status.equals("3") || status.equals("4")) {
											returnMessage = commonmethod.getJsonErr(400,
													"Bad request. If request parameter are not provided.",
													"Transaction already Rejected");
											LOGGER.info(returnMessage.toString() + " -- " +action);
										}
										//jobj.put("error", "Transaction already Rejected");                    }
										else{
											returnMessage = commonmethod.getJsonErr(400,
													"Bad request. If request parameter are not provided.",
													"Invalid data");
											LOGGER.info(returnMessage.toString() + " -- " +action);
											//    jobj.put("error", "Invalid data");
										}
										LOGGER.info("Update Status " + statusflag);

									} else {
										returnMessage = commonmethod.getJsonErr(400,
												"Bad request. If request parameter are not provided.",
												"Invalid Corp ID");
										LOGGER.info(returnMessage.toString() + " -- " +action);
										//    jobj.put("error", "Invalid Corp ID");
										// dinvalid corp i
									}
								} else {
									returnMessage = commonmethod.getJsonErr(400,
											"Bad request. If request parameter are not provided.",
											"tran id should be valid number");
									//    jobj.put("error", "Invalid Transaction ID");
									// Invalid tran no
								}
							} catch (SQLException e) {
								e.printStackTrace();
							} 
							finally {
							try {
								connection.close();
								connection = null;
								rs.close();
								rs = null;
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
						}else{
							returnMessage = commonmethod.getJsonErr(400,
									"Bad request. If request parameter are not provided.",
									"Action should be 'A' or 'R'");
							LOGGER.info(returnMessage.toString() + " -- " +action);
						}
					}else{
						returnMessage = commonmethod.getJsonErr(400,
								"Bad request. If request parameter are not provided.",
								"Transaction ID can not nbe null and should be valid number");
						LOGGER.info(returnMessage.toString() + " -- " +action);
					}
				}else{
					returnMessage = commonmethod.getJsonErr(400,
							"Bad request. If request parameter are not provided.",
							"cust id should be valid 8 digit number");
					LOGGER.info(returnMessage.toString() + " -- " +action);
				}
			}else{
				returnMessage = commonmethod.getJsonErr(400,
						"Bad request. If request parameter are not provided.",
						"Corp Id should be fixed 10 digit alphanumberic string");
				LOGGER.info(returnMessage.toString() + " -- " +action);
			}

			if (statusflag == 1) {
				jobj.put("code", 200);
				jobj.put("approvalstatus", "success");
			} else {
				jobj.put("code", 200);
				jobj.put("approvalstatus", "failure or already approved");

			}
			LOGGER.info("Response : " + jobj.toString());
			if(jobj.size()==0)
			{
				result=returnMessage.toString();
			}
			else{
				result=jobj.toString();
			}

		}
		else{
			JSONObject errjobj = new JSONObject();
			JSONArray jarray = new JSONArray();
			LOGGER.info("Inside getCorpExportSummaryByUCC(..) method ---> ");
			errjobj = commonmethod.getJsonStatus(401, "User Not Authorized", "Access Denied");
			jarray.add(errjobj);
		}

		return result;
	}*/
	//Prev limit utilization code
/*	public String getSummaryForLimitUtilization(@QueryParam("email") String email,@QueryParam("token") String token,@QueryParam("rmmobile") String rm_mobile,@QueryParam("custid") String custid) {
		Connection connection = null;
		CommonMethod commonmethod = new CommonMethod();
		JSONObject errjobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		Statement statement = null;
		ResultSet rs = null;
		boolean returnValue=false;
		int count = 0;
		String regex1 = "^[0-9]*$";
		//	String regex = "^[a-zA-Z0-9]*$";
		String result = "";
		String query  = "";
		boolean flag = false;
		LOGGER.info("Inside getSummaryForLimitUtilization(..) method rm_mobile is "+rm_mobile+" custid is "+custid);
		try {
			flag = validateClient(email, token);
			if(flag){
				//			if(connection == null || connection.isClosed()){
				connection = DatabaseUtil.getConnection();
				//			}
				if (!rm_mobile.equals("") && rm_mobile.length() == 10 && rm_mobile.matches(regex1)) {

					if(!custid.equals("") && custid.matches(regex1) && custid.length()==8){

						query = "SELECT typeoflimit,limit_sanction,limit_utilized,equvivalent_INR,current date as sysdate from user09768.corp_limit_utilization where custid='"+custid+"' and rm_mobile='"+rm_mobile+"'";
						statement = connection.createStatement();
						rs = statement.executeQuery(query);
						while (rs.next()) {
							JSONObject jobj = new JSONObject();

							if(count==0){
								jarray.add(successObj);
								count++;
							}
							jobj.put("type_of_limit", rs.getString("typeoflimit"));
							jobj.put("limit_sanction", rs.getString("limit_sanction"));
							jobj.put("limit_utilized", rs.getString("limit_utilized"));
							jarray.add(jobj);
						}

						if(jarray.size() == 0){
							LOGGER.info("Inside getSummaryForLimitUtilization(..) method ---> NO record Found");
							errjobj = commonmethod.getJsonStatus(503, "No Record Found", "NO Record Found");
							jarray.add(errjobj);
						}
						count = 0;
					}
					else{
						LOGGER.info("Inside getSummaryForLimitUtilization(..) method ---> cust id should be valid 8 digit number");
						errjobj = commonmethod.getJsonStatus(400, "Bad request", "cust id should be valid 8 digit number");
						jarray.add(errjobj);
					}

				}
				else{
					LOGGER.info("Inside getSummaryForLimitUtilization(..) method --->RM Mobile number should be valid 10 digit number");
					errjobj = commonmethod.getJsonStatus(400, "Bad request", "RM Mobile number should be valid 10 digit number");
					jarray.add(errjobj);
				}
			}else{
				LOGGER.info("Inside getSummaryForLimitUtilization(..) method ---> ");
				errjobj = commonmethod.getJsonStatus(401, "User Not Authorized", "Access Denied");
				jarray.add(errjobj);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			//error for sql exception
			errjobj = commonmethod.getJsonStatus(501, "Database connectivity issues or timeouts", "Database Error,Please try after some time");
			jarray.add(errjobj);
		}
		catch (Exception e) {
			e.printStackTrace();
			//error for processing
			errjobj = commonmethod.getJsonStatus(500, "Processing Error", e.getMessage());
			jarray.add(errjobj);
		}
		finally{
		try{
			statement.close();
			rs.close();
			connection.close();
			rs = null;
			statement = null;
			connection = null;
			count = 0;
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
		result = jarray.toString();
		return result;
	}*/
//prv import summary
/*	public String getCorpImportSummaryAtUCCLevel(@QueryParam("email") String email,@QueryParam("token") String token,@QueryParam("rmmobile") String rm_mobile,@QueryParam("ucc") String ucc,@QueryParam("startdate_FY") String start_FYdate) {
		Connection connection = null;
		CommonMethod commonmethod = new CommonMethod();
		JSONObject errjobj = new JSONObject();
		JSONArray jarray = new JSONArray();
		Statement statement = null;
		ResultSet rs = null;
		boolean returnValue=false;
		int count = 0;
		String regex1 = "^[0-9]*$";
		//		String regex = "^[a-zA-Z0-9]*$";
		String result = "";
		String query  = "";
		boolean flag = false;
		//select custid,total_trade_transactions,total_eligible_transactions,total_tol_transactions,total_nontol_transactions,current date as sysdate from corp_tol_profile where rm_mobile ='9006512345' and custid ='cust01'
		LOGGER.info("Inside getCorpImportSummaryAtUCCLevel(..) method rm_mobile is "+rm_mobile+" ucc is "+ucc+"start_FYdate-"+start_FYdate);

		try {
			HashMap hm = new HashMap();
			hm = commonmethod.getDates(start_FYdate);
			LOGGER.info("hm.get(currYear_strat_date)+hm.get(currYear_end_date)----->"+hm.get("currYear_strat_date")+hm.get("currYear_end_date"));

					s = hm.entrySet();
			it = s.iterator();
			while(it.hasNext()){
				me = (Entry) it.next();
				me.g
			}
			 	
			flag = validateClient(email, token);
			if(flag){
				//			if(connection == null || connection.isClosed()){
				connection = DatabaseUtil.getConnection();
				//			}
				if (!rm_mobile.equals("") && rm_mobile.length() == 10 &&  rm_mobile.matches(regex1)) {

					if(!ucc.equals("") && ucc.matches(regex1) && ucc.length()>=3 && ucc.length()<=15){
						query = "select custid,ucc, sum(value_of_transaction) as total_of_value_Of_transaction, count(value_of_transaction) as count_of_transaction, type_of_transaction,count(supported_by_billOfEntry) as count_of_billOfEntry from user09768.corp_import_summary where rm_mobile = '"+rm_mobile+"' and ucc ='"+ucc+"' and supported_by_billOfEntry ='Y'  and (transaction_date between '"+hm.get("currYear_strat_date")+"' and '"+hm.get("currYear_end_date")+"') group by custid, ucc, type_of_transaction";
						statement = connection.createStatement();
						LOGGER.info("quer---REMOVE-------------------y=--------------------------"+query);
						rs = statement.executeQuery(query);
						while (rs.next()) {
							JSONObject jobj = new JSONObject();

							if(count==0){
								JSONObject yearObj = new JSONObject();
								yearObj.put("Year", "Current Finacial Year");
								jarray.add(successObj);
								jarray.add(yearObj);
								count++;
							}

							jobj.put("cust_id", rs.getString("custid"));
							jobj.put("ucc", rs.getString("ucc"));
							jobj.put("total_of_value_of_transactions", rs.getString("total_of_value_Of_transaction"));
							jobj.put("count_of_transactions", rs.getString("count_of_transaction"));
							jobj.put("count_of_bill_of_entry", rs.getString("count_of_billOfEntry"));
							jarray.add(jobj);
						}

						if(jarray.size() == 0){
							LOGGER.info("Inside getCorpImportSummaryAtUCCLevel(..) method ---> NO record Found");
							errjobj = commonmethod.getJsonStatus(503, "No Record Found", "NO Record Found");
							jarray.add(errjobj);
						}
						count=0;
						query = "select custid,ucc, sum(value_of_transaction) as total_of_value_Of_transaction, count(value_of_transaction) as count_of_transaction, type_of_transaction,count(supported_by_billOfEntry) as count_of_billOfEntry from user09768.corp_import_summary where rm_mobile = '"+rm_mobile+"' and ucc ='"+ucc+"' and supported_by_billOfEntry ='Y'  and (transaction_date between '"+hm.get("prevYear_start_date")+"' and '"+hm.get("prevYear_end_date")+"') group by custid, ucc, type_of_transaction";
						statement = connection.createStatement();
						LOGGER.info("quer---REMOVE-------------------y=--------------------------"+query);
						rs = statement.executeQuery(query);
						while (rs.next()) {
							JSONObject jobj = new JSONObject();

							if(count==0){
								JSONObject yearObj = new JSONObject();
								yearObj.put("Year", "Previous Finacial Year");
								jarray.add(successObj);
								jarray.add(yearObj);
								count++;
							}

							jobj.put("cust_id", rs.getString("custid"));
							jobj.put("ucc", rs.getString("ucc"));
							jobj.put("total_of_value_of_transactions", rs.getString("total_of_value_Of_transaction"));
							jobj.put("count_of_transactions", rs.getString("count_of_transaction"));
							jobj.put("count_of_bill_of_entry", rs.getString("count_of_billOfEntry"));
							jarray.add(jobj);
						}

						count=0;
						if(jarray.size() == 0){
							LOGGER.info("Inside getCorpImportSummaryAtUCCLevel(..) method ---> NO record Found");
							errjobj = commonmethod.getJsonStatus(503, "No Record Found", "NO Record Found");
							jarray.add(errjobj);
						}
					}
					else{
						//error for custid  blank
						LOGGER.info("Inside getCorpImportSummaryAtUCCLevel(..) method ---> ucc should be valid 3 to 15 digit number");
						errjobj = commonmethod.getJsonStatus(400, "Bad request.", "ucc should be valid 3 to 15 digit number");
						jarray.add(errjobj);
					}

				}
				else{
					//error for mobile no is not a valid number
					LOGGER.info("Inside getCorpImportSummaryAtUCCLevel(..) method ---> RM Mobile number should be valid 10 digit number");
					errjobj = commonmethod.getJsonStatus(400, "Bad request.", "RM Mobile number should be valid 10 digit number");
					jarray.add(errjobj);
				}
			}
			else{
				LOGGER.info("Inside getCorpImportSummary(..) method ---> ");
				errjobj = commonmethod.getJsonStatus(401, "User Not Authorized", "Access Denied");
				jarray.add(errjobj);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			//error for sql exception
			errjobj = commonmethod.getJsonStatus(501, "Database connectivity issues or timeouts", "Database Error,Please try after some time");
			jarray.add(errjobj);
		}
		catch(Exception e){
			e.printStackTrace();
			errjobj = commonmethod.getJsonStatus(402, "Error in processing", "Error while processing request");
			jarray.add(errjobj);
		}
		finally{
		try{
			statement.close();
			rs.close();
			connection.close();
			rs = null;
			statement = null;
			connection = null;
			count = 0;
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
		result = jarray.toString();
		return result;

	}*/

}
