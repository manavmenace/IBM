package appathon.bluemix.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Logger;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@Path("/icici")
public class GeneralInsurance_RestCall {
	private static final Logger log = Logger.getLogger(GeneralInsurance_RestCall.class.getName());

	public GeneralInsurance_RestCall() throws JSONException {
		gobj.put("code", 200);
		count = 0;
	}

	boolean flag;
	public int count = 0;
	JSONObject gobj = new JSONObject();
	DatabaseUtil dbUtil = new DatabaseUtil();

	@GET
	@Path("/test")
	@Produces
	public String tm() {
		return "Ok";
	}

	// --/getQuickQuote?custName=?&mobileNo=?&emailId=?&manufacturer=?&model=?&address=?&rto=?&regDt=?

	/*
	 * Mobile_Number Email_ID Product_Type RTO_LOCATION Registration_Date
	 * Manufacturer Model Current_Location_India Travel_Location
	 * Immigrant_Visa_Status Leaving_Date Trip_Days Return_Date Age_Group
	 * Sum_Insured
	 */

	// http://generalinsurance.mybluemix.net/banking/icicibank_general_insurance/getQuickQuote?
	// client_id=test@abc.com&token=f5316a5e35a4&custName=Amar&mobileNo=1234567890&emailId=ama@gmail.com
	@GET
	@Path("/getQuickQuote")
	@Produces
	public String getQuickQuote(@QueryParam("client_id") String client_id, @QueryParam("token") String token,
			@QueryParam("custName") String custName, @QueryParam("mobileNo") String mobileNo,
			@QueryParam("emailId") String emailId, @QueryParam("manufacturer") String manufacturer,
			@QueryParam("model") String model, @QueryParam("address") String address, @QueryParam("rto") String rto,
			@QueryParam("regDt") String regDt) throws JSONException {
		String returnValue = "";
		String mobileRegex = "[0-9]+";
		String emailRegex = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$";
		log.info("###-------------- Get Quick Quotes ------------###");

		log.info("Client_id : " + client_id);
		log.info("Token : " + token);
		GeneralInsuranceDAO dao = new GeneralInsuranceDAO();
		CommonClass commonClass = new CommonClass();
		JSONObject jsonObject = new JSONObject();
		JSONArray jsonArray = new JSONArray();
		Connection connection = null;
		try {
			if (connection == null || connection.isClosed()) {
				System.out.println("Inside getMessage connection open : " + connection);
				connection = dbUtil.getConnection();
			}
			flag = dao.validateClient(client_id, token, "L_getQuickQuote", connection);

			// validate client
			if (flag) {
				// validate mobile_no
				if (!mobileNo.equals("")) {
					if (mobileNo.length() == 10) {
						if (mobileNo.matches(mobileRegex)) {

							// validate email_id
							if (emailId.matches(emailRegex)) {
								try {

									Double premium_amt, ex_showroom_price = 0.0;
									Double idv = 0.0;

									premium_amt = dao.getPremiumAmt(manufacturer, model, connection);
									if (premium_amt > 0) {
										ex_showroom_price = premium_amt * 20;
										idv = (ex_showroom_price) - (0.05 * ex_showroom_price);

										dao.saveQuickQuotes(custName, mobileNo, emailId, manufacturer, model,
												premium_amt, address, rto, regDt, ex_showroom_price, idv, connection);
										log.info("After Insert premium_amt : " + premium_amt);
										if (count == 0) {
											jsonArray.put(gobj);
										}
										jsonObject.put("cust_name", custName);
										jsonObject.put("mobile_no", mobileNo);
										jsonObject.put("email_id", emailId);
										jsonObject.put("manufacture", manufacturer);
										jsonObject.put("model", model);
										jsonObject.put("premium", premium_amt);
										jsonObject.put("address", address);
										jsonObject.put("rto", rto);
										jsonObject.put("regDt", regDt);
										jsonObject.put("ex_showroom_price", ex_showroom_price);
										jsonObject.put("idv", idv);

										jsonArray.put(jsonObject);
										returnValue = jsonArray.toString();
									} else {
										returnValue = commonClass.getJsonErr(402, "Invalid Input",
												"Manufacture or Model is not correct");
									}
								} catch (SQLException e) {
									log.info(e.getMessage());
									returnValue = commonClass.getJsonErr(501,
											"Database connectivity issue or Timeouts.",
											"Database Error. Please try after some time.");
									jsonArray.put(returnValue);
								} catch (Exception e) {
									log.info(e.getMessage());
									returnValue = commonClass.getJsonErr(402, "Error in processing.",
											"Currency Pairs value couldn't be fetched.");
									jsonArray.put(returnValue);
								}

							} else {
								jsonArray.put("Invalid email Id");
								returnValue = commonClass.getJsonErr(401, "Invalid email Id", "Bad Request");
							}

						} else {
							jsonArray.put("Moblie Number should contain only Numbers");
							returnValue = commonClass.getJsonErr(401, "Moblie Number should contain only Numbers",
									"Bad Request");
						}
					} else {
						jsonArray.put("Mobile Number should be 10 digits");
						returnValue = commonClass.getJsonErr(401, "Mobile Number should be 10 digits", "Bad Request");
					}
				} else {
					// jsonArray.add("Mobile Number can not be Empty");
					returnValue = commonClass.getJsonErr(401, "Mobile Number can not be Empty", "Bad Request");
				}
			} else {
				log.info("Token Verification Failed.");
				returnValue = commonClass.getJsonErr(401, "User Not Authorized", "Access Denied");
				// jarray.add(returnMessage);
			}
		} catch (Exception e) {
			log.info("Inside Exception");
			returnValue = commonClass.getJsonErr(401, "User Not Authorized", "Access Denied");
			e.printStackTrace();
		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return returnValue;
	}

	// --/getRenewalNotice?mobileNo=?&emailId=?
	@GET
	@Path("/getRenewalNotice")
	@Produces
	public String getRenewalNotice(@QueryParam("client_id") String client_id, @QueryParam("token") String token,
			@QueryParam("mobileNo") String mobileNo, @QueryParam("emailId") String emailId) throws JSONException {

		String returnValue = "";
		String mobileRegex = "[0-9]+";
		String emailRegex = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$";

		CommonClass commonClass = new CommonClass();
		GeneralInsuranceDAO dao = new GeneralInsuranceDAO();
		JSONArray jsonArray = new JSONArray();
		Connection connection = null;
		try {
			if (connection == null || connection.isClosed()) {
				System.out.println("Inside getMessage connection open : " + connection);
				connection = dbUtil.getConnection();
			}

			flag = dao.validateClient(client_id, token, "L_getRenewalNotice", connection);

			// validate client
			if (flag) {

				// validate mobile_no
				if (!mobileNo.equals("")) {
					if (mobileNo.length() == 10) {
						if (mobileNo.matches(mobileRegex)) {

							// validate email_id
							if (emailId.matches(emailRegex)) {

								try {
									jsonArray = dao.getRenewalNotice(mobileNo, emailId, connection);
									System.out.println("---------Renual-JsonArray :" + jsonArray.toString());
									if (jsonArray.toString().length() > 50) {
										returnValue = jsonArray.toString();
									} else {
										returnValue = commonClass.getJsonErr(402, "No records available.",
												"No Records available");
									}
								} catch (SQLException e) {
									log.info(e.getMessage());
									returnValue = commonClass.getJsonErr(501,
											"Database connectivity issue or Timeouts.",
											"Database Error. Please try after some time.");
								} catch (Exception e) {
									log.info(e.getMessage());
									returnValue = commonClass.getJsonErr(402, "Error in processing.",
											"Renewal Data cannot be fetched.");
								}

							} else {
								// jsonArray.add("Invalid email Id");
								// returnValue = jsonArray.toString();
								returnValue = commonClass.getJsonErr(400, "Bad Request", "Invalid email Id");
							}

						} else {
							// jsonArray.add("Moblie Number should contain only
							// Numbers");
							// returnValue = jsonArray.toString();
							returnValue = commonClass.getJsonErr(400, "Bad Request",
									"Moblie Number should contain only Numbers");
						}
					} else {
						returnValue = commonClass.getJsonErr(400, "Bad Request", "Mobile Number should be 10 digits");
						// jsonArray.add("Mobile Number should be 10 digits");
						// returnValue = jsonArray.toString();
					}
				} else {
					// jsonArray.add("Mobile Number can not be Empty");
					returnValue = commonClass.getJsonErr(400, "Bad Request", "Mobile Number can not be Empty");
					// returnValue = jsonArray.toString();
				}
			} else {
				log.info("Token Verification Failed.");
				returnValue = commonClass.getJsonErr(401, "User Not Authorized", "Access Denied");
				// jarray.add(returnMessage);
			}
		} catch (Exception e) {
			log.info("Inside Exception");
			returnValue = commonClass.getJsonErr(401, "User Not Authorized", "Access Denied");
			e.printStackTrace();
		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return returnValue;
	}

	@GET
	@Path("/getCustomerDtls")
	@Produces
	public String getCustomerDtls(@QueryParam("client_id") String client_id, @QueryParam("token") String token,
			@QueryParam("mobileNo") String mobileNo, @QueryParam("emailId") String emailId) throws JSONException {
		String returnValue = "";
		String mobileRegex = "[0-9]+";
		String emailRegex = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$";

		CommonClass commonClass = new CommonClass();
		GeneralInsuranceDAO dao = new GeneralInsuranceDAO();
		JSONArray jsonArray = new JSONArray();
		Connection connection = null;
		try {
			if (connection == null || connection.isClosed()) {
				System.out.println("Inside getMessage connection open : " + connection);
				connection = dbUtil.getConnection();
			}

			flag = dao.validateClient(client_id, token, "L_getCustomerDtls", connection);

			// validate client
			if (flag) {
				// validate mobile_no
				if (!mobileNo.equals("")) {
					if (mobileNo.length() == 10) {
						if (mobileNo.matches(mobileRegex)) {

							// validate email_id
							if (emailId.matches(emailRegex)) {

								try {

									jsonArray = dao.getCustomerDtls(mobileNo, emailId, connection);
									System.out.println("---------jsonArray " + jsonArray.toString());
									if (jsonArray.toString().length() > 50) {
										returnValue = jsonArray.toString();
									} else {
										returnValue = commonClass.getJsonErr(402, "No records available.",
												"No Records available");
									}
								} catch (SQLException e) {
									log.info(e.getMessage());
									returnValue = commonClass.getJsonErr(501,
											"Database connectivity issue or Timeouts.",
											"Database Error. Please try after some time.");
								} catch (Exception e) {
									log.info(e.getMessage());
									returnValue = commonClass.getJsonErr(402, "Error in processing.",
											"Renewal Data cannot be fetched.");
								}

							} else {
								// jsonArray.add("Invalid email Id");
								// returnValue = jsonArray.toString();
								returnValue = commonClass.getJsonErr(400, "Bad Request", "Invalid email Id");
							}

						} else {
							// jsonArray.add("Moblie Number should contain only
							// Numbers");
							// returnValue = jsonArray.toString();
							returnValue = commonClass.getJsonErr(400, "Bad Request",
									"Moblie Number should contain only Numbers");
						}
					} else {
						// jsonArray.add("Mobile Number should be 10 digits");
						// returnValue = jsonArray.toString();
						returnValue = commonClass.getJsonErr(400, "Bad Request", "Mobile Number should be 10 digits");
					}
				} else {
					// jsonArray.add("Mobile Number can not be Empty");
					// returnValue = jsonArray.toString();
					returnValue = commonClass.getJsonErr(400, "Bad Request", "Mobile Number can not be Empty");
				}
			} else {
				log.info("Token Verification Failed.");
				returnValue = commonClass.getJsonErr(401, "User Not Authorized", "Access Denied");

				// jarray.add(returnMessage);
			}
		} catch (Exception e) {
			log.info("Inside Exception");
			returnValue = commonClass.getJsonErr(401, "User Not Authorized", "Access Denied");
			e.printStackTrace();
		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return returnValue;
	}

}
